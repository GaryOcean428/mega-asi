
import { Suspense } from 'react'
import { ModelsDashboard } from '@/components/models/models-dashboard'
import { SystemHeader } from '@/components/system-header'
import { LoadingSpinner } from '@/components/ui/loading-spinner'

export default function ModelsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950">
      <SystemHeader />
      
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <Suspense fallback={<LoadingSpinner />}>
          <ModelsDashboard />
        </Suspense>
      </main>
    </div>
  )
}

export const metadata = {
  title: 'AI Models - Modern Agent Framework',
  description: 'Explore all available AI models on the platform',
}
