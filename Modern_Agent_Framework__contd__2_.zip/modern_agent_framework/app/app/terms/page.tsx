
export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950 p-8">
      <div className="container mx-auto max-w-4xl">
        <div className="bg-black/40 rounded-lg p-8 border border-gray-800">
          <h1 className="text-3xl font-bold text-white mb-6">Terms of Service</h1>
          
          <div className="prose prose-invert max-w-none">
            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">1. Acceptance of Terms</h2>
            <p className="text-gray-300 mb-4">
              By accessing and using Modern Agent Framework, you accept and agree to be bound by the terms and provision of this agreement.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">2. Use License</h2>
            <p className="text-gray-300 mb-4">
              Permission is granted to temporarily download one copy of Modern Agent Framework per device for personal, non-commercial transitory viewing only.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">3. Disclaimer</h2>
            <p className="text-gray-300 mb-4">
              The materials on Modern Agent Framework are provided on an 'as is' basis. Modern Agent Framework makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">4. Limitations</h2>
            <p className="text-gray-300 mb-4">
              In no event shall Modern Agent Framework or its suppliers be liable for any damages arising out of the use or inability to use the materials on Modern Agent Framework.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">5. Contact Information</h2>
            <p className="text-gray-300 mb-4">
              If you have any questions about these Terms of Service, please contact us through our support channels.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
