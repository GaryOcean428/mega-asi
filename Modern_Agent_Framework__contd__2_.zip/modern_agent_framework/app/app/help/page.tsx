
'use client'

import { SystemHeader } from '@/components/system-header'
import { HelpSystem } from '@/components/help/help-system'

export default function HelpPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950">
      <SystemHeader />
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <HelpSystem />
      </main>
    </div>
  )
}
