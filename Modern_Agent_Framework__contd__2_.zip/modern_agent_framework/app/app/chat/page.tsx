
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { ChatRoom } from '@/components/chat/chat-room'
import { SystemHeader } from '@/components/system-header'
import { 
  MessageSquare, 
  Plus, 
  Search,
  Users,
  Bot,
  Hash,
  Lock
} from 'lucide-react'

interface ChatRoomData {
  id: string
  name: string
  description?: string | null
  type: string
  isPrivate: boolean
  _count: {
    participants: number
    messages: number
  }
  messages: Array<{
    content: any
    createdAt: string
    userSender?: { name?: string | null }
    agentSender?: { name: string }
  }>
  participants: Array<{
    lastReadAt?: string | null
  }>
}

export default function ChatPage() {
  const { data: session, status } = useSession() || {}
  const router = useRouter()
  const [chatRooms, setChatRooms] = useState<ChatRoomData[]>([])
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')

  // For demo purposes, we'll use a default workspace
  const workspaceId = 'default-workspace'

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }
    
    if (session?.user) {
      loadChatRooms()
    }
  }, [session, status])

  const loadChatRooms = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/chat/rooms?workspaceId=${workspaceId}`)
      if (response.ok) {
        const data = await response.json()
        setChatRooms(data.chatRooms || [])
        
        // Auto-select first room if available
        if (data.chatRooms?.length > 0 && !selectedRoom) {
          setSelectedRoom(data.chatRooms[0].id)
        }
      }
    } catch (error) {
      console.error('Failed to load chat rooms:', error)
    } finally {
      setLoading(false)
    }
  }

  const createDemoRoom = async () => {
    try {
      // First, let's create a demo workspace if it doesn't exist
      const workspaceResponse = await fetch('/api/workspaces', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Default Workspace',
          slug: 'default-workspace'
        })
      })

      // Create a demo chat room
      const response = await fetch('/api/chat/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'General Chat',
          description: 'A general chat room for team collaboration',
          workspaceId: workspaceId,
          type: 'GENERAL'
        })
      })

      if (response.ok) {
        await loadChatRooms()
      }
    } catch (error) {
      console.error('Failed to create demo room:', error)
    }
  }

  const filteredRooms = chatRooms.filter(room =>
    room.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getRoomIcon = (type: string, isPrivate: boolean) => {
    if (isPrivate) return <Lock className="h-4 w-4" />
    if (type === 'TASK_FOCUSED') return <Bot className="h-4 w-4" />
    return <Hash className="h-4 w-4" />
  }

  const getLastMessage = (room: ChatRoomData) => {
    if (room.messages.length === 0) return 'No messages yet'
    
    const lastMessage = room.messages[0]
    const senderName = lastMessage.userSender?.name || lastMessage.agentSender?.name || 'Someone'
    const content = typeof lastMessage.content === 'string' 
      ? lastMessage.content 
      : lastMessage.content?.text || 'Message'
    
    return `${senderName}: ${content.substring(0, 50)}${content.length > 50 ? '...' : ''}`
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950">
        <div className="flex items-center justify-center h-screen">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950">
      <SystemHeader />
      
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-12rem)]">
          {/* Chat rooms sidebar */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    Chat Rooms
                  </CardTitle>
                  <Button size="sm" variant="outline" onClick={createDemoRoom}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search rooms..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-8"
                  />
                </div>
              </CardHeader>
              
              <CardContent className="p-0">
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                  </div>
                ) : filteredRooms.length === 0 ? (
                  <div className="p-6 text-center text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p className="text-sm mb-4">No chat rooms found</p>
                    <Button onClick={createDemoRoom} size="sm">
                      Create Demo Room
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {filteredRooms.map((room) => (
                      <div
                        key={room.id}
                        className={`p-3 m-2 rounded-lg cursor-pointer transition-colors ${
                          selectedRoom === room.id 
                            ? 'bg-primary text-primary-foreground' 
                            : 'hover:bg-muted'
                        }`}
                        onClick={() => setSelectedRoom(room.id)}
                      >
                        <div className="flex items-start gap-2">
                          {getRoomIcon(room.type, room.isPrivate)}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <h4 className="text-sm font-medium truncate">
                                {room.name}
                              </h4>
                              <div className="flex items-center gap-1">
                                <Users className="h-3 w-3" />
                                <span className="text-xs">{room._count.participants}</span>
                              </div>
                            </div>
                            
                            <p className="text-xs opacity-75 truncate">
                              {getLastMessage(room)}
                            </p>
                            
                            <div className="flex items-center justify-between mt-2">
                              <Badge variant="secondary" className="text-xs">
                                {room.type.toLowerCase()}
                              </Badge>
                              {room._count.messages > 0 && (
                                <span className="text-xs opacity-60">
                                  {room._count.messages} messages
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Chat room content */}
          <div className="lg:col-span-3">
            {selectedRoom ? (
              <Card className="h-full">
                <ChatRoom 
                  roomId={selectedRoom} 
                  workspaceId={workspaceId}
                  className="h-full"
                />
              </Card>
            ) : (
              <Card className="h-full">
                <CardContent className="h-full flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <MessageSquare className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-medium mb-2">Welcome to Agent Chat</h3>
                    <p className="text-sm mb-4">
                      Select a chat room to start collaborating with agents and team members.
                    </p>
                    <div className="space-y-2 text-xs">
                      <p>✨ Real-time messaging with WebSocket support</p>
                      <p>🤖 Multi-agent collaboration</p>
                      <p>🧵 Threaded conversations</p>
                      <p>⚡ Live typing indicators</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
