
'use client'

import { Suspense } from 'react'
import { AgentDashboard } from '@/components/agent-dashboard'
import { SystemHeader } from '@/components/system-header'
import { LoadingSpinner } from '@/components/ui/loading-spinner'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MessageSquare, Brain, Zap, Users, Sparkles } from 'lucide-react'
import Link from 'next/link'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950">
      <SystemHeader />
      
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent mb-4">
            Modern Agent Framework
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-8">
            Create, manage, and orchestrate autonomous agents with advanced AI capabilities and collaborative workflows.
          </p>
        </div>

        {/* Featured: Intelligent Chat */}
        <div className="mb-12">
          <Card className="bg-gradient-to-r from-purple-900/40 via-blue-900/40 to-purple-900/40 border-purple-500/30 overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="p-3 bg-purple-500/20 rounded-xl">
                      <Brain className="h-10 w-10 text-purple-400" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-bold text-white flex items-center">
                        Intelligent Chat Orchestrator
                        <Sparkles className="h-6 w-6 ml-2 text-yellow-400" />
                      </h2>
                      <p className="text-lg text-purple-300">Revolutionary chat interface that understands your intent</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                    <div className="text-center">
                      <div className="p-3 bg-blue-500/20 rounded-lg mx-auto w-fit mb-2">
                        <MessageSquare className="h-8 w-8 text-blue-400" />
                      </div>
                      <div className="text-sm font-medium text-blue-300">Auto Agent Creation</div>
                      <div className="text-xs text-gray-400">Just describe what you need</div>
                    </div>
                    <div className="text-center">
                      <div className="p-3 bg-green-500/20 rounded-lg mx-auto w-fit mb-2">
                        <Zap className="h-8 w-8 text-green-400" />
                      </div>
                      <div className="text-sm font-medium text-green-300">MCP Integration</div>
                      <div className="text-xs text-gray-400">One-click tool installation</div>
                    </div>
                    <div className="text-center">
                      <div className="p-3 bg-purple-500/20 rounded-lg mx-auto w-fit mb-2">
                        <Users className="h-8 w-8 text-purple-400" />
                      </div>
                      <div className="text-sm font-medium text-purple-300">Collaboration Setup</div>
                      <div className="text-xs text-gray-400">Multi-agent workflows</div>
                    </div>
                    <div className="text-center">
                      <div className="p-3 bg-yellow-500/20 rounded-lg mx-auto w-fit mb-2">
                        <Brain className="h-8 w-8 text-yellow-400" />
                      </div>
                      <div className="text-sm font-medium text-yellow-300">AI Intent Recognition</div>
                      <div className="text-xs text-gray-400">Understands your goals</div>
                    </div>
                  </div>
                  
                  <div className="bg-black/30 rounded-lg p-4 mb-6 border border-gray-700">
                    <p className="text-gray-300 mb-2">
                      <strong>Try saying:</strong>
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                      <div className="bg-gray-800/50 rounded px-3 py-2 text-blue-300">
                        "I need a data analyst agent"
                      </div>
                      <div className="bg-gray-800/50 rounded px-3 py-2 text-green-300">
                        "Add web search capability"
                      </div>
                      <div className="bg-gray-800/50 rounded px-3 py-2 text-purple-300">
                        "Set up a research team"
                      </div>
                      <div className="bg-gray-800/50 rounded px-3 py-2 text-yellow-300">
                        "Automate my daily reports"
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <Link href="/chat/intelligent">
                      <Button 
                        size="lg" 
                        className="bg-purple-600 hover:bg-purple-700 text-lg px-8"
                      >
                        <MessageSquare className="h-5 w-5 mr-2" />
                        Try Intelligent Chat
                      </Button>
                    </Link>
                    <Button size="lg" variant="outline" className="text-lg" onClick={() => alert('Demo video coming soon!')}>
                      Watch Demo
                    </Button>
                  </div>
                </div>
                
                <div className="hidden lg:block ml-8">
                  <div className="relative">
                    <div className="w-80 h-64 bg-black/40 rounded-xl border border-purple-500/30 p-6 shadow-2xl">
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                            <MessageSquare className="h-4 w-4 text-white" />
                          </div>
                          <div className="h-4 bg-gray-600 rounded flex-1"></div>
                        </div>
                        <div className="flex items-center space-x-3 justify-end">
                          <div className="h-4 bg-purple-500 rounded w-40"></div>
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                            <Brain className="h-4 w-4 text-white" />
                          </div>
                        </div>
                        <div className="bg-yellow-500/20 border border-yellow-500/40 rounded-lg p-3 animate-pulse">
                          <div className="text-xs text-yellow-300 mb-1">💡 AI Suggestion</div>
                          <div className="text-xs text-yellow-200">I can create a data analyst agent for you!</div>
                          <div className="flex space-x-2 mt-2">
                            <div className="bg-blue-500/30 rounded px-2 py-1 text-xs text-blue-300">Quick Setup</div>
                            <div className="bg-green-500/30 rounded px-2 py-1 text-xs text-green-300">Install Tools</div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <div className="h-8 bg-gray-700 rounded flex-1"></div>
                          <div className="w-8 h-8 bg-blue-500 rounded"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Suspense fallback={<LoadingSpinner />}>
          <AgentDashboard />
        </Suspense>
      </main>
    </div>
  )
}
