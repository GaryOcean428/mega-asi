
/**
 * MCP Marketplace Page - Browse and install MCPs
 */

'use client'

import React, { useState } from 'react'
import { useSession } from 'next-auth/react'
import { MCPMarketplace } from '@/components/mcp/mcp-marketplace'
import { IntelligentChatIntegration } from '@/components/mcp/intelligent-chat-integration'
import { MCPManagementDashboard } from '@/components/mcp/mcp-management-dashboard'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

export default function MCPMarketplacePage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState('marketplace')

  const handleMCPInstall = (mcpId: string) => {
    // Handle MCP installation success
    console.log('MCP installed:', mcpId)
    
    // Switch to management tab to show the installed MCP
    setActiveTab('management')
  }

  const handleMCPConfigure = (installationId: string) => {
    // Handle MCP configuration
    console.log('Configure MCP:', installationId)
    
    // Switch to management tab
    setActiveTab('management')
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            MCP Platform
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Discover, install, and manage Model Context Protocol servers for your AI agents
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
                <TabsTrigger value="management">My MCPs</TabsTrigger>
              </TabsList>
              
              <TabsContent value="marketplace" className="mt-6">
                <MCPMarketplace
                  onInstall={(mcp) => handleMCPInstall(mcp.id)}
                />
              </TabsContent>
              
              <TabsContent value="management" className="mt-6">
                <MCPManagementDashboard />
              </TabsContent>
            </Tabs>
          </div>

          {/* Intelligent Assistant Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8">
              <IntelligentChatIntegration
                onMCPInstall={handleMCPInstall}
                onMCPConfigure={handleMCPConfigure}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
