
"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, ArrowLeft, RefreshCw, Mail, Github } from "lucide-react";
import { FcGoogle } from "react-icons/fc";

function AuthErrorContent() {
  const searchParams = useSearchParams();
  const error = searchParams.get("error");

  const getErrorMessage = (errorType: string | null) => {
    switch (errorType) {
      case "Configuration":
        return {
          title: "Server Configuration Error",
          description: "There is a problem with the server configuration. Please contact support.",
          suggestion: "This is likely a temporary issue. Please try again later.",
        };
      case "AccessDenied":
        return {
          title: "Access Denied",
          description: "You do not have permission to sign in with this account.",
          suggestion: "Please contact your administrator or try a different account.",
        };
      case "Verification":
        return {
          title: "Unable to Verify",
          description: "The verification token has expired or is invalid.",
          suggestion: "Please try signing in again to get a fresh verification link.",
        };
      case "Default":
        return {
          title: "Authentication Error",
          description: "An unexpected error occurred during authentication.",
          suggestion: "Please try signing in again. If the problem persists, contact support.",
        };
      case "CredentialsSignin":
        return {
          title: "Invalid Credentials",
          description: "The email or password you entered is incorrect.",
          suggestion: "Please check your credentials and try again, or reset your password.",
        };
      case "EmailCreateAccount":
        return {
          title: "Account Creation Failed",
          description: "Unable to create an account with this email address.",
          suggestion: "This email might already be in use or there was a server error.",
        };
      case "OAuthSignin":
      case "OAuthCallback":
      case "OAuthCreateAccount":
        return {
          title: "OAuth Authentication Failed",
          description: "There was a problem signing in with your selected provider.",
          suggestion: "Please try again or use a different sign-in method.",
        };
      case "EmailSignin":
        return {
          title: "Email Sign-in Failed",
          description: "Unable to send sign-in email.",
          suggestion: "Please check your email address and try again.",
        };
      case "OAuthAccountNotLinked":
        return {
          title: "Account Not Linked",
          description: "This email is already associated with another account.",
          suggestion: "Please sign in using your original method, or link your accounts in profile settings.",
        };
      default:
        return {
          title: "Authentication Error",
          description: "Something went wrong during the authentication process.",
          suggestion: "Please try again. If the issue continues, contact our support team.",
        };
    }
  };

  const errorInfo = getErrorMessage(error);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 via-white to-orange-50 p-4">
      <Card className="w-full max-w-md shadow-xl border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <AlertTriangle className="h-8 w-8 text-red-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            {errorInfo.title}
          </CardTitle>
          <CardDescription className="text-gray-600">
            {errorInfo.description}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <Alert className="border-amber-200 bg-amber-50">
            <AlertDescription className="text-amber-800 text-sm">
              {errorInfo.suggestion}
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <Link href="/auth/signin">
              <Button className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold">
                <Mail className="mr-2 h-4 w-4" />
                Try Email Sign-in
              </Button>
            </Link>

            <div className="grid grid-cols-2 gap-3">
              <Link href="/auth/signin">
                <Button variant="outline" className="w-full h-11 border-gray-300 hover:bg-gray-50">
                  <FcGoogle className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="/auth/signin">
                <Button variant="outline" className="w-full h-11 border-gray-300 hover:bg-gray-50">
                  <Github className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>

          {(error === "CredentialsSignin" || error === "EmailSignin") && (
            <div className="text-center">
              <Link
                href="/auth/forgot-password"
                className="text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors"
              >
                Forgot your password?
              </Link>
            </div>
          )}

          <div className="pt-4 border-t border-gray-100 flex justify-between">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-800">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Home
              </Button>
            </Link>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => window.location.reload()}
              className="text-gray-600 hover:text-gray-800"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Retry
            </Button>
          </div>

          {error && (
            <div className="text-center">
              <details className="text-xs text-gray-500">
                <summary className="cursor-pointer hover:text-gray-700">Error Details</summary>
                <code className="mt-2 block p-2 bg-gray-100 rounded text-left">
                  Error Code: {error}
                </code>
              </details>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function AuthError() {
  return (
    <Suspense 
      fallback={
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      }
    >
      <AuthErrorContent />
    </Suspense>
  );
}
