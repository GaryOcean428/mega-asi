
'use client'

import { OnboardingFlow } from '@/components/onboarding/onboarding-flow'
import { useRouter } from 'next/navigation'
import { useUserPreferences } from '@/lib/user-preferences'

export default function OnboardingPage() {
  const router = useRouter()
  const { markOnboardingComplete, skipTutorial } = useUserPreferences()

  const handleComplete = () => {
    markOnboardingComplete()
    router.push('/chat/intelligent')
  }

  const handleSkip = () => {
    skipTutorial()
    router.push('/')
  }

  return (
    <OnboardingFlow 
      onComplete={handleComplete}
      onSkip={handleSkip}
    />
  )
}
