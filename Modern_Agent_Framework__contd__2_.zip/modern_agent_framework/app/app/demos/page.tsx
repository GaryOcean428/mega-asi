
'use client'

import { SystemHeader } from '@/components/system-header'
import { DemoScenarios } from '@/components/demo/demo-scenarios'

export default function DemosPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950">
      <SystemHeader />
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <DemoScenarios />
      </main>
    </div>
  )
}
