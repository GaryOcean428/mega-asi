
import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import { AgentEngine } from '@/lib/agent-engine'
import { llmClient } from '@/lib/llm-client'
import { CollaborationType, CollaborationStatus, AgentStatus } from '@prisma/client'

const prisma = new PrismaClient()

export const dynamic = 'force-dynamic'

// POST /api/collaborations/[id]/execute - Execute collaboration
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { task, stream = true } = body

    if (!task || !task.title || !task.description) {
      return NextResponse.json(
        { error: 'Task with title and description is required' },
        { status: 400 }
      )
    }

    // Get collaboration details
    const collaboration = await prisma.collaboration.findUnique({
      where: { id: params.id }
    })

    if (!collaboration) {
      return NextResponse.json(
        { error: 'Collaboration not found' },
        { status: 404 }
      )
    }

    // Get participating agents
    const agents = await prisma.agent.findMany({
      where: { id: { in: collaboration.agentIds } }
    })

    if (agents.length === 0) {
      return NextResponse.json(
        { error: 'No active agents in collaboration' },
        { status: 400 }
      )
    }

    // Update collaboration status
    await prisma.collaboration.update({
      where: { id: params.id },
      data: { status: CollaborationStatus.ACTIVE }
    })

    if (!stream) {
      return await executeCollaborationNonStreaming(collaboration, agents, task)
    }

    // Streaming execution
    const responseStream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder()
        let collaborationResult = ''
        const agentOutputs: Array<{ agentName: string; agentRole: string; output: string; timestamp?: Date }> = []

        try {
          // Execute based on collaboration type
          if (collaboration.type === CollaborationType.SEQUENTIAL) {
            // Sequential execution - one agent after another
            for (let i = 0; i < agents.length; i++) {
              const agent = agents[i]
              
              // Update agent status
              await AgentEngine.updateAgentStatus(agent.id, AgentStatus.BUSY)

              const progressData = JSON.stringify({
                status: 'processing',
                message: `Agent ${agent.name} is working...`,
                currentAgent: agent.name,
                step: i + 1,
                totalSteps: agents.length
              })
              controller.enqueue(encoder.encode(`data: ${progressData}\n\n`))

              // Create prompt with previous outputs
              const messages = llmClient.createCollaborationPrompt(
                agents,
                task,
                agent,
                agentOutputs
              )

              let agentResponse = ''
              const streamGenerator = llmClient.streamComplete({
                messages,
                model: agent.model,
                temperature: 0.7
              })

              for await (const chunk of streamGenerator) {
                agentResponse += chunk
                
                const chunkData = JSON.stringify({
                  status: 'processing',
                  message: `${agent.name}: ${chunk}`,
                  agent: agent.name,
                  chunk
                })
                controller.enqueue(encoder.encode(`data: ${chunkData}\n\n`))
              }

              agentOutputs.push({
                agentName: agent.name,
                agentRole: agent.role,
                output: agentResponse,
                timestamp: new Date()
              })

              // Create message record
              await AgentEngine.createMessage({
                content: agentResponse,
                role: 'ASSISTANT',
                senderId: agent.id,
                isInternal: true,
                metadata: { 
                  collaborationId: params.id,
                  step: i + 1
                }
              })

              // Update agent status back to idle
              await AgentEngine.updateAgentStatus(agent.id, AgentStatus.IDLE)
            }

            collaborationResult = agentOutputs
              .map(output => `${output.agentName}:\n${output.output}`)
              .join('\n\n---\n\n')

          } else if (collaboration.type === CollaborationType.PARALLEL) {
            // Parallel execution - all agents work simultaneously
            const progressData = JSON.stringify({
              status: 'processing',
              message: 'All agents are working in parallel...',
              step: 1,
              totalSteps: 1
            })
            controller.enqueue(encoder.encode(`data: ${progressData}\n\n`))

            const promises = agents.map(async (agent) => {
              await AgentEngine.updateAgentStatus(agent.id, AgentStatus.BUSY)

              const messages = llmClient.createCollaborationPrompt(
                agents,
                task,
                agent
              )

              let agentResponse = ''
              const streamGenerator = llmClient.streamComplete({
                messages,
                model: agent.model,
                temperature: 0.7
              })

              for await (const chunk of streamGenerator) {
                agentResponse += chunk
                
                const chunkData = JSON.stringify({
                  status: 'processing',
                  message: `${agent.name}: ${chunk}`,
                  agent: agent.name,
                  chunk
                })
                controller.enqueue(encoder.encode(`data: ${chunkData}\n\n`))
              }

              // Create message record
              await AgentEngine.createMessage({
                content: agentResponse,
                role: 'ASSISTANT',
                senderId: agent.id,
                isInternal: true,
                metadata: { 
                  collaborationId: params.id
                }
              })

              await AgentEngine.updateAgentStatus(agent.id, AgentStatus.IDLE)

              return {
                agentName: agent.name,
                agentRole: agent.role,
                output: agentResponse,
                timestamp: new Date()
              }
            })

            const results = await Promise.all(promises)
            agentOutputs.push(...results)

            collaborationResult = agentOutputs
              .map(output => `${output.agentName}:\n${output.output}`)
              .join('\n\n---\n\n')
          }

          // Update collaboration with result
          await prisma.collaboration.update({
            where: { id: params.id },
            data: {
              status: CollaborationStatus.COMPLETED,
              result: collaborationResult,
              currentStep: collaboration.totalSteps || agents.length
            }
          })

          // Send completion data
          const completionData = JSON.stringify({
            status: 'completed',
            result: {
              collaborationResult,
              agentOutputs,
              totalSteps: agents.length,
              completedAt: new Date()
            }
          })
          controller.enqueue(encoder.encode(`data: ${completionData}\n\n`))

        } catch (error) {
          console.error('Collaboration execution error:', error)

          // Update collaboration status to failed
          await prisma.collaboration.update({
            where: { id: params.id },
            data: { 
              status: CollaborationStatus.FAILED,
              metadata: { 
                ...(collaboration.metadata as any || {}),
                error: error instanceof Error ? error.message : 'Unknown error'
              }
            }
          })

          const errorData = JSON.stringify({
            status: 'error',
            message: error instanceof Error ? error.message : 'Collaboration execution failed'
          })
          controller.enqueue(encoder.encode(`data: ${errorData}\n\n`))
        } finally {
          controller.close()
        }
      }
    })

    return new Response(responseStream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
      }
    })

  } catch (error) {
    console.error('Execute collaboration error:', error)
    return NextResponse.json(
      { error: 'Failed to execute collaboration' },
      { status: 500 }
    )
  }
}

async function executeCollaborationNonStreaming(
  collaboration: any,
  agents: any[],
  task: any
) {
  // Similar logic but without streaming - simplified for brevity
  const agentOutputs: Array<{ agentName: string; agentRole: string; output: string; timestamp?: Date }> = []

  if (collaboration.type === CollaborationType.SEQUENTIAL) {
    for (const agent of agents) {
      const messages = llmClient.createCollaborationPrompt(
        agents,
        task,
        agent,
        agentOutputs
      )

      const response = await llmClient.complete({
        messages,
        model: agent.model,
        temperature: 0.7
      })

      agentOutputs.push({
        agentName: agent.name,
        agentRole: agent.role,
        output: response.content,
        timestamp: new Date()
      })
    }
  } else {
    // Parallel execution
    const promises = agents.map(async (agent) => {
      const messages = llmClient.createCollaborationPrompt(
        agents,
        task,
        agent
      )

      const response = await llmClient.complete({
        messages,
        model: agent.model,
        temperature: 0.7
      })

      return {
        agentName: agent.name,
        agentRole: agent.role,
        output: response.content,
        timestamp: new Date()
      }
    })

    const results = await Promise.all(promises)
    agentOutputs.push(...results)
  }

  const collaborationResult = agentOutputs
    .map(output => `${output.agentName}:\n${output.output}`)
    .join('\n\n---\n\n')

  await prisma.collaboration.update({
    where: { id: collaboration.id },
    data: {
      status: CollaborationStatus.COMPLETED,
      result: collaborationResult
    }
  })

  return NextResponse.json({
    result: {
      collaborationResult,
      agentOutputs,
      completedAt: new Date()
    }
  })
}
