
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const workspaceId = searchParams.get('workspaceId')
    const status = searchParams.get('status')

    // For now, return all collaborations since we don't have user filtering
    const collaborations = await prisma.collaboration.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json({ collaborations })
  } catch (error) {
    console.error('Error fetching collaborations:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const {
      name,
      description,
      type,
      agents,
      workflow,
      workspaceId
    } = await request.json()

    if (!name || !type) {
      return NextResponse.json(
        { error: 'Name and type are required' },
        { status: 400 }
      )
    }

    // Create the collaboration
    const collaboration = await prisma.collaboration.create({
      data: {
        name,
        description,
        type: type.toUpperCase() as 'PARALLEL' | 'SEQUENTIAL' | 'HIERARCHICAL',
        status: 'ACTIVE',
        agentIds: (agents || []).map((agent: any, index: number) => `agent_${index}`),
        totalSteps: (workflow || []).length,
        metadata: {
          agents: agents || [],
          workflow: workflow || [],
          createdBy: (session.user as any).id
        }
      }
    })

    return NextResponse.json({ collaboration }, { status: 201 })
  } catch (error) {
    console.error('Error creating collaboration:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
