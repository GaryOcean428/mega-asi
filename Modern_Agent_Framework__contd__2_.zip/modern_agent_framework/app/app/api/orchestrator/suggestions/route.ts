
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { suggestionEngine } from '@/lib/ai-orchestrator/suggestion-engine'
import { IntentAnalysis } from '@/lib/ai-orchestrator/intent-engine'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { analysis }: { analysis: IntentAnalysis } = await request.json()

    const suggestions = await suggestionEngine.generateSuggestions(analysis)

    return NextResponse.json(suggestions)
  } catch (error) {
    console.error('Suggestions generation error:', error)
    return NextResponse.json(
      { error: 'Failed to generate suggestions' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const id = searchParams.get('id')

    if (id) {
      let result
      switch (type) {
        case 'agent':
          result = suggestionEngine.getAgentTemplate(id)
          break
        case 'mcp':
          result = suggestionEngine.getMCPRecommendation(id)
          break
        case 'collaboration':
          result = suggestionEngine.getCollaborationTemplate(id)
          break
        default:
          return NextResponse.json({ error: 'Invalid type' }, { status: 400 })
      }

      if (!result) {
        return NextResponse.json({ error: 'Not found' }, { status: 404 })
      }

      return NextResponse.json(result)
    }

    // Return all templates for browsing
    return NextResponse.json({
      agents: [],
      mcps: [],
      collaborations: []
    })
  } catch (error) {
    console.error('Suggestions API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
