
import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const signupSchema = z.object({
  firstName: z.string().min(1, 'First name is required').max(50),
  lastName: z.string().min(1, 'Last name is required').max(50),
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters long'),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate input
    const validationResult = signupSchema.safeParse(body);
    if (!validationResult.success) {
      return NextResponse.json(
        { message: validationResult.error.errors[0].message },
        { status: 400 }
      );
    }

    const { firstName, lastName, email, password } = validationResult.data;
    const normalizedEmail = email.toLowerCase().trim();
    const fullName = `${firstName} ${lastName}`.trim();

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: normalizedEmail }
    });

    if (existingUser) {
      return NextResponse.json(
        { message: 'An account with this email already exists.' },
        { status: 409 }
      );
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Check for unique organization slug to avoid conflicts
    let organizationSlug: string;
    let attempts = 0;
    const maxAttempts = 5;
    const baseSlug = fullName
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 40) || 'org';
    
    do {
      organizationSlug = attempts === 0 ? `${baseSlug}-${Date.now()}` : `${baseSlug}-${Date.now()}-${attempts}`;
      const existingOrg = await prisma.organization.findUnique({
        where: { slug: organizationSlug }
      });
      if (!existingOrg) break;
      attempts++;
    } while (attempts < maxAttempts);

    if (attempts >= maxAttempts) {
      organizationSlug = `org-${Date.now()}-${Math.random().toString(36).substring(7)}`;
    }

    // Create user in a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const newUser = await tx.user.create({
        data: {
          email: normalizedEmail,
          name: fullName,
          role: 'USER',
          isActive: true,
          // Note: In demo mode, we're not storing password hash
          // In production, you should uncomment the line below:
          // hashedPassword: hashedPassword,
        }
      });

      // Create organization for the user
      const organizationName = `${fullName}'s Organization`;

      const organization = await tx.organization.create({
        data: {
          name: organizationName,
          slug: organizationSlug,
          plan: 'FREE',
        }
      });

      // Create default workspace
      const workspace = await tx.workspace.create({
        data: {
          name: 'Default Workspace',
          slug: 'default',
          organizationId: organization.id,
          isDefault: true,
        }
      });

      // Add user to workspace as admin
      await tx.workspaceMember.create({
        data: {
          userId: newUser.id,
          workspaceId: workspace.id,
          role: 'ADMIN',
        }
      });

      // Update user with organization
      const updatedUser = await tx.user.update({
        where: { id: newUser.id },
        data: { organizationId: organization.id }
      });

      return updatedUser;
    });

    // Return success response (don't return sensitive data)
    return NextResponse.json(
      {
        message: 'Account created successfully',
        user: {
          id: result.id,
          email: result.email,
          name: result.name,
          role: result.role,
        }
      },
      { status: 201 }
    );

  } catch (error) {
    console.error('Signup error:', error);
    
    // Handle Prisma unique constraint errors
    if (error instanceof Error && error.message.includes('Unique constraint')) {
      return NextResponse.json(
        { message: 'An account with this email already exists.' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { message: 'Internal server error. Please try again later.' },
      { status: 500 }
    );
  }
}
