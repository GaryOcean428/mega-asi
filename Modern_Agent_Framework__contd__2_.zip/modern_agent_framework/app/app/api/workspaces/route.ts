
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const workspaces = await prisma.workspace.findMany({
      where: {
        members: {
          some: {
            userId: (session.user as any).id
          }
        }
      },
      include: {
        organization: true,
        _count: {
          select: {
            members: true,
            agents: true,
            chatRooms: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json({ workspaces })
  } catch (error) {
    console.error('Error fetching workspaces:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { name, description, slug } = await request.json()

    if (!name) {
      return NextResponse.json(
        { error: 'Name is required' },
        { status: 400 }
      )
    }

    // Get user's organization or create one
    const user = await prisma.user.findUnique({
      where: { id: (session.user as any).id },
      include: { organization: true }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    let organizationId = user.organizationId

    if (!organizationId) {
      // Create organization for user
      const organization = await prisma.organization.create({
        data: {
          name: `${user.name || user.email}'s Organization`,
          slug: (user.name || user.email).toLowerCase().replace(/[^a-z0-9]/g, '-')
        }
      })

      // Update user with organization
      await prisma.user.update({
        where: { id: user.id },
        data: { organizationId: organization.id }
      })

      organizationId = organization.id
    }

    // Create workspace
    const workspace = await prisma.workspace.create({
      data: {
        name,
        description,
        slug: slug || name.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        organizationId: organizationId!,
        members: {
          create: {
            userId: (session.user as any).id,
            role: 'ADMIN'
          }
        }
      },
      include: {
        organization: true,
        _count: {
          select: {
            members: true,
            agents: true,
            chatRooms: true
          }
        }
      }
    })

    return NextResponse.json({ workspace }, { status: 201 })
  } catch (error) {
    console.error('Error creating workspace:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
