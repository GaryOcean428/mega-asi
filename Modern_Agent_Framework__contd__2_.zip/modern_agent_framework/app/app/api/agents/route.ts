
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    const { searchParams } = new URL(request.url)
    const workspaceId = searchParams.get('workspaceId')
    const status = searchParams.get('status')

    let whereClause: any = {}

    // If user is authenticated, show their agents, otherwise show public agents
    if (session?.user) {
      whereClause.userId = (session.user as any).id
    } else {
      whereClause.isPublic = true
    }

    if (workspaceId) {
      whereClause.workspaceId = workspaceId
    }

    if (status) {
      whereClause.status = status
    }

    // Try to get agents from database, fallback to sample data if needed
    let agents;
    try {
      agents = await prisma.agent.findMany({
        where: whereClause,
        include: {
          user: {
            select: { id: true, name: true, email: true }
          },
          workspace: {
            select: { id: true, name: true }
          },
          _count: {
            select: {
              tasks: true,
              sentMessages: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        }
      })
    } catch (dbError) {
      console.error('Database unavailable, using sample agents:', dbError)
      // If database access fails, return comprehensive mock data
      agents = [
        {
          id: 'demo-agent-1',
          name: 'Research Assistant',
          description: 'Specialized in research and analysis tasks with web search capabilities',
          role: 'researcher',
          model: 'gpt-4.1-mini',
          status: 'IDLE',
          isPublic: true,
          systemPrompt: 'You are a research assistant focused on gathering, analyzing, and presenting information.',
          capabilities: { webSearch: true, dataAnalysis: true, reporting: true },
          user: { id: 'demo-user-1', name: 'Demo User', email: 'demo@framework.ai' },
          workspace: null,
          _count: { tasks: 8, sentMessages: 24 },
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 'demo-agent-2',
          name: 'Data Analyst',
          description: 'Expert in data processing, statistical analysis, and visualization',
          role: 'analyst',
          model: 'claude-4-sonnet',
          status: 'BUSY',
          isPublic: true,
          systemPrompt: 'You are a data analyst specializing in statistical analysis and data visualization.',
          capabilities: { dataVisualization: true, statisticalAnalysis: true, reporting: true },
          user: { id: 'demo-user-2', name: 'Analytics Team', email: 'analytics@framework.ai' },
          workspace: null,
          _count: { tasks: 12, sentMessages: 31 },
          createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 'demo-agent-3',
          name: 'Content Creator',
          description: 'Creative writing and content generation specialist',
          role: 'writer',
          model: 'claude-4-opus',
          status: 'IDLE',
          isPublic: true,
          systemPrompt: 'You are a creative content creator skilled in writing, editing, and content strategy.',
          capabilities: { contentCreation: true, copywriting: true, seoOptimization: true },
          user: { id: 'demo-user-3', name: 'Content Team', email: 'content@framework.ai' },
          workspace: null,
          _count: { tasks: 6, sentMessages: 18 },
          createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date().toISOString()
        }
      ]
    }

    return NextResponse.json({ 
      agents,
      fallback: agents.length > 0 && agents[0].id?.startsWith('demo-') ? true : false
    })
  } catch (error) {
    console.error('Critical error in agents API, using emergency fallback:', error)
    // Emergency fallback data
    return NextResponse.json({ 
      agents: [
        {
          id: 'emergency-agent-1',
          name: 'Emergency Assistant',
          description: 'Basic assistant available when system is experiencing issues',
          role: 'assistant',
          model: 'gpt-4.1-mini',
          status: 'IDLE',
          isPublic: true,
          user: { id: 'system', name: 'System', email: 'system@framework.ai' },
          workspace: null,
          _count: { tasks: 0, sentMessages: 0 },
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ],
      fallback: true,
      emergency: true
    })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const {
      name,
      description,
      role,
      model,
      systemPrompt,
      capabilities,
      workspaceId,
      isPublic,
      personality,
      specializations
    } = await request.json()

    if (!name || !role) {
      return NextResponse.json(
        { error: 'Name and role are required' },
        { status: 400 }
      )
    }

    const agent = await prisma.agent.create({
      data: {
        name,
        description,
        role,
        model: model || 'gpt-4.1-mini',
        systemPrompt,
        capabilities: capabilities || {},
        userId: (session.user as any).id,
        workspaceId: workspaceId || null,
        isPublic: isPublic || false,
        personality: personality || {},
        specializations: specializations || [],
        status: 'IDLE'
      },
      include: {
        user: {
          select: { id: true, name: true, email: true }
        },
        workspace: {
          select: { id: true, name: true }
        }
      }
    })

    return NextResponse.json({ agent }, { status: 201 })
  } catch (error) {
    console.error('Error creating agent:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
