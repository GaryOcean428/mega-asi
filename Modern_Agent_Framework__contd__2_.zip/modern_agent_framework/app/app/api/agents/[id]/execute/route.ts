
import { NextRequest, NextResponse } from 'next/server'
import { AgentEngine } from '@/lib/agent-engine'
import { llmClient } from '@/lib/llm-client'
import { AgentStatus, TaskStatus, ExecutionStatus } from '@prisma/client'

export const dynamic = 'force-dynamic'

// POST /api/agents/[id]/execute - Execute agent task with streaming
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { taskId, input = '', stream = true } = body

    if (!taskId) {
      return NextResponse.json(
        { error: 'Task ID is required' },
        { status: 400 }
      )
    }

    // Get agent context
    const context = await AgentEngine.getAgentContext(params.id, taskId)
    if (!context) {
      return NextResponse.json(
        { error: 'Agent or task not found' },
        { status: 404 }
      )
    }

    // Update agent status to busy
    await AgentEngine.updateAgentStatus(params.id, AgentStatus.BUSY)
    
    // Update task status to in progress
    await AgentEngine.updateTaskStatus(taskId, TaskStatus.IN_PROGRESS)

    if (!stream) {
      // Non-streaming execution
      return await executeNonStreaming(context, input)
    }

    // Streaming execution
    const executionStep = await AgentEngine.createTaskExecution({
      taskId,
      step: 1, // We'll update this based on actual execution count
      action: 'agent_execute',
      input,
      status: ExecutionStatus.RUNNING
    })

    const responseStream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder()
        let fullResponse = ''

        try {
          // Create LLM prompt with context
          const messages = llmClient.createAgentPrompt(
            context.agent,
            context.task,
            {
              previousMessages: context.messages.map(m => ({
                role: m.role.toLowerCase(),
                content: m.content
              })),
              executionHistory: []
            }
          )

          // Add current input if provided
          if (input) {
            messages.push({
              role: 'user',
              content: input
            })
          }

          // Stream LLM response
          const streamGenerator = llmClient.streamComplete({
            messages,
            model: context.agent.model,
            temperature: 0.7
          })

          for await (const chunk of streamGenerator) {
            fullResponse += chunk
            
            // Send progress update
            const progressData = JSON.stringify({
              status: 'processing',
              message: 'Generating response...',
              chunk
            })
            
            controller.enqueue(encoder.encode(`data: ${progressData}\n\n`))
          }

          // Update execution with final result
          await AgentEngine.updateTaskExecution(executionStep.id, {
            output: fullResponse,
            status: ExecutionStatus.COMPLETED
          })

          // Create message record
          await AgentEngine.createMessage({
            content: fullResponse,
            role: 'ASSISTANT',
            senderId: params.id,
            taskId,
            metadata: { executionId: executionStep.id }
          })

          // Update task with result (if this completes the task)
          await AgentEngine.updateTaskStatus(
            taskId,
            TaskStatus.COMPLETED,
            fullResponse
          )

          // Update agent status back to idle
          await AgentEngine.updateAgentStatus(params.id, AgentStatus.IDLE)

          // Send completion data
          const completionData = JSON.stringify({
            status: 'completed',
            result: {
              response: fullResponse,
              executionId: executionStep.id,
              taskCompleted: true
            }
          })
          
          controller.enqueue(encoder.encode(`data: ${completionData}\n\n`))
          
        } catch (error) {
          console.error('Agent execution error:', error)
          
          // Update execution with error
          await AgentEngine.updateTaskExecution(executionStep.id, {
            status: ExecutionStatus.FAILED,
            error: error instanceof Error ? error.message : 'Unknown error'
          })

          // Update task status to failed
          await AgentEngine.updateTaskStatus(taskId, TaskStatus.FAILED, undefined, 
            error instanceof Error ? error.message : 'Unknown error')

          // Update agent status back to idle
          await AgentEngine.updateAgentStatus(params.id, AgentStatus.IDLE)

          const errorData = JSON.stringify({
            status: 'error',
            message: error instanceof Error ? error.message : 'Agent execution failed'
          })
          
          controller.enqueue(encoder.encode(`data: ${errorData}\n\n`))
        } finally {
          controller.close()
        }
      }
    })

    return new Response(responseStream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
      }
    })

  } catch (error) {
    console.error('Execute agent error:', error)
    return NextResponse.json(
      { error: 'Failed to execute agent' },
      { status: 500 }
    )
  }
}

async function executeNonStreaming(context: any, input: string) {
  try {
    const messages = llmClient.createAgentPrompt(
      context.agent,
      context.task,
      {
        previousMessages: context.messages.map((m: any) => ({
          role: m.role.toLowerCase(),
          content: m.content
        })),
        executionHistory: []
      }
    )

    if (input) {
      messages.push({
        role: 'user',
        content: input
      })
    }

    const response = await llmClient.complete({
      messages,
      model: context.agent.model,
      temperature: 0.7
    })

    // Create execution record
    const executionStep = await AgentEngine.createTaskExecution({
      taskId: context.task.id,
      step: 1,
      action: 'agent_execute',
      input,
      output: response.content,
      status: ExecutionStatus.COMPLETED
    })

    // Create message record
    await AgentEngine.createMessage({
      content: response.content,
      role: 'ASSISTANT',
      senderId: context.agent.id,
      taskId: context.task.id,
      metadata: { executionId: executionStep.id }
    })

    // Update task status
    await AgentEngine.updateTaskStatus(
      context.task.id,
      TaskStatus.COMPLETED,
      response.content
    )

    // Update agent status back to idle
    await AgentEngine.updateAgentStatus(context.agent.id, AgentStatus.IDLE)

    return NextResponse.json({
      result: {
        response: response.content,
        executionId: executionStep.id,
        taskCompleted: true,
        usage: response.usage
      }
    })

  } catch (error) {
    console.error('Non-streaming execution error:', error)
    throw error
  }
}
