
import { NextResponse } from 'next/server'
import { AgentEngine } from '@/lib/agent-engine'

export const dynamic = 'force-dynamic'

// GET /api/system/metrics - Get system metrics
export async function GET() {
  try {
    // Try to get real metrics from database
    const metrics = await AgentEngine.getSystemMetrics()
    
    return NextResponse.json({
      metrics,
      health: {
        database: 'healthy',
        llmApi: 'healthy',
        agents: metrics.activeAgents > 0 ? 'healthy' : 'idle',
        lastUpdated: new Date()
      }
    })
  } catch (error) {
    console.error('Database unavailable, using fallback metrics:', error)
    
    // Return fallback metrics when database is unavailable
    const fallbackMetrics = {
      totalAgents: 3,
      activeAgents: 1,
      completedTasks: 15,
      pendingTasks: 2,
      failedTasks: 0,
      avgTaskCompletionTime: 45
    }
    
    return NextResponse.json({
      metrics: fallbackMetrics,
      health: {
        database: 'unavailable',
        llmApi: 'healthy',
        agents: 'idle',
        lastUpdated: new Date()
      },
      fallback: true
    })
  }
}
