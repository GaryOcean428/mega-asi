
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const workspaceId = searchParams.get('workspaceId')

    if (!workspaceId) {
      return NextResponse.json({ error: 'Workspace ID is required' }, { status: 400 })
    }

    // Get user's workspaces to verify access
    const workspaceMember = await prisma.workspaceMember.findFirst({
      where: {
        userId: (session.user as any).id,
        workspaceId
      }
    })

    if (!workspaceMember) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    // Get chat rooms for this workspace where user is a participant
    const chatRooms = await prisma.chatRoom.findMany({
      where: {
        workspaceId,
        participants: {
          some: {
            userId: (session.user as any).id
          }
        },
        archivedAt: null
      },
      include: {
        _count: {
          select: {
            participants: true,
            messages: {
              where: { deletedAt: null }
            }
          }
        },
        messages: {
          where: { deletedAt: null },
          orderBy: { createdAt: 'desc' },
          take: 1,
          include: {
            userSender: {
              select: { id: true, name: true }
            },
            agentSender: {
              select: { id: true, name: true }
            }
          }
        },
        participants: {
          where: { userId: (session.user as any).id },
          select: { lastReadAt: true }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    })

    return NextResponse.json({ chatRooms })
  } catch (error) {
    console.error('Error fetching chat rooms:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { name, description, workspaceId, type = 'GENERAL', isPrivate = false } = await request.json()

    if (!name || !workspaceId) {
      return NextResponse.json(
        { error: 'Name and workspace ID are required' },
        { status: 400 }
      )
    }

    // Verify user has access to the workspace
    const workspaceMember = await prisma.workspaceMember.findFirst({
      where: {
        userId: (session.user as any).id,
        workspaceId,
        role: { in: ['ADMIN', 'MANAGER', 'MEMBER'] }
      }
    })

    if (!workspaceMember) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    // Create the chat room
    const chatRoom = await prisma.chatRoom.create({
      data: {
        name,
        description,
        workspaceId,
        type,
        isPrivate,
        participants: {
          create: {
            userId: (session.user as any).id,
            role: 'ADMIN'
          }
        }
      },
      include: {
        participants: {
          include: {
            user: {
              select: { id: true, name: true, email: true, image: true }
            }
          }
        },
        _count: {
          select: {
            participants: true,
            messages: true
          }
        }
      }
    })

    return NextResponse.json({ chatRoom }, { status: 201 })
  } catch (error) {
    console.error('Error creating chat room:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
