
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'

export async function GET(
  request: NextRequest,
  { params }: { params: { roomId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Verify user has access to the chat room
    const userParticipant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        userId: (session.user as any).id
      }
    })

    if (!userParticipant) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    const participants = await prisma.chatParticipant.findMany({
      where: {
        chatRoomId: params.roomId
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
            lastActiveAt: true,
            isActive: true
          }
        },
        agent: {
          select: {
            id: true,
            name: true,
            description: true,
            status: true,
            role: true
          }
        }
      },
      orderBy: [
        { role: 'desc' }, // Admins first
        { joinedAt: 'asc' } // Then by join time
      ]
    })

    return NextResponse.json({ participants })
  } catch (error) {
    console.error('Error fetching participants:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { roomId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { userId, agentId, role = 'MEMBER' } = await request.json()

    if (!userId && !agentId) {
      return NextResponse.json(
        { error: 'Either userId or agentId is required' },
        { status: 400 }
      )
    }

    // Verify user has admin permissions in the chat room
    const userParticipant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        userId: (session.user as any).id,
        role: { in: ['ADMIN', 'MODERATOR'] }
      }
    })

    if (!userParticipant) {
      return NextResponse.json({ error: 'Insufficient permissions' }, { status: 403 })
    }

    // Check if participant already exists
    const existingParticipant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        ...(userId ? { userId } : { agentId })
      }
    })

    if (existingParticipant) {
      return NextResponse.json(
        { error: 'Participant already exists in this room' },
        { status: 409 }
      )
    }

    const participant = await prisma.chatParticipant.create({
      data: {
        chatRoomId: params.roomId,
        userId,
        agentId,
        role
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true
          }
        },
        agent: {
          select: {
            id: true,
            name: true,
            description: true,
            status: true
          }
        }
      }
    })

    return NextResponse.json({ participant }, { status: 201 })
  } catch (error) {
    console.error('Error adding participant:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
