
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'

export async function GET(
  request: NextRequest,
  { params }: { params: { roomId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Verify user has access to the chat room
    const participant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        userId: (session.user as any).id
      }
    })

    if (!participant) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    const threads = await prisma.messageThread.findMany({
      where: {
        chatRoomId: params.roomId
      },
      include: {
        parentMessage: {
          include: {
            userSender: {
              select: { id: true, name: true }
            },
            agentSender: {
              select: { id: true, name: true }
            }
          }
        },
        _count: {
          select: {
            messages: true
          }
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    })

    // Get the last activity for each thread
    const threadsWithActivity = await Promise.all(
      threads.map(async (thread) => {
        const lastMessage = await prisma.chatMessage.findFirst({
          where: {
            threadId: thread.id,
            deletedAt: null
          },
          orderBy: {
            createdAt: 'desc'
          },
          select: {
            createdAt: true
          }
        })

        return {
          ...thread,
          messageCount: thread._count.messages,
          lastActivity: lastMessage?.createdAt || thread.createdAt
        }
      })
    )

    return NextResponse.json({ 
      threads: threadsWithActivity.sort(
        (a, b) => new Date(b.lastActivity).getTime() - new Date(a.lastActivity).getTime()
      )
    })
  } catch (error) {
    console.error('Error fetching threads:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { roomId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { title, parentMessageId } = await request.json()

    if (!parentMessageId) {
      return NextResponse.json(
        { error: 'Parent message ID is required' },
        { status: 400 }
      )
    }

    // Verify user has access to the chat room
    const participant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        userId: (session.user as any).id
      }
    })

    if (!participant) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    // Verify the parent message exists and belongs to this room
    const parentMessage = await prisma.chatMessage.findFirst({
      where: {
        id: parentMessageId,
        chatRoomId: params.roomId,
        deletedAt: null
      }
    })

    if (!parentMessage) {
      return NextResponse.json(
        { error: 'Parent message not found' },
        { status: 404 }
      )
    }

    const thread = await prisma.messageThread.create({
      data: {
        title,
        chatRoomId: params.roomId,
        parentMessageId
      },
      include: {
        parentMessage: {
          include: {
            userSender: {
              select: { id: true, name: true }
            },
            agentSender: {
              select: { id: true, name: true }
            }
          }
        }
      }
    })

    return NextResponse.json({ thread }, { status: 201 })
  } catch (error) {
    console.error('Error creating thread:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
