
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'

export async function GET(
  request: NextRequest,
  { params }: { params: { roomId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '50')
    const offset = parseInt(searchParams.get('offset') || '0')
    const threadId = searchParams.get('threadId')

    // Verify user has access to the chat room
    const participant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        userId: (session.user as any).id
      }
    })

    if (!participant) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    // Build the where clause
    const whereClause: any = {
      chatRoomId: params.roomId,
      deletedAt: null
    }

    if (threadId) {
      whereClause.threadId = threadId
    } else {
      // Main thread (no threadId)
      whereClause.threadId = null
    }

    const messages = await prisma.chatMessage.findMany({
      where: whereClause,
      include: {
        userSender: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true
          }
        },
        agentSender: {
          select: {
            id: true,
            name: true,
            description: true,
            status: true
          }
        },
        replyTo: {
          include: {
            userSender: {
              select: { id: true, name: true }
            },
            agentSender: {
              select: { id: true, name: true }
            }
          }
        },
        reactions: true,
        attachments: true,
        _count: {
          select: {
            replies: true,
            childThreads: true
          }
        }
      },
      orderBy: {
        createdAt: 'asc'
      },
      skip: offset,
      take: limit
    })

    // Update participant's last read timestamp
    await prisma.chatParticipant.update({
      where: {
        id: participant.id
      },
      data: {
        lastReadAt: new Date()
      }
    })

    return NextResponse.json({
      messages,
      hasMore: messages.length === limit
    })
  } catch (error) {
    console.error('Error fetching messages:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { roomId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { content, threadId, replyToId } = await request.json()

    if (!content) {
      return NextResponse.json({ error: 'Content is required' }, { status: 400 })
    }

    // Verify user has access to the chat room
    const participant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        userId: (session.user as any).id
      }
    })

    if (!participant) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    const message = await prisma.chatMessage.create({
      data: {
        content,
        chatRoomId: params.roomId,
        threadId,
        replyToId,
        senderUserId: (session.user as any).id,
        senderType: 'USER'
      },
      include: {
        userSender: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true
          }
        },
        replyTo: {
          include: {
            userSender: {
              select: { id: true, name: true }
            },
            agentSender: {
              select: { id: true, name: true }
            }
          }
        }
      }
    })

    return NextResponse.json({ message }, { status: 201 })
  } catch (error) {
    console.error('Error creating message:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
