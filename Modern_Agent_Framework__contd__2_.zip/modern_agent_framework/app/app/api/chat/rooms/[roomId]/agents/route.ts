
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { prisma } from '@/lib/prisma'
import { cache } from '@/lib/redis/cache'

export async function GET(
  request: NextRequest,
  { params }: { params: { roomId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Verify user has access to the chat room
    const participant = await prisma.chatParticipant.findFirst({
      where: {
        chatRoomId: params.roomId,
        userId: (session.user as any).id
      }
    })

    if (!participant) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    // Get agents that are participants in this room
    const agentParticipants = await prisma.chatParticipant.findMany({
      where: {
        chatRoomId: params.roomId,
        agentId: { not: null }
      },
      include: {
        agent: {
          select: {
            id: true,
            name: true,
            description: true,
            status: true,
            role: true,
            updatedAt: true
          }
        }
      }
    })

    // Enhance with real-time status from cache
    const agentsWithStatus = await Promise.all(
      agentParticipants.map(async (participant) => {
        if (!participant.agent) return null

        // Get cached status
        const cachedStatus = await cache.getAgentStatus(participant.agent.id)
        
        // Get current task from task executions
        const currentTask = await prisma.taskExecution.findFirst({
          where: {
            task: {
              agentId: participant.agent.id
            },
            status: 'RUNNING'
          },
          include: {
            task: {
              select: { title: true }
            }
          },
          orderBy: { createdAt: 'desc' }
        })

        return {
          id: participant.agent.id,
          name: participant.agent.name,
          status: cachedStatus?.status || participant.agent.status,
          currentTask: currentTask?.task?.title || undefined,
          lastActivity: participant.agent.updatedAt.toISOString()
        }
      })
    )

    const agents = agentsWithStatus.filter(Boolean)

    return NextResponse.json({ agents })
  } catch (error) {
    console.error('Error fetching room agents:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
