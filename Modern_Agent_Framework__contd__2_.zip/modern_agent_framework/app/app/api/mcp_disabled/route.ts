
/**
 * MCP Management API - Core endpoints for MCP discovery, installation, and management
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { mcpManager } from '@/lib/mcp/manager'
import { mcpAssistant } from '@/lib/mcp/intelligent-assistant'
import { logger } from '@/lib/utils/logger'

export const dynamic = 'force-dynamic'

// GET /api/mcp - Search and discover MCPs
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    const { searchParams } = new URL(request.url)
    
    const query = searchParams.get('q') || ''
    const category = searchParams.get('category') || undefined
    const action = searchParams.get('action') || 'search'
    
    switch (action) {
      case 'search':
        const mcps = await mcpManager.searchMCPs(
          query, 
          category, 
          session?.user?.id
        )
        
        return NextResponse.json({
          mcps,
          totalCount: mcps.length,
          categories: ['productivity', 'development', 'data', 'ai', 'communication', 'automation'],
          query,
          category
        })
        
      case 'recommendations':
        if (!session?.user?.id) {
          return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
        }
        
        const workspaceId = searchParams.get('workspace') || undefined
        const context = searchParams.get('context') || undefined
        
        const recommendations = await mcpAssistant.getIntelligentRecommendations(
          query,
          session.user.id,
          workspaceId
        )
        
        return NextResponse.json(recommendations)
        
      case 'installed':
        if (!session?.user?.id) {
          return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
        }
        
        const userMCPs = await mcpManager.getUserMCPs(
          session.user.id,
          searchParams.get('workspace') || undefined
        )
        
        return NextResponse.json({ mcps: userMCPs })
        
      default:
        return NextResponse.json(
          { error: 'Invalid action parameter' },
          { status: 400 }
        )
    }
  } catch (error) {
    logger.error('Error in MCP API GET:', error)
    return NextResponse.json(
      { error: 'Failed to process MCP request' },
      { status: 500 }
    )
  }
}

// POST /api/mcp - Install or configure MCPs
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const body = await request.json()
    const { action, ...params } = body

    switch (action) {
      case 'install':
        const { mcpRegistryId, workspaceId, config = {}, credentials = [] } = params
        
        if (!mcpRegistryId) {
          return NextResponse.json({ error: 'MCP registry ID required' }, { status: 400 })
        }
        
        const installResult = await mcpManager.installMCP(
          mcpRegistryId,
          session.user.id,
          workspaceId,
          config,
          credentials
        )
        
        if (installResult.success) {
          logger.mcpActivity('install', params.mcpName || mcpRegistryId, { 
            userId: session.user.id,
            workspaceId,
            installationId: installResult.installationId
          })
        }
        
        return NextResponse.json(installResult)
        
      case 'configure':
        const { installationId, newConfig, newCredentials } = params
        
        if (!installationId) {
          return NextResponse.json({ error: 'Installation ID required' }, { status: 400 })
        }
        
        const configResult = await mcpManager.updateMCPConfig(
          installationId,
          newConfig,
          newCredentials
        )
        
        if (configResult.success) {
          logger.mcpActivity('configure', installationId, {
            userId: session.user.id
          })
        }
        
        return NextResponse.json(configResult)
        
      case 'analyze_message':
        const { message } = params
        
        if (!message) {
          return NextResponse.json({ error: 'Message required' }, { status: 400 })
        }
        
        const analysis = await mcpAssistant.analyzeIntent(message, session.user.id)
        
        return NextResponse.json({ analysis })
        
      default:
        return NextResponse.json(
          { error: 'Invalid action parameter' },
          { status: 400 }
        )
    }
  } catch (error) {
    logger.error('Error in MCP API POST:', error)
    return NextResponse.json(
      { error: 'Failed to process MCP request' },
      { status: 500 }
    )
  }
}

// DELETE /api/mcp - Uninstall MCPs
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const installationId = searchParams.get('installationId')
    
    if (!installationId) {
      return NextResponse.json({ error: 'Installation ID required' }, { status: 400 })
    }
    
    const uninstallResult = await mcpManager.uninstallMCP(installationId)
    
    if (uninstallResult.success) {
      logger.mcpActivity('uninstall', installationId, {
        userId: session.user.id
      })
    }
    
    return NextResponse.json(uninstallResult)
  } catch (error) {
    logger.error('Error in MCP API DELETE:', error)
    return NextResponse.json(
      { error: 'Failed to uninstall MCP' },
      { status: 500 }
    )
  }
}
