
/**
 * MCP Health Check API - Monitor MCP installation health and status
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { mcpManager } from '@/lib/mcp/manager'
import { logger } from '@/lib/utils/logger'

export const dynamic = 'force-dynamic'

// GET /api/mcp/[installationId]/health - Check MCP health
export async function GET(
  request: NextRequest,
  { params }: { params: { installationId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const { installationId } = params
    
    const healthResult = await mcpManager.performHealthCheck(installationId)
    
    logger.mcpActivity('health_check', installationId, {
      userId: session.user.id,
      status: healthResult.status
    })
    
    return NextResponse.json(healthResult)
  } catch (error) {
    logger.error('Error checking MCP health:', error)
    return NextResponse.json(
      { error: 'Failed to check MCP health' },
      { status: 500 }
    )
  }
}

// POST /api/mcp/[installationId]/health - Trigger health check or restart
export async function POST(
  request: NextRequest,
  { params }: { params: { installationId: string } }
) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const { installationId } = params
    const body = await request.json()
    const { action = 'check' } = body

    switch (action) {
      case 'check':
        const healthResult = await mcpManager.performHealthCheck(installationId)
        return NextResponse.json(healthResult)
        
      case 'restart':
        // Restart MCP installation
        try {
          // Implementation would restart the MCP server
          logger.mcpActivity('restart', installationId, {
            userId: session.user.id
          })
          
          return NextResponse.json({ 
            success: true, 
            message: 'MCP restart initiated' 
          })
        } catch (error) {
          return NextResponse.json(
            { error: 'Failed to restart MCP' },
            { status: 500 }
          )
        }
        
      default:
        return NextResponse.json(
          { error: 'Invalid action' },
          { status: 400 }
        )
    }
  } catch (error) {
    logger.error('Error in MCP health action:', error)
    return NextResponse.json(
      { error: 'Failed to perform health action' },
      { status: 500 }
    )
  }
}
