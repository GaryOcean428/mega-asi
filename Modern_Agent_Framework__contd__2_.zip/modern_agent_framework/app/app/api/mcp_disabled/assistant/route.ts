
/**
 * MCP Intelligent Assistant API - Natural language MCP management
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { mcpAssistant } from '@/lib/mcp/intelligent-assistant'
import { ragService } from '@/lib/rag/service'
import { logger } from '@/lib/utils/logger'

export const dynamic = 'force-dynamic'

// POST /api/mcp/assistant - Intelligent MCP assistance
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const body = await request.json()
    const { action, ...params } = body

    switch (action) {
      case 'analyze_intent':
        const { message } = params
        
        if (!message) {
          return NextResponse.json({ error: 'Message required' }, { status: 400 })
        }
        
        const analysis = await mcpAssistant.analyzeIntent(message, session.user.id)
        
        return NextResponse.json({ 
          analysis,
          timestamp: new Date().toISOString()
        })
        
      case 'get_recommendations':
        const { query, workspaceId, context } = params
        
        const recommendations = await mcpAssistant.getIntelligentRecommendations(
          query || '',
          session.user.id,
          workspaceId
        )
        
        return NextResponse.json(recommendations)
        
      case 'generate_setup_guide':
        const { mcpId } = params
        
        if (!mcpId) {
          return NextResponse.json({ error: 'MCP ID required' }, { status: 400 })
        }
        
        const setupGuide = await mcpAssistant.generateSetupGuide(mcpId)
        
        return NextResponse.json({ setupGuide })
        
      case 'troubleshoot':
        const { problem, installationId } = params
        
        if (!problem || !installationId) {
          return NextResponse.json(
            { error: 'Problem description and installation ID required' },
            { status: 400 }
          )
        }
        
        const troubleshooting = await mcpAssistant.troubleshootMCP(
          problem,
          installationId,
          session.user.id
        )
        
        return NextResponse.json({ troubleshooting })
        
      case 'configure_from_message':
        const { configMessage, installationId: configInstallationId } = params
        
        if (!configMessage || !configInstallationId) {
          return NextResponse.json(
            { error: 'Configuration message and installation ID required' },
            { status: 400 }
          )
        }
        
        const configResult = await mcpAssistant.configureMCPFromMessage(
          configMessage,
          configInstallationId,
          session.user.id
        )
        
        return NextResponse.json({ result: configResult })
        
      case 'get_configuration_help':
        const { mcpId: helpMcpId, configField, userQuery } = params
        
        if (!helpMcpId || !configField) {
          return NextResponse.json(
            { error: 'MCP ID and configuration field required' },
            { status: 400 }
          )
        }
        
        const help = await ragService.getConfigurationHelp(
          helpMcpId,
          configField,
          userQuery
        )
        
        return NextResponse.json({ help })
        
      case 'search_knowledge':
        const { searchQuery, options } = params
        
        if (!searchQuery) {
          return NextResponse.json({ error: 'Search query required' }, { status: 400 })
        }
        
        const knowledgeResults = await ragService.searchMCPKnowledge(
          searchQuery,
          options || {}
        )
        
        return NextResponse.json({ 
          results: knowledgeResults,
          totalCount: knowledgeResults.length
        })
        
      case 'get_usage_insights':
        const { workspaceId: insightWorkspaceId } = params
        
        const insights = await ragService.generateUsageInsights(
          session.user.id,
          insightWorkspaceId
        )
        
        return NextResponse.json({ insights })
        
      default:
        return NextResponse.json(
          { error: 'Invalid action parameter' },
          { status: 400 }
        )
    }
  } catch (error) {
    logger.error('Error in MCP assistant API:', error)
    return NextResponse.json(
      { error: 'Failed to process assistant request' },
      { status: 500 }
    )
  }
}

// GET /api/mcp/assistant - Get MCP knowledge and assistance data
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'knowledge'

    switch (type) {
      case 'knowledge':
        const query = searchParams.get('q') || ''
        const section = searchParams.get('section') || undefined
        const mcpId = searchParams.get('mcpId') || undefined
        
        const knowledgeResults = await ragService.searchMCPKnowledge(query, {
          section: section as any,
          mcpId,
          limit: parseInt(searchParams.get('limit') || '10')
        })
        
        return NextResponse.json({ 
          results: knowledgeResults,
          query,
          filters: { section, mcpId }
        })
        
      case 'insights':
        const workspaceId = searchParams.get('workspace') || undefined
        
        const insights = await ragService.generateUsageInsights(
          session.user.id,
          workspaceId
        )
        
        return NextResponse.json({ insights })
        
      default:
        return NextResponse.json(
          { error: 'Invalid type parameter' },
          { status: 400 }
        )
    }
  } catch (error) {
    logger.error('Error in MCP assistant API GET:', error)
    return NextResponse.json(
      { error: 'Failed to retrieve assistant data' },
      { status: 500 }
    )
  }
}
