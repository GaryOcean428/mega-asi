
import { NextRequest, NextResponse } from 'next/server'
import { AgentEngine } from '@/lib/agent-engine'

export const dynamic = 'force-dynamic'

// GET /api/messages - Get messages with filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const taskId = searchParams.get('taskId')
    const senderId = searchParams.get('senderId')
    const receiverId = searchParams.get('receiverId')
    const isInternal = searchParams.get('isInternal')
    const limit = parseInt(searchParams.get('limit') || '50')

    const filters: any = { limit }
    if (taskId) filters.taskId = taskId
    if (senderId) filters.senderId = senderId
    if (receiverId) filters.receiverId = receiverId
    if (isInternal !== null) filters.isInternal = isInternal === 'true'

    const messages = await AgentEngine.getMessages(filters)

    return NextResponse.json({ messages })
  } catch (error) {
    console.error('Error fetching messages:', error)
    return NextResponse.json(
      { error: 'Failed to fetch messages' },
      { status: 500 }
    )
  }
}

// POST /api/messages - Create new message
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    if (!body.content) {
      return NextResponse.json(
        { error: 'Content is required' },
        { status: 400 }
      )
    }

    const message = await AgentEngine.createMessage({
      content: body.content,
      role: body.role,
      senderId: body.senderId,
      receiverId: body.receiverId,
      taskId: body.taskId,
      isInternal: body.isInternal,
      metadata: body.metadata
    })

    return NextResponse.json({ message }, { status: 201 })
  } catch (error) {
    console.error('Error creating message:', error)
    return NextResponse.json(
      { error: 'Failed to create message' },
      { status: 500 }
    )
  }
}
