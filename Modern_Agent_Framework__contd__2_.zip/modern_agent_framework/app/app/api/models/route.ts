
import { NextRequest, NextResponse } from 'next/server'
import { LLMClient, PLATFORM_MODELS } from '@/lib/llm-client'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const provider = url.searchParams.get('provider')
    const capability = url.searchParams.get('capability')
    const sortBy = url.searchParams.get('sortBy') || 'name'
    
    let models = Object.entries(PLATFORM_MODELS).map(([id, model]) => ({
      id,
      ...model
    }))

    // Filter by provider if specified
    if (provider) {
      models = models.filter(model => 
        model.provider.toLowerCase() === provider.toLowerCase()
      )
    }

    // Filter by capability if specified
    if (capability) {
      models = models.filter(model => 
(model.capabilities as readonly string[]).includes(capability.toLowerCase())
      )
    }

    // Sort models
    switch (sortBy) {
      case 'cost':
        models.sort((a, b) => a.costPer1MTokens.input - b.costPer1MTokens.input)
        break
      case 'context':
        models.sort((a, b) => b.contextWindow - a.contextWindow)
        break
      case 'provider':
        models.sort((a, b) => a.provider.localeCompare(b.provider))
        break
      case 'name':
      default:
        models.sort((a, b) => a.name.localeCompare(b.name))
        break
    }

    return NextResponse.json({
      models,
      providers: [...new Set(Object.values(PLATFORM_MODELS).map(m => m.provider))],
      capabilities: [...new Set(Object.values(PLATFORM_MODELS).flatMap(m => m.capabilities))],
      totalCount: models.length
    })

  } catch (error) {
    console.error('Error fetching models, using fallback data:', error)
    
    // Return fallback model data when there are issues
    const fallbackModels = [
      {
        id: 'gpt-4.1-mini',
        name: 'GPT-4.1 Mini',
        provider: 'OpenAI',
        capabilities: ['text', 'code', 'reasoning'],
        contextWindow: 128000,
        costPer1MTokens: { input: 0.15, output: 0.6 },
        description: 'Fast, efficient model for everyday tasks'
      },
      {
        id: 'claude-4-sonnet',
        name: 'Claude 4 Sonnet',
        provider: 'Anthropic',
        capabilities: ['text', 'code', 'reasoning', 'writing', 'analysis'],
        contextWindow: 200000,
        costPer1MTokens: { input: 3.0, output: 15 },
        description: 'Balanced Claude model for most tasks'
      },
      {
        id: 'gemini-2.5-flash',
        name: 'Gemini 2.5 Flash',
        provider: 'Google',
        capabilities: ['text', 'code', 'multimodal', 'fast_processing'],
        contextWindow: 1000000,
        costPer1MTokens: { input: 0.075, output: 0.3 },
        description: 'Ultra-fast multimodal model'
      }
    ]
    
    return NextResponse.json({
      models: fallbackModels,
      providers: ['OpenAI', 'Anthropic', 'Google'],
      capabilities: ['text', 'code', 'reasoning', 'writing', 'analysis', 'multimodal', 'fast_processing'],
      totalCount: fallbackModels.length,
      fallback: true
    })
  }
}

// Get model recommendations for specific use cases
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { taskType, agentRole, budget, requirements } = body

    const recommendations = []

    // Get best model for task type
    if (taskType) {
      const modelId = LLMClient.getBestModelForTask(taskType)
      const model = PLATFORM_MODELS[modelId]
      recommendations.push({
        id: modelId,
        ...model,
        reason: `Optimized for ${taskType} tasks`,
        score: 10
      })
    }

    // Get role-specific recommendations
    if (agentRole) {
      const client = new LLMClient()
      const modelId = client.autoSelectModel(agentRole, taskType)
      const model = PLATFORM_MODELS[modelId]
      if (!recommendations.find(r => r.id === modelId)) {
        recommendations.push({
          id: modelId,
          ...model,
          reason: `Specialized for ${agentRole} role`,
          score: 8
        })
      }
    }

    // Budget-based recommendations
    if (budget && typeof budget === 'number') {
      const budgetFriendly = Object.entries(PLATFORM_MODELS)
        .filter(([, model]) => model.costPer1MTokens.input <= budget)
        .sort(([, a], [, b]) => a.costPer1MTokens.input - b.costPer1MTokens.input)
        .slice(0, 3)
        .map(([id, model]) => ({
          id,
          ...model,
          reason: `Within budget of $${budget} per 1M tokens`,
          score: 6
        }))
      
      recommendations.push(...budgetFriendly)
    }

    // Capability-based recommendations
    if (requirements && Array.isArray(requirements)) {
      const capabilityMatches = Object.entries(PLATFORM_MODELS)
        .filter(([, model]) => 
          requirements.every(req => [...model.capabilities].includes(req))
        )
        .map(([id, model]) => ({
          id,
          ...model,
          reason: `Supports all required capabilities: ${requirements.join(', ')}`,
          score: 7
        }))
      
      recommendations.push(...capabilityMatches)
    }

    // Remove duplicates and sort by score
    const uniqueRecommendations = recommendations
      .filter((model, index, arr) => 
        arr.findIndex(m => m.id === model.id) === index
      )
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)

    return NextResponse.json({
      recommendations: uniqueRecommendations,
      totalRecommendations: uniqueRecommendations.length
    })

  } catch (error) {
    console.error('Error getting model recommendations, using fallback:', error)
    
    // Return fallback recommendations
    const fallbackRecommendations = [
      {
        id: 'gpt-4.1-mini',
        name: 'GPT-4.1 Mini',
        provider: 'OpenAI',
        capabilities: ['text', 'code', 'reasoning'],
        contextWindow: 128000,
        costPer1MTokens: { input: 0.15, output: 0.6 },
        description: 'Fast, efficient model for everyday tasks',
        reason: 'Versatile model suitable for most tasks',
        score: 8
      },
      {
        id: 'claude-4-sonnet',
        name: 'Claude 4 Sonnet',
        provider: 'Anthropic',
        capabilities: ['text', 'code', 'reasoning', 'writing', 'analysis'],
        contextWindow: 200000,
        costPer1MTokens: { input: 3.0, output: 15 },
        description: 'Balanced Claude model for most tasks',
        reason: 'Excellent for complex reasoning and analysis',
        score: 9
      }
    ]
    
    return NextResponse.json({
      recommendations: fallbackRecommendations,
      totalRecommendations: fallbackRecommendations.length,
      fallback: true
    })
  }
}
