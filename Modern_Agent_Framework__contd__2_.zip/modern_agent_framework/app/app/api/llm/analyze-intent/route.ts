
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession()
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { prompt, model, context } = await request.json()

    const response = await fetch(`${process.env.ABACUSAI_API_URL || 'https://api.abacus.ai'}/api/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: model || 'gpt-4.1-mini',
        messages: [
          {
            role: 'system',
            content: 'You are an AI intent recognition system. Always respond with valid JSON.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 1000
      })
    })

    if (!response.ok) {
      throw new Error('LLM API request failed')
    }

    const data = await response.json()
    
    // Validate API response structure
    if (!data || !data.choices || !Array.isArray(data.choices) || data.choices.length === 0) {
      console.error('Invalid API response structure:', data)
      return NextResponse.json({
        intent: 'general_chat',
        confidence: 0.3,
        entities: {},
        suggestedActions: [],
        actions: []
      })
    }

    const choice = data.choices[0]
    if (!choice || !choice.message || typeof choice.message.content !== 'string') {
      console.error('Invalid choice structure:', choice)
      return NextResponse.json({
        intent: 'general_chat',
        confidence: 0.3,
        entities: {},
        suggestedActions: [],
        actions: []
      })
    }

    const content = choice.message.content

    try {
      const analysis = JSON.parse(content)
      // Ensure required fields are present
      return NextResponse.json({
        intent: analysis.intent || 'general_chat',
        confidence: analysis.confidence || 0.5,
        entities: analysis.entities || {},
        suggestedActions: analysis.suggestedActions || [],
        actions: analysis.actions || []
      })
    } catch (parseError) {
      console.error('JSON parsing error:', parseError, 'Content:', content)
      // Fallback if JSON parsing fails
      return NextResponse.json({
        intent: 'general_chat',
        confidence: 0.3,
        entities: {},
        suggestedActions: [],
        actions: []
      })
    }
  } catch (error) {
    console.error('Intent analysis error:', error)
    return NextResponse.json(
      { error: 'Intent analysis failed' },
      { status: 500 }
    )
  }
}
