
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth/config'
import { UsageAnalytics } from '@/lib/analytics/types'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const timeRange = searchParams.get('timeRange') || '7d'

    // In a real implementation, this would query your analytics database
    // For now, return mock data based on time range
    const analytics = getMockAnalytics(timeRange)

    return NextResponse.json(analytics)
  } catch (error) {
    console.error('Analytics API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

function getMockAnalytics(timeRange: string): UsageAnalytics {
  const multiplier = getTimeRangeMultiplier(timeRange)
  
  return {
    totalUsers: Math.floor(1247 * multiplier),
    activeUsers: Math.floor(356 * multiplier),
    newUsers: Math.floor(89 * multiplier),
    returningUsers: Math.floor(267 * multiplier),
    totalAgents: Math.floor(45 * multiplier),
    totalCollaborations: Math.floor(23 * multiplier),
    totalMessages: Math.floor(8942 * multiplier),
    averageSessionDuration: 24.5,
    topFeatures: [
      { feature: 'Agent Creation', usage: Math.floor(450 * multiplier) },
      { feature: 'Intelligent Chat', usage: Math.floor(389 * multiplier) },
      { feature: 'Collaboration Setup', usage: Math.floor(267 * multiplier) },
      { feature: 'MCP Integration', usage: Math.floor(178 * multiplier) },
      { feature: 'Workflow Automation', usage: Math.floor(134 * multiplier) }
    ],
    userGrowth: generateUserGrowthData(timeRange),
    agentPopularity: [
      { type: 'Data Analysis', count: Math.floor(15 * multiplier) },
      { type: 'Research', count: Math.floor(12 * multiplier) },
      { type: 'Content Creation', count: Math.floor(8 * multiplier) },
      { type: 'Development', count: Math.floor(6 * multiplier) },
      { type: 'Project Management', count: Math.floor(4 * multiplier) }
    ]
  }
}

function getTimeRangeMultiplier(timeRange: string): number {
  switch (timeRange) {
    case '24h': return 0.1
    case '7d': return 1
    case '30d': return 3.5
    case '90d': return 10
    default: return 1
  }
}

function generateUserGrowthData(timeRange: string) {
  const points = getDataPointsCount(timeRange)
  const data = []
  const startValue = 100
  
  for (let i = 0; i < points; i++) {
    const date = getDateForPoint(timeRange, i)
    const growth = startValue + (i * 20) + Math.random() * 50
    
    data.push({
      date: date.toISOString().split('T')[0],
      users: Math.floor(growth)
    })
  }
  
  return data
}

function getDataPointsCount(timeRange: string): number {
  switch (timeRange) {
    case '24h': return 24
    case '7d': return 7
    case '30d': return 30
    case '90d': return 12 // Weekly points for 3 months
    default: return 7
  }
}

function getDateForPoint(timeRange: string, index: number): Date {
  const now = new Date()
  
  switch (timeRange) {
    case '24h':
      return new Date(now.getTime() - (24 - index) * 60 * 60 * 1000)
    case '7d':
      return new Date(now.getTime() - (7 - index) * 24 * 60 * 60 * 1000)
    case '30d':
      return new Date(now.getTime() - (30 - index) * 24 * 60 * 60 * 1000)
    case '90d':
      return new Date(now.getTime() - (12 - index) * 7 * 24 * 60 * 60 * 1000)
    default:
      return new Date(now.getTime() - (7 - index) * 24 * 60 * 60 * 1000)
  }
}
