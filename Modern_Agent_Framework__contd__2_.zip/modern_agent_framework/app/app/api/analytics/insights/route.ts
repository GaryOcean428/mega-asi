
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth/config'
import { AnalyticsInsight } from '@/lib/analytics/types'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const timeRange = searchParams.get('timeRange') || '7d'

    const insights = generateInsights(timeRange)

    return NextResponse.json({ insights })
  } catch (error) {
    console.error('Analytics insights API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

function generateInsights(timeRange: string): AnalyticsInsight[] {
  const insights: AnalyticsInsight[] = []

  // Usage trend insights
  if (timeRange === '7d' || timeRange === '30d') {
    insights.push({
      id: 'usage-trend-1',
      type: 'trend',
      title: 'Agent Creation Spike',
      description: `Agent creation has increased by 45% in the last ${timeRange === '7d' ? 'week' : 'month'}, indicating strong adoption of automation features.`,
      confidence: 87,
      impact: 'high',
      category: 'adoption',
      data: { growth: 45, period: timeRange },
      generatedAt: new Date(),
      actionable: true,
      actions: [
        { label: 'Create More Templates', action: 'create_templates' },
        { label: 'Improve Onboarding', action: 'enhance_onboarding' }
      ]
    })
  }

  // Performance insights
  insights.push({
    id: 'performance-1',
    type: 'recommendation',
    title: 'Response Time Optimization',
    description: 'Average response time has increased to 2.3s. Consider implementing caching strategies to improve performance.',
    confidence: 92,
    impact: 'medium',
    category: 'performance',
    data: { currentResponseTime: 2.3, targetResponseTime: 1.0 },
    generatedAt: new Date(),
    actionable: true,
    actions: [
      { label: 'Enable Redis Caching', action: 'enable_caching' },
      { label: 'Optimize Database Queries', action: 'optimize_db' }
    ]
  })

  // User engagement insights
  if (timeRange !== '24h') {
    insights.push({
      id: 'engagement-1',
      type: 'trend',
      title: 'Feature Adoption Pattern',
      description: 'Collaboration features are being adopted 3x faster than expected, suggesting strong team-oriented use cases.',
      confidence: 78,
      impact: 'medium',
      category: 'engagement',
      data: { adoptionRate: 3.0, feature: 'collaborations' },
      generatedAt: new Date(),
      actionable: true,
      actions: [
        { label: 'Expand Team Features', action: 'expand_team_features' },
        { label: 'Create Team Tutorials', action: 'team_tutorials' }
      ]
    })
  }

  // Error rate insights
  insights.push({
    id: 'error-1',
    type: 'alert',
    title: 'Agent Execution Errors',
    description: 'Detected 12% increase in agent execution failures. Most common error: MCP connection timeout.',
    confidence: 94,
    impact: 'high',
    category: 'reliability',
    data: { errorIncrease: 12, commonError: 'MCP timeout' },
    generatedAt: new Date(),
    actionable: true,
    actions: [
      { label: 'Check MCP Health', action: 'check_mcp_health' },
      { label: 'Increase Timeout Limits', action: 'increase_timeouts' }
    ]
  })

  // Long-term insights for extended time ranges
  if (timeRange === '90d') {
    insights.push({
      id: 'longterm-1',
      type: 'trend',
      title: 'Seasonal Usage Patterns',
      description: 'User activity peaks on Tuesdays and Wednesdays, with 40% higher agent creation rates.',
      confidence: 85,
      impact: 'low',
      category: 'patterns',
      data: { peakDays: ['Tuesday', 'Wednesday'], increaseRate: 40 },
      generatedAt: new Date(),
      actionable: true,
      actions: [
        { label: 'Schedule Maintenance', action: 'schedule_maintenance' },
        { label: 'Optimize Peak Hours', action: 'optimize_peak' }
      ]
    })
  }

  return insights
}
