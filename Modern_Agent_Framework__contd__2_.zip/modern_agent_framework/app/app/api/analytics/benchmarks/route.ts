
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth/config'
import { PerformanceBenchmark } from '@/lib/analytics/types'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const benchmarks = generateBenchmarks()

    return NextResponse.json({ benchmarks })
  } catch (error) {
    console.error('Analytics benchmarks API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

function generateBenchmarks(): PerformanceBenchmark[] {
  return [
    {
      metric: 'Response Time',
      current: 1.2,
      target: 1.0,
      benchmark: 0.8,
      status: 'good',
      trend: 'improving'
    },
    {
      metric: 'Success Rate',
      current: 94.2,
      target: 95.0,
      benchmark: 98.0,
      status: 'good',
      trend: 'stable'
    },
    {
      metric: 'User Satisfaction',
      current: 4.6,
      target: 4.5,
      benchmark: 4.8,
      status: 'excellent',
      trend: 'improving'
    },
    {
      metric: 'Agent Utilization',
      current: 67.3,
      target: 70.0,
      benchmark: 85.0,
      status: 'needs_improvement',
      trend: 'improving'
    },
    {
      metric: 'Error Rate',
      current: 2.1,
      target: 2.0,
      benchmark: 1.0,
      status: 'needs_improvement',
      trend: 'declining'
    },
    {
      metric: 'Uptime',
      current: 99.8,
      target: 99.9,
      benchmark: 99.95,
      status: 'excellent',
      trend: 'stable'
    }
  ]
}
