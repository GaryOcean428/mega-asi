
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';
import crypto from 'crypto';

const forgotPasswordSchema = z.object({
  email: z.string().email('Invalid email address'),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate input
    const validationResult = forgotPasswordSchema.safeParse(body);
    if (!validationResult.success) {
      return NextResponse.json(
        { message: validationResult.error.errors[0].message },
        { status: 400 }
      );
    }

    const { email } = validationResult.data;
    const normalizedEmail = email.toLowerCase().trim();

    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail }
    });

    // Always return success to prevent email enumeration attacks
    if (!user) {
      return NextResponse.json(
        { message: 'If an account with that email exists, we sent you a reset link.' },
        { status: 200 }
      );
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetTokenExpiry = new Date(Date.now() + 3600000); // 1 hour from now

    // Create or update verification token
    await prisma.verificationToken.upsert({
      where: {
        identifier_token: {
          identifier: normalizedEmail,
          token: resetToken,
        },
      },
      update: {
        expires: resetTokenExpiry,
      },
      create: {
        identifier: normalizedEmail,
        token: resetToken,
        expires: resetTokenExpiry,
      },
    });

    // In a real application, you would send an email here
    // For now, we'll just log it (remove in production)
    console.log('Password reset token for', normalizedEmail, ':', resetToken);
    console.log('Reset URL: http://localhost:3000/auth/reset-password?token=' + resetToken);

    // TODO: Send actual email
    // await sendPasswordResetEmail(normalizedEmail, resetToken);

    return NextResponse.json(
      { message: 'If an account with that email exists, we sent you a reset link.' },
      { status: 200 }
    );

  } catch (error) {
    console.error('Forgot password error:', error);
    
    return NextResponse.json(
      { message: 'Internal server error. Please try again later.' },
      { status: 500 }
    );
  }
}
