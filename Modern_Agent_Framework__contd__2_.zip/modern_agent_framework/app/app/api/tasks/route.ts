
import { NextRequest, NextResponse } from 'next/server'
import { AgentEngine } from '@/lib/agent-engine'
import { CreateTaskRequest } from '@/lib/types'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export const dynamic = 'force-dynamic'

// GET /api/tasks - List all tasks
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const agentId = searchParams.get('agentId')
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '50')

    const where: any = {}
    if (agentId) where.agentId = agentId
    if (status) where.status = status

    const tasks = await prisma.task.findMany({
      where,
      include: {
        agent: true,
        parentTask: true,
        subTasks: true,
        executions: {
          orderBy: { step: 'desc' },
          take: 1
        },
        _count: {
          select: {
            subTasks: true,
            executions: true,
            messages: true
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: limit
    })

    return NextResponse.json({ tasks })
  } catch (error) {
    console.error('Error fetching tasks:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tasks' },
      { status: 500 }
    )
  }
}

// POST /api/tasks - Create new task
export async function POST(request: NextRequest) {
  try {
    const body: CreateTaskRequest = await request.json()
    
    if (!body.title || !body.description) {
      return NextResponse.json(
        { error: 'Title and description are required' },
        { status: 400 }
      )
    }

    const task = await AgentEngine.createTask({
      title: body.title,
      description: body.description,
      instructions: body.instructions,
      priority: body.priority,
      agentId: body.agentId,
      parentTaskId: body.parentTaskId
    })

    return NextResponse.json({ task }, { status: 201 })
  } catch (error) {
    console.error('Error creating task:', error)
    return NextResponse.json(
      { error: 'Failed to create task' },
      { status: 500 }
    )
  }
}
