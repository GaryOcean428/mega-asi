
export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950 p-8">
      <div className="container mx-auto max-w-4xl">
        <div className="bg-black/40 rounded-lg p-8 border border-gray-800">
          <h1 className="text-3xl font-bold text-white mb-6">Privacy Policy</h1>
          
          <div className="prose prose-invert max-w-none">
            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">1. Information We Collect</h2>
            <p className="text-gray-300 mb-4">
              We collect information you provide directly to us, such as when you create an account, use our services, or contact us for support.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">2. How We Use Your Information</h2>
            <p className="text-gray-300 mb-4">
              We use the information we collect to provide, maintain, and improve our services, process transactions, and communicate with you.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">3. Information Sharing</h2>
            <p className="text-gray-300 mb-4">
              We do not sell, rent, or share your personal information with third parties without your explicit consent, except as described in this policy.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">4. Data Security</h2>
            <p className="text-gray-300 mb-4">
              We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">5. Your Rights</h2>
            <p className="text-gray-300 mb-4">
              You have the right to access, update, or delete your personal information. You may also opt out of certain communications from us.
            </p>

            <h2 className="text-xl font-semibold text-gray-200 mt-6 mb-4">6. Contact Us</h2>
            <p className="text-gray-300 mb-4">
              If you have any questions about this Privacy Policy, please contact us through our support channels.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
