
'use client'

import { io, Socket } from 'socket.io-client'
import { useSession } from 'next-auth/react'
import { useEffect, useState, useCallback } from 'react'

interface UseWebSocketOptions {
  autoConnect?: boolean
  workspaceId?: string
}

interface WebSocketState {
  connected: boolean
  connecting: boolean
  error: string | null
}

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const { autoConnect = false, workspaceId } = options // Disable auto-connect by default
  const { data: session } = useSession() || {}
  const [socket, setSocket] = useState<Socket | null>(null)
  const [state, setState] = useState<WebSocketState>({
    connected: false,
    connecting: false,
    error: null
  })

  useEffect(() => {
    if (!autoConnect || !session?.user || !(session.user as any).id) return

    // Check if WebSocket URL is configured
    const wsUrl = process.env.NEXT_PUBLIC_WS_URL
    if (!wsUrl || wsUrl.trim() === '') {
      console.log('WebSocket URL not configured, skipping connection')
      setState(prev => ({ ...prev, error: 'WebSocket URL not configured' }))
      return
    }

    setState(prev => ({ ...prev, connecting: true, error: null }))

    const newSocket = io(wsUrl, {
      transports: ['websocket', 'polling'],
      autoConnect: false,
      timeout: 5000,
      reconnection: false
    })

    // Connection handlers
    newSocket.on('connect', () => {
      console.log('WebSocket connected')
      setState(prev => ({ ...prev, connected: true, connecting: false }))
      
      // Authenticate user
      newSocket.emit('authenticate', { 
        userId: (session.user as any).id, 
        workspaceId 
      })
    })

    newSocket.on('disconnect', () => {
      console.log('WebSocket disconnected')
      setState(prev => ({ ...prev, connected: false, connecting: false }))
    })

    newSocket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error)
      setState(prev => ({ 
        ...prev, 
        connected: false, 
        connecting: false, 
        error: error.message 
      }))
    })

    // Authentication handlers
    newSocket.on('authenticated', (data) => {
      console.log('WebSocket authenticated:', data)
    })

    newSocket.on('auth_error', (error) => {
      console.error('WebSocket auth error:', error)
      setState(prev => ({ 
        ...prev, 
        error: error.message 
      }))
    })

    newSocket.connect()
    setSocket(newSocket)

    return () => {
      newSocket.disconnect()
    }
  }, [(session?.user as any)?.id, autoConnect, workspaceId])

  // Helper functions
  const joinChat = useCallback((roomId: string) => {
    if (!socket?.connected) return
    socket.emit('join_chat', { roomId })
  }, [socket])

  const sendMessage = useCallback((data: {
    roomId: string
    content: any
    threadId?: string
    replyToId?: string
  }) => {
    if (!socket?.connected) return
    socket.emit('send_message', data)
  }, [socket])

  const sendTyping = useCallback((roomId: string, isTyping: boolean) => {
    if (!socket?.connected) return
    socket.emit('typing', { roomId, isTyping })
  }, [socket])

  const subscribeToTask = useCallback((taskId: string) => {
    if (!socket?.connected) return
    socket.emit('subscribe_task', { taskId })
  }, [socket])

  const subscribeToAgent = useCallback((agentId: string) => {
    if (!socket?.connected) return
    socket.emit('subscribe_agent', { agentId })
  }, [socket])

  const on = useCallback((event: string, handler: (...args: any[]) => void) => {
    if (!socket) return
    socket.on(event, handler)
    return () => socket.off(event, handler)
  }, [socket])

  const off = useCallback((event: string, handler?: (...args: any[]) => void) => {
    if (!socket) return
    if (handler) {
      socket.off(event, handler)
    } else {
      socket.off(event)
    }
  }, [socket])

  return {
    socket,
    state,
    joinChat,
    sendMessage,
    sendTyping,
    subscribeToTask,
    subscribeToAgent,
    on,
    off
  }
}

// Hook for managing typing indicators
export function useTypingIndicator(roomId: string, debounceMs: number = 1000) {
  const { sendTyping } = useWebSocket()
  const [isTyping, setIsTyping] = useState(false)
  const [typingUsers, setTypingUsers] = useState<string[]>([])

  useEffect(() => {
    let timeoutId: NodeJS.Timeout

    if (isTyping) {
      sendTyping(roomId, true)
      
      timeoutId = setTimeout(() => {
        setIsTyping(false)
        sendTyping(roomId, false)
      }, debounceMs)
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId)
    }
  }, [isTyping, roomId, debounceMs, sendTyping])

  const startTyping = useCallback(() => {
    setIsTyping(true)
  }, [])

  const stopTyping = useCallback(() => {
    setIsTyping(false)
    sendTyping(roomId, false)
  }, [roomId, sendTyping])

  return {
    isTyping,
    typingUsers,
    startTyping,
    stopTyping,
    setTypingUsers
  }
}
