
import { Server } from 'socket.io'
import { createServer } from 'http'
import { pubsub } from '@/lib/redis/pubsub'
import { cache } from '@/lib/redis/cache'
import { prisma } from '@/lib/prisma'

export interface SocketUser {
  id: string
  email: string
  name?: string | null
  workspaceId?: string
}

export class WebSocketServer {
  private io: Server
  private userSockets: Map<string, string[]> = new Map() // userId -> socketIds
  private socketUsers: Map<string, SocketUser> = new Map() // socketId -> user

  constructor(server: any) {
    this.io = new Server(server, {
      cors: {
        origin: process.env.NEXTAUTH_URL || "http://localhost:3000",
        methods: ["GET", "POST"],
        credentials: true
      },
      transports: ['websocket', 'polling']
    })

    this.setupEventHandlers()
    this.setupRedisSubscriptions()
  }

  private setupEventHandlers() {
    this.io.on('connection', (socket) => {
      console.log(`Socket connected: ${socket.id}`)

      // Handle user authentication
      socket.on('authenticate', async (data: { userId: string, workspaceId?: string }) => {
        try {
          const user = await prisma.user.findUnique({
            where: { id: data.userId },
            select: { id: true, email: true, name: true }
          })

          if (!user) {
            socket.emit('auth_error', { message: 'User not found' })
            return
          }

          // Store user-socket mapping
          const socketUser: SocketUser = { ...user, workspaceId: data.workspaceId }
          this.socketUsers.set(socket.id, socketUser)

          // Track user sockets
          const userSocketIds = this.userSockets.get(user.id) || []
          userSocketIds.push(socket.id)
          this.userSockets.set(user.id, userSocketIds)

          // Update online status
          await cache.setUserOnline(user.id, 300) // 5 minutes TTL

          // Join workspace rooms
          if (data.workspaceId) {
            socket.join(`workspace:${data.workspaceId}`)
            socket.join(`user:${user.id}`)
          }

          socket.emit('authenticated', { success: true, user })
          
          // Broadcast user online status
          this.io.to(`workspace:${data.workspaceId}`).emit('user_status', {
            userId: user.id,
            status: 'online'
          })
        } catch (error) {
          console.error('Authentication error:', error)
          socket.emit('auth_error', { message: 'Authentication failed' })
        }
      })

      // Handle chat room joining
      socket.on('join_chat', async (data: { roomId: string }) => {
        const user = this.socketUsers.get(socket.id)
        if (!user) return

        try {
          // Verify user has access to chat room
          const participant = await prisma.chatParticipant.findFirst({
            where: {
              chatRoomId: data.roomId,
              userId: user.id
            }
          })

          if (!participant) {
            socket.emit('chat_error', { message: 'Access denied to chat room' })
            return
          }

          socket.join(`chat:${data.roomId}`)
          socket.emit('joined_chat', { roomId: data.roomId })
          
          // Update last read timestamp
          await prisma.chatParticipant.update({
            where: {
              id: participant.id
            },
            data: {
              lastReadAt: new Date()
            }
          })
        } catch (error) {
          console.error('Join chat error:', error)
          socket.emit('chat_error', { message: 'Failed to join chat' })
        }
      })

      // Handle typing indicators
      socket.on('typing', (data: { roomId: string, isTyping: boolean }) => {
        const user = this.socketUsers.get(socket.id)
        if (!user) return

        socket.to(`chat:${data.roomId}`).emit('user_typing', {
          userId: user.id,
          isTyping: data.isTyping,
          timestamp: Date.now()
        })

        // Publish typing indicator via Redis for cross-server sync
        pubsub.publishTypingIndicator(data.roomId, user.id, data.isTyping)
      })

      // Handle chat messages
      socket.on('send_message', async (data: {
        roomId: string
        content: any
        threadId?: string
        replyToId?: string
      }) => {
        const user = this.socketUsers.get(socket.id)
        if (!user) return

        try {
          const message = await prisma.chatMessage.create({
            data: {
              content: data.content,
              chatRoomId: data.roomId,
              threadId: data.threadId,
              replyToId: data.replyToId,
              senderUserId: user.id,
              senderType: 'USER'
            },
            include: {
              userSender: {
                select: { id: true, name: true, email: true, image: true }
              },
              agentSender: {
                select: { id: true, name: true, description: true }
              },
              replyTo: {
                include: {
                  userSender: {
                    select: { id: true, name: true }
                  },
                  agentSender: {
                    select: { id: true, name: true }
                  }
                }
              }
            }
          })

          // Broadcast message to room
          this.io.to(`chat:${data.roomId}`).emit('new_message', message)

          // Publish via Redis for cross-server sync
          await pubsub.publishChatMessage(data.roomId, message)
        } catch (error) {
          console.error('Send message error:', error)
          socket.emit('message_error', { message: 'Failed to send message' })
        }
      })

      // Handle agent task execution updates
      socket.on('subscribe_task', (data: { taskId: string }) => {
        socket.join(`task:${data.taskId}`)
      })

      // Handle agent status updates
      socket.on('subscribe_agent', (data: { agentId: string }) => {
        socket.join(`agent:${data.agentId}`)
      })

      // Handle disconnection
      socket.on('disconnect', async () => {
        console.log(`Socket disconnected: ${socket.id}`)
        
        const user = this.socketUsers.get(socket.id)
        if (user) {
          // Remove socket from user's socket list
          const userSocketIds = this.userSockets.get(user.id) || []
          const updatedSocketIds = userSocketIds.filter(id => id !== socket.id)
          
          if (updatedSocketIds.length === 0) {
            // User has no more active sockets - mark offline
            this.userSockets.delete(user.id)
            await cache.delete(`online:${user.id}`)
            
            // Broadcast user offline status
            if (user.workspaceId) {
              this.io.to(`workspace:${user.workspaceId}`).emit('user_status', {
                userId: user.id,
                status: 'offline'
              })
            }
          } else {
            this.userSockets.set(user.id, updatedSocketIds)
          }
          
          this.socketUsers.delete(socket.id)
        }
      })
    })
  }

  private setupRedisSubscriptions() {
    // Subscribe to real-time events from Redis
    pubsub.on('message', (channel: string, message: any) => {
      switch (message.type) {
        case 'chat_message':
          this.io.to(`chat:${message.roomId}`).emit('new_message', message.payload)
          break
        
        case 'agent_status':
          this.io.to(`agent:${message.agentId}`).emit('agent_status_update', message.payload)
          break
        
        case 'task_update':
          if (message.payload?.taskId) {
            this.io.to(`task:${message.payload.taskId}`).emit('task_update', message.payload)
          }
          break
        
        case 'user_typing':
          this.io.to(`chat:${message.roomId}`).emit('user_typing', message.payload)
          break
      }
    })
  }

  public getUserSockets(userId: string): string[] {
    return this.userSockets.get(userId) || []
  }

  public getOnlineUsers(): string[] {
    return Array.from(this.userSockets.keys())
  }

  public sendToUser(userId: string, event: string, data: any) {
    const socketIds = this.getUserSockets(userId)
    socketIds.forEach(socketId => {
      this.io.to(socketId).emit(event, data)
    })
  }

  public sendToRoom(room: string, event: string, data: any) {
    this.io.to(room).emit(event, data)
  }

  public getServer() {
    return this.io
  }
}

// Export singleton instance
let wsServer: WebSocketServer | null = null

export function initializeWebSocketServer(server: any): WebSocketServer {
  if (!wsServer) {
    wsServer = new WebSocketServer(server)
  }
  return wsServer
}

export function getWebSocketServer(): WebSocketServer | null {
  return wsServer
}
