
import { PrismaClient } from '@prisma/client'
import { 
  Agent, 
  Task, 
  Message, 
  AgentStatus, 
  TaskStatus, 
  ExecutionStatus,
  MessageRole,
  Priority 
} from '@prisma/client'
import { AgentContext, TaskExecution } from './types'

const prisma = new PrismaClient()

export class AgentEngine {
  
  // Create a new agent
  static async createAgent(data: {
    name: string
    description?: string
    role: string
    model?: string
    systemPrompt?: string
    capabilities?: string[]
  }) {
    return await prisma.agent.create({
      data: {
        name: data.name,
        description: data.description,
        role: data.role,
        model: data.model || 'gpt-4.1-mini',
        systemPrompt: data.systemPrompt,
        capabilities: data.capabilities || [],
        status: AgentStatus.IDLE
      }
    })
  }

  // Get agent with relationships
  static async getAgent(id: string, includeRelations = true) {
    return await prisma.agent.findUnique({
      where: { id },
      include: includeRelations ? {
        tasks: {
          include: {
            executions: true,
            messages: true
          },
          orderBy: { createdAt: 'desc' },
          take: 10
        },
        sentMessages: {
          orderBy: { createdAt: 'desc' },
          take: 20
        },
        receivedMessages: {
          orderBy: { createdAt: 'desc' },
          take: 20
        },
        _count: {
          select: {
            tasks: true,
            sentMessages: true,
            receivedMessages: true
          }
        }
      } : undefined
    })
  }

  // List all agents with basic metrics
  static async listAgents() {
    return await prisma.agent.findMany({
      include: {
        _count: {
          select: {
            tasks: true,
            sentMessages: true,
            receivedMessages: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })
  }

  // Update agent status
  static async updateAgentStatus(id: string, status: AgentStatus) {
    return await prisma.agent.update({
      where: { id },
      data: { status }
    })
  }

  // Create a new task
  static async createTask(data: {
    title: string
    description: string
    instructions?: string
    priority?: Priority
    agentId?: string
    parentTaskId?: string
  }) {
    return await prisma.task.create({
      data: {
        title: data.title,
        description: data.description,
        instructions: data.instructions,
        priority: data.priority || Priority.MEDIUM,
        agentId: data.agentId,
        parentTaskId: data.parentTaskId,
        status: TaskStatus.PENDING
      },
      include: {
        agent: true,
        parentTask: true,
        subTasks: true
      }
    })
  }

  // Assign task to agent
  static async assignTask(taskId: string, agentId: string) {
    return await prisma.task.update({
      where: { id: taskId },
      data: { 
        agentId,
        status: TaskStatus.IN_PROGRESS,
        startedAt: new Date()
      },
      include: {
        agent: true,
        parentTask: true,
        subTasks: true
      }
    })
  }

  // Update task status and result
  static async updateTaskStatus(
    taskId: string, 
    status: TaskStatus, 
    result?: string,
    error?: string
  ) {
    const updateData: any = {
      status,
      ...(result && { result }),
      ...(error && { metadata: { error } })
    }

    if (status === TaskStatus.COMPLETED || status === TaskStatus.FAILED) {
      updateData.completedAt = new Date()
    }

    return await prisma.task.update({
      where: { id: taskId },
      data: updateData
    })
  }

  // Create task execution step
  static async createTaskExecution(data: {
    taskId: string
    step: number
    action: string
    input?: string
    output?: string
    status?: ExecutionStatus
    error?: string
    metadata?: any
  }) {
    return await prisma.taskExecution.create({
      data: {
        taskId: data.taskId,
        step: data.step,
        action: data.action,
        input: data.input,
        output: data.output,
        status: data.status || ExecutionStatus.RUNNING,
        error: data.error,
        metadata: data.metadata
      }
    })
  }

  // Update task execution
  static async updateTaskExecution(
    id: string,
    data: {
      output?: string
      status?: ExecutionStatus
      error?: string
      metadata?: any
    }
  ) {
    return await prisma.taskExecution.update({
      where: { id },
      data
    })
  }

  // Create message (for agent communication)
  static async createMessage(data: {
    content: string
    role?: MessageRole
    senderId?: string
    receiverId?: string
    taskId?: string
    isInternal?: boolean
    metadata?: any
  }) {
    return await prisma.message.create({
      data: {
        content: data.content,
        role: data.role || MessageRole.ASSISTANT,
        senderId: data.senderId,
        receiverId: data.receiverId,
        taskId: data.taskId,
        isInternal: data.isInternal || false,
        metadata: data.metadata
      },
      include: {
        sender: true,
        receiver: true,
        task: true
      }
    })
  }

  // Get messages for a task or between agents
  static async getMessages(filters: {
    taskId?: string
    senderId?: string
    receiverId?: string
    isInternal?: boolean
    limit?: number
  }) {
    const where: any = {}
    
    if (filters.taskId) where.taskId = filters.taskId
    if (filters.senderId) where.senderId = filters.senderId
    if (filters.receiverId) where.receiverId = filters.receiverId
    if (filters.isInternal !== undefined) where.isInternal = filters.isInternal

    return await prisma.message.findMany({
      where,
      include: {
        sender: true,
        receiver: true,
        task: true
      },
      orderBy: { createdAt: 'desc' },
      take: filters.limit || 50
    })
  }

  // Get agent context for task execution
  static async getAgentContext(agentId: string, taskId: string): Promise<AgentContext | null> {
    const agent = await prisma.agent.findUnique({
      where: { id: agentId }
    })

    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: {
        parentTask: true,
        subTasks: true,
        executions: {
          orderBy: { step: 'desc' }
        }
      }
    })

    if (!agent || !task) return null

    const messages = await prisma.message.findMany({
      where: {
        OR: [
          { taskId },
          { senderId: agentId },
          { receiverId: agentId }
        ]
      },
      include: {
        sender: true,
        receiver: true
      },
      orderBy: { createdAt: 'asc' }
    })

    return {
      agent,
      task,
      messages
    }
  }

  // Get system metrics
  static async getSystemMetrics() {
    const [totalAgents, activeAgents, tasks] = await Promise.all([
      prisma.agent.count(),
      prisma.agent.count({ where: { status: AgentStatus.BUSY } }),
      prisma.task.findMany({
        select: {
          status: true,
          createdAt: true,
          completedAt: true
        }
      })
    ])

    const completedTasks = tasks.filter(t => t.status === TaskStatus.COMPLETED).length
    const pendingTasks = tasks.filter(t => t.status === TaskStatus.PENDING).length
    const failedTasks = tasks.filter(t => t.status === TaskStatus.FAILED).length

    // Calculate average completion time
    const completedTasksWithTime = tasks.filter(t => 
      t.status === TaskStatus.COMPLETED && t.completedAt
    )
    
    const avgCompletionTime = completedTasksWithTime.length > 0
      ? completedTasksWithTime.reduce((sum, task) => {
          const time = task.completedAt!.getTime() - task.createdAt.getTime()
          return sum + time
        }, 0) / completedTasksWithTime.length
      : 0

    return {
      totalAgents,
      activeAgents,
      completedTasks,
      pendingTasks,
      failedTasks,
      avgTaskCompletionTime: Math.round(avgCompletionTime / 1000) // Convert to seconds
    }
  }

  // Clean up old data (optional maintenance)
  static async cleanup() {
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    // Clean up old completed/failed tasks
    await prisma.task.deleteMany({
      where: {
        AND: [
          {
            status: {
              in: [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]
            }
          },
          {
            completedAt: {
              lt: thirtyDaysAgo
            }
          }
        ]
      }
    })

    // Clean up old messages
    await prisma.message.deleteMany({
      where: {
        createdAt: {
          lt: thirtyDaysAgo
        }
      }
    })

    return { success: true, cleanedAt: new Date() }
  }
}
