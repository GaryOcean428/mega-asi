
interface LLMMessage {
  role: 'system' | 'user' | 'assistant'
  content: string | Array<{
    type: 'text' | 'image_url' | 'file'
    text?: string
    image_url?: { url: string }
    file?: { filename: string, file_data: string }
  }>
}

interface LLMRequest {
  messages: LLMMessage[]
  model?: string
  maxTokens?: number
  temperature?: number
  stream?: boolean
  responseFormat?: { type: 'json_object' | 'text' }
  topP?: number
  frequencyPenalty?: number
  presencePenalty?: number
}

interface LLMResponse {
  content: string
  usage?: {
    prompt_tokens: number
    completion_tokens: number
    total_tokens: number
  }
  model?: string
  finishReason?: string
}

// All available models on the platform with their capabilities
export const PLATFORM_MODELS = {
  // OpenAI Models
  'gpt-4.1-mini': {
    name: 'GPT-4.1 Mini',
    provider: 'OpenAI',
    capabilities: ['text', 'code', 'reasoning'],
    contextWindow: 128000,
    costPer1MTokens: { input: 0.15, output: 0.6 },
    description: 'Fast, efficient model for everyday tasks'
  },
  'gpt-4.1': {
    name: 'GPT-4.1',
    provider: 'OpenAI', 
    capabilities: ['text', 'code', 'reasoning', 'multimodal'],
    contextWindow: 1000000,
    costPer1MTokens: { input: 2.5, output: 10 },
    description: 'Most capable OpenAI model with 1M context'
  },
  'gpt-5': {
    name: 'GPT-5',
    provider: 'OpenAI',
    capabilities: ['text', 'code', 'reasoning', 'multimodal', 'advanced_reasoning'],
    contextWindow: 1000000,
    costPer1MTokens: { input: 5.0, output: 15 },
    description: 'Latest OpenAI flagship model'
  },
  'o3-mini': {
    name: 'O3 Mini',
    provider: 'OpenAI',
    capabilities: ['reasoning', 'math', 'code', 'logic'],
    contextWindow: 128000,
    costPer1MTokens: { input: 3.0, output: 12 },
    description: 'Optimized for complex reasoning tasks'
  },
  'o3': {
    name: 'O3',
    provider: 'OpenAI',
    capabilities: ['reasoning', 'math', 'code', 'logic', 'research'],
    contextWindow: 128000,
    costPer1MTokens: { input: 10.0, output: 40 },
    description: 'Advanced reasoning model for complex problems'
  },

  // Anthropic Claude Models
  'claude-4-haiku': {
    name: 'Claude 4 Haiku',
    provider: 'Anthropic',
    capabilities: ['text', 'code', 'reasoning', 'fast_processing'],
    contextWindow: 200000,
    costPer1MTokens: { input: 0.25, output: 1.25 },
    description: 'Fast and efficient Claude model'
  },
  'claude-4-sonnet': {
    name: 'Claude 4 Sonnet',
    provider: 'Anthropic',
    capabilities: ['text', 'code', 'reasoning', 'writing', 'analysis'],
    contextWindow: 200000,
    costPer1MTokens: { input: 3.0, output: 15 },
    description: 'Balanced Claude model for most tasks'
  },
  'claude-4-opus': {
    name: 'Claude 4 Opus',
    provider: 'Anthropic',
    capabilities: ['text', 'code', 'reasoning', 'writing', 'analysis', 'creative'],
    contextWindow: 200000,
    costPer1MTokens: { input: 15.0, output: 75 },
    description: 'Most capable Claude model'
  },

  // Google Gemini Models
  'gemini-2.5-flash': {
    name: 'Gemini 2.5 Flash',
    provider: 'Google',
    capabilities: ['text', 'code', 'multimodal', 'fast_processing'],
    contextWindow: 1000000,
    costPer1MTokens: { input: 0.075, output: 0.3 },
    description: 'Ultra-fast multimodal model'
  },
  'gemini-2.5-pro': {
    name: 'Gemini 2.5 Pro',
    provider: 'Google',
    capabilities: ['text', 'code', 'multimodal', 'reasoning', 'analysis'],
    contextWindow: 2000000,
    costPer1MTokens: { input: 1.25, output: 5.0 },
    description: 'Advanced Gemini with 2M context'
  },

  // Meta LLaMA Models
  'llama-4-scout': {
    name: 'LLaMA 4 Scout',
    provider: 'Meta',
    capabilities: ['text', 'code', 'reasoning', 'multilingual'],
    contextWindow: 10000000,
    costPer1MTokens: { input: 0.1, output: 0.1 },
    description: 'Open-source model with 10M context'
  },
  'llama-4-maverick': {
    name: 'LLaMA 4 Maverick',
    provider: 'Meta',
    capabilities: ['text', 'code', 'reasoning', 'creative', 'multilingual'],
    contextWindow: 1000000,
    costPer1MTokens: { input: 0.15, output: 0.15 },
    description: 'Advanced open-source model'
  },

  // xAI Grok Models  
  'grok-4': {
    name: 'Grok 4',
    provider: 'xAI',
    capabilities: ['text', 'code', 'reasoning', 'real_time', 'web_search'],
    contextWindow: 128000,
    costPer1MTokens: { input: 2.0, output: 8.0 },
    description: 'Real-time model with web access'
  },

  // DeepSeek Models
  'deepseek-r1': {
    name: 'DeepSeek R1',
    provider: 'DeepSeek',
    capabilities: ['reasoning', 'math', 'code', 'logic'],
    contextWindow: 64000,
    costPer1MTokens: { input: 0.55, output: 2.2 },
    description: 'Advanced reasoning at low cost'
  },

  // Alibaba Qwen Models
  'qwen-2.5-coder': {
    name: 'Qwen 2.5 Coder',
    provider: 'Alibaba',
    capabilities: ['code', 'programming', 'debugging'],
    contextWindow: 128000,
    costPer1MTokens: { input: 0.3, output: 0.6 },
    description: 'Specialized coding model'
  },
  'qwen-2.5-math': {
    name: 'Qwen 2.5 Math',
    provider: 'Alibaba',
    capabilities: ['math', 'reasoning', 'problem_solving'],
    contextWindow: 128000,
    costPer1MTokens: { input: 0.3, output: 0.6 },
    description: 'Specialized mathematics model'
  }
} as const

export type ModelId = keyof typeof PLATFORM_MODELS

export class LLMClient {
  private apiKey: string
  private baseUrl: string

  constructor() {
    this.apiKey = process.env.ABACUSAI_API_KEY!
    this.baseUrl = 'https://apps.abacus.ai/v1/chat/completions'
  }

  // Get all available models
  static getAvailableModels() {
    return PLATFORM_MODELS
  }

  // Get models by capability
  static getModelsByCapability(capability: string) {
    return Object.entries(PLATFORM_MODELS)
      .filter(([, model]) => (model.capabilities as readonly string[]).includes(capability))
      .map(([id, model]) => ({ id: id as ModelId, ...model }))
  }

  // Get models by provider
  static getModelsByProvider(provider: string) {
    return Object.entries(PLATFORM_MODELS)
      .filter(([, model]) => model.provider === provider)
      .map(([id, model]) => ({ id: id as ModelId, ...model }))
  }

  // Get best model for task type
  static getBestModelForTask(taskType: 'reasoning' | 'coding' | 'writing' | 'multimodal' | 'fast' | 'cost_effective') {
    switch (taskType) {
      case 'reasoning':
        return 'o3'
      case 'coding':
        return 'claude-4-sonnet'
      case 'writing':
        return 'claude-4-opus'
      case 'multimodal':
        return 'gemini-2.5-pro'
      case 'fast':
        return 'gemini-2.5-flash'
      case 'cost_effective':
        return 'llama-4-scout'
      default:
        return 'gpt-4.1-mini'
    }
  }

  async complete(request: LLMRequest): Promise<LLMResponse> {
    if (request.stream) {
      throw new Error('Use streamComplete for streaming responses')
    }

    const body: any = {
      model: request.model || 'gpt-4.1-mini',
      messages: request.messages,
      max_tokens: request.maxTokens || 3000,
      temperature: request.temperature || 0.7,
      stream: false
    }

    // Add optional parameters
    if (request.topP !== undefined) body.top_p = request.topP
    if (request.frequencyPenalty !== undefined) body.frequency_penalty = request.frequencyPenalty
    if (request.presencePenalty !== undefined) body.presence_penalty = request.presencePenalty
    if (request.responseFormat) body.response_format = request.responseFormat

    const response = await fetch(this.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify(body)
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`LLM API error (${response.status}): ${errorText}`)
    }

    const data = await response.json()
    
    return {
      content: data.choices?.[0]?.message?.content || '',
      usage: data.usage,
      model: data.model,
      finishReason: data.choices?.[0]?.finish_reason
    }
  }

  async *streamComplete(request: LLMRequest): AsyncGenerator<string, void, unknown> {
    const body: any = {
      model: request.model || 'gpt-4.1-mini',
      messages: request.messages,
      max_tokens: request.maxTokens || 3000,
      temperature: request.temperature || 0.7,
      stream: true
    }

    // Add optional parameters
    if (request.topP !== undefined) body.top_p = request.topP
    if (request.frequencyPenalty !== undefined) body.frequency_penalty = request.frequencyPenalty
    if (request.presencePenalty !== undefined) body.presence_penalty = request.presencePenalty
    if (request.responseFormat) body.response_format = request.responseFormat

    const response = await fetch(this.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify(body)
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`LLM API error (${response.status}): ${errorText}`)
    }

    const reader = response.body?.getReader()
    if (!reader) {
      throw new Error('Failed to get response reader')
    }

    const decoder = new TextDecoder()
    let buffer = ''

    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim()
            if (data === '[DONE]') return

            try {
              const parsed = JSON.parse(data)
              const content = parsed.choices?.[0]?.delta?.content
              if (content) {
                yield content
              }
            } catch (e) {
              // Skip invalid JSON chunks
            }
          }
        }
      }
    } finally {
      reader.releaseLock()
    }
  }

  // Process files (PDF, images, etc.) with multimodal models
  async processFile(
    file: Buffer,
    filename: string,
    prompt: string,
    model: ModelId = 'gpt-4.1'
  ): Promise<LLMResponse> {
    const fileExtension = filename.split('.').pop()?.toLowerCase()
    const base64String = file.toString('base64')
    
    let content: Array<{
      type: 'text' | 'image_url' | 'file'
      text?: string
      image_url?: { url: string }
      file?: { filename: string, file_data: string }
    }>

    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExtension || '')) {
      // Image processing
      content = [
        { type: 'text', text: prompt },
        { 
          type: 'image_url', 
          image_url: { url: `data:image/${fileExtension};base64,${base64String}` }
        }
      ]
    } else if (fileExtension === 'pdf') {
      // PDF processing
      content = [
        {
          type: 'file',
          file: {
            filename,
            file_data: `data:application/pdf;base64,${base64String}`
          }
        },
        { type: 'text', text: prompt }
      ]
    } else {
      throw new Error(`Unsupported file type: ${fileExtension}`)
    }

    return this.complete({
      messages: [
        {
          role: 'user',
          content
        }
      ],
      model
    })
  }

  // Auto-select best model for agent based on role and task
  autoSelectModel(
    agentRole: string,
    taskType?: 'reasoning' | 'coding' | 'writing' | 'multimodal' | 'fast' | 'cost_effective'
  ): ModelId {
    // Role-based model selection
    const roleModels: Record<string, ModelId> = {
      'researcher': 'o3',
      'coder': 'claude-4-sonnet',
      'writer': 'claude-4-opus',
      'analyst': 'gemini-2.5-pro',
      'assistant': 'gpt-4.1-mini',
      'reasoning': 'o3-mini',
      'creative': 'claude-4-opus',
      'translator': 'llama-4-maverick',
      'math': 'qwen-2.5-math'
    }

    // Task type takes precedence
    if (taskType) {
      return LLMClient.getBestModelForTask(taskType)
    }

    // Check role-specific models
    for (const [role, model] of Object.entries(roleModels)) {
      if (agentRole.toLowerCase().includes(role)) {
        return model
      }
    }

    // Default fallback
    return 'gpt-4.1-mini'
  }

  // Estimate cost for a request
  estimateCost(
    messageLength: number,
    responseLength: number,
    model: ModelId = 'gpt-4.1-mini'
  ): { inputCost: number, outputCost: number, totalCost: number } {
    const modelInfo = PLATFORM_MODELS[model]
    const inputTokens = Math.ceil(messageLength / 4) // Rough approximation
    const outputTokens = Math.ceil(responseLength / 4)
    
    const inputCost = (inputTokens / 1000000) * modelInfo.costPer1MTokens.input
    const outputCost = (outputTokens / 1000000) * modelInfo.costPer1MTokens.output
    
    return {
      inputCost: Math.round(inputCost * 10000) / 10000,
      outputCost: Math.round(outputCost * 10000) / 10000,
      totalCost: Math.round((inputCost + outputCost) * 10000) / 10000
    }
  }

  // Enhanced agent execution prompts with model-aware features
  createAgentPrompt(
    agent: { name: string; role: string; model?: string | null; systemPrompt?: string | null },
    task: { title: string; description: string; instructions?: string | null },
    context?: {
      previousMessages?: Array<{ role: string; content: string }>
      executionHistory?: Array<{ step: number; action: string; output?: string | null }>
      availableTools?: string[]
      collaborators?: Array<{ name: string; role: string }>
    }
  ): LLMMessage[] {
    const messages: LLMMessage[] = []
    const modelInfo = agent.model && PLATFORM_MODELS[agent.model as ModelId] 
      ? PLATFORM_MODELS[agent.model as ModelId] 
      : null

    // Enhanced system prompt with model-specific capabilities
    let systemContent = `You are ${agent.name}, a ${agent.role} agent in an advanced autonomous agent framework.

Your role: ${agent.role}
Current task: ${task.title}
Task description: ${task.description}`

    // Add model-specific capabilities
    if (modelInfo) {
      systemContent += `\n\nYour AI model: ${modelInfo.name} (${modelInfo.provider})
Capabilities: ${modelInfo.capabilities.join(', ')}
Context window: ${modelInfo.contextWindow.toLocaleString()} tokens`
    }

    if (agent.systemPrompt) {
      systemContent += `\n\nPersonality and instructions: ${agent.systemPrompt}`
    }

    if (task.instructions) {
      systemContent += `\n\nSpecific task instructions: ${task.instructions}`
    }

    // Add available tools
    if (context?.availableTools && context.availableTools.length > 0) {
      systemContent += `\n\nAvailable tools: ${context.availableTools.join(', ')}`
    }

    // Add collaborator context
    if (context?.collaborators && context.collaborators.length > 0) {
      systemContent += `\n\nCollaborating agents:
${context.collaborators.map(c => `- ${c.name} (${c.role})`).join('\n')}`
    }

    systemContent += `\n\nRespond thoughtfully and take action as needed to complete the task. Be specific and actionable in your responses. Leverage your unique capabilities and collaborate effectively with other agents when available.`

    messages.push({
      role: 'system',
      content: systemContent
    })

    // Add previous messages for context
    if (context?.previousMessages) {
      context.previousMessages.forEach(msg => {
        messages.push({
          role: msg.role as 'system' | 'user' | 'assistant',
          content: msg.content
        })
      })
    }

    // Add execution history
    if (context?.executionHistory && context.executionHistory.length > 0) {
      const historyContent = context.executionHistory
        .map(exec => `Step ${exec.step}: ${exec.action}${exec.output ? ` - Result: ${exec.output}` : ''}`)
        .join('\n')

      messages.push({
        role: 'user',
        content: `Previous execution steps:\n${historyContent}\n\nWhat should be the next step?`
      })
    }

    return messages
  }

  // Enhanced collaboration prompts with multi-agent coordination
  createCollaborationPrompt(
    agents: Array<{ name: string; role: string; model?: string | null }>,
    task: { title: string; description: string },
    currentAgent: { name: string; role: string; model?: string | null },
    previousOutputs?: Array<{ agentName: string; agentRole: string; output: string; timestamp?: Date }>,
    collaborationType: 'sequential' | 'parallel' | 'hierarchical' = 'sequential'
  ): LLMMessage[] {
    const messages: LLMMessage[] = []
    const currentModelInfo = currentAgent.model && PLATFORM_MODELS[currentAgent.model as ModelId] 
      ? PLATFORM_MODELS[currentAgent.model as ModelId] 
      : null

    let systemContent = `You are ${currentAgent.name}, a ${currentAgent.role} agent in a multi-agent collaboration.

Collaboration type: ${collaborationType}
Task: ${task.title}
Description: ${task.description}

Team composition:
${agents.map(a => {
  const modelInfo = a.model && PLATFORM_MODELS[a.model as ModelId] 
    ? PLATFORM_MODELS[a.model as ModelId] 
    : null
  return `- ${a.name} (${a.role})${modelInfo ? ` - ${modelInfo.name}` : ''}`
}).join('\n')}

Your role: ${currentAgent.role}`

    if (currentModelInfo) {
      systemContent += `
Your model: ${currentModelInfo.name} with capabilities: ${currentModelInfo.capabilities.join(', ')}`
    }

    if (previousOutputs && previousOutputs.length > 0) {
      systemContent += `\n\nPrevious contributions:
${previousOutputs.map(p => `${p.agentName} (${p.agentRole}): ${p.output}`).join('\n\n')}`
    }

    // Collaboration-specific instructions
    switch (collaborationType) {
      case 'sequential':
        systemContent += `\n\nSequential collaboration: Build directly upon the previous agent's work and pass clear outputs to the next agent.`
        break
      case 'parallel':
        systemContent += `\n\nParallel collaboration: Work independently on your specialized aspect and ensure your output can integrate with others.`
        break
      case 'hierarchical':
        systemContent += `\n\nHierarchical collaboration: Follow the coordination structure and provide specific deliverables as requested.`
        break
    }

    systemContent += `\n\nProvide your specialized contribution to this collaborative task. Be clear about your outputs and how they connect to the overall goal.`

    messages.push({
      role: 'system',
      content: systemContent
    })

    return messages
  }

  // Create JSON-structured prompts for complex data extraction
  createStructuredPrompt(
    task: string,
    outputSchema: Record<string, any>,
    model: ModelId = 'gpt-4.1'
  ): LLMMessage[] {
    const schemaDescription = JSON.stringify(outputSchema, null, 2)
    
    return [
      {
        role: 'system',
        content: `You are an AI assistant that provides structured JSON responses. Always respond with valid JSON that matches the specified schema exactly.`
      },
      {
        role: 'user',
        content: `${task}

Please respond in JSON format with the following structure:
${schemaDescription}

Respond with raw JSON only. Do not include code blocks, markdown, or any other formatting.`
      }
    ]
  }
}

export const llmClient = new LLMClient()
