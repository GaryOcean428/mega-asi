
import { safeRedis, getRedisClient, isRedisAvailable } from './client'

export class CacheManager {
  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await safeRedis.get(key)
      if (!value) return null
      return JSON.parse(value)
    } catch (error) {
      console.warn('Cache get error (continuing without cache):', error)
      return null
    }
  }

  async set(key: string, value: any, ttlSeconds?: number): Promise<void> {
    try {
      const serialized = JSON.stringify(value)
      await safeRedis.set(key, serialized, ttlSeconds)
    } catch (error) {
      console.warn('Cache set error (continuing without cache):', error)
    }
  }

  async delete(key: string): Promise<void> {
    try {
      await safeRedis.del(key)
    } catch (error) {
      console.warn('Cache delete error (continuing without cache):', error)
    }
  }

  async exists(key: string): Promise<boolean> {
    try {
      const redis = getRedisClient()
      if (!redis || !isRedisAvailable()) return false
      const result = await redis.exists(key)
      return result === 1
    } catch (error) {
      console.warn('Cache exists error (continuing without cache):', error)
      return false
    }
  }

  async increment(key: string, amount: number = 1): Promise<number> {
    try {
      const redis = getRedisClient()
      if (!redis || !isRedisAvailable()) return 0
      return await redis.incrby(key, amount)
    } catch (error) {
      console.warn('Cache increment error (continuing without cache):', error)
      return 0
    }
  }

  async expire(key: string, seconds: number): Promise<void> {
    try {
      const redis = getRedisClient()
      if (!redis || !isRedisAvailable()) return
      await redis.expire(key, seconds)
    } catch (error) {
      console.warn('Cache expire error (continuing without cache):', error)
    }
  }

  async getUserSession(sessionId: string): Promise<any> {
    return this.get(`session:${sessionId}`)
  }

  async setUserSession(sessionId: string, data: any, ttl: number = 3600): Promise<void> {
    return this.set(`session:${sessionId}`, data, ttl)
  }

  async setUserOnline(userId: string, ttl: number = 300): Promise<void> {
    return this.set(`online:${userId}`, { status: 'online', timestamp: Date.now() }, ttl)
  }

  async isUserOnline(userId: string): Promise<boolean> {
    return this.exists(`online:${userId}`)
  }

  async cacheAgentStatus(agentId: string, status: any, ttl: number = 60): Promise<void> {
    return this.set(`agent:status:${agentId}`, status, ttl)
  }

  async getAgentStatus(agentId: string): Promise<any> {
    return this.get(`agent:status:${agentId}`)
  }
}

export const cache = new CacheManager()
