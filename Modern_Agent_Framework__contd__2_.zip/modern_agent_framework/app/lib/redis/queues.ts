
import { getRedisClient, isRedisAvailable } from './client'

export interface QueueJob {
  id: string
  type: string
  payload: any
  priority: number
  attempts: number
  maxAttempts: number
  delay: number
  createdAt: number
}

export class TaskQueue {
  private queueName: string
  private processingName: string

  constructor(queueName: string) {
    this.queueName = `queue:${queueName}`
    this.processingName = `processing:${queueName}`
  }

  private getRedis() {
    return getRedisClient()
  }

  private isAvailable(): boolean {
    return isRedisAvailable() && this.getRedis() !== null
  }

  async addJob(job: Omit<QueueJob, 'id' | 'createdAt'>): Promise<string> {
    const jobId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    const fullJob: QueueJob = {
      ...job,
      id: jobId,
      createdAt: Date.now()
    }

    if (!this.isAvailable()) {
      console.warn('Redis not available, job will not be queued')
      return jobId
    }

    const redis = this.getRedis()!
    const score = Date.now() + (job.delay || 0)
    await redis.zadd(this.queueName, score, JSON.stringify(fullJob))
    return jobId
  }

  async getNextJob(): Promise<QueueJob | null> {
    if (!this.isAvailable()) {
      return null
    }

    const redis = this.getRedis()!
    const now = Date.now()
    const jobs = await redis.zrangebyscore(
      this.queueName, 
      0, 
      now, 
      'WITHSCORES', 
      'LIMIT', 
      0, 
      1
    )

    if (jobs.length === 0) return null

    const jobData = jobs[0]
    const job: QueueJob = JSON.parse(jobData)

    // Move job to processing queue
    await redis.multi()
      .zrem(this.queueName, jobData)
      .zadd(this.processingName, now, jobData)
      .exec()

    return job
  }

  async completeJob(jobId: string): Promise<void> {
    if (!this.isAvailable()) return

    const redis = this.getRedis()!
    const jobs = await redis.zrange(this.processingName, 0, -1)
    for (const jobData of jobs) {
      const job: QueueJob = JSON.parse(jobData)
      if (job.id === jobId) {
        await redis.zrem(this.processingName, jobData)
        break
      }
    }
  }

  async failJob(jobId: string, error?: string): Promise<void> {
    if (!this.isAvailable()) return

    const redis = this.getRedis()!
    const jobs = await redis.zrange(this.processingName, 0, -1)
    for (const jobData of jobs) {
      const job: QueueJob = JSON.parse(jobData)
      if (job.id === jobId) {
        job.attempts += 1
        
        if (job.attempts >= job.maxAttempts) {
          // Move to dead letter queue
          await redis.multi()
            .zrem(this.processingName, jobData)
            .zadd(`dead:${this.queueName}`, Date.now(), JSON.stringify({ ...job, error }))
            .exec()
        } else {
          // Retry with exponential backoff
          const delay = Math.pow(2, job.attempts) * 1000
          await redis.multi()
            .zrem(this.processingName, jobData)
            .zadd(this.queueName, Date.now() + delay, JSON.stringify(job))
            .exec()
        }
        break
      }
    }
  }

  async getQueueStats(): Promise<{
    waiting: number
    processing: number
    failed: number
  }> {
    if (!this.isAvailable()) {
      return { waiting: 0, processing: 0, failed: 0 }
    }

    const redis = this.getRedis()!
    const [waiting, processing, failed] = await Promise.all([
      redis.zcard(this.queueName),
      redis.zcard(this.processingName),
      redis.zcard(`dead:${this.queueName}`)
    ])

    return { waiting, processing, failed }
  }
}

// Pre-configured queues
export const agentTaskQueue = new TaskQueue('agent-tasks')
export const chatProcessingQueue = new TaskQueue('chat-processing')
export const toolExecutionQueue = new TaskQueue('tool-execution')
