
import Redis from 'ioredis'

let redis: Redis | null = null
let redisAvailable = false

export function getRedisClient(): Redis | null {
  if (!redis) {
    const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379'
    
    redis = new Redis(redisUrl, {
      lazyConnect: true,
      maxRetriesPerRequest: 1,
      connectTimeout: 2000,
      commandTimeout: 1000,
    })

    redis.on('error', (err) => {
      console.warn('Redis connection error (continuing without Redis):', err.message)
      redisAvailable = false
    })

    redis.on('connect', () => {
      console.log('Redis connected successfully')
      redisAvailable = true
    })

    redis.on('close', () => {
      redisAvailable = false
    })
  }

  return redis
}

export function isRedisAvailable(): boolean {
  return redisAvailable
}

// Safe Redis operations that handle connection failures
export const safeRedis = {
  async get(key: string): Promise<string | null> {
    try {
      const client = getRedisClient()
      if (!client || !redisAvailable) return null
      return await client.get(key)
    } catch (error) {
      console.warn('Redis get failed:', error)
      return null
    }
  },

  async set(key: string, value: string, ttl?: number): Promise<boolean> {
    try {
      const client = getRedisClient()
      if (!client || !redisAvailable) return false
      if (ttl) {
        await client.setex(key, ttl, value)
      } else {
        await client.set(key, value)
      }
      return true
    } catch (error) {
      console.warn('Redis set failed:', error)
      return false
    }
  },

  async del(key: string): Promise<boolean> {
    try {
      const client = getRedisClient()
      if (!client || !redisAvailable) return false
      await client.del(key)
      return true
    } catch (error) {
      console.warn('Redis del failed:', error)
      return false
    }
  },

  async publish(channel: string, message: string): Promise<boolean> {
    try {
      const client = getRedisClient()
      if (!client || !redisAvailable) return false
      await client.publish(channel, message)
      return true
    } catch (error) {
      console.warn('Redis publish failed:', error)
      return false
    }
  }
}

export async function disconnectRedis(): Promise<void> {
  if (redis) {
    await redis.disconnect()
    redis = null
  }
}

// Redis key helpers
export const RedisKeys = {
  userSession: (sessionId: string) => `session:${sessionId}`,
  userOnline: (userId: string) => `online:${userId}`,
  chatRoom: (roomId: string) => `chat:${roomId}`,
  agentStatus: (agentId: string) => `agent:status:${agentId}`,
  taskExecution: (taskId: string) => `task:${taskId}`,
  realtimeMessage: (roomId: string) => `messages:${roomId}`,
  agentCollaboration: (collaborationId: string) => `collab:${collaborationId}`,
} as const
