
import { getRedisClient } from './client'
import { EventEmitter } from 'events'

export interface RealtimeMessage {
  type: 'chat_message' | 'agent_status' | 'task_update' | 'user_typing' | 'collaboration_update'
  payload: any
  roomId?: string
  userId?: string
  agentId?: string
  timestamp: number
}

class PubSubManager extends EventEmitter {
  private subscriber: any
  private publisher: any
  private subscriptions: Set<string> = new Set()

  constructor() {
    super()
    this.publisher = getRedisClient()
    this.subscriber = getRedisClient()
    
    this.subscriber.on('message', (channel: string, message: string) => {
      try {
        const parsedMessage: RealtimeMessage = JSON.parse(message)
        this.emit('message', channel, parsedMessage)
        this.emit(channel, parsedMessage)
      } catch (error) {
        console.error('Error parsing Redis message:', error)
      }
    })
  }

  async publish(channel: string, message: Omit<RealtimeMessage, 'timestamp'>): Promise<void> {
    const fullMessage: RealtimeMessage = {
      ...message,
      timestamp: Date.now()
    }
    
    await this.publisher.publish(channel, JSON.stringify(fullMessage))
  }

  async subscribe(channel: string): Promise<void> {
    if (!this.subscriptions.has(channel)) {
      await this.subscriber.subscribe(channel)
      this.subscriptions.add(channel)
    }
  }

  async unsubscribe(channel: string): Promise<void> {
    if (this.subscriptions.has(channel)) {
      await this.subscriber.unsubscribe(channel)
      this.subscriptions.delete(channel)
    }
  }

  async publishChatMessage(roomId: string, message: any): Promise<void> {
    await this.publish(`chat:${roomId}`, {
      type: 'chat_message',
      payload: message,
      roomId
    })
  }

  async publishAgentStatus(agentId: string, status: any): Promise<void> {
    await this.publish(`agent:${agentId}`, {
      type: 'agent_status',
      payload: status,
      agentId
    })
  }

  async publishTaskUpdate(taskId: string, update: any): Promise<void> {
    await this.publish(`task:${taskId}`, {
      type: 'task_update',
      payload: update
    })
  }

  async publishTypingIndicator(roomId: string, userId: string, isTyping: boolean): Promise<void> {
    await this.publish(`typing:${roomId}`, {
      type: 'user_typing',
      payload: { userId, isTyping },
      roomId,
      userId
    })
  }
}

export const pubsub = new PubSubManager()
