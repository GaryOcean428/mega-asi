
export interface APIIntegration {
  id: string
  name: string
  type: 'rest' | 'graphql' | 'webhook' | 'websocket'
  baseUrl: string
  headers?: Record<string, string>
  authentication?: {
    type: 'bearer' | 'api-key' | 'basic' | 'oauth'
    credentials: Record<string, string>
  }
  rateLimit?: {
    requests: number
    window: number // in seconds
  }
  timeout: number
  retryConfig?: {
    attempts: number
    delay: number
    backoffMultiplier: number
  }
  createdAt: Date
  lastUsed?: Date
  status: 'active' | 'disabled' | 'error'
}

export interface APIRequest {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'
  endpoint: string
  headers?: Record<string, string>
  params?: Record<string, any>
  body?: any
  timeout?: number
}

export interface APIResponse<T = any> {
  data: T
  status: number
  headers: Record<string, string>
  duration: number
  timestamp: Date
}

class APIClient {
  private integrations = new Map<string, APIIntegration>()
  private rateLimiters = new Map<string, RateLimiter>()

  async addIntegration(integration: APIIntegration): Promise<void> {
    this.integrations.set(integration.id, integration)
    
    if (integration.rateLimit) {
      this.rateLimiters.set(
        integration.id,
        new RateLimiter(integration.rateLimit.requests, integration.rateLimit.window)
      )
    }
  }

  async removeIntegration(integrationId: string): Promise<void> {
    this.integrations.delete(integrationId)
    this.rateLimiters.delete(integrationId)
  }

  async makeRequest<T = any>(
    integrationId: string,
    request: APIRequest
  ): Promise<APIResponse<T>> {
    const integration = this.integrations.get(integrationId)
    if (!integration) {
      throw new Error(`Integration ${integrationId} not found`)
    }

    if (integration.status !== 'active') {
      throw new Error(`Integration ${integrationId} is not active`)
    }

    // Check rate limits
    const rateLimiter = this.rateLimiters.get(integrationId)
    if (rateLimiter && !rateLimiter.allowRequest()) {
      throw new Error('Rate limit exceeded')
    }

    const startTime = Date.now()
    
    try {
      const response = await this.executeRequest(integration, request)
      const duration = Date.now() - startTime
      
      // Update last used timestamp
      integration.lastUsed = new Date()
      
      return {
        data: response.data,
        status: response.status,
        headers: response.headers,
        duration,
        timestamp: new Date()
      }
    } catch (error) {
      // Handle retries if configured
      if (integration.retryConfig && request.method === 'GET') {
        return this.retryRequest(integration, request, error, 0)
      }
      throw error
    }
  }

  private async executeRequest(
    integration: APIIntegration,
    request: APIRequest
  ): Promise<any> {
    const url = new URL(request.endpoint, integration.baseUrl)
    
    // Add query parameters
    if (request.params) {
      Object.entries(request.params).forEach(([key, value]) => {
        url.searchParams.append(key, String(value))
      })
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...integration.headers,
      ...request.headers
    }

    // Add authentication headers
    if (integration.authentication) {
      this.addAuthHeaders(headers, integration.authentication)
    }

    const fetchOptions: RequestInit = {
      method: request.method,
      headers,
      signal: AbortSignal.timeout(request.timeout || integration.timeout || 30000)
    }

    // Add body for non-GET requests
    if (request.body && request.method !== 'GET') {
      fetchOptions.body = JSON.stringify(request.body)
    }

    const response = await fetch(url.toString(), fetchOptions)
    
    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()
    
    return {
      data,
      status: response.status,
      headers: Object.fromEntries(response.headers.entries())
    }
  }

  private async retryRequest<T>(
    integration: APIIntegration,
    request: APIRequest,
    lastError: any,
    attempt: number
  ): Promise<APIResponse<T>> {
    const retryConfig = integration.retryConfig!
    
    if (attempt >= retryConfig.attempts) {
      throw lastError
    }

    const delay = retryConfig.delay * Math.pow(retryConfig.backoffMultiplier, attempt)
    await new Promise(resolve => setTimeout(resolve, delay))

    try {
      const startTime = Date.now()
      const response = await this.executeRequest(integration, request)
      const duration = Date.now() - startTime
      
      return {
        data: response.data,
        status: response.status,
        headers: response.headers,
        duration,
        timestamp: new Date()
      }
    } catch (error) {
      return this.retryRequest(integration, request, error, attempt + 1)
    }
  }

  private addAuthHeaders(
    headers: Record<string, string>,
    auth: APIIntegration['authentication']
  ): void {
    if (!auth) return

    switch (auth.type) {
      case 'bearer':
        headers['Authorization'] = `Bearer ${auth.credentials.token}`
        break
      case 'api-key':
        if (auth.credentials.headerName && auth.credentials.key) {
          headers[auth.credentials.headerName] = auth.credentials.key
        }
        break
      case 'basic':
        if (auth.credentials.username && auth.credentials.password) {
          const encoded = btoa(`${auth.credentials.username}:${auth.credentials.password}`)
          headers['Authorization'] = `Basic ${encoded}`
        }
        break
      case 'oauth':
        // OAuth implementation would be more complex
        if (auth.credentials.accessToken) {
          headers['Authorization'] = `Bearer ${auth.credentials.accessToken}`
        }
        break
    }
  }

  getIntegration(integrationId: string): APIIntegration | undefined {
    return this.integrations.get(integrationId)
  }

  getAllIntegrations(): APIIntegration[] {
    return Array.from(this.integrations.values())
  }

  async testIntegration(integrationId: string): Promise<boolean> {
    try {
      await this.makeRequest(integrationId, {
        method: 'GET',
        endpoint: '/health',
        timeout: 5000
      })
      return true
    } catch (error) {
      console.error(`Integration test failed for ${integrationId}:`, error)
      return false
    }
  }
}

class RateLimiter {
  private requests: number[] = []

  constructor(
    private maxRequests: number,
    private windowSeconds: number
  ) {}

  allowRequest(): boolean {
    const now = Date.now()
    const windowStart = now - (this.windowSeconds * 1000)
    
    // Remove old requests
    this.requests = this.requests.filter(time => time > windowStart)
    
    if (this.requests.length >= this.maxRequests) {
      return false
    }
    
    this.requests.push(now)
    return true
  }

  getRequestsInWindow(): number {
    const now = Date.now()
    const windowStart = now - (this.windowSeconds * 1000)
    return this.requests.filter(time => time > windowStart).length
  }
}

export const apiClient = new APIClient()

// React hook for API integrations
export function useAPIIntegrations() {
  return {
    addIntegration: apiClient.addIntegration.bind(apiClient),
    removeIntegration: apiClient.removeIntegration.bind(apiClient),
    makeRequest: apiClient.makeRequest.bind(apiClient),
    getIntegration: apiClient.getIntegration.bind(apiClient),
    getAllIntegrations: apiClient.getAllIntegrations.bind(apiClient),
    testIntegration: apiClient.testIntegration.bind(apiClient),
  }
}
