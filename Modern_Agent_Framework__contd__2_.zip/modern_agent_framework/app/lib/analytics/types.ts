
export interface AnalyticsEvent {
  id: string
  type: 'user_action' | 'agent_action' | 'system_event' | 'performance'
  category: string
  action: string
  label?: string
  value?: number
  userId?: string
  agentId?: string
  sessionId?: string
  metadata?: Record<string, any>
  timestamp: Date
}

export interface UserBehaviorMetrics {
  userId: string
  sessionDuration: number
  actionsPerSession: number
  messagesSent: number
  agentsCreated: number
  collaborationsStarted: number
  featuresUsed: string[]
  lastActive: Date
  totalSessions: number
}

export interface AgentPerformanceMetrics {
  agentId: string
  name: string
  type: string
  totalExecutions: number
  successRate: number
  averageResponseTime: number
  errorsCount: number
  lastUsed: Date
  popularityScore: number
  userSatisfactionRating: number
}

export interface SystemPerformanceMetrics {
  timestamp: Date
  activeUsers: number
  activeAgents: number
  totalMessages: number
  averageResponseTime: number
  errorRate: number
  memoryUsage: number
  cpuUsage: number
  requestsPerMinute: number
  collaborationsActive: number
}

export interface UsageAnalytics {
  totalUsers: number
  activeUsers: number
  newUsers: number
  returningUsers: number
  totalAgents: number
  totalCollaborations: number
  totalMessages: number
  averageSessionDuration: number
  topFeatures: Array<{ feature: string; usage: number }>
  userGrowth: Array<{ date: string; users: number }>
  agentPopularity: Array<{ type: string; count: number }>
}

export interface AnalyticsFilter {
  dateRange: {
    start: Date
    end: Date
  }
  userId?: string
  agentType?: string
  eventCategory?: string
  granularity: 'hour' | 'day' | 'week' | 'month'
}

export interface AnalyticsInsight {
  id: string
  type: 'trend' | 'anomaly' | 'recommendation' | 'alert'
  title: string
  description: string
  confidence: number
  impact: 'high' | 'medium' | 'low'
  category: string
  data: any
  generatedAt: Date
  actionable: boolean
  actions?: Array<{
    label: string
    action: string
    params?: any
  }>
}

export interface PerformanceBenchmark {
  metric: string
  current: number
  target: number
  benchmark: number
  status: 'excellent' | 'good' | 'needs_improvement' | 'critical'
  trend: 'improving' | 'stable' | 'declining'
}
