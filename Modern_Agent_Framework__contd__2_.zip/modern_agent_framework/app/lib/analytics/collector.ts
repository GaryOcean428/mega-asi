
import { AnalyticsEvent, UserBehaviorMetrics } from './types'
import { safeRedis } from '../redis/client'

class AnalyticsCollector {
  private batchSize = 50
  private flushInterval = 30000 // 30 seconds
  private events: AnalyticsEvent[] = []
  private timer: NodeJS.Timeout | null = null

  constructor() {
    if (typeof window !== 'undefined') {
      this.startFlushTimer()
      
      // Flush on page unload
      window.addEventListener('beforeunload', () => {
        this.flush()
      })
    }
  }

  // Track user actions
  trackUserAction(
    category: string,
    action: string,
    label?: string,
    value?: number,
    metadata?: Record<string, any>
  ) {
    this.addEvent({
      type: 'user_action',
      category,
      action,
      label,
      value,
      metadata
    })
  }

  // Track agent actions
  trackAgentAction(
    agentId: string,
    action: string,
    label?: string,
    value?: number,
    metadata?: Record<string, any>
  ) {
    this.addEvent({
      type: 'agent_action',
      category: 'agent',
      action,
      label,
      value,
      agentId,
      metadata
    })
  }

  // Track system events
  trackSystemEvent(
    category: string,
    action: string,
    label?: string,
    value?: number,
    metadata?: Record<string, any>
  ) {
    this.addEvent({
      type: 'system_event',
      category,
      action,
      label,
      value,
      metadata
    })
  }

  // Track performance metrics
  trackPerformance(
    action: string,
    value: number,
    label?: string,
    metadata?: Record<string, any>
  ) {
    this.addEvent({
      type: 'performance',
      category: 'performance',
      action,
      label,
      value,
      metadata
    })
  }

  // Track page views
  trackPageView(page: string, title?: string) {
    this.trackUserAction('navigation', 'page_view', page, undefined, {
      title,
      url: typeof window !== 'undefined' ? window.location.href : undefined,
      referrer: typeof document !== 'undefined' ? document.referrer : undefined
    })
  }

  // Track user interactions
  trackInteraction(element: string, action: string, metadata?: Record<string, any>) {
    this.trackUserAction('interaction', action, element, undefined, metadata)
  }

  // Track feature usage
  trackFeatureUsage(feature: string, action: string = 'use', metadata?: Record<string, any>) {
    this.trackUserAction('feature', action, feature, undefined, metadata)
  }

  // Track errors
  trackError(error: string, category: string = 'error', metadata?: Record<string, any>) {
    this.trackSystemEvent(category, 'error', error, undefined, {
      ...metadata,
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : undefined,
      timestamp: new Date().toISOString()
    })
  }

  // Track timing events (e.g., how long something took)
  trackTiming(category: string, variable: string, time: number, label?: string) {
    this.trackPerformance(`${category}_${variable}`, time, label, {
      category,
      variable
    })
  }

  private addEvent(eventData: Omit<AnalyticsEvent, 'id' | 'timestamp' | 'userId' | 'sessionId'>) {
    const event: AnalyticsEvent = {
      id: this.generateEventId(),
      ...eventData,
      userId: this.getCurrentUserId(),
      sessionId: this.getSessionId(),
      timestamp: new Date()
    }

    this.events.push(event)

    // Auto-flush if batch size reached
    if (this.events.length >= this.batchSize) {
      this.flush()
    }
  }

  private generateEventId(): string {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  private getCurrentUserId(): string | undefined {
    if (typeof window === 'undefined') return undefined
    
    // Try to get user ID from various sources
    const sessionData = localStorage.getItem('user-session')
    if (sessionData) {
      try {
        const parsed = JSON.parse(sessionData)
        return parsed.user?.id
      } catch {}
    }

    // Fallback to a persistent anonymous ID
    let anonymousId = localStorage.getItem('anonymous-id')
    if (!anonymousId) {
      anonymousId = `anon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      localStorage.setItem('anonymous-id', anonymousId)
    }
    return anonymousId
  }

  private getSessionId(): string {
    if (typeof window === 'undefined') return 'server-session'
    
    let sessionId = sessionStorage.getItem('session-id')
    if (!sessionId) {
      sessionId = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      sessionStorage.setItem('session-id', sessionId)
    }
    return sessionId
  }

  private startFlushTimer() {
    this.timer = setInterval(() => {
      this.flush()
    }, this.flushInterval)
  }

  private async flush() {
    if (this.events.length === 0) return

    const eventsToSend = [...this.events]
    this.events = []

    try {
      // Store events in Redis for processing
      await this.storeEvents(eventsToSend)
      
      // Also send to analytics API if available
      if (typeof window !== 'undefined' && process.env.NODE_ENV === 'production') {
        await this.sendToAPI(eventsToSend)
      }
    } catch (error) {
      console.warn('Failed to flush analytics events:', error)
      // Re-add events back to queue for retry
      this.events.unshift(...eventsToSend)
    }
  }

  private async storeEvents(events: AnalyticsEvent[]) {
    const key = `analytics:events:${new Date().toISOString().slice(0, 10)}`
    const serializedEvents = events.map(event => JSON.stringify(event))
    
    for (const event of serializedEvents) {
      await safeRedis.publish('analytics:events', event)
    }

    // Also store in daily batch for offline analysis
    try {
      const existing = await safeRedis.get(key)
      const existingEvents = existing ? JSON.parse(existing) : []
      await safeRedis.set(key, JSON.stringify([...existingEvents, ...events]), 86400) // 24 hours TTL
    } catch (error) {
      console.warn('Failed to store analytics batch:', error)
    }
  }

  private async sendToAPI(events: AnalyticsEvent[]) {
    try {
      await fetch('/api/analytics/events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ events }),
      })
    } catch (error) {
      console.warn('Failed to send events to API:', error)
    }
  }

  // Create a timing tracker for measuring execution time
  startTiming(category: string, variable: string): () => void {
    const startTime = performance.now()
    
    return (label?: string) => {
      const duration = performance.now() - startTime
      this.trackTiming(category, variable, duration, label)
    }
  }

  // Cleanup
  destroy() {
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }
    this.flush()
  }
}

export const analytics = new AnalyticsCollector()

// React hook for tracking analytics
export function useAnalytics() {
  return {
    trackUserAction: analytics.trackUserAction.bind(analytics),
    trackAgentAction: analytics.trackAgentAction.bind(analytics),
    trackSystemEvent: analytics.trackSystemEvent.bind(analytics),
    trackPerformance: analytics.trackPerformance.bind(analytics),
    trackPageView: analytics.trackPageView.bind(analytics),
    trackInteraction: analytics.trackInteraction.bind(analytics),
    trackFeatureUsage: analytics.trackFeatureUsage.bind(analytics),
    trackError: analytics.trackError.bind(analytics),
    trackTiming: analytics.trackTiming.bind(analytics),
    startTiming: analytics.startTiming.bind(analytics),
  }
}

// Decorator for tracking function execution time
export function trackExecution(category: string, action: string) {
  return function (target: any, propertyName: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value

    descriptor.value = async function (...args: any[]) {
      const endTiming = analytics.startTiming(category, action)
      
      try {
        const result = await method.apply(this, args)
        endTiming()
        return result
      } catch (error: any) {
        endTiming()
        analytics.trackError(`${category}:${action}:${error?.message || 'Unknown error'}`, 'execution_error', {
          function: propertyName,
          args: JSON.stringify(args),
        })
        throw error
      }
    }
  }
}
