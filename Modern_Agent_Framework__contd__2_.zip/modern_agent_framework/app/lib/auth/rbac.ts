
export type Permission = 
  // Agent permissions
  | 'agents:create' 
  | 'agents:read' 
  | 'agents:update' 
  | 'agents:delete'
  | 'agents:execute'
  
  // Collaboration permissions
  | 'collaborations:create'
  | 'collaborations:read'
  | 'collaborations:update'
  | 'collaborations:delete'
  | 'collaborations:invite'
  
  // Organization permissions
  | 'org:manage'
  | 'org:invite'
  | 'org:remove_members'
  | 'org:view_audit'
  | 'org:manage_billing'
  
  // Workspace permissions
  | 'workspace:create'
  | 'workspace:update'
  | 'workspace:delete'
  | 'workspace:manage_members'
  | 'workspace:view_analytics'
  
  // System permissions
  | 'system:admin'
  | 'system:view_logs'
  | 'system:manage_integrations'
  | 'system:manage_schedules'

export type Role = 'owner' | 'admin' | 'manager' | 'member' | 'viewer' | 'guest'

export interface RolePermissions {
  role: Role
  permissions: Permission[]
  inherits?: Role[]
}

export interface UserRole {
  userId: string
  role: Role
  scope: 'organization' | 'workspace' | 'collaboration'
  scopeId: string
  grantedBy: string
  grantedAt: Date
  expiresAt?: Date
}

export interface AccessPolicy {
  id: string
  name: string
  description: string
  rules: AccessRule[]
  active: boolean
  priority: number
  createdAt: Date
  updatedAt: Date
}

export interface AccessRule {
  id: string
  type: 'allow' | 'deny'
  resource: string
  permissions: Permission[]
  conditions?: AccessCondition[]
}

export interface AccessCondition {
  field: string
  operator: 'equals' | 'not_equals' | 'contains' | 'in' | 'not_in' | 'greater' | 'less'
  value: any
}

// Default role permissions
export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  owner: [
    // All permissions
    'agents:create', 'agents:read', 'agents:update', 'agents:delete', 'agents:execute',
    'collaborations:create', 'collaborations:read', 'collaborations:update', 'collaborations:delete', 'collaborations:invite',
    'org:manage', 'org:invite', 'org:remove_members', 'org:view_audit', 'org:manage_billing',
    'workspace:create', 'workspace:update', 'workspace:delete', 'workspace:manage_members', 'workspace:view_analytics',
    'system:admin', 'system:view_logs', 'system:manage_integrations', 'system:manage_schedules'
  ],
  
  admin: [
    'agents:create', 'agents:read', 'agents:update', 'agents:delete', 'agents:execute',
    'collaborations:create', 'collaborations:read', 'collaborations:update', 'collaborations:delete', 'collaborations:invite',
    'org:invite', 'org:remove_members', 'org:view_audit',
    'workspace:create', 'workspace:update', 'workspace:delete', 'workspace:manage_members', 'workspace:view_analytics',
    'system:view_logs', 'system:manage_integrations', 'system:manage_schedules'
  ],
  
  manager: [
    'agents:create', 'agents:read', 'agents:update', 'agents:delete', 'agents:execute',
    'collaborations:create', 'collaborations:read', 'collaborations:update', 'collaborations:delete', 'collaborations:invite',
    'workspace:update', 'workspace:manage_members', 'workspace:view_analytics',
    'system:manage_integrations', 'system:manage_schedules'
  ],
  
  member: [
    'agents:create', 'agents:read', 'agents:update', 'agents:execute',
    'collaborations:create', 'collaborations:read', 'collaborations:update', 'collaborations:invite'
  ],
  
  viewer: [
    'agents:read',
    'collaborations:read'
  ],
  
  guest: [
    'agents:read'
  ]
}

export class RBACManager {
  private static instance: RBACManager
  private userRoles = new Map<string, UserRole[]>()
  private policies = new Map<string, AccessPolicy>()

  static getInstance(): RBACManager {
    if (!RBACManager.instance) {
      RBACManager.instance = new RBACManager()
    }
    return RBACManager.instance
  }

  // Check if user has permission
  async hasPermission(
    userId: string, 
    permission: Permission, 
    resource?: { type: string; id: string }
  ): Promise<boolean> {
    const userRoles = await this.getUserRoles(userId)
    
    // Check role-based permissions
    for (const userRole of userRoles) {
      const rolePermissions = ROLE_PERMISSIONS[userRole.role]
      if (rolePermissions.includes(permission)) {
        // Check if role is still valid
        if (userRole.expiresAt && userRole.expiresAt < new Date()) {
          continue
        }
        
        // Apply access policies if any
        if (await this.checkAccessPolicies(userId, permission, resource)) {
          return true
        }
      }
    }
    
    return false
  }

  // Check multiple permissions
  async hasAllPermissions(
    userId: string, 
    permissions: Permission[], 
    resource?: { type: string; id: string }
  ): Promise<boolean> {
    for (const permission of permissions) {
      if (!(await this.hasPermission(userId, permission, resource))) {
        return false
      }
    }
    return true
  }

  async hasAnyPermission(
    userId: string, 
    permissions: Permission[], 
    resource?: { type: string; id: string }
  ): Promise<boolean> {
    for (const permission of permissions) {
      if (await this.hasPermission(userId, permission, resource)) {
        return true
      }
    }
    return false
  }

  // Grant role to user
  async grantRole(
    userId: string, 
    role: Role, 
    scope: UserRole['scope'], 
    scopeId: string,
    grantedBy: string,
    expiresAt?: Date
  ): Promise<void> {
    const userRole: UserRole = {
      userId,
      role,
      scope,
      scopeId,
      grantedBy,
      grantedAt: new Date(),
      expiresAt
    }
    
    const roles = this.userRoles.get(userId) || []
    
    // Remove existing role for same scope if any
    const filteredRoles = roles.filter(
      r => !(r.scope === scope && r.scopeId === scopeId)
    )
    
    filteredRoles.push(userRole)
    this.userRoles.set(userId, filteredRoles)
    
    // Audit log
    this.logAction('role_granted', {
      userId,
      role,
      scope,
      scopeId,
      grantedBy
    })
  }

  // Revoke role from user
  async revokeRole(
    userId: string, 
    scope: UserRole['scope'], 
    scopeId: string,
    revokedBy: string
  ): Promise<void> {
    const roles = this.userRoles.get(userId) || []
    const filteredRoles = roles.filter(
      r => !(r.scope === scope && r.scopeId === scopeId)
    )
    
    this.userRoles.set(userId, filteredRoles)
    
    // Audit log
    this.logAction('role_revoked', {
      userId,
      scope,
      scopeId,
      revokedBy
    })
  }

  // Get user's roles
  async getUserRoles(userId: string): Promise<UserRole[]> {
    const roles = this.userRoles.get(userId) || []
    
    // Filter out expired roles
    const validRoles = roles.filter(role => 
      !role.expiresAt || role.expiresAt > new Date()
    )
    
    return validRoles
  }

  // Get user's effective permissions for a scope
  async getUserPermissions(userId: string, scope?: string): Promise<Permission[]> {
    const userRoles = await this.getUserRoles(userId)
    const permissions = new Set<Permission>()
    
    for (const userRole of userRoles) {
      // Filter by scope if specified
      if (scope && userRole.scopeId !== scope) {
        continue
      }
      
      const rolePermissions = ROLE_PERMISSIONS[userRole.role]
      rolePermissions.forEach(permission => permissions.add(permission))
    }
    
    return Array.from(permissions)
  }

  // Access policy management
  async createAccessPolicy(policy: Omit<AccessPolicy, 'id' | 'createdAt' | 'updatedAt'>): Promise<AccessPolicy> {
    const newPolicy: AccessPolicy = {
      ...policy,
      id: `policy_${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date()
    }
    
    this.policies.set(newPolicy.id, newPolicy)
    return newPolicy
  }

  async updateAccessPolicy(policyId: string, updates: Partial<AccessPolicy>): Promise<AccessPolicy | null> {
    const policy = this.policies.get(policyId)
    if (!policy) return null
    
    const updatedPolicy = {
      ...policy,
      ...updates,
      updatedAt: new Date()
    }
    
    this.policies.set(policyId, updatedPolicy)
    return updatedPolicy
  }

  async deleteAccessPolicy(policyId: string): Promise<boolean> {
    return this.policies.delete(policyId)
  }

  // Check access policies
  private async checkAccessPolicies(
    userId: string, 
    permission: Permission, 
    resource?: { type: string; id: string }
  ): Promise<boolean> {
    const policies = Array.from(this.policies.values())
      .filter(p => p.active)
      .sort((a, b) => b.priority - a.priority) // Higher priority first
    
    for (const policy of policies) {
      for (const rule of policy.rules) {
        if (this.matchesRule(rule, permission, resource)) {
          if (rule.conditions) {
            const conditionsMet = await this.evaluateConditions(rule.conditions, userId, resource)
            if (!conditionsMet) continue
          }
          
          return rule.type === 'allow'
        }
      }
    }
    
    return false // Default deny
  }

  private matchesRule(
    rule: AccessRule, 
    permission: Permission, 
    resource?: { type: string; id: string }
  ): boolean {
    // Check permission
    if (!rule.permissions.includes(permission)) {
      return false
    }
    
    // Check resource if specified
    if (resource && rule.resource !== '*' && rule.resource !== resource.type) {
      return false
    }
    
    return true
  }

  private async evaluateConditions(
    conditions: AccessCondition[], 
    userId: string, 
    resource?: { type: string; id: string }
  ): Promise<boolean> {
    for (const condition of conditions) {
      if (!this.evaluateCondition(condition, userId, resource)) {
        return false
      }
    }
    return true
  }

  private evaluateCondition(
    condition: AccessCondition, 
    userId: string, 
    resource?: { type: string; id: string }
  ): boolean {
    let value: any
    
    // Get field value
    switch (condition.field) {
      case 'user.id':
        value = userId
        break
      case 'resource.type':
        value = resource?.type
        break
      case 'resource.id':
        value = resource?.id
        break
      case 'time.hour':
        value = new Date().getHours()
        break
      case 'time.day':
        value = new Date().getDay()
        break
      default:
        return false
    }
    
    // Evaluate condition
    switch (condition.operator) {
      case 'equals':
        return value === condition.value
      case 'not_equals':
        return value !== condition.value
      case 'contains':
        return String(value).includes(String(condition.value))
      case 'in':
        return Array.isArray(condition.value) && condition.value.includes(value)
      case 'not_in':
        return Array.isArray(condition.value) && !condition.value.includes(value)
      case 'greater':
        return Number(value) > Number(condition.value)
      case 'less':
        return Number(value) < Number(condition.value)
      default:
        return false
    }
  }

  private logAction(action: string, data: any): void {
    // In production, this would log to audit system
    console.log('RBAC Action:', action, data)
  }
}

export const rbac = RBACManager.getInstance()

// React hook for RBAC
export function useRBAC() {
  return {
    hasPermission: rbac.hasPermission.bind(rbac),
    hasAllPermissions: rbac.hasAllPermissions.bind(rbac),
    hasAnyPermission: rbac.hasAnyPermission.bind(rbac),
    getUserRoles: rbac.getUserRoles.bind(rbac),
    getUserPermissions: rbac.getUserPermissions.bind(rbac),
  }
}


