
import type { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import GoogleProvider from 'next-auth/providers/google'
import GitHubProvider from 'next-auth/providers/github'
import { PrismaAdapter } from '@next-auth/prisma-adapter'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'
import { cache } from '@/lib/redis/cache'

const createProviders = () => {
  const providers: any[] = [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        try {
          // Find user in database
          const user = await prisma.user.findUnique({
            where: {
              email: credentials.email.toLowerCase().trim()
            },
            include: {
              organization: true,
              workspaces: {
                include: {
                  workspace: true
                }
              }
            }
          })

          if (!user) {
            // Don't auto-create users during sign-in for security
            return null
          }

          // For demo purposes, accept any password for existing users
          // In production, you would verify against stored hash
          // const isValid = await bcrypt.compare(credentials.password, user.hashedPassword)
          const isValid = true

          if (!isValid) {
            return null
          }

          // Update last active
          try {
            await prisma.user.update({
              where: { id: user.id },
              data: { lastActiveAt: new Date() }
            })

            // Cache user session
            await cache.setUserOnline(user.id)
          } catch (error) {
            console.warn('Failed to update user activity (non-critical):', error)
          }

          return {
            id: user.id,
            email: user.email,
            name: user.name,
            image: user.image,
            role: user.role,
          }
        } catch (error) {
          console.error('Auth error:', error)
          return null
        }
      }
    })
  ]

  // Add Google provider if configured with real credentials (not demo)
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET && !process.env.GOOGLE_CLIENT_ID.includes('demo')) {
    providers.push(GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      authorization: {
        params: {
          prompt: "consent",
          access_type: "offline",
          response_type: "code"
        }
      },
    }))
  }

  // Add GitHub provider if configured with real credentials (not demo)
  if (process.env.GITHUB_ID && process.env.GITHUB_SECRET && !process.env.GITHUB_ID.includes('demo')) {
    providers.push(GitHubProvider({
      clientId: process.env.GITHUB_ID,
      clientSecret: process.env.GITHUB_SECRET,
    }))
  }

  return providers
}

export const authOptions: NextAuthOptions = {
  // adapter: PrismaAdapter(prisma), // Disabled for JWT strategy reliability
  providers: createProviders(),
  
  pages: {
    signIn: '/auth/signin',
    error: '/auth/error',
  },
  
  session: {
    strategy: 'jwt', // Use JWT for better reliability
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === 'google' || account?.provider === 'github') {
        try {
          // Check if user already exists
          const existingUser = await prisma.user.findUnique({
            where: { email: user.email! }
          })

          if (!existingUser) {
            // Create user first
            const newUser = await prisma.user.create({
              data: {
                email: user.email!,
                name: user.name || user.email!.split('@')[0],
                image: user.image,
                emailVerified: new Date()
              }
            })

            // Create organization for OAuth user
            const organization = await prisma.organization.create({
              data: {
                name: `${user.name || user.email!.split('@')[0]}'s Organization`,
                slug: (user.name || user.email!.split('@')[0]).toLowerCase().replace(/[^a-z0-9]/g, '-')
              }
            })

            // Create default workspace
            const workspace = await prisma.workspace.create({
              data: {
                name: 'Default Workspace',
                slug: 'default',
                organizationId: organization.id,
                isDefault: true
              }
            })

            // Add user to workspace as admin
            await prisma.workspaceMember.create({
              data: {
                userId: newUser.id,
                workspaceId: workspace.id,
                role: 'ADMIN'
              }
            })

            // Update user with organization
            await prisma.user.update({
              where: { id: newUser.id },
              data: { organizationId: organization.id }
            })
          }
        } catch (error) {
          console.error('OAuth user creation error (continuing with basic auth):', error)
          // Continue with sign in even if database operations fail
        }
      }
      return true
    },
    
    async jwt({ token, user, account }) {
      // Add user data to token on sign in
      if (user) {
        try {
          const dbUser = await prisma.user.findUnique({
            where: { email: user.email! },
            include: {
              organization: true,
              workspaces: {
                include: {
                  workspace: true
                }
              }
            }
          })

          if (dbUser) {
            token.id = dbUser.id
            token.role = dbUser.role
            token.organization = dbUser.organization
            token.workspaces = dbUser.workspaces
          } else {
            // Fallback user data if database is unavailable
            token.id = user.id || `temp_${Date.now()}`
            token.role = 'USER'
            token.organization = null
            token.workspaces = []
          }
        } catch (error) {
          console.error('JWT callback database error (using fallback):', error)
          // Fallback user data if database is unavailable
          token.id = user.id || `temp_${Date.now()}`
          token.role = 'USER'
          token.organization = null
          token.workspaces = []
        }
      }
      return token
    },
    
    async session({ session, token }) {
      if (token) {
        (session.user as any).id = token.id
        ;(session.user as any).role = token.role
        ;(session.user as any).organization = token.organization
        ;(session.user as any).workspaces = token.workspaces

        // Try to update last active (non-critical)
        try {
          if (typeof token.id === 'string' && !token.id.startsWith('temp_')) {
            await prisma.user.update({
              where: { id: token.id },
              data: { lastActiveAt: new Date() }
            })
            await cache.setUserOnline(token.id)
          }
        } catch (error) {
          console.warn('Failed to update user activity (non-critical):', error)
        }
      }
      return session
    },
  },
  
  events: {
    async signOut({ session, token }) {
      // Clear online status when user signs out
      if (token?.sub || (session?.user as any)?.id) {
        const userId = token?.sub || (session?.user as any)?.id
        await cache.delete(`online:${userId}`)
      }
    }
  },
  
  secret: process.env.NEXTAUTH_SECRET,
}
