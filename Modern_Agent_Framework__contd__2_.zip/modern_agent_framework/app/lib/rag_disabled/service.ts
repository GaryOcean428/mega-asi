
/**
 * RAG (Retrieval-Augmented Generation) Service for MCP Knowledge Management
 * Handles vector embeddings, semantic search, and knowledge retrieval
 */

import { prisma } from '@/lib/prisma'
import { llmClient } from '@/lib/llm-client'
import { logger } from '@/lib/utils/logger'

export interface MCPKnowledgeResult {
  id: string
  title: string
  content: string
  section: string
  mcpName: string
  relevanceScore: number
  sourceUrl?: string
}

export interface MCPSearchOptions {
  section?: 'installation' | 'configuration' | 'usage' | 'troubleshooting' | 'api'
  contentType?: 'documentation' | 'tutorial' | 'troubleshooting' | 'example'
  mcpId?: string
  limit?: number
  minRelevance?: number
}

export class RAGService {
  
  /**
   * Generate embeddings for text using OpenAI embeddings API
   */
  private async generateEmbedding(text: string): Promise<number[]> {
    try {
      // Note: In a real implementation, you'd call OpenAI embeddings API
      // For now, we'll simulate embeddings
      const response = await fetch('https://apps.abacus.ai/v1/embeddings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
        },
        body: JSON.stringify({
          model: 'text-embedding-3-small',
          input: text
        })
      })

      if (!response.ok) {
        throw new Error(`Embeddings API error: ${response.status}`)
      }

      const data = await response.json()
      return data.data[0].embedding
    } catch (error) {
      logger.error('Error generating embedding:', error)
      // Return a dummy embedding for development
      return new Array(1536).fill(0).map(() => Math.random())
    }
  }

  /**
   * Add knowledge to the RAG system
   */
  async addKnowledge(knowledge: {
    mcpRegistryId: string
    title: string
    content: string
    section: string
    contentType: 'documentation' | 'tutorial' | 'troubleshooting' | 'example'
    sourceUrl?: string
    tags?: string[]
    isOfficial?: boolean
  }): Promise<string> {
    try {
      // Generate embedding for the content
      const embedding = await this.generateEmbedding(
        `${knowledge.title} ${knowledge.content} ${knowledge.tags?.join(' ') || ''}`
      )

      // Store in database
      const result = await prisma.mcpKnowledgeBase.create({
        data: {
          mcpRegistryId: knowledge.mcpRegistryId,
          title: knowledge.title,
          content: knowledge.content,
          section: knowledge.section,
          contentType: knowledge.contentType,
          sourceUrl: knowledge.sourceUrl,
          tags: knowledge.tags || [],
          isOfficial: knowledge.isOfficial || false,
          embedding: `[${embedding.join(',')}]` as any // PostgreSQL vector type
        }
      })

      return result.id
    } catch (error) {
      logger.error('Error adding knowledge:', error)
      throw error
    }
  }

  /**
   * Search MCP knowledge using semantic similarity
   */
  async searchMCPKnowledge(
    query: string,
    options: MCPSearchOptions = {}
  ): Promise<MCPKnowledgeResult[]> {
    try {
      const {
        section,
        contentType,
        mcpId,
        limit = 10,
        minRelevance = 0.5
      } = options

      // Generate query embedding
      const queryEmbedding = await this.generateEmbedding(query)

      // Build SQL query with vector similarity search
      let sqlQuery = `
        SELECT 
          k.id,
          k.title,
          k.content,
          k.section,
          m.name as mcp_name,
          k.source_url,
          1 - (k.embedding <=> $1::vector) as relevance_score
        FROM mcp_knowledge_base k
        JOIN mcp_registry m ON k.mcp_registry_id = m.id
        WHERE 1 = 1
      `

      const params: any[] = [`[${queryEmbedding.join(',')}]`]
      let paramIndex = 2

      if (section) {
        sqlQuery += ` AND k.section = $${paramIndex}`
        params.push(section)
        paramIndex++
      }

      if (contentType) {
        sqlQuery += ` AND k.content_type = $${paramIndex}`
        params.push(contentType)
        paramIndex++
      }

      if (mcpId) {
        sqlQuery += ` AND k.mcp_registry_id = $${paramIndex}`
        params.push(mcpId)
        paramIndex++
      }

      sqlQuery += `
        AND (1 - (k.embedding <=> $1::vector)) > ${minRelevance}
        ORDER BY relevance_score DESC
        LIMIT ${limit}
      `

      const results = await prisma.$queryRawUnsafe(sqlQuery, ...params) as any[]

      return results.map(row => ({
        id: row.id,
        title: row.title,
        content: row.content,
        section: row.section,
        mcpName: row.mcp_name,
        relevanceScore: row.relevance_score,
        sourceUrl: row.source_url
      }))
    } catch (error) {
      logger.error('Error searching MCP knowledge:', error)
      
      // Fallback to text search
      return this.fallbackTextSearch(query, options)
    }
  }

  /**
   * Fallback text search when vector search fails
   */
  private async fallbackTextSearch(
    query: string,
    options: MCPSearchOptions
  ): Promise<MCPKnowledgeResult[]> {
    try {
      const whereClause: any = {}

      if (options.section) whereClause.section = options.section
      if (options.contentType) whereClause.contentType = options.contentType
      if (options.mcpId) whereClause.mcpRegistryId = options.mcpId

      const results = await prisma.mcpKnowledgeBase.findMany({
        where: {
          ...whereClause,
          OR: [
            { title: { contains: query, mode: 'insensitive' } },
            { content: { contains: query, mode: 'insensitive' } },
            { tags: { has: query.toLowerCase() } }
          ]
        },
        include: {
          mcpRegistry: { select: { name: true } }
        },
        take: options.limit || 10,
        orderBy: [
          { isOfficial: 'desc' },
          { qualityScore: 'desc' },
          { upvotes: 'desc' }
        ]
      })

      return results.map(result => ({
        id: result.id,
        title: result.title,
        content: result.content,
        section: result.section,
        mcpName: result.mcpRegistry.name,
        relevanceScore: 0.7, // Fixed score for text search
        sourceUrl: result.sourceUrl
      }))
    } catch (error) {
      logger.error('Error in fallback text search:', error)
      return []
    }
  }

  /**
   * Find relevant MCPs based on task/workflow analysis
   */
  async findRelevantMCPs(
    workflowDescription: string,
    context?: string
  ): Promise<Array<{
    mcp: {
      id: string
      name: string
      description: string
      category: string
      capabilities: string[]
      rating: number
    }
    reasoning: string
    confidence: number
  }>> {
    try {
      // Generate embedding for the workflow description
      const workflowEmbedding = await this.generateEmbedding(
        `${workflowDescription} ${context || ''}`
      )

      // Find MCPs with similar capabilities
      const similarMCPs = await prisma.$queryRawUnsafe(`
        SELECT 
          m.*,
          AVG(1 - (k.embedding <=> $1::vector)) as avg_relevance
        FROM mcp_registry m
        LEFT JOIN mcp_knowledge_base k ON m.id = k.mcp_registry_id
        WHERE m.is_active = true
        GROUP BY m.id
        HAVING AVG(1 - (k.embedding <=> $1::vector)) > 0.6
        ORDER BY avg_relevance DESC
        LIMIT 8
      `, `[${workflowEmbedding.join(',')}]`) as any[]

      // Generate reasoning for each recommendation using LLM
      const recommendations = []
      for (const mcp of similarMCPs) {
        try {
          const reasoningPrompt = [
            {
              role: 'system' as const,
              content: 'You are an expert MCP consultant. Explain why this MCP would be helpful for the user\'s workflow in 1-2 sentences.'
            },
            {
              role: 'user' as const,
              content: `Workflow: ${workflowDescription}
              
MCP: ${mcp.name} - ${mcp.description}
Capabilities: ${mcp.capabilities?.join(', ') || 'Not specified'}

Why would this MCP be helpful? Be specific about the value it provides.`
            }
          ]

          const reasoningResponse = await llmClient.complete({
            messages: reasoningPrompt,
            temperature: 0.3,
            maxTokens: 100
          })

          recommendations.push({
            mcp: {
              id: mcp.id,
              name: mcp.name,
              description: mcp.description,
              category: mcp.category,
              capabilities: mcp.capabilities || [],
              rating: mcp.rating || 0
            },
            reasoning: reasoningResponse.content,
            confidence: Math.min(0.95, mcp.avg_relevance + 0.1)
          })
        } catch (error) {
          logger.warn('Error generating reasoning for MCP recommendation:', error)
          recommendations.push({
            mcp: {
              id: mcp.id,
              name: mcp.name,
              description: mcp.description,
              category: mcp.category,
              capabilities: mcp.capabilities || [],
              rating: mcp.rating || 0
            },
            reasoning: `This MCP could be useful for your workflow based on capability matching.`,
            confidence: mcp.avg_relevance
          })
        }
      }

      return recommendations
    } catch (error) {
      logger.error('Error finding relevant MCPs:', error)
      return []
    }
  }

  /**
   * Update knowledge base with new MCP information
   */
  async syncMCPKnowledge(mcpRegistryId: string): Promise<void> {
    try {
      const mcp = await prisma.mcpRegistry.findUnique({
        where: { id: mcpRegistryId }
      })

      if (!mcp || !mcp.repositoryUrl) {
        return
      }

      // In a real implementation, this would:
      // 1. Fetch README and documentation from the repository
      // 2. Parse and extract different sections
      // 3. Generate embeddings and store in knowledge base
      
      logger.info(`Syncing knowledge for MCP: ${mcp.name}`)
      
      // For now, add basic knowledge entry
      await this.addKnowledge({
        mcpRegistryId,
        title: `${mcp.name} Overview`,
        content: mcp.description || `${mcp.name} MCP integration`,
        section: 'overview',
        contentType: 'documentation',
        sourceUrl: mcp.repositoryUrl,
        tags: mcp.capabilities || [],
        isOfficial: mcp.securityLevel === 'official'
      })
    } catch (error) {
      logger.error('Error syncing MCP knowledge:', error)
    }
  }

  /**
   * Get contextual help for MCP configuration
   */
  async getConfigurationHelp(
    mcpId: string,
    configField: string,
    userQuery?: string
  ): Promise<{
    explanation: string
    examples: string[]
    commonIssues: string[]
  }> {
    try {
      // Search for configuration-specific knowledge
      const configDocs = await this.searchMCPKnowledge(
        `${configField} configuration setup`,
        { mcpId, section: 'configuration', limit: 3 }
      )

      // Generate helpful explanation
      const helpPrompt = [
        {
          role: 'system' as const,
          content: 'You are a helpful MCP configuration assistant. Provide clear, practical guidance for MCP configuration.'
        },
        {
          role: 'user' as const,
          content: `Help with configuring "${configField}" for MCP.

User question: ${userQuery || 'How do I configure this field?'}

Available documentation:
${configDocs.map(doc => `- ${doc.title}: ${doc.content.slice(0, 200)}...`).join('\n')}

Provide:
1. Clear explanation of what this field does
2. 2-3 example values
3. Common configuration issues to avoid`
        }
      ]

      const helpResponse = await llmClient.complete({
        messages: helpPrompt,
        temperature: 0.3,
        maxTokens: 400
      })

      // Parse the response to extract structured information
      const lines = helpResponse.content.split('\n')
      const explanation = lines.slice(0, 3).join('\n')
      const examples = lines.filter(line => line.includes('example') || line.includes('Example'))
      const issues = lines.filter(line => line.includes('avoid') || line.includes('issue') || line.includes('common'))

      return {
        explanation,
        examples: examples.length > 0 ? examples : ['No specific examples available'],
        commonIssues: issues.length > 0 ? issues : ['No common issues documented']
      }
    } catch (error) {
      logger.error('Error getting configuration help:', error)
      return {
        explanation: 'Configuration help is temporarily unavailable.',
        examples: [],
        commonIssues: []
      }
    }
  }

  /**
   * Generate MCP usage analytics insights
   */
  async generateUsageInsights(userId: string, workspaceId?: string): Promise<{
    insights: string[]
    recommendations: string[]
    trendsAnalysis: string
  }> {
    try {
      // Get user's MCP usage patterns
      const usageData = await prisma.mcpUsageAnalytics.findMany({
        where: {
          installation: {
            userId,
            ...(workspaceId && { workspaceId })
          },
          usedAt: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
          }
        },
        include: {
          installation: {
            include: {
              mcpRegistry: true
            }
          }
        },
        orderBy: { usedAt: 'desc' }
      })

      if (usageData.length === 0) {
        return {
          insights: ['No MCP usage data available yet.'],
          recommendations: ['Start by installing MCPs that match your workflow needs.'],
          trendsAnalysis: 'Insufficient data for trend analysis.'
        }
      }

      // Analyze usage patterns with LLM
      const analysisPrompt = [
        {
          role: 'system' as const,
          content: 'You are an MCP usage analyst. Provide insights and recommendations based on user\'s MCP usage patterns.'
        },
        {
          role: 'user' as const,
          content: `Analyze this MCP usage data:

Usage summary:
- Total calls: ${usageData.length}
- Unique MCPs used: ${new Set(usageData.map(u => u.installation.mcpRegistry.name)).size}
- Most used: ${Object.entries(usageData.reduce((acc, u) => {
            acc[u.installation.mcpRegistry.name] = (acc[u.installation.mcpRegistry.name] || 0) + 1
            return acc
          }, {} as Record<string, number>))
          .sort(([,a], [,b]) => b - a)
          .slice(0, 3)
          .map(([name, count]) => `${name} (${count} calls)`)
          .join(', ')}

Recent usage patterns:
${usageData.slice(0, 10).map(u => 
  `- ${u.installation.mcpRegistry.name}: ${u.methodCalled} (${u.responseStatus})`
).join('\n')}

Provide:
1. Key insights about usage patterns
2. Recommendations for optimization
3. Trend analysis`
        }
      ]

      const analysisResponse = await llmClient.complete({
        messages: analysisPrompt,
        temperature: 0.3,
        maxTokens: 500
      })

      // Parse response into structured format
      const content = analysisResponse.content
      const sections = content.split(/\d+\./).filter(s => s.trim())
      
      return {
        insights: sections[0]?.split('\n').filter(l => l.trim()) || [],
        recommendations: sections[1]?.split('\n').filter(l => l.trim()) || [],
        trendsAnalysis: sections[2]?.trim() || 'Analysis unavailable'
      }
    } catch (error) {
      logger.error('Error generating usage insights:', error)
      return {
        insights: ['Unable to generate insights at this time.'],
        recommendations: ['Check back later for personalized recommendations.'],
        trendsAnalysis: 'Analysis temporarily unavailable.'
      }
    }
  }
}

export const ragService = new RAGService()
