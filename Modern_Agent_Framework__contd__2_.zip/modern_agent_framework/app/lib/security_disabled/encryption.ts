
/**
 * Encryption Service for secure credential storage
 * Handles encryption/decryption of sensitive MCP credentials and secrets
 */

import crypto from 'crypto'
import { logger } from '@/lib/utils/logger'

export interface EncryptionResult {
  encryptedData: string
  keyId: string
  algorithm: string
}

export interface DecryptionOptions {
  keyId?: string
  algorithm?: string
}

// Simplified encryption service for MCP system
// In production, integrate with your existing database schema
export class EncryptionService {
  private readonly ALGORITHM = 'aes-256-gcm'
  private readonly KEY_LENGTH = 32 // 256 bits
  private readonly IV_LENGTH = 16
  private readonly TAG_LENGTH = 16

  // In-memory key store for demo (use database in production)
  private keyStore = new Map<string, string>()

  /**
   * Get or create master encryption key from environment
   */
  private getMasterKey(): Buffer {
    const masterKey = process.env.MASTER_ENCRYPTION_KEY || 'default-key-for-development'
    
    // In production, this should be a proper 256-bit key
    return crypto.scryptSync(masterKey, 'salt', 32)
  }

  /**
   * Generate a new encryption key for specific purpose
   */
  async generateEncryptionKey(purpose: string = 'mcp_credentials'): Promise<string> {
    try {
      // Generate a random encryption key
      const key = crypto.randomBytes(this.KEY_LENGTH)
      
      // Encrypt the key with master key
      const masterKey = this.getMasterKey()
      const iv = crypto.randomBytes(this.IV_LENGTH)
      const cipher = crypto.createCipherGCM(this.ALGORITHM, masterKey, iv)
      
      let encryptedKey = cipher.update(key)
      cipher.final()
      
      const authTag = cipher.getAuthTag()
      const encryptedKeyWithMetadata = `${iv.toString('hex')}:${authTag.toString('hex')}:${encryptedKey.toString('hex')}`

      // Store in memory (use database in production)
      const keyId = crypto.randomUUID()
      this.keyStore.set(keyId, encryptedKeyWithMetadata)

      return keyId
    } catch (error) {
      logger.error('Error generating encryption key:', error)
      throw error
    }
  }

  /**
   * Get encryption key by ID
   */
  private async getEncryptionKey(keyId: string): Promise<Buffer> {
    try {
      const encryptedKeyWithMetadata = this.keyStore.get(keyId)
      if (!encryptedKeyWithMetadata) {
        throw new Error(`Encryption key not found: ${keyId}`)
      }

      // Decrypt the stored key
      const masterKey = this.getMasterKey()
      const [ivHex, tagHex, encryptedKeyHex] = encryptedKeyWithMetadata.split(':')
      
      const iv = Buffer.from(ivHex, 'hex')
      const tag = Buffer.from(tagHex, 'hex')
      const encryptedKey = Buffer.from(encryptedKeyHex, 'hex')
      
      const decipher = crypto.createDecipherGCM(this.ALGORITHM, masterKey, iv)
      decipher.setAuthTag(tag)
      
      let decryptedKey = decipher.update(encryptedKey)
      const final = decipher.final()
      
      return Buffer.concat([decryptedKey, final])
    } catch (error) {
      logger.error('Error retrieving encryption key:', error)
      throw error
    }
  }

  /**
   * Encrypt sensitive data
   */
  async encrypt(
    data: string, 
    purpose: string = 'mcp_credentials'
  ): Promise<EncryptionResult> {
    try {
      // Get or create encryption key
      const keyId = await this.getActiveKeyForPurpose(purpose) || 
                   await this.generateEncryptionKey(purpose)
      
      const encryptionKey = await this.getEncryptionKey(keyId)
      
      // Generate random IV for this encryption
      const iv = crypto.randomBytes(this.IV_LENGTH)
      
      // Create cipher
      const cipher = crypto.createCipherGCM(this.ALGORITHM, encryptionKey, iv)
      
      // Encrypt the data
      let encrypted = cipher.update(data, 'utf8')
      cipher.final()
      
      // Get authentication tag
      const authTag = cipher.getAuthTag()
      
      // Combine IV, auth tag, and encrypted data
      const encryptedData = `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted.toString('hex')}`
      
      return {
        encryptedData,
        keyId,
        algorithm: this.ALGORITHM
      }
    } catch (error) {
      logger.error('Error encrypting data:', error)
      throw error
    }
  }

  /**
   * Decrypt sensitive data
   */
  async decrypt(
    encryptedData: string, 
    keyId: string,
    options: DecryptionOptions = {}
  ): Promise<string> {
    try {
      // Parse the encrypted data
      const [ivHex, tagHex, encryptedHex] = encryptedData.split(':')
      
      if (!ivHex || !tagHex || !encryptedHex) {
        throw new Error('Invalid encrypted data format')
      }
      
      const iv = Buffer.from(ivHex, 'hex')
      const authTag = Buffer.from(tagHex, 'hex')
      const encrypted = Buffer.from(encryptedHex, 'hex')
      
      // Get the encryption key
      const encryptionKey = await this.getEncryptionKey(keyId)
      
      // Create decipher
      const decipher = crypto.createDecipherGCM(options.algorithm || this.ALGORITHM, encryptionKey, iv)
      decipher.setAuthTag(authTag)
      
      // Decrypt the data
      let decrypted = decipher.update(encrypted, null, 'utf8')
      decrypted += decipher.final('utf8')
      
      return decrypted
    } catch (error) {
      logger.error('Error decrypting data:', error)
      throw error
    }
  }

  /**
   * Get active encryption key for a specific purpose
   */
  private async getActiveKeyForPurpose(purpose: string): Promise<string | null> {
    try {
      // For demo, use the most recent key for this purpose
      for (const [keyId] of this.keyStore.entries()) {
        return keyId // Return the first available key
      }
      return null
    } catch (error) {
      logger.error('Error getting active key for purpose:', error)
      return null
    }
  }

  /**
   * Rotate encryption keys (for security best practices) - Simplified for demo
   */
  async rotateKeys(purpose: string = 'mcp_credentials'): Promise<{
    oldKeyId: string
    newKeyId: string
    migratedCredentials: number
  }> {
    try {
      // Get current active key
      const currentKeyId = await this.getActiveKeyForPurpose(purpose)
      if (!currentKeyId) {
        throw new Error('No active key found for rotation')
      }

      // Generate new key
      const newKeyId = await this.generateEncryptionKey(purpose)

      logger.info(`Key rotation completed. Old key: ${currentKeyId}, New key: ${newKeyId}`)

      return {
        oldKeyId: currentKeyId,
        newKeyId,
        migratedCredentials: 0 // Simplified for demo
      }
    } catch (error) {
      logger.error('Error rotating encryption keys:', error)
      throw error
    }
  }

  /**
   * Securely hash passwords or API keys for validation
   */
  async hashSecret(secret: string, salt?: string): Promise<{ hash: string; salt: string }> {
    try {
      const secretSalt = salt || crypto.randomBytes(16).toString('hex')
      const hash = crypto.pbkdf2Sync(secret, secretSalt, 10000, 64, 'sha512').toString('hex')
      
      return { hash, salt: secretSalt }
    } catch (error) {
      logger.error('Error hashing secret:', error)
      throw error
    }
  }

  /**
   * Verify a secret against its hash
   */
  async verifySecret(secret: string, hash: string, salt: string): Promise<boolean> {
    try {
      const computedHash = crypto.pbkdf2Sync(secret, salt, 10000, 64, 'sha512').toString('hex')
      return computedHash === hash
    } catch (error) {
      logger.error('Error verifying secret:', error)
      return false
    }
  }

  /**
   * Generate secure API key for MCP authentication
   */
  generateSecureApiKey(prefix: string = 'mcp'): string {
    const randomBytes = crypto.randomBytes(32).toString('hex')
    const timestamp = Date.now().toString(36)
    return `${prefix}_${timestamp}_${randomBytes}`
  }

  /**
   * Validate API key format
   */
  validateApiKeyFormat(apiKey: string): boolean {
    const pattern = /^[a-zA-Z]+_[a-z0-9]+_[a-f0-9]{64}$/
    return pattern.test(apiKey)
  }
}

export const encryptionService = new EncryptionService()
