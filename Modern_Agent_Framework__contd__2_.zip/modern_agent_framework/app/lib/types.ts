
import { Agent, Task, Message, Collaboration, AgentStatus, TaskStatus, Priority, ExecutionStatus, MessageRole, CollaborationType, CollaborationStatus } from '@prisma/client'

// Extended types with relationships
export interface AgentWithRelations extends Agent {
  tasks?: Task[]
  sentMessages?: Message[]
  receivedMessages?: Message[]
  _count?: {
    tasks: number
    sentMessages: number
    receivedMessages: number
  }
}

export interface TaskWithRelations extends Task {
  agent?: Agent
  parentTask?: Task
  subTasks?: Task[]
  executions?: TaskExecution[]
  messages?: Message[]
}

export interface TaskExecution {
  id: string
  taskId: string
  step: number
  action: string
  input?: string | null
  output?: string | null
  status: ExecutionStatus
  error?: string | null
  metadata?: any
  createdAt: Date
}

// Agent creation and update types
export interface CreateAgentRequest {
  name: string
  description?: string
  role: string
  model?: string
  systemPrompt?: string
  capabilities?: string[]
}

export interface UpdateAgentRequest {
  name?: string
  description?: string
  role?: string
  model?: string
  systemPrompt?: string
  capabilities?: string[]
  status?: AgentStatus
}

// Task creation and update types
export interface CreateTaskRequest {
  title: string
  description: string
  instructions?: string
  priority?: Priority
  agentId?: string
  parentTaskId?: string
}

export interface UpdateTaskRequest {
  title?: string
  description?: string
  instructions?: string
  status?: TaskStatus
  priority?: Priority
  result?: string
  agentId?: string
}

// Agent execution context
export interface AgentContext {
  agent: Agent
  task: Task
  messages: Message[]
  collaborationContext?: CollaborationContext
}

export interface CollaborationContext {
  collaboration: Collaboration
  participants: Agent[]
  currentStep: number
  totalSteps?: number
}

// LLM streaming types
export interface LLMStreamResponse {
  status: 'processing' | 'completed' | 'error'
  message?: string
  result?: any
  progress?: number
}

export interface AgentExecutionRequest {
  agentId: string
  taskId: string
  input?: string
  stream?: boolean
}

// Dashboard types
export interface AgentMetrics {
  totalAgents: number
  activeAgents: number
  completedTasks: number
  pendingTasks: number
  failedTasks: number
  avgTaskCompletionTime: number
}

export interface SystemHealth {
  database: 'healthy' | 'error'
  llmApi: 'healthy' | 'error'
  agents: 'healthy' | 'warning' | 'error'
  lastUpdated: Date
}

// Re-export Prisma enums
export {
  AgentStatus,
  TaskStatus,
  Priority,
  ExecutionStatus,
  MessageRole,
  CollaborationType,
  CollaborationStatus
}
