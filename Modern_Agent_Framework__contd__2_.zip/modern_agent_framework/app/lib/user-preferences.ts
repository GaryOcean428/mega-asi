
import React from 'react'

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system'
  language: string
  chatSettings: {
    showIntentAnalysis: boolean
    autoSuggestions: boolean
    voiceEnabled: boolean
    soundEffects: boolean
    compactMode: boolean
  }
  agentDefaults: {
    model: string
    temperature: number
    maxTokens: number
    systemPromptTemplate: string
  }
  notifications: {
    agentCreated: boolean
    collaborationInvites: boolean
    taskCompleted: boolean
    emailDigest: boolean
    pushEnabled: boolean
  }
  accessibility: {
    reduceMotion: boolean
    highContrast: boolean
    largeText: boolean
    screenReader: boolean
  }
  onboarding: {
    completed: boolean
    currentStep: number
    skippedTutorial: boolean
    demosSeen: string[]
  }
  workspace: {
    defaultView: 'dashboard' | 'chat' | 'agents'
    sidebarCollapsed: boolean
    gridView: boolean
    sortBy: 'name' | 'created' | 'status'
  }
}

const DEFAULT_PREFERENCES: UserPreferences = {
  theme: 'dark',
  language: 'en',
  chatSettings: {
    showIntentAnalysis: true,
    autoSuggestions: true,
    voiceEnabled: false,
    soundEffects: true,
    compactMode: false
  },
  agentDefaults: {
    model: 'gpt-4.1-mini',
    temperature: 0.7,
    maxTokens: 2000,
    systemPromptTemplate: 'You are a helpful AI assistant specialized in {role}. {additionalInstructions}'
  },
  notifications: {
    agentCreated: true,
    collaborationInvites: true,
    taskCompleted: true,
    emailDigest: false,
    pushEnabled: false
  },
  accessibility: {
    reduceMotion: false,
    highContrast: false,
    largeText: false,
    screenReader: false
  },
  onboarding: {
    completed: false,
    currentStep: 0,
    skippedTutorial: false,
    demosSeen: []
  },
  workspace: {
    defaultView: 'dashboard',
    sidebarCollapsed: false,
    gridView: true,
    sortBy: 'created'
  }
}

export class UserPreferencesManager {
  private static STORAGE_KEY = 'agent_framework_preferences'
  
  static getPreferences(): UserPreferences {
    if (typeof window === 'undefined') {
      return DEFAULT_PREFERENCES
    }
    
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored)
        return { ...DEFAULT_PREFERENCES, ...parsed }
      }
    } catch (error) {
      console.error('Error loading user preferences:', error)
    }
    
    return DEFAULT_PREFERENCES
  }
  
  static setPreferences(preferences: Partial<UserPreferences>): void {
    if (typeof window === 'undefined') return
    
    try {
      const current = this.getPreferences()
      const updated = this.deepMerge(current, preferences)
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updated))
      
      // Dispatch custom event for reactive updates
      window.dispatchEvent(new CustomEvent('preferencesChanged', { 
        detail: updated 
      }))
    } catch (error) {
      console.error('Error saving user preferences:', error)
    }
  }
  
  static updatePreference<K extends keyof UserPreferences>(
    key: K, 
    value: UserPreferences[K]
  ): void {
    this.setPreferences({ [key]: value } as Partial<UserPreferences>)
  }
  
  static resetPreferences(): void {
    if (typeof window === 'undefined') return
    
    try {
      localStorage.removeItem(this.STORAGE_KEY)
      window.dispatchEvent(new CustomEvent('preferencesChanged', { 
        detail: DEFAULT_PREFERENCES 
      }))
    } catch (error) {
      console.error('Error resetting user preferences:', error)
    }
  }
  
  private static deepMerge(target: any, source: any): any {
    const result = { ...target }
    
    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        result[key] = this.deepMerge(target[key] || {}, source[key])
      } else {
        result[key] = source[key]
      }
    }
    
    return result
  }
  
  // Onboarding helpers
  static markOnboardingComplete(): void {
    this.updatePreference('onboarding', {
      ...this.getPreferences().onboarding,
      completed: true,
      currentStep: 0
    })
  }
  
  static updateOnboardingStep(step: number): void {
    this.updatePreference('onboarding', {
      ...this.getPreferences().onboarding,
      currentStep: step
    })
  }
  
  static addSeenDemo(demoId: string): void {
    const prefs = this.getPreferences()
    const demosSeen = [...prefs.onboarding.demosSeen, demoId]
    this.updatePreference('onboarding', {
      ...prefs.onboarding,
      demosSeen
    })
  }
  
  static skipTutorial(): void {
    this.updatePreference('onboarding', {
      ...this.getPreferences().onboarding,
      skippedTutorial: true,
      completed: true
    })
  }
}

// React hook for using preferences
export function useUserPreferences() {
  const [preferences, setPreferences] = React.useState<UserPreferences>(
    UserPreferencesManager.getPreferences()
  )
  
  React.useEffect(() => {
    const handlePreferencesChange = (event: CustomEvent<UserPreferences>) => {
      setPreferences(event.detail)
    }
    
    window.addEventListener('preferencesChanged', handlePreferencesChange as EventListener)
    
    return () => {
      window.removeEventListener('preferencesChanged', handlePreferencesChange as EventListener)
    }
  }, [])
  
  const updatePreferences = React.useCallback((updates: Partial<UserPreferences>) => {
    UserPreferencesManager.setPreferences(updates)
  }, [])
  
  const updatePreference = React.useCallback(<K extends keyof UserPreferences>(
    key: K, 
    value: UserPreferences[K]
  ) => {
    UserPreferencesManager.updatePreference(key, value)
  }, [])
  
  return {
    preferences,
    updatePreferences,
    updatePreference,
    resetPreferences: UserPreferencesManager.resetPreferences,
    markOnboardingComplete: UserPreferencesManager.markOnboardingComplete,
    updateOnboardingStep: UserPreferencesManager.updateOnboardingStep,
    addSeenDemo: UserPreferencesManager.addSeenDemo,
    skipTutorial: UserPreferencesManager.skipTutorial
  }
}
