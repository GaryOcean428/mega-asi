
export type ScheduleFrequency = 'once' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'cron'

export interface ScheduleConfig {
  frequency: ScheduleFrequency
  cronExpression?: string  // For custom schedules
  startDate?: Date
  endDate?: Date
  timezone: string
  active: boolean
}

export interface WorkflowTrigger {
  id: string
  type: 'schedule' | 'event' | 'webhook' | 'manual'
  name: string
  description?: string
  config: ScheduleConfig | EventTriggerConfig | WebhookTriggerConfig
  workflowId: string
  createdAt: Date
  updatedAt: Date
  lastTriggered?: Date
  nextRun?: Date
  status: 'active' | 'paused' | 'disabled'
}

export interface EventTriggerConfig {
  eventType: string
  filters?: Record<string, any>
  conditions?: Array<{
    field: string
    operator: 'equals' | 'contains' | 'greater' | 'less' | 'exists'
    value: any
  }>
}

export interface WebhookTriggerConfig {
  url: string
  secret?: string
  headers?: Record<string, string>
  method: 'POST' | 'GET' | 'PUT' | 'PATCH'
}

export interface WorkflowExecution {
  id: string
  workflowId: string
  triggerId: string
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled'
  startedAt: Date
  completedAt?: Date
  duration?: number
  result?: any
  error?: string
  logs: WorkflowLog[]
  context: Record<string, any>
}

export interface WorkflowLog {
  id: string
  executionId: string
  level: 'info' | 'warn' | 'error' | 'debug'
  message: string
  timestamp: Date
  agentId?: string
  stepId?: string
  metadata?: Record<string, any>
}

export interface WorkflowStep {
  id: string
  type: 'agent' | 'condition' | 'delay' | 'webhook' | 'transform'
  name: string
  config: any
  agentId?: string
  dependsOn?: string[]
  timeout?: number
  retryConfig?: {
    attempts: number
    delay: number
    backoffMultiplier: number
  }
}

export interface Workflow {
  id: string
  name: string
  description?: string
  steps: WorkflowStep[]
  triggers: WorkflowTrigger[]
  status: 'active' | 'draft' | 'paused'
  version: number
  createdBy: string
  createdAt: Date
  updatedAt: Date
  tags: string[]
  settings: {
    timeout: number
    maxRetries: number
    notifyOnFailure: boolean
    parallelExecution: boolean
  }
}

export interface ScheduledTask {
  id: string
  name: string
  type: 'workflow' | 'agent' | 'maintenance' | 'report'
  schedule: ScheduleConfig
  payload: any
  status: 'active' | 'paused' | 'disabled'
  lastRun?: Date
  nextRun?: Date
  runCount: number
  successCount: number
  failureCount: number
  createdAt: Date
  updatedAt: Date
}
