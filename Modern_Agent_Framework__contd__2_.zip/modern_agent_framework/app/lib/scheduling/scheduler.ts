
import { ScheduleConfig, WorkflowTrigger, WorkflowExecution, ScheduledTask, Workflow } from './types'
import { safeRedis } from '../redis/client'
import { analytics } from '../analytics/collector'

class WorkflowScheduler {
  private static instance: WorkflowScheduler
  private running = false
  private interval: NodeJS.Timeout | null = null
  private readonly checkInterval = 30000 // Check every 30 seconds

  static getInstance(): WorkflowScheduler {
    if (!WorkflowScheduler.instance) {
      WorkflowScheduler.instance = new WorkflowScheduler()
    }
    return WorkflowScheduler.instance
  }

  start() {
    if (this.running) return

    this.running = true
    this.interval = setInterval(() => {
      this.processScheduledTasks()
    }, this.checkInterval)

    console.log('Workflow scheduler started')
    analytics.trackSystemEvent('scheduler', 'started')
  }

  stop() {
    if (!this.running) return

    this.running = false
    if (this.interval) {
      clearInterval(this.interval)
      this.interval = null
    }

    console.log('Workflow scheduler stopped')
    analytics.trackSystemEvent('scheduler', 'stopped')
  }

  async scheduleWorkflow(workflowId: string, schedule: ScheduleConfig): Promise<WorkflowTrigger> {
    const trigger: WorkflowTrigger = {
      id: this.generateId(),
      type: 'schedule',
      name: `Schedule for ${workflowId}`,
      config: schedule,
      workflowId,
      createdAt: new Date(),
      updatedAt: new Date(),
      nextRun: this.calculateNextRun(schedule),
      status: 'active'
    }

    await this.saveTrigger(trigger)
    analytics.trackSystemEvent('scheduler', 'workflow_scheduled', workflowId)

    return trigger
  }

  async createScheduledTask(task: Omit<ScheduledTask, 'id' | 'createdAt' | 'updatedAt' | 'runCount' | 'successCount' | 'failureCount'>): Promise<ScheduledTask> {
    const scheduledTask: ScheduledTask = {
      ...task,
      id: this.generateId(),
      nextRun: this.calculateNextRun(task.schedule),
      runCount: 0,
      successCount: 0,
      failureCount: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    }

    await this.saveScheduledTask(scheduledTask)
    analytics.trackSystemEvent('scheduler', 'task_created', scheduledTask.type)

    return scheduledTask
  }

  async updateSchedule(triggerId: string, schedule: ScheduleConfig): Promise<void> {
    const trigger = await this.getTrigger(triggerId)
    if (!trigger) {
      throw new Error('Trigger not found')
    }

    trigger.config = schedule
    trigger.nextRun = this.calculateNextRun(schedule)
    trigger.updatedAt = new Date()

    await this.saveTrigger(trigger)
    analytics.trackSystemEvent('scheduler', 'schedule_updated', triggerId)
  }

  async pauseSchedule(triggerId: string): Promise<void> {
    const trigger = await this.getTrigger(triggerId)
    if (!trigger) {
      throw new Error('Trigger not found')
    }

    trigger.status = 'paused'
    trigger.updatedAt = new Date()

    await this.saveTrigger(trigger)
    analytics.trackSystemEvent('scheduler', 'schedule_paused', triggerId)
  }

  async resumeSchedule(triggerId: string): Promise<void> {
    const trigger = await this.getTrigger(triggerId)
    if (!trigger) {
      throw new Error('Trigger not found')
    }

    trigger.status = 'active'
    trigger.nextRun = this.calculateNextRun(trigger.config as ScheduleConfig)
    trigger.updatedAt = new Date()

    await this.saveTrigger(trigger)
    analytics.trackSystemEvent('scheduler', 'schedule_resumed', triggerId)
  }

  async deleteSchedule(triggerId: string): Promise<void> {
    await safeRedis.del(`schedule:trigger:${triggerId}`)
    analytics.trackSystemEvent('scheduler', 'schedule_deleted', triggerId)
  }

  async getScheduledTasks(): Promise<ScheduledTask[]> {
    // In a real implementation, this would query the database
    // For now, return mock data or implement Redis-based storage
    return []
  }

  async getUpcomingExecutions(limit: number = 10): Promise<Array<{ trigger: WorkflowTrigger; nextRun: Date }>> {
    // Implementation would query scheduled triggers and return next executions
    return []
  }

  private async processScheduledTasks() {
    try {
      const now = new Date()
      const triggers = await this.getActiveTriggers()

      for (const trigger of triggers) {
        if (this.shouldTrigger(trigger, now)) {
          await this.executeTrigger(trigger)
        }
      }
    } catch (error: any) {
      console.error('Error processing scheduled tasks:', error)
      analytics.trackError(`scheduler_process_error:${error?.message || 'Unknown error'}`, 'scheduler')
    }
  }

  private shouldTrigger(trigger: WorkflowTrigger, now: Date): boolean {
    if (trigger.status !== 'active') return false
    if (!trigger.nextRun) return false
    return trigger.nextRun <= now
  }

  private async executeTrigger(trigger: WorkflowTrigger) {
    try {
      analytics.trackSystemEvent('scheduler', 'trigger_executed', trigger.id)

      const execution: WorkflowExecution = {
        id: this.generateId(),
        workflowId: trigger.workflowId,
        triggerId: trigger.id,
        status: 'pending',
        startedAt: new Date(),
        logs: [],
        context: {}
      }

      // Update trigger's next run time
      trigger.lastTriggered = new Date()
      trigger.nextRun = this.calculateNextRun(trigger.config as ScheduleConfig, trigger.lastTriggered)
      await this.saveTrigger(trigger)

      // Execute the workflow (this would integrate with your workflow engine)
      await this.executeWorkflow(execution)

    } catch (error: any) {
      console.error('Error executing trigger:', error)
      analytics.trackError(`trigger_execution_error:${error?.message || 'Unknown error'}`, 'scheduler', {
        triggerId: trigger.id,
        workflowId: trigger.workflowId
      })
    }
  }

  private async executeWorkflow(execution: WorkflowExecution) {
    // This is a placeholder for workflow execution logic
    // In a real implementation, this would:
    // 1. Load the workflow definition
    // 2. Execute each step in sequence or parallel
    // 3. Handle errors and retries
    // 4. Update execution status and logs
    
    console.log(`Executing workflow ${execution.workflowId}`)
    
    // Simulate workflow execution
    execution.status = 'running'
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    execution.status = 'completed'
    execution.completedAt = new Date()
    execution.duration = execution.completedAt.getTime() - execution.startedAt.getTime()
  }

  private calculateNextRun(schedule: ScheduleConfig, fromDate?: Date): Date {
    const now = fromDate || new Date()
    let nextRun = new Date(now)

    switch (schedule.frequency) {
      case 'once':
        return schedule.startDate || now
      
      case 'hourly':
        nextRun.setHours(nextRun.getHours() + 1)
        break
      
      case 'daily':
        nextRun.setDate(nextRun.getDate() + 1)
        break
      
      case 'weekly':
        nextRun.setDate(nextRun.getDate() + 7)
        break
      
      case 'monthly':
        nextRun.setMonth(nextRun.getMonth() + 1)
        break
      
      case 'cron':
        if (schedule.cronExpression) {
          // Would use a cron parser library like 'cron-parser'
          // For now, default to daily
          nextRun.setDate(nextRun.getDate() + 1)
        }
        break
    }

    // Respect start and end dates
    if (schedule.startDate && nextRun < schedule.startDate) {
      nextRun = new Date(schedule.startDate)
    }

    return nextRun
  }

  private async getActiveTriggers(): Promise<WorkflowTrigger[]> {
    // Implementation would query stored triggers
    // For now, return empty array
    return []
  }

  private async getTrigger(triggerId: string): Promise<WorkflowTrigger | null> {
    try {
      const data = await safeRedis.get(`schedule:trigger:${triggerId}`)
      return data ? JSON.parse(data) : null
    } catch {
      return null
    }
  }

  private async saveTrigger(trigger: WorkflowTrigger): Promise<void> {
    await safeRedis.set(`schedule:trigger:${trigger.id}`, JSON.stringify(trigger), 86400 * 30) // 30 days
  }

  private async saveScheduledTask(task: ScheduledTask): Promise<void> {
    await safeRedis.set(`schedule:task:${task.id}`, JSON.stringify(task), 86400 * 30) // 30 days
  }

  private generateId(): string {
    return `sched_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  // Utility methods for common scheduling patterns
  static createDailySchedule(time: string, timezone: string = 'UTC'): ScheduleConfig {
    return {
      frequency: 'daily',
      timezone,
      active: true
    }
  }

  static createWeeklySchedule(dayOfWeek: number, time: string, timezone: string = 'UTC'): ScheduleConfig {
    return {
      frequency: 'weekly',
      timezone,
      active: true
    }
  }

  static createCronSchedule(expression: string, timezone: string = 'UTC'): ScheduleConfig {
    return {
      frequency: 'cron',
      cronExpression: expression,
      timezone,
      active: true
    }
  }
}

export const scheduler = WorkflowScheduler.getInstance()

// React hook for scheduling functionality
export function useScheduler() {
  return {
    scheduleWorkflow: scheduler.scheduleWorkflow.bind(scheduler),
    createScheduledTask: scheduler.createScheduledTask.bind(scheduler),
    updateSchedule: scheduler.updateSchedule.bind(scheduler),
    pauseSchedule: scheduler.pauseSchedule.bind(scheduler),
    resumeSchedule: scheduler.resumeSchedule.bind(scheduler),
    deleteSchedule: scheduler.deleteSchedule.bind(scheduler),
    getScheduledTasks: scheduler.getScheduledTasks.bind(scheduler),
    getUpcomingExecutions: scheduler.getUpcomingExecutions.bind(scheduler),
  }
}
