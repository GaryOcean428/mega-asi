
/**
 * Logger utility for structured logging across the application
 */

interface LogLevel {
  ERROR: 'error'
  WARN: 'warn'  
  INFO: 'info'
  DEBUG: 'debug'
}

interface LogEntry {
  level: keyof LogLevel
  message: string
  timestamp: string
  context?: Record<string, any>
  error?: Error
}

class Logger {
  private logLevel: keyof LogLevel = 'INFO'

  constructor() {
    // Set log level from environment
    const envLevel = (process.env.LOG_LEVEL || 'info').toUpperCase() as keyof LogLevel
    if (['ERROR', 'WARN', 'INFO', 'DEBUG'].includes(envLevel)) {
      this.logLevel = envLevel
    }
  }

  private shouldLog(level: keyof LogLevel): boolean {
    const levels: LogLevel = { ERROR: 'error', WARN: 'warn', INFO: 'info', DEBUG: 'debug' }
    const currentLevelIndex = Object.keys(levels).indexOf(this.logLevel)
    const requestedLevelIndex = Object.keys(levels).indexOf(level)
    return requestedLevelIndex <= currentLevelIndex
  }

  private formatLog(entry: LogEntry): string {
    const baseLog = {
      timestamp: entry.timestamp,
      level: entry.level,
      message: entry.message
    }

    if (entry.context) {
      Object.assign(baseLog, { context: entry.context })
    }

    if (entry.error) {
      Object.assign(baseLog, { 
        error: {
          name: entry.error.name,
          message: entry.error.message,
          stack: entry.error.stack
        }
      })
    }

    return JSON.stringify(baseLog)
  }

  private log(level: keyof LogLevel, message: string, context?: Record<string, any>, error?: Error): void {
    if (!this.shouldLog(level)) return

    const entry: LogEntry = {
      level,
      message,
      timestamp: new Date().toISOString(),
      context,
      error
    }

    const formattedLog = this.formatLog(entry)

    // In development, also log to console with colors
    if (process.env.NODE_ENV !== 'production') {
      const colors = {
        ERROR: '\x1b[31m', // Red
        WARN: '\x1b[33m',  // Yellow
        INFO: '\x1b[36m',  // Cyan
        DEBUG: '\x1b[90m'  // Gray
      }
      const reset = '\x1b[0m'
      console.log(`${colors[level]}[${level}]${reset} ${message}`, context || '', error || '')
    }

    // Always log structured format
    console.log(formattedLog)
  }

  error(message: string, error?: Error | unknown, context?: Record<string, any>): void {
    const err = error instanceof Error ? error : 
                error ? new Error(String(error)) : undefined
    this.log('ERROR', message, context, err)
  }

  warn(message: string, context?: Record<string, any>): void {
    this.log('WARN', message, context)
  }

  info(message: string, context?: Record<string, any>): void {
    this.log('INFO', message, context)
  }

  debug(message: string, context?: Record<string, any>): void {
    this.log('DEBUG', message, context)
  }

  // Structured logging helpers
  mcpActivity(action: string, mcpName: string, details?: Record<string, any>): void {
    this.info(`MCP Activity: ${action}`, { 
      mcp: mcpName,
      action,
      ...details 
    })
  }

  securityEvent(event: string, userId?: string, details?: Record<string, any>): void {
    this.warn(`Security Event: ${event}`, {
      event,
      userId,
      ...details
    })
  }

  performanceMetric(operation: string, duration: number, details?: Record<string, any>): void {
    this.info(`Performance: ${operation}`, {
      operation,
      duration,
      ...details
    })
  }

  apiCall(method: string, endpoint: string, status: number, duration: number): void {
    const level = status >= 400 ? 'WARN' : 'INFO'
    this.log(level, `API ${method} ${endpoint}`, {
      method,
      endpoint, 
      status,
      duration
    })
  }
}

export const logger = new Logger()
