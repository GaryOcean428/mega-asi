
export interface AuditEvent {
  id: string
  timestamp: Date
  userId?: string
  userEmail?: string
  userName?: string
  action: string
  category: 'auth' | 'agents' | 'collaborations' | 'system' | 'data' | 'security'
  resource?: {
    type: string
    id: string
    name?: string
  }
  details: Record<string, any>
  metadata: {
    ip?: string
    userAgent?: string
    sessionId?: string
    organizationId?: string
    workspaceId?: string
  }
  severity: 'low' | 'medium' | 'high' | 'critical'
  outcome: 'success' | 'failure' | 'partial'
}

export interface AuditFilter {
  startDate?: Date
  endDate?: Date
  userId?: string
  category?: AuditEvent['category']
  action?: string
  severity?: AuditEvent['severity']
  outcome?: AuditEvent['outcome']
  resourceType?: string
  organizationId?: string
  workspaceId?: string
}

export interface AuditReport {
  id: string
  name: string
  description: string
  filters: AuditFilter
  events: AuditEvent[]
  generatedAt: Date
  generatedBy: string
  totalEvents: number
  summary: {
    byCategory: Record<string, number>
    byAction: Record<string, number>
    bySeverity: Record<string, number>
    byOutcome: Record<string, number>
    timeRange: { start: Date; end: Date }
  }
}

class AuditLogger {
  private static instance: AuditLogger
  private events: AuditEvent[] = []
  private listeners: Array<(event: AuditEvent) => void> = []
  private maxEvents = 10000 // Keep last 10k events in memory
  
  static getInstance(): AuditLogger {
    if (!AuditLogger.instance) {
      AuditLogger.instance = new AuditLogger()
    }
    return AuditLogger.instance
  }

  // Log an audit event
  async log(eventData: Omit<AuditEvent, 'id' | 'timestamp'>): Promise<void> {
    const event: AuditEvent = {
      id: this.generateEventId(),
      timestamp: new Date(),
      ...eventData
    }

    // Add to in-memory store
    this.events.unshift(event)
    
    // Keep only the most recent events
    if (this.events.length > this.maxEvents) {
      this.events = this.events.slice(0, this.maxEvents)
    }

    // Persist to storage (Redis, database, etc.)
    await this.persistEvent(event)
    
    // Notify listeners
    this.notifyListeners(event)
    
    // Check for security alerts
    await this.checkSecurityAlerts(event)
  }

  // Convenience methods for common audit events
  async logAuth(action: string, userId?: string, details: any = {}, outcome: AuditEvent['outcome'] = 'success'): Promise<void> {
    await this.log({
      userId,
      action,
      category: 'auth',
      details,
      metadata: await this.getMetadata(),
      severity: outcome === 'failure' ? 'medium' : 'low',
      outcome
    })
  }

  async logAgentAction(
    action: string, 
    userId: string, 
    agentId: string, 
    agentName: string, 
    details: any = {},
    outcome: AuditEvent['outcome'] = 'success'
  ): Promise<void> {
    await this.log({
      userId,
      action,
      category: 'agents',
      resource: { type: 'agent', id: agentId, name: agentName },
      details,
      metadata: await this.getMetadata(),
      severity: this.getSeverityForAction(action),
      outcome
    })
  }

  async logCollaborationAction(
    action: string,
    userId: string,
    collaborationId: string,
    collaborationName: string,
    details: any = {},
    outcome: AuditEvent['outcome'] = 'success'
  ): Promise<void> {
    await this.log({
      userId,
      action,
      category: 'collaborations',
      resource: { type: 'collaboration', id: collaborationId, name: collaborationName },
      details,
      metadata: await this.getMetadata(),
      severity: this.getSeverityForAction(action),
      outcome
    })
  }

  async logSystemEvent(
    action: string,
    userId?: string,
    details: any = {},
    severity: AuditEvent['severity'] = 'medium'
  ): Promise<void> {
    await this.log({
      userId,
      action,
      category: 'system',
      details,
      metadata: await this.getMetadata(),
      severity,
      outcome: 'success'
    })
  }

  async logDataAccess(
    action: string,
    userId: string,
    resourceType: string,
    resourceId: string,
    resourceName?: string,
    details: any = {}
  ): Promise<void> {
    await this.log({
      userId,
      action,
      category: 'data',
      resource: { type: resourceType, id: resourceId, name: resourceName },
      details,
      metadata: await this.getMetadata(),
      severity: 'low',
      outcome: 'success'
    })
  }

  async logSecurityEvent(
    action: string,
    userId?: string,
    details: any = {},
    severity: AuditEvent['severity'] = 'high',
    outcome: AuditEvent['outcome'] = 'failure'
  ): Promise<void> {
    await this.log({
      userId,
      action,
      category: 'security',
      details,
      metadata: await this.getMetadata(),
      severity,
      outcome
    })
  }

  // Query audit events
  async queryEvents(filter: AuditFilter = {}): Promise<AuditEvent[]> {
    let results = this.events

    // Apply filters
    if (filter.startDate) {
      results = results.filter(e => e.timestamp >= filter.startDate!)
    }
    
    if (filter.endDate) {
      results = results.filter(e => e.timestamp <= filter.endDate!)
    }
    
    if (filter.userId) {
      results = results.filter(e => e.userId === filter.userId)
    }
    
    if (filter.category) {
      results = results.filter(e => e.category === filter.category)
    }
    
    if (filter.action) {
      results = results.filter(e => e.action.includes(filter.action!))
    }
    
    if (filter.severity) {
      results = results.filter(e => e.severity === filter.severity)
    }
    
    if (filter.outcome) {
      results = results.filter(e => e.outcome === filter.outcome)
    }
    
    if (filter.resourceType) {
      results = results.filter(e => e.resource?.type === filter.resourceType)
    }
    
    if (filter.organizationId) {
      results = results.filter(e => e.metadata.organizationId === filter.organizationId)
    }
    
    if (filter.workspaceId) {
      results = results.filter(e => e.metadata.workspaceId === filter.workspaceId)
    }

    return results
  }

  // Generate audit report
  async generateReport(
    name: string,
    description: string,
    filters: AuditFilter,
    generatedBy: string
  ): Promise<AuditReport> {
    const events = await this.queryEvents(filters)
    
    const report: AuditReport = {
      id: this.generateReportId(),
      name,
      description,
      filters,
      events,
      generatedAt: new Date(),
      generatedBy,
      totalEvents: events.length,
      summary: this.generateSummary(events)
    }

    return report
  }

  // Export events for compliance
  async exportEvents(
    filter: AuditFilter = {},
    format: 'json' | 'csv' | 'pdf' = 'json'
  ): Promise<string> {
    const events = await this.queryEvents(filter)
    
    switch (format) {
      case 'json':
        return JSON.stringify(events, null, 2)
      case 'csv':
        return this.exportToCSV(events)
      case 'pdf':
        return this.exportToPDF(events)
      default:
        throw new Error('Unsupported export format')
    }
  }

  // Real-time event subscription
  subscribe(listener: (event: AuditEvent) => void): () => void {
    this.listeners.push(listener)
    
    return () => {
      const index = this.listeners.indexOf(listener)
      if (index > -1) {
        this.listeners.splice(index, 1)
      }
    }
  }

  // Security alert patterns
  private async checkSecurityAlerts(event: AuditEvent): Promise<void> {
    // Check for suspicious patterns
    if (event.category === 'security' || event.severity === 'critical') {
      await this.triggerSecurityAlert(event)
    }

    // Check for repeated failures
    if (event.outcome === 'failure') {
      const recentFailures = this.events
        .filter(e => 
          e.userId === event.userId &&
          e.action === event.action &&
          e.outcome === 'failure' &&
          e.timestamp > new Date(Date.now() - 15 * 60 * 1000) // Last 15 minutes
        )
        .length

      if (recentFailures >= 5) {
        await this.triggerSecurityAlert({
          ...event,
          action: 'repeated_failures',
          category: 'security',
          severity: 'high',
          details: { ...event.details, failureCount: recentFailures }
        })
      }
    }

    // Check for privilege escalation
    if (event.action.includes('role_granted') || event.action.includes('permission_granted')) {
      const details = event.details
      if (details.role === 'admin' || details.role === 'owner') {
        await this.triggerSecurityAlert({
          ...event,
          action: 'privilege_escalation',
          category: 'security',
          severity: 'high'
        })
      }
    }
  }

  private async triggerSecurityAlert(event: AuditEvent): Promise<void> {
    // In production, this would:
    // 1. Send notifications to security team
    // 2. Create incident tickets
    // 3. Trigger automated responses
    // 4. Log to SIEM systems
    
    console.warn('🚨 Security Alert:', event)
    
    // Example: Notify security webhook
    if (process.env.SECURITY_WEBHOOK_URL) {
      try {
        await fetch(process.env.SECURITY_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'security_alert',
            event,
            timestamp: new Date().toISOString()
          })
        })
      } catch (error) {
        console.error('Failed to send security alert:', error)
      }
    }
  }

  private async persistEvent(event: AuditEvent): Promise<void> {
    try {
      // Store in Redis or database
      // For now, we'll just log to console in development
      if (process.env.NODE_ENV === 'development') {
        console.log('📋 Audit Event:', {
          timestamp: event.timestamp.toISOString(),
          action: event.action,
          category: event.category,
          severity: event.severity,
          userId: event.userId,
          resource: event.resource
        })
      }
      
      // In production, store in database
      // await db.auditEvents.create(event)
    } catch (error) {
      console.error('Failed to persist audit event:', error)
    }
  }

  private notifyListeners(event: AuditEvent): void {
    this.listeners.forEach(listener => {
      try {
        listener(event)
      } catch (error) {
        console.error('Audit listener error:', error)
      }
    })
  }

  private getSeverityForAction(action: string): AuditEvent['severity'] {
    if (action.includes('delete') || action.includes('remove')) {
      return 'high'
    }
    if (action.includes('create') || action.includes('update')) {
      return 'medium'
    }
    return 'low'
  }

  private async getMetadata(): Promise<AuditEvent['metadata']> {
    // In browser environment, gather context
    if (typeof window !== 'undefined') {
      return {
        userAgent: navigator.userAgent,
        sessionId: sessionStorage.getItem('session-id') || undefined,
        // IP and organization context would come from server
      }
    }
    
    return {}
  }

  private generateEventId(): string {
    return `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  private generateReportId(): string {
    return `report_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  private generateSummary(events: AuditEvent[]): AuditReport['summary'] {
    const byCategory: Record<string, number> = {}
    const byAction: Record<string, number> = {}
    const bySeverity: Record<string, number> = {}
    const byOutcome: Record<string, number> = {}
    
    let earliestTimestamp = new Date()
    let latestTimestamp = new Date(0)

    events.forEach(event => {
      // Count by category
      byCategory[event.category] = (byCategory[event.category] || 0) + 1
      
      // Count by action
      byAction[event.action] = (byAction[event.action] || 0) + 1
      
      // Count by severity
      bySeverity[event.severity] = (bySeverity[event.severity] || 0) + 1
      
      // Count by outcome
      byOutcome[event.outcome] = (byOutcome[event.outcome] || 0) + 1
      
      // Track time range
      if (event.timestamp < earliestTimestamp) {
        earliestTimestamp = event.timestamp
      }
      if (event.timestamp > latestTimestamp) {
        latestTimestamp = event.timestamp
      }
    })

    return {
      byCategory,
      byAction,
      bySeverity,
      byOutcome,
      timeRange: { start: earliestTimestamp, end: latestTimestamp }
    }
  }

  private exportToCSV(events: AuditEvent[]): string {
    const headers = ['Timestamp', 'User ID', 'Action', 'Category', 'Severity', 'Outcome', 'Resource Type', 'Resource ID', 'Details']
    const rows = events.map(event => [
      event.timestamp.toISOString(),
      event.userId || '',
      event.action,
      event.category,
      event.severity,
      event.outcome,
      event.resource?.type || '',
      event.resource?.id || '',
      JSON.stringify(event.details)
    ])

    return [headers, ...rows]
      .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n')
  }

  private exportToPDF(events: AuditEvent[]): string {
    // In production, would use a PDF library
    return `PDF export not implemented yet. ${events.length} events would be included.`
  }
}

export const auditLogger = AuditLogger.getInstance()

// React hook for audit logging
export function useAuditLogger() {
  return {
    log: auditLogger.log.bind(auditLogger),
    logAuth: auditLogger.logAuth.bind(auditLogger),
    logAgentAction: auditLogger.logAgentAction.bind(auditLogger),
    logCollaborationAction: auditLogger.logCollaborationAction.bind(auditLogger),
    logSystemEvent: auditLogger.logSystemEvent.bind(auditLogger),
    logDataAccess: auditLogger.logDataAccess.bind(auditLogger),
    logSecurityEvent: auditLogger.logSecurityEvent.bind(auditLogger),
    queryEvents: auditLogger.queryEvents.bind(auditLogger),
    generateReport: auditLogger.generateReport.bind(auditLogger),
    exportEvents: auditLogger.exportEvents.bind(auditLogger),
    subscribe: auditLogger.subscribe.bind(auditLogger),
  }
}
