
/**
 * Intelligent MCP Assistant - AI-powered MCP discovery, setup, and troubleshooting
 * Integrates with the chat system to provide natural language MCP management
 */

import { LLMClient } from '@/lib/llm-client'
import { mcpManager, MCPRecommendation } from './manager'
import { RAGService } from '@/lib/rag/service'
import { prisma } from '@/lib/prisma'
import { logger } from '@/lib/utils/logger'

export interface MCPIntentAnalysis {
  intent: 'discover' | 'install' | 'configure' | 'troubleshoot' | 'recommend'
  confidence: number
  extractedInfo: {
    mcpName?: string
    capabilities?: string[]
    service?: string // GitHub, Slack, etc.
    problem?: string
    requirements?: string[]
  }
  suggestedActions: Array<{
    type: 'search' | 'install' | 'configure' | 'documentation'
    description: string
    parameters?: Record<string, any>
  }>
}

export interface MCPSetupGuide {
  steps: Array<{
    id: string
    title: string
    description: string
    type: 'info' | 'input' | 'action' | 'credential'
    required?: boolean
    inputType?: 'text' | 'password' | 'select' | 'file'
    options?: string[]
    validation?: {
      pattern?: string
      message?: string
    }
  }>
  estimatedTime: string
  difficulty: 'easy' | 'medium' | 'hard'
  prerequisites: string[]
}

export class IntelligentMCPAssistant {
  private llmClient: LLMClient
  private ragService: RAGService

  constructor() {
    this.llmClient = new LLMClient()
    this.ragService = new RAGService()
  }

  /**
   * Analyze user message to understand MCP-related intent
   */
  async analyzeIntent(message: string, userId: string): Promise<MCPIntentAnalysis | null> {
    try {
      const analysisPrompt = this.llmClient.createStructuredPrompt(
        `Analyze this user message to determine if they're asking about MCP (Model Context Protocol) integration and what they want to do.

User message: "${message}"

Determine:
1. Is this MCP-related? 
2. What do they want to accomplish?
3. What specific services or capabilities do they mention?
4. What's their likely intent?

Consider these common patterns:
- "I need to connect to GitHub" → install GitHub MCP
- "How do I set up Slack integration?" → configure Slack MCP  
- "My database connection isn't working" → troubleshoot database MCP
- "What tools can help with data analysis?" → discover/recommend MCPs

Respond with analysis of their intent and suggested actions.`,
        {
          isMCPRelated: "boolean",
          intent: "string", // 'discover', 'install', 'configure', 'troubleshoot', 'recommend'
          confidence: "number", // 0.0 to 1.0
          extractedInfo: {
            mcpName: "string or null",
            capabilities: "array of strings",
            service: "string or null", 
            problem: "string or null",
            requirements: "array of strings"
          },
          suggestedActions: "array of objects with type, description, and optional parameters"
        },
        'gpt-4.1'
      )

      const response = await this.llmClient.complete({
        messages: analysisPrompt,
        temperature: 0.1,
        responseFormat: { type: 'json_object' }
      })

      const analysis = JSON.parse(response.content)
      
      if (!analysis.isMCPRelated) {
        return null
      }

      return {
        intent: analysis.intent,
        confidence: analysis.confidence,
        extractedInfo: analysis.extractedInfo,
        suggestedActions: analysis.suggestedActions
      }
    } catch (error) {
      logger.error('Error analyzing MCP intent:', error)
      return null
    }
  }

  /**
   * Provide intelligent MCP recommendations based on user query
   */
  async getIntelligentRecommendations(
    query: string,
    userId: string,
    workspaceId?: string
  ): Promise<{
    recommendations: MCPRecommendation[]
    explanation: string
    setupGuides: Record<string, MCPSetupGuide>
  }> {
    try {
      // Get AI-powered recommendations
      const recommendations = await mcpManager.getRecommendations(userId, workspaceId, query)

      // Get relevant documentation from RAG
      const ragResults = await this.ragService.searchMCPKnowledge(query)

      // Generate explanation using LLM
      const explanationPrompt = [
        {
          role: 'system' as const,
          content: `You are an expert MCP (Model Context Protocol) consultant. Help users understand which MCPs would be most helpful for their needs and explain why.

Be conversational, helpful, and focus on practical benefits. Mention specific use cases and how the MCPs will solve their problems.`
        },
        {
          role: 'user' as const,
          content: `User query: "${query}"

Available MCP recommendations:
${recommendations.map(r => `- ${r.mcp.name}: ${r.mcp.description} (${r.reason})`).join('\n')}

Relevant documentation context:
${ragResults.slice(0, 3).map(r => `- ${r.title}: ${r.content.slice(0, 200)}...`).join('\n')}

Provide a helpful explanation of these recommendations and how they address the user's needs.`
        }
      ]

      const explanationResponse = await this.llmClient.complete({
        messages: explanationPrompt,
        temperature: 0.7,
        maxTokens: 500
      })

      // Generate setup guides for top recommendations
      const setupGuides: Record<string, MCPSetupGuide> = {}
      for (const rec of recommendations.slice(0, 3)) {
        setupGuides[rec.mcp.id] = await this.generateSetupGuide(rec.mcp.id)
      }

      return {
        recommendations,
        explanation: explanationResponse.content,
        setupGuides
      }
    } catch (error) {
      logger.error('Error getting intelligent recommendations:', error)
      return {
        recommendations: [],
        explanation: 'I encountered an error while analyzing your request. Please try again.',
        setupGuides: {}
      }
    }
  }

  /**
   * Generate step-by-step setup guide for an MCP
   */
  async generateSetupGuide(mcpId: string): Promise<MCPSetupGuide> {
    try {
      const mcp = await prisma.mcpRegistry.findUnique({
        where: { id: mcpId }
      })

      if (!mcp) {
        throw new Error('MCP not found')
      }

      // Get setup documentation from RAG
      const setupDocs = await this.ragService.searchMCPKnowledge(
        `${mcp.name} installation setup configuration`,
        { section: 'installation' }
      )

      // Generate personalized setup guide
      const guidePrompt = [
        {
          role: 'system' as const,
          content: `You are an expert technical guide writer. Create a clear, step-by-step setup guide for installing and configuring an MCP.

Make the guide:
- Clear and actionable
- Include all necessary steps
- Mention any prerequisites
- Estimate time and difficulty
- Include credential setup when needed

Format as JSON with structured steps.`
        },
        {
          role: 'user' as const,
          content: `Create a setup guide for: ${mcp.name}
Description: ${mcp.description}
Required credentials: ${mcp.requiredCredentials?.join(', ') || 'none'}
Configuration schema: ${JSON.stringify(mcp.configSchema, null, 2)}

Documentation context:
${setupDocs.slice(0, 2).map(doc => doc.content.slice(0, 300)).join('\n\n')}`
        }
      ]

      const guideResponse = await this.llmClient.complete({
        messages: guidePrompt,
        temperature: 0.3,
        responseFormat: { type: 'json_object' }
      })

      const guide = JSON.parse(guideResponse.content)
      return guide
    } catch (error) {
      logger.error('Error generating setup guide:', error)
      return {
        steps: [
          {
            id: 'error',
            title: 'Setup Guide Unavailable',
            description: 'Unable to generate setup guide at this time.',
            type: 'info'
          }
        ],
        estimatedTime: 'Unknown',
        difficulty: 'medium',
        prerequisites: []
      }
    }
  }

  /**
   * Provide troubleshooting assistance for MCP issues
   */
  async troubleshootMCP(
    problem: string,
    installationId: string,
    userId: string
  ): Promise<{
    diagnosis: string
    solutions: Array<{
      title: string
      description: string
      steps: string[]
      difficulty: 'easy' | 'medium' | 'hard'
      estimatedTime: string
    }>
    preventionTips: string[]
  }> {
    try {
      const installation = await prisma.mcpInstallation.findUnique({
        where: { id: installationId },
        include: { mcpRegistry: true }
      })

      if (!installation) {
        throw new Error('Installation not found')
      }

      // Get health check data
      const healthCheck = await mcpManager.performHealthCheck(installationId)

      // Search for similar issues in knowledge base
      const troubleshootingDocs = await this.ragService.searchMCPKnowledge(
        `${installation.mcpRegistry.name} ${problem} error troubleshooting`,
        { contentType: 'troubleshooting' }
      )

      // Generate diagnosis and solutions
      const troubleshootPrompt = [
        {
          role: 'system' as const,
          content: `You are an expert MCP troubleshooting specialist. Analyze the problem and provide practical solutions.

Provide:
1. Clear diagnosis of what's likely wrong
2. Step-by-step solutions (multiple options if possible)
3. Prevention tips for the future

Be specific and actionable.`
        },
        {
          role: 'user' as const,
          content: `Problem: ${problem}

MCP Details:
- Name: ${installation.mcpRegistry.name}
- Version: ${installation.version}
- Status: ${installation.status}
- Health: ${healthCheck.status}
- Error: ${installation.errorMessage || 'None'}

Configuration:
${JSON.stringify(installation.config, null, 2)}

Similar issues from knowledge base:
${troubleshootingDocs.slice(0, 3).map(doc => `- ${doc.title}: ${doc.content.slice(0, 200)}...`).join('\n')}

Provide diagnosis and solutions in JSON format.`
        }
      ]

      const troubleshootResponse = await this.llmClient.complete({
        messages: troubleshootPrompt,
        temperature: 0.3,
        responseFormat: { type: 'json_object' }
      })

      return JSON.parse(troubleshootResponse.content)
    } catch (error) {
      logger.error('Error troubleshooting MCP:', error)
      return {
        diagnosis: 'Unable to diagnose the issue at this time.',
        solutions: [{
          title: 'General Troubleshooting',
          description: 'Try these general steps to resolve common MCP issues.',
          steps: [
            'Check your internet connection',
            'Verify API credentials are correct',
            'Restart the MCP service',
            'Check the MCP logs for detailed errors'
          ],
          difficulty: 'easy',
          estimatedTime: '10 minutes'
        }],
        preventionTips: [
          'Regularly update your MCPs to the latest versions',
          'Monitor MCP health status',
          'Keep API credentials secure and up to date'
        ]
      }
    }
  }

  /**
   * Handle natural language MCP configuration
   */
  async configureMCPFromMessage(
    message: string,
    installationId: string,
    userId: string
  ): Promise<{
    success: boolean
    changes: Array<{ field: string; oldValue: any; newValue: any }>
    confirmationRequired?: boolean
    confirmationMessage?: string
  }> {
    try {
      const installation = await prisma.mcpInstallation.findUnique({
        where: { id: installationId },
        include: { mcpRegistry: true }
      })

      if (!installation) {
        throw new Error('Installation not found')
      }

      // Extract configuration changes from natural language
      const configPrompt = this.llmClient.createStructuredPrompt(
        `User wants to configure their ${installation.mcpRegistry.name} MCP with this request: "${message}"

Current configuration:
${JSON.stringify(installation.config, null, 2)}

Configuration schema:
${JSON.stringify(installation.mcpRegistry.configSchema, null, 2)}

What changes do they want to make? Extract specific field changes and new values.`,
        {
          changes: "array of objects with field, oldValue, newValue",
          needsConfirmation: "boolean",
          confirmationMessage: "string or null",
          reasoning: "string"
        }
      )

      const configResponse = await this.llmClient.complete({
        messages: configPrompt,
        temperature: 0.1,
        responseFormat: { type: 'json_object' }
      })

      const configAnalysis = JSON.parse(configResponse.content)

      if (configAnalysis.needsConfirmation) {
        return {
          success: false,
          changes: configAnalysis.changes,
          confirmationRequired: true,
          confirmationMessage: configAnalysis.confirmationMessage
        }
      }

      // Apply configuration changes
      const newConfig = { ...installation.config }
      for (const change of configAnalysis.changes) {
        newConfig[change.field] = change.newValue
      }

      const updateResult = await mcpManager.updateMCPConfig(installationId, newConfig)

      return {
        success: updateResult.success,
        changes: configAnalysis.changes
      }
    } catch (error) {
      logger.error('Error configuring MCP from message:', error)
      return {
        success: false,
        changes: []
      }
    }
  }
}

export const mcpAssistant = new IntelligentMCPAssistant()
