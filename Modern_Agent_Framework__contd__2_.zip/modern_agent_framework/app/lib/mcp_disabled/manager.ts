
/**
 * MCP Manager - Core system for managing Model Context Protocol servers
 * Handles installation, configuration, health monitoring, and secure credential management
 */

import { prisma } from '@/lib/prisma'
import { EncryptionService } from '@/lib/security/encryption'
import { RAGService } from '@/lib/rag/service'
import { logger } from '@/lib/utils/logger'

export interface MCPInstallation {
  id: string
  name: string
  description: string
  version: string
  status: 'installing' | 'active' | 'error' | 'disabled'
  healthStatus: 'healthy' | 'warning' | 'error' | 'unknown'
  config: Record<string, any>
  capabilities: string[]
  lastUsed?: Date
}

export interface MCPCredential {
  key: string
  type: 'api_key' | 'oauth' | 'basic_auth' | 'certificate'
  value: string
  description?: string
  expiresAt?: Date
}

export interface MCPRecommendation {
  mcp: {
    id: string
    name: string
    description: string
    category: string
    capabilities: string[]
    rating: number
  }
  reason: string
  confidence: number
  context: string
}

export class MCPManager {
  private encryptionService: EncryptionService
  private ragService: RAGService

  constructor() {
    this.encryptionService = new EncryptionService()
    this.ragService = new RAGService()
  }

  // MCP Discovery and Installation

  /**
   * Search for available MCPs based on user query or needs
   */
  async searchMCPs(query: string, category?: string, userId?: string): Promise<any[]> {
    try {
      const whereClause: any = {
        isActive: true
      }

      if (category) {
        whereClause.category = category
      }

      // Use full-text search for better results
      const mcps = await prisma.$queryRaw`
        SELECT m.*, 
               ts_rank(search_vector, plainto_tsquery('english', ${query})) as relevance_score
        FROM mcp_registry m
        WHERE m.is_active = true
          ${category ? `AND m.category = ${category}` : ''}
          AND (search_vector @@ plainto_tsquery('english', ${query})
               OR similarity(m.name, ${query}) > 0.3
               OR similarity(m.description, ${query}) > 0.2)
        ORDER BY relevance_score DESC, install_count DESC
        LIMIT 20
      `

      // Get user's current installations to mark installed MCPs
      if (userId) {
        const userInstallations = await prisma.mcpInstallation.findMany({
          where: { userId },
          select: { mcpRegistryId: true }
        })
        const installedIds = new Set(userInstallations.map(i => i.mcpRegistryId))
        
        mcps.forEach((mcp: any) => {
          mcp.isInstalled = installedIds.has(mcp.id)
        })
      }

      return mcps
    } catch (error) {
      logger.error('Error searching MCPs:', error)
      return []
    }
  }

  /**
   * Get intelligent MCP recommendations based on user behavior and context
   */
  async getRecommendations(userId: string, workspaceId?: string, context?: string): Promise<MCPRecommendation[]> {
    try {
      // Get user's current workflow and agent usage patterns
      const userAgents = await prisma.agent.findMany({
        where: { userId },
        include: { tasks: { take: 10, orderBy: { createdAt: 'desc' } } }
      })

      // Analyze recent tasks to understand user needs
      const recentTasks = userAgents.flatMap(agent => agent.tasks)
      const taskDescriptions = recentTasks.map(task => task.description).join(' ')

      // Use RAG to find relevant MCPs based on task analysis
      const recommendations = await this.ragService.findRelevantMCPs(taskDescriptions, context)

      // Get trending MCPs in similar workspaces
      const trendingMCPs = await prisma.$queryRaw`
        SELECT m.*, 
               COUNT(mi.id) as recent_installs,
               AVG(m.rating) as avg_rating
        FROM mcp_registry m
        LEFT JOIN mcp_installations mi ON m.id = mi.mcp_registry_id
        WHERE mi.installed_at > NOW() - INTERVAL '30 days'
          AND m.is_active = true
        GROUP BY m.id
        ORDER BY recent_installs DESC, avg_rating DESC
        LIMIT 5
      `

      const combinedRecommendations: MCPRecommendation[] = [
        ...recommendations.map(r => ({
          mcp: r.mcp,
          reason: `Based on your recent tasks: ${r.reasoning}`,
          confidence: r.confidence,
          context: 'workflow_analysis'
        })),
        ...trendingMCPs.map((mcp: any) => ({
          mcp: {
            id: mcp.id,
            name: mcp.name,
            description: mcp.description,
            category: mcp.category,
            capabilities: mcp.capabilities,
            rating: mcp.rating
          },
          reason: `Popular in similar workspaces (${mcp.recent_installs} recent installs)`,
          confidence: Math.min(0.8, mcp.recent_installs / 10),
          context: 'trending'
        }))
      ]

      return combinedRecommendations.slice(0, 10)
    } catch (error) {
      logger.error('Error getting MCP recommendations:', error)
      return []
    }
  }

  /**
   * Install an MCP for a user/workspace
   */
  async installMCP(
    mcpRegistryId: string,
    userId: string,
    workspaceId?: string,
    config: Record<string, any> = {},
    credentials: MCPCredential[] = []
  ): Promise<{ success: boolean; installationId?: string; error?: string }> {
    try {
      // Get MCP details from registry
      const mcp = await prisma.mcpRegistry.findUnique({
        where: { id: mcpRegistryId }
      })

      if (!mcp) {
        return { success: false, error: 'MCP not found in registry' }
      }

      // Check if already installed
      const existingInstallation = await prisma.mcpInstallation.findFirst({
        where: {
          mcpRegistryId,
          userId,
          workspaceId
        }
      })

      if (existingInstallation) {
        return { success: false, error: 'MCP already installed' }
      }

      // Create installation record
      const installation = await prisma.mcpInstallation.create({
        data: {
          mcpRegistryId,
          userId,
          workspaceId,
          version: mcp.version,
          config,
          status: 'installing'
        }
      })

      // Store credentials securely
      for (const credential of credentials) {
        await this.storeCredential(installation.id, credential)
      }

      // Update install count
      await prisma.mcpRegistry.update({
        where: { id: mcpRegistryId },
        data: {
          installCount: { increment: 1 }
        }
      })

      // Perform actual installation (this would interact with the MCP server)
      const installResult = await this.performMCPInstallation(mcp, config, credentials)

      if (installResult.success) {
        await prisma.mcpInstallation.update({
          where: { id: installation.id },
          data: {
            status: 'active',
            healthStatus: 'healthy'
          }
        })
      } else {
        await prisma.mcpInstallation.update({
          where: { id: installation.id },
          data: {
            status: 'error',
            errorMessage: installResult.error
          }
        })
      }

      return {
        success: installResult.success,
        installationId: installation.id,
        error: installResult.error
      }
    } catch (error) {
      logger.error('Error installing MCP:', error)
      return { success: false, error: 'Installation failed' }
    }
  }

  /**
   * Store encrypted credentials for an MCP installation
   */
  private async storeCredential(installationId: string, credential: MCPCredential): Promise<void> {
    const encryptionResult = await this.encryptionService.encrypt(credential.value)
    
    await prisma.mcpCredential.create({
      data: {
        installationId,
        credentialKey: credential.key,
        credentialType: credential.type,
        encryptedValue: encryptionResult.encryptedData,
        encryptionKeyId: encryptionResult.keyId,
        description: credential.description,
        expiresAt: credential.expiresAt
      }
    })
  }

  /**
   * Retrieve and decrypt credentials for an MCP installation
   */
  async getCredentials(installationId: string): Promise<Record<string, string>> {
    const credentials = await prisma.mcpCredential.findMany({
      where: {
        installationId,
        isActive: true
      }
    })

    const decryptedCredentials: Record<string, string> = {}
    
    for (const cred of credentials) {
      try {
        const decryptedValue = await this.encryptionService.decrypt(
          cred.encryptedValue,
          cred.encryptionKeyId
        )
        decryptedCredentials[cred.credentialKey] = decryptedValue
      } catch (error) {
        logger.error(`Error decrypting credential ${cred.credentialKey}:`, error)
      }
    }

    return decryptedCredentials
  }

  /**
   * Update MCP configuration
   */
  async updateMCPConfig(
    installationId: string,
    config: Record<string, any>,
    credentials?: MCPCredential[]
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const installation = await prisma.mcpInstallation.findUnique({
        where: { id: installationId }
      })

      if (!installation) {
        return { success: false, error: 'Installation not found' }
      }

      // Update configuration
      await prisma.mcpInstallation.update({
        where: { id: installationId },
        data: {
          config,
          updatedAt: new Date()
        }
      })

      // Update credentials if provided
      if (credentials) {
        // Remove old credentials
        await prisma.mcpCredential.deleteMany({
          where: { installationId }
        })

        // Add new credentials
        for (const credential of credentials) {
          await this.storeCredential(installationId, credential)
        }
      }

      // Restart MCP with new configuration
      await this.restartMCP(installationId)

      return { success: true }
    } catch (error) {
      logger.error('Error updating MCP config:', error)
      return { success: false, error: 'Failed to update configuration' }
    }
  }

  /**
   * Health check for MCP installations
   */
  async performHealthCheck(installationId: string): Promise<{
    status: 'healthy' | 'warning' | 'error'
    message?: string
    metrics?: Record<string, any>
  }> {
    try {
      const installation = await prisma.mcpInstallation.findUnique({
        where: { id: installationId },
        include: { mcpRegistry: true }
      })

      if (!installation) {
        return { status: 'error', message: 'Installation not found' }
      }

      // Perform actual health check (ping MCP server, check connectivity, etc.)
      const healthResult = await this.pingMCPServer(installation)

      // Update health status in database
      await prisma.mcpInstallation.update({
        where: { id: installationId },
        data: {
          healthStatus: healthResult.status,
          lastHealthCheck: new Date(),
          errorMessage: healthResult.status === 'error' ? healthResult.message : null
        }
      })

      return healthResult
    } catch (error) {
      logger.error('Error performing health check:', error)
      return { status: 'error', message: 'Health check failed' }
    }
  }

  /**
   * Get user's installed MCPs with status
   */
  async getUserMCPs(userId: string, workspaceId?: string): Promise<MCPInstallation[]> {
    const whereClause: any = { userId }
    if (workspaceId) {
      whereClause.workspaceId = workspaceId
    }

    const installations = await prisma.mcpInstallation.findMany({
      where: whereClause,
      include: {
        mcpRegistry: true
      },
      orderBy: { lastUsedAt: 'desc' }
    })

    return installations.map(installation => ({
      id: installation.id,
      name: installation.customName || installation.mcpRegistry.name,
      description: installation.mcpRegistry.description || '',
      version: installation.version,
      status: installation.status as any,
      healthStatus: installation.healthStatus as any,
      config: installation.config as Record<string, any>,
      capabilities: installation.mcpRegistry.capabilities || [],
      lastUsed: installation.lastUsedAt
    }))
  }

  /**
   * Uninstall an MCP
   */
  async uninstallMCP(installationId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const installation = await prisma.mcpInstallation.findUnique({
        where: { id: installationId }
      })

      if (!installation) {
        return { success: false, error: 'Installation not found' }
      }

      // Perform cleanup of MCP server and resources
      await this.cleanupMCPInstallation(installation)

      // Remove credentials
      await prisma.mcpCredential.deleteMany({
        where: { installationId }
      })

      // Remove installation record
      await prisma.mcpInstallation.delete({
        where: { id: installationId }
      })

      return { success: true }
    } catch (error) {
      logger.error('Error uninstalling MCP:', error)
      return { success: false, error: 'Uninstallation failed' }
    }
  }

  // Private helper methods for actual MCP operations
  private async performMCPInstallation(
    mcp: any,
    config: Record<string, any>,
    credentials: MCPCredential[]
  ): Promise<{ success: boolean; error?: string }> {
    // This would handle the actual MCP server installation
    // For now, simulate successful installation
    return { success: true }
  }

  private async restartMCP(installationId: string): Promise<void> {
    // Implementation for restarting MCP server
    logger.info(`Restarting MCP installation ${installationId}`)
  }

  private async pingMCPServer(installation: any): Promise<{
    status: 'healthy' | 'warning' | 'error'
    message?: string
    metrics?: Record<string, any>
  }> {
    // Implementation for pinging MCP server
    return {
      status: 'healthy',
      metrics: {
        responseTime: 50,
        lastPing: new Date()
      }
    }
  }

  private async cleanupMCPInstallation(installation: any): Promise<void> {
    // Implementation for cleaning up MCP installation
    logger.info(`Cleaning up MCP installation ${installation.id}`)
  }
}

export const mcpManager = new MCPManager()
