
'use client'

import { useEffect, useState } from 'react'
import { translations, SupportedLanguage, TranslationKeys, SUPPORTED_LANGUAGES } from './translations'
import { UserPreferencesManager } from '../user-preferences'

class I18nManager {
  private currentLanguage: SupportedLanguage = 'en'
  private listeners: Array<(language: SupportedLanguage) => void> = []

  constructor() {
    if (typeof window !== 'undefined') {
      this.initializeLanguage()
    }
  }

  private initializeLanguage() {
    // Get language from user preferences
    const preferences = UserPreferencesManager.getPreferences()
    if (preferences.language && this.isValidLanguage(preferences.language)) {
      this.currentLanguage = preferences.language as SupportedLanguage
    } else {
      // Detect browser language
      const browserLang = this.detectBrowserLanguage()
      this.setLanguage(browserLang)
    }
  }

  private detectBrowserLanguage(): SupportedLanguage {
    if (typeof window === 'undefined') return 'en'

    const browserLang = navigator.language || (navigator as any).userLanguage
    const langCode = browserLang.split('-')[0] as SupportedLanguage

    // Check if detected language is supported
    if (this.isValidLanguage(langCode)) {
      return langCode
    }

    return 'en' // Default fallback
  }

  private isValidLanguage(lang: string): lang is SupportedLanguage {
    return SUPPORTED_LANGUAGES.some(l => l.code === lang)
  }

  getCurrentLanguage(): SupportedLanguage {
    return this.currentLanguage
  }

  setLanguage(language: SupportedLanguage) {
    if (!this.isValidLanguage(language)) {
      console.warn(`Unsupported language: ${language}. Falling back to English.`)
      language = 'en'
    }

    this.currentLanguage = language
    
    // Update user preferences
    UserPreferencesManager.updatePreference('language', language)
    
    // Update document language and direction
    if (typeof document !== 'undefined') {
      document.documentElement.lang = language
      document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr'
    }

    // Notify listeners
    this.listeners.forEach(listener => listener(language))
  }

  getAvailableLanguages() {
    return SUPPORTED_LANGUAGES
  }

  translate<K extends keyof TranslationKeys>(key: K, params?: Record<string, string>): string {
    const translation = translations[this.currentLanguage][key]
    
    if (!translation) {
      console.warn(`Translation missing for key "${key}" in language "${this.currentLanguage}"`)
      // Fallback to English
      return translations.en[key] || key
    }

    // Simple parameter replacement
    if (params) {
      return Object.entries(params).reduce(
        (text, [param, value]) => text.replace(new RegExp(`{${param}}`, 'g'), value),
        translation
      )
    }

    return translation
  }

  // Short alias for translate
  t<K extends keyof TranslationKeys>(key: K, params?: Record<string, string>): string {
    return this.translate(key, params)
  }

  subscribe(listener: (language: SupportedLanguage) => void) {
    this.listeners.push(listener)
    return () => {
      const index = this.listeners.indexOf(listener)
      if (index > -1) {
        this.listeners.splice(index, 1)
      }
    }
  }

  // Format numbers according to current locale
  formatNumber(number: number): string {
    const locale = this.getLocaleString()
    return new Intl.NumberFormat(locale).format(number)
  }

  // Format dates according to current locale
  formatDate(date: Date, options?: Intl.DateTimeFormatOptions): string {
    const locale = this.getLocaleString()
    return new Intl.DateTimeFormat(locale, options).format(date)
  }

  // Format relative time (e.g., "2 hours ago")
  formatRelativeTime(date: Date): string {
    const locale = this.getLocaleString()
    const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' })
    
    const now = new Date()
    const diffMs = date.getTime() - now.getTime()
    const diffSec = Math.round(diffMs / 1000)
    const diffMin = Math.round(diffSec / 60)
    const diffHour = Math.round(diffMin / 60)
    const diffDay = Math.round(diffHour / 24)

    if (Math.abs(diffSec) < 60) return rtf.format(diffSec, 'second')
    if (Math.abs(diffMin) < 60) return rtf.format(diffMin, 'minute')
    if (Math.abs(diffHour) < 24) return rtf.format(diffHour, 'hour')
    return rtf.format(diffDay, 'day')
  }

  private getLocaleString(): string {
    const localeMap: Record<SupportedLanguage, string> = {
      en: 'en-US',
      es: 'es-ES',
      fr: 'fr-FR',
      de: 'de-DE',
      zh: 'zh-CN',
      ja: 'ja-JP',
      ko: 'ko-KR',
      pt: 'pt-PT',
      ru: 'ru-RU',
      ar: 'ar-SA'
    }
    return localeMap[this.currentLanguage]
  }

  // Check if current language is RTL
  isRTL(): boolean {
    return this.currentLanguage === 'ar'
  }
}

export const i18n = new I18nManager()

// React hook for using i18n
export function useTranslation() {
  const [language, setLanguage] = useState<SupportedLanguage>(i18n.getCurrentLanguage())

  useEffect(() => {
    const unsubscribe = i18n.subscribe(setLanguage)
    return unsubscribe
  }, [])

  return {
    language,
    setLanguage: (lang: SupportedLanguage) => i18n.setLanguage(lang),
    t: i18n.t.bind(i18n),
    translate: i18n.translate.bind(i18n),
    formatNumber: i18n.formatNumber.bind(i18n),
    formatDate: i18n.formatDate.bind(i18n),
    formatRelativeTime: i18n.formatRelativeTime.bind(i18n),
    availableLanguages: i18n.getAvailableLanguages(),
    isRTL: i18n.isRTL()
  }
}

// Higher-order component for wrapping components with translation
export function withTranslation<P extends object>(Component: React.ComponentType<P>) {
  return function TranslatedComponent(props: P) {
    const translation = useTranslation()
    const React = require('react')
    return React.createElement(Component, { ...props, ...translation } as P & ReturnType<typeof useTranslation>)
  }
}

export * from './translations'
