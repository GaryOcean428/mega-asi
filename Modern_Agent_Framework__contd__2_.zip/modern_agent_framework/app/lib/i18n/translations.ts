
export type SupportedLanguage = 'en' | 'es' | 'fr' | 'de' | 'zh' | 'ja' | 'ko' | 'pt' | 'ru' | 'ar'

export interface TranslationKeys {
  // Common
  'common.loading': string
  'common.error': string
  'common.success': string
  'common.cancel': string
  'common.save': string
  'common.delete': string
  'common.edit': string
  'common.create': string
  'common.close': string
  'common.back': string
  'common.next': string
  'common.previous': string
  'common.search': string
  'common.settings': string

  // Navigation
  'nav.dashboard': string
  'nav.chat': string
  'nav.agents': string
  'nav.models': string
  'nav.demos': string
  'nav.help': string
  'nav.onboarding': string

  // Dashboard
  'dashboard.title': string
  'dashboard.subtitle': string
  'dashboard.quickActions': string
  'dashboard.recentActivity': string
  'dashboard.stats.agents': string
  'dashboard.stats.tasks': string
  'dashboard.stats.collaborations': string

  // Chat
  'chat.placeholder': string
  'chat.sendMessage': string
  'chat.voiceInput': string
  'chat.suggestions': string
  'chat.intelligentOrchestrator': string
  'chat.smartSuggestions': string

  // Agents
  'agents.create': string
  'agents.list': string
  'agents.edit': string
  'agents.delete': string
  'agents.status.idle': string
  'agents.status.busy': string
  'agents.status.error': string
  'agents.capabilities': string
  'agents.templates': string

  // Onboarding
  'onboarding.welcome.title': string
  'onboarding.welcome.description': string
  'onboarding.features.title': string
  'onboarding.demo.title': string
  'onboarding.ready.title': string
  'onboarding.skip': string
  'onboarding.complete': string

  // Help
  'help.title': string
  'help.search.placeholder': string
  'help.categories.gettingStarted': string
  'help.categories.chat': string
  'help.categories.agents': string
  'help.categories.collaborations': string
  'help.categories.mcps': string
  'help.categories.troubleshooting': string

  // Errors
  'errors.networkError': string
  'errors.unauthorized': string
  'errors.notFound': string
  'errors.serverError': string
  'errors.validationError': string
}

export const translations: Record<SupportedLanguage, TranslationKeys> = {
  en: {
    // Common
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.success': 'Success',
    'common.cancel': 'Cancel',
    'common.save': 'Save',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.create': 'Create',
    'common.close': 'Close',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.previous': 'Previous',
    'common.search': 'Search',
    'common.settings': 'Settings',

    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.chat': 'Intelligent Chat',
    'nav.agents': 'Agents',
    'nav.models': 'AI Models',
    'nav.demos': 'Demos',
    'nav.help': 'Help',
    'nav.onboarding': 'Get Started',

    // Dashboard
    'dashboard.title': 'Modern Agent Framework',
    'dashboard.subtitle': 'Create, manage, and orchestrate autonomous agents with advanced AI capabilities and collaborative workflows.',
    'dashboard.quickActions': 'Quick Actions',
    'dashboard.recentActivity': 'Recent Activity',
    'dashboard.stats.agents': 'Active Agents',
    'dashboard.stats.tasks': 'Tasks Completed',
    'dashboard.stats.collaborations': 'Collaborations',

    // Chat
    'chat.placeholder': 'Describe what you\'d like to create or automate...',
    'chat.sendMessage': 'Send Message',
    'chat.voiceInput': 'Voice Input',
    'chat.suggestions': 'Suggestions',
    'chat.intelligentOrchestrator': 'Intelligent Chat Orchestrator',
    'chat.smartSuggestions': 'Smart Suggestions',

    // Agents
    'agents.create': 'Create Agent',
    'agents.list': 'Agent List',
    'agents.edit': 'Edit Agent',
    'agents.delete': 'Delete Agent',
    'agents.status.idle': 'Idle',
    'agents.status.busy': 'Busy',
    'agents.status.error': 'Error',
    'agents.capabilities': 'Capabilities',
    'agents.templates': 'Templates',

    // Onboarding
    'onboarding.welcome.title': 'Welcome to Intelligent Chat',
    'onboarding.welcome.description': 'Your AI-powered agent orchestration hub',
    'onboarding.features.title': 'Powerful Features at Your Fingertips',
    'onboarding.demo.title': 'Try These Demo Scenarios',
    'onboarding.ready.title': 'You\'re All Set!',
    'onboarding.skip': 'Skip Tutorial',
    'onboarding.complete': 'Get Started',

    // Help
    'help.title': 'Help Center',
    'help.search.placeholder': 'Search for help articles, guides, and tutorials...',
    'help.categories.gettingStarted': 'Getting Started',
    'help.categories.chat': 'Intelligent Chat',
    'help.categories.agents': 'Agents',
    'help.categories.collaborations': 'Collaborations',
    'help.categories.mcps': 'MCP Tools',
    'help.categories.troubleshooting': 'Troubleshooting',

    // Errors
    'errors.networkError': 'Network connection error. Please try again.',
    'errors.unauthorized': 'You are not authorized to perform this action.',
    'errors.notFound': 'The requested resource was not found.',
    'errors.serverError': 'Internal server error. Please try again later.',
    'errors.validationError': 'Please check your input and try again.',
  },

  es: {
    // Common
    'common.loading': 'Cargando...',
    'common.error': 'Error',
    'common.success': 'Éxito',
    'common.cancel': 'Cancelar',
    'common.save': 'Guardar',
    'common.delete': 'Eliminar',
    'common.edit': 'Editar',
    'common.create': 'Crear',
    'common.close': 'Cerrar',
    'common.back': 'Atrás',
    'common.next': 'Siguiente',
    'common.previous': 'Anterior',
    'common.search': 'Buscar',
    'common.settings': 'Configuración',

    // Navigation
    'nav.dashboard': 'Panel de Control',
    'nav.chat': 'Chat Inteligente',
    'nav.agents': 'Agentes',
    'nav.models': 'Modelos IA',
    'nav.demos': 'Demos',
    'nav.help': 'Ayuda',
    'nav.onboarding': 'Comenzar',

    // Dashboard
    'dashboard.title': 'Framework de Agentes Moderno',
    'dashboard.subtitle': 'Crea, gestiona y orquesta agentes autónomos con capacidades avanzadas de IA y flujos de trabajo colaborativos.',
    'dashboard.quickActions': 'Acciones Rápidas',
    'dashboard.recentActivity': 'Actividad Reciente',
    'dashboard.stats.agents': 'Agentes Activos',
    'dashboard.stats.tasks': 'Tareas Completadas',
    'dashboard.stats.collaborations': 'Colaboraciones',

    // Chat
    'chat.placeholder': 'Describe lo que te gustaría crear o automatizar...',
    'chat.sendMessage': 'Enviar Mensaje',
    'chat.voiceInput': 'Entrada de Voz',
    'chat.suggestions': 'Sugerencias',
    'chat.intelligentOrchestrator': 'Orquestador de Chat Inteligente',
    'chat.smartSuggestions': 'Sugerencias Inteligentes',

    // Agents
    'agents.create': 'Crear Agente',
    'agents.list': 'Lista de Agentes',
    'agents.edit': 'Editar Agente',
    'agents.delete': 'Eliminar Agente',
    'agents.status.idle': 'Inactivo',
    'agents.status.busy': 'Ocupado',
    'agents.status.error': 'Error',
    'agents.capabilities': 'Capacidades',
    'agents.templates': 'Plantillas',

    // Onboarding
    'onboarding.welcome.title': 'Bienvenido al Chat Inteligente',
    'onboarding.welcome.description': 'Tu centro de orquestación de agentes con IA',
    'onboarding.features.title': 'Características Poderosas al Alcance de tus Dedos',
    'onboarding.demo.title': 'Prueba Estos Escenarios de Demo',
    'onboarding.ready.title': '¡Ya Estás Listo!',
    'onboarding.skip': 'Saltar Tutorial',
    'onboarding.complete': 'Comenzar',

    // Help
    'help.title': 'Centro de Ayuda',
    'help.search.placeholder': 'Buscar artículos de ayuda, guías y tutoriales...',
    'help.categories.gettingStarted': 'Primeros Pasos',
    'help.categories.chat': 'Chat Inteligente',
    'help.categories.agents': 'Agentes',
    'help.categories.collaborations': 'Colaboraciones',
    'help.categories.mcps': 'Herramientas MCP',
    'help.categories.troubleshooting': 'Solución de Problemas',

    // Errors
    'errors.networkError': 'Error de conexión de red. Por favor, inténtalo de nuevo.',
    'errors.unauthorized': 'No tienes autorización para realizar esta acción.',
    'errors.notFound': 'El recurso solicitado no fue encontrado.',
    'errors.serverError': 'Error interno del servidor. Por favor, inténtalo más tarde.',
    'errors.validationError': 'Por favor, verifica tu entrada e inténtalo de nuevo.',
  },

  fr: {
    // Common
    'common.loading': 'Chargement...',
    'common.error': 'Erreur',
    'common.success': 'Succès',
    'common.cancel': 'Annuler',
    'common.save': 'Enregistrer',
    'common.delete': 'Supprimer',
    'common.edit': 'Modifier',
    'common.create': 'Créer',
    'common.close': 'Fermer',
    'common.back': 'Retour',
    'common.next': 'Suivant',
    'common.previous': 'Précédent',
    'common.search': 'Rechercher',
    'common.settings': 'Paramètres',

    // Navigation
    'nav.dashboard': 'Tableau de Bord',
    'nav.chat': 'Chat Intelligent',
    'nav.agents': 'Agents',
    'nav.models': 'Modèles IA',
    'nav.demos': 'Démos',
    'nav.help': 'Aide',
    'nav.onboarding': 'Commencer',

    // Dashboard
    'dashboard.title': 'Framework d\'Agents Moderne',
    'dashboard.subtitle': 'Créez, gérez et orchestrez des agents autonomes avec des capacités IA avancées et des flux de travail collaboratifs.',
    'dashboard.quickActions': 'Actions Rapides',
    'dashboard.recentActivity': 'Activité Récente',
    'dashboard.stats.agents': 'Agents Actifs',
    'dashboard.stats.tasks': 'Tâches Terminées',
    'dashboard.stats.collaborations': 'Collaborations',

    // Chat
    'chat.placeholder': 'Décrivez ce que vous aimeriez créer ou automatiser...',
    'chat.sendMessage': 'Envoyer un Message',
    'chat.voiceInput': 'Entrée Vocale',
    'chat.suggestions': 'Suggestions',
    'chat.intelligentOrchestrator': 'Orchestrateur de Chat Intelligent',
    'chat.smartSuggestions': 'Suggestions Intelligentes',

    // Agents
    'agents.create': 'Créer un Agent',
    'agents.list': 'Liste des Agents',
    'agents.edit': 'Modifier l\'Agent',
    'agents.delete': 'Supprimer l\'Agent',
    'agents.status.idle': 'Inactif',
    'agents.status.busy': 'Occupé',
    'agents.status.error': 'Erreur',
    'agents.capabilities': 'Capacités',
    'agents.templates': 'Modèles',

    // Onboarding
    'onboarding.welcome.title': 'Bienvenue dans le Chat Intelligent',
    'onboarding.welcome.description': 'Votre hub d\'orchestration d\'agents IA',
    'onboarding.features.title': 'Fonctionnalités Puissantes à Portée de Main',
    'onboarding.demo.title': 'Essayez Ces Scénarios de Démo',
    'onboarding.ready.title': 'Vous Êtes Prêt !',
    'onboarding.skip': 'Ignorer le Tutoriel',
    'onboarding.complete': 'Commencer',

    // Help
    'help.title': 'Centre d\'Aide',
    'help.search.placeholder': 'Rechercher des articles d\'aide, guides et tutoriels...',
    'help.categories.gettingStarted': 'Premiers Pas',
    'help.categories.chat': 'Chat Intelligent',
    'help.categories.agents': 'Agents',
    'help.categories.collaborations': 'Collaborations',
    'help.categories.mcps': 'Outils MCP',
    'help.categories.troubleshooting': 'Dépannage',

    // Errors
    'errors.networkError': 'Erreur de connexion réseau. Veuillez réessayer.',
    'errors.unauthorized': 'Vous n\'êtes pas autorisé à effectuer cette action.',
    'errors.notFound': 'La ressource demandée n\'a pas été trouvée.',
    'errors.serverError': 'Erreur interne du serveur. Veuillez réessayer plus tard.',
    'errors.validationError': 'Veuillez vérifier votre saisie et réessayer.',
  },

  de: {
    // Common
    'common.loading': 'Laden...',
    'common.error': 'Fehler',
    'common.success': 'Erfolg',
    'common.cancel': 'Abbrechen',
    'common.save': 'Speichern',
    'common.delete': 'Löschen',
    'common.edit': 'Bearbeiten',
    'common.create': 'Erstellen',
    'common.close': 'Schließen',
    'common.back': 'Zurück',
    'common.next': 'Weiter',
    'common.previous': 'Vorherige',
    'common.search': 'Suchen',
    'common.settings': 'Einstellungen',

    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.chat': 'Intelligenter Chat',
    'nav.agents': 'Agenten',
    'nav.models': 'KI-Modelle',
    'nav.demos': 'Demos',
    'nav.help': 'Hilfe',
    'nav.onboarding': 'Loslegen',

    // Dashboard
    'dashboard.title': 'Modernes Agenten-Framework',
    'dashboard.subtitle': 'Erstellen, verwalten und orchestrieren Sie autonome Agenten mit erweiterten KI-Funktionen und kollaborativen Workflows.',
    'dashboard.quickActions': 'Schnellaktionen',
    'dashboard.recentActivity': 'Letzte Aktivität',
    'dashboard.stats.agents': 'Aktive Agenten',
    'dashboard.stats.tasks': 'Erledigte Aufgaben',
    'dashboard.stats.collaborations': 'Kollaborationen',

    // Chat
    'chat.placeholder': 'Beschreiben Sie, was Sie erstellen oder automatisieren möchten...',
    'chat.sendMessage': 'Nachricht Senden',
    'chat.voiceInput': 'Spracheingabe',
    'chat.suggestions': 'Vorschläge',
    'chat.intelligentOrchestrator': 'Intelligenter Chat-Orchestrator',
    'chat.smartSuggestions': 'Intelligente Vorschläge',

    // Agents
    'agents.create': 'Agent Erstellen',
    'agents.list': 'Agentenliste',
    'agents.edit': 'Agent Bearbeiten',
    'agents.delete': 'Agent Löschen',
    'agents.status.idle': 'Untätig',
    'agents.status.busy': 'Beschäftigt',
    'agents.status.error': 'Fehler',
    'agents.capabilities': 'Fähigkeiten',
    'agents.templates': 'Vorlagen',

    // Onboarding
    'onboarding.welcome.title': 'Willkommen beim Intelligenten Chat',
    'onboarding.welcome.description': 'Ihr KI-gestütztes Agenten-Orchestrierungszentrum',
    'onboarding.features.title': 'Leistungsstarke Funktionen zur Hand',
    'onboarding.demo.title': 'Probieren Sie Diese Demo-Szenarien',
    'onboarding.ready.title': 'Sie Sind Bereit!',
    'onboarding.skip': 'Tutorial Überspringen',
    'onboarding.complete': 'Loslegen',

    // Help
    'help.title': 'Hilfe-Center',
    'help.search.placeholder': 'Nach Hilfeartikeln, Anleitungen und Tutorials suchen...',
    'help.categories.gettingStarted': 'Erste Schritte',
    'help.categories.chat': 'Intelligenter Chat',
    'help.categories.agents': 'Agenten',
    'help.categories.collaborations': 'Kollaborationen',
    'help.categories.mcps': 'MCP-Tools',
    'help.categories.troubleshooting': 'Fehlerbehebung',

    // Errors
    'errors.networkError': 'Netzwerkverbindungsfehler. Bitte versuchen Sie es erneut.',
    'errors.unauthorized': 'Sie sind nicht berechtigt, diese Aktion auszuführen.',
    'errors.notFound': 'Die angeforderte Ressource wurde nicht gefunden.',
    'errors.serverError': 'Interner Serverfehler. Bitte versuchen Sie es später erneut.',
    'errors.validationError': 'Bitte überprüfen Sie Ihre Eingabe und versuchen Sie es erneut.',
  },

  zh: {
    // Common
    'common.loading': '加载中...',
    'common.error': '错误',
    'common.success': '成功',
    'common.cancel': '取消',
    'common.save': '保存',
    'common.delete': '删除',
    'common.edit': '编辑',
    'common.create': '创建',
    'common.close': '关闭',
    'common.back': '返回',
    'common.next': '下一步',
    'common.previous': '上一步',
    'common.search': '搜索',
    'common.settings': '设置',

    // Navigation
    'nav.dashboard': '仪表板',
    'nav.chat': '智能聊天',
    'nav.agents': '代理',
    'nav.models': 'AI 模型',
    'nav.demos': '演示',
    'nav.help': '帮助',
    'nav.onboarding': '开始使用',

    // Dashboard
    'dashboard.title': '现代代理框架',
    'dashboard.subtitle': '使用先进的人工智能功能和协作工作流创建、管理和编排自主代理。',
    'dashboard.quickActions': '快速操作',
    'dashboard.recentActivity': '最近活动',
    'dashboard.stats.agents': '活跃代理',
    'dashboard.stats.tasks': '完成任务',
    'dashboard.stats.collaborations': '协作',

    // Chat
    'chat.placeholder': '描述您想要创建或自动化的内容...',
    'chat.sendMessage': '发送消息',
    'chat.voiceInput': '语音输入',
    'chat.suggestions': '建议',
    'chat.intelligentOrchestrator': '智能聊天编排器',
    'chat.smartSuggestions': '智能建议',

    // Agents
    'agents.create': '创建代理',
    'agents.list': '代理列表',
    'agents.edit': '编辑代理',
    'agents.delete': '删除代理',
    'agents.status.idle': '空闲',
    'agents.status.busy': '忙碌',
    'agents.status.error': '错误',
    'agents.capabilities': '功能',
    'agents.templates': '模板',

    // Onboarding
    'onboarding.welcome.title': '欢迎使用智能聊天',
    'onboarding.welcome.description': '您的AI驱动代理编排中心',
    'onboarding.features.title': '强大功能触手可及',
    'onboarding.demo.title': '尝试这些演示场景',
    'onboarding.ready.title': '您已准备就绪！',
    'onboarding.skip': '跳过教程',
    'onboarding.complete': '开始使用',

    // Help
    'help.title': '帮助中心',
    'help.search.placeholder': '搜索帮助文章、指南和教程...',
    'help.categories.gettingStarted': '入门指南',
    'help.categories.chat': '智能聊天',
    'help.categories.agents': '代理',
    'help.categories.collaborations': '协作',
    'help.categories.mcps': 'MCP 工具',
    'help.categories.troubleshooting': '故障排除',

    // Errors
    'errors.networkError': '网络连接错误。请重试。',
    'errors.unauthorized': '您无权执行此操作。',
    'errors.notFound': '未找到请求的资源。',
    'errors.serverError': '内部服务器错误。请稍后重试。',
    'errors.validationError': '请检查您的输入并重试。',
  },

  ja: {
    // Common
    'common.loading': '読み込み中...',
    'common.error': 'エラー',
    'common.success': '成功',
    'common.cancel': 'キャンセル',
    'common.save': '保存',
    'common.delete': '削除',
    'common.edit': '編集',
    'common.create': '作成',
    'common.close': '閉じる',
    'common.back': '戻る',
    'common.next': '次へ',
    'common.previous': '前へ',
    'common.search': '検索',
    'common.settings': '設定',

    // Navigation
    'nav.dashboard': 'ダッシュボード',
    'nav.chat': 'インテリジェントチャット',
    'nav.agents': 'エージェント',
    'nav.models': 'AIモデル',
    'nav.demos': 'デモ',
    'nav.help': 'ヘルプ',
    'nav.onboarding': '始めましょう',

    // Dashboard
    'dashboard.title': 'モダンエージェントフレームワーク',
    'dashboard.subtitle': '高度なAI機能と協調ワークフローを使用して、自律エージェントを作成、管理、編成します。',
    'dashboard.quickActions': 'クイックアクション',
    'dashboard.recentActivity': '最近のアクティビティ',
    'dashboard.stats.agents': 'アクティブエージェント',
    'dashboard.stats.tasks': '完了タスク',
    'dashboard.stats.collaborations': 'コラボレーション',

    // Chat
    'chat.placeholder': '作成または自動化したい内容を説明してください...',
    'chat.sendMessage': 'メッセージを送信',
    'chat.voiceInput': '音声入力',
    'chat.suggestions': '提案',
    'chat.intelligentOrchestrator': 'インテリジェントチャットオーケストレーター',
    'chat.smartSuggestions': 'スマート提案',

    // Agents
    'agents.create': 'エージェントを作成',
    'agents.list': 'エージェントリスト',
    'agents.edit': 'エージェントを編集',
    'agents.delete': 'エージェントを削除',
    'agents.status.idle': 'アイドル',
    'agents.status.busy': 'ビジー',
    'agents.status.error': 'エラー',
    'agents.capabilities': '機能',
    'agents.templates': 'テンプレート',

    // Onboarding
    'onboarding.welcome.title': 'インテリジェントチャットへようこそ',
    'onboarding.welcome.description': 'AIパワードエージェントオーケストレーションハブ',
    'onboarding.features.title': '指先で強力な機能',
    'onboarding.demo.title': 'これらのデモシナリオを試してください',
    'onboarding.ready.title': '準備完了！',
    'onboarding.skip': 'チュートリアルをスキップ',
    'onboarding.complete': '始めましょう',

    // Help
    'help.title': 'ヘルプセンター',
    'help.search.placeholder': 'ヘルプ記事、ガイド、チュートリアルを検索...',
    'help.categories.gettingStarted': '入門',
    'help.categories.chat': 'インテリジェントチャット',
    'help.categories.agents': 'エージェント',
    'help.categories.collaborations': 'コラボレーション',
    'help.categories.mcps': 'MCPツール',
    'help.categories.troubleshooting': 'トラブルシューティング',

    // Errors
    'errors.networkError': 'ネットワーク接続エラーです。再試行してください。',
    'errors.unauthorized': 'この操作を実行する権限がありません。',
    'errors.notFound': '要求されたリソースが見つかりませんでした。',
    'errors.serverError': '内部サーバーエラーです。後でもう一度お試しください。',
    'errors.validationError': '入力を確認して再試行してください。',
  },

  ko: {
    // Common
    'common.loading': '로딩 중...',
    'common.error': '오류',
    'common.success': '성공',
    'common.cancel': '취소',
    'common.save': '저장',
    'common.delete': '삭제',
    'common.edit': '편집',
    'common.create': '생성',
    'common.close': '닫기',
    'common.back': '뒤로',
    'common.next': '다음',
    'common.previous': '이전',
    'common.search': '검색',
    'common.settings': '설정',

    // Navigation
    'nav.dashboard': '대시보드',
    'nav.chat': '인텔리전트 채팅',
    'nav.agents': '에이전트',
    'nav.models': 'AI 모델',
    'nav.demos': '데모',
    'nav.help': '도움말',
    'nav.onboarding': '시작하기',

    // Dashboard
    'dashboard.title': '모던 에이전트 프레임워크',
    'dashboard.subtitle': '고급 AI 기능과 협업 워크플로우로 자율 에이전트를 생성, 관리, 조율합니다.',
    'dashboard.quickActions': '빠른 작업',
    'dashboard.recentActivity': '최근 활동',
    'dashboard.stats.agents': '활성 에이전트',
    'dashboard.stats.tasks': '완료된 작업',
    'dashboard.stats.collaborations': '협업',

    // Chat
    'chat.placeholder': '생성하거나 자동화하고 싶은 내용을 설명해주세요...',
    'chat.sendMessage': '메시지 보내기',
    'chat.voiceInput': '음성 입력',
    'chat.suggestions': '제안',
    'chat.intelligentOrchestrator': '인텔리전트 채팅 오케스트레이터',
    'chat.smartSuggestions': '스마트 제안',

    // Agents
    'agents.create': '에이전트 생성',
    'agents.list': '에이전트 목록',
    'agents.edit': '에이전트 편집',
    'agents.delete': '에이전트 삭제',
    'agents.status.idle': '유휴',
    'agents.status.busy': '사용 중',
    'agents.status.error': '오류',
    'agents.capabilities': '기능',
    'agents.templates': '템플릿',

    // Onboarding
    'onboarding.welcome.title': '인텔리전트 채팅에 오신 것을 환영합니다',
    'onboarding.welcome.description': 'AI 기반 에이전트 오케스트레이션 허브',
    'onboarding.features.title': '손끝에서 강력한 기능',
    'onboarding.demo.title': '이 데모 시나리오를 시도해보세요',
    'onboarding.ready.title': '모든 준비가 완료되었습니다!',
    'onboarding.skip': '튜토리얼 건너뛰기',
    'onboarding.complete': '시작하기',

    // Help
    'help.title': '도움말 센터',
    'help.search.placeholder': '도움말 문서, 가이드, 튜토리얼 검색...',
    'help.categories.gettingStarted': '시작하기',
    'help.categories.chat': '인텔리전트 채팅',
    'help.categories.agents': '에이전트',
    'help.categories.collaborations': '협업',
    'help.categories.mcps': 'MCP 도구',
    'help.categories.troubleshooting': '문제 해결',

    // Errors
    'errors.networkError': '네트워크 연결 오류입니다. 다시 시도해주세요.',
    'errors.unauthorized': '이 작업을 수행할 권한이 없습니다.',
    'errors.notFound': '요청한 리소스를 찾을 수 없습니다.',
    'errors.serverError': '내부 서버 오류입니다. 나중에 다시 시도해주세요.',
    'errors.validationError': '입력을 확인하고 다시 시도해주세요.',
  },

  pt: {
    // Common
    'common.loading': 'Carregando...',
    'common.error': 'Erro',
    'common.success': 'Sucesso',
    'common.cancel': 'Cancelar',
    'common.save': 'Salvar',
    'common.delete': 'Excluir',
    'common.edit': 'Editar',
    'common.create': 'Criar',
    'common.close': 'Fechar',
    'common.back': 'Voltar',
    'common.next': 'Próximo',
    'common.previous': 'Anterior',
    'common.search': 'Pesquisar',
    'common.settings': 'Configurações',

    // Navigation
    'nav.dashboard': 'Painel',
    'nav.chat': 'Chat Inteligente',
    'nav.agents': 'Agentes',
    'nav.models': 'Modelos IA',
    'nav.demos': 'Demos',
    'nav.help': 'Ajuda',
    'nav.onboarding': 'Começar',

    // Dashboard
    'dashboard.title': 'Framework de Agentes Moderno',
    'dashboard.subtitle': 'Crie, gerencie e orquestre agentes autônomos com recursos avançados de IA e fluxos de trabalho colaborativos.',
    'dashboard.quickActions': 'Ações Rápidas',
    'dashboard.recentActivity': 'Atividade Recente',
    'dashboard.stats.agents': 'Agentes Ativos',
    'dashboard.stats.tasks': 'Tarefas Concluídas',
    'dashboard.stats.collaborations': 'Colaborações',

    // Chat
    'chat.placeholder': 'Descreva o que você gostaria de criar ou automatizar...',
    'chat.sendMessage': 'Enviar Mensagem',
    'chat.voiceInput': 'Entrada de Voz',
    'chat.suggestions': 'Sugestões',
    'chat.intelligentOrchestrator': 'Orquestrador de Chat Inteligente',
    'chat.smartSuggestions': 'Sugestões Inteligentes',

    // Agents
    'agents.create': 'Criar Agente',
    'agents.list': 'Lista de Agentes',
    'agents.edit': 'Editar Agente',
    'agents.delete': 'Excluir Agente',
    'agents.status.idle': 'Inativo',
    'agents.status.busy': 'Ocupado',
    'agents.status.error': 'Erro',
    'agents.capabilities': 'Capacidades',
    'agents.templates': 'Modelos',

    // Onboarding
    'onboarding.welcome.title': 'Bem-vindo ao Chat Inteligente',
    'onboarding.welcome.description': 'Seu hub de orquestração de agentes com IA',
    'onboarding.features.title': 'Recursos Poderosos ao Seu Alcance',
    'onboarding.demo.title': 'Experimente Estes Cenários de Demo',
    'onboarding.ready.title': 'Você Está Pronto!',
    'onboarding.skip': 'Pular Tutorial',
    'onboarding.complete': 'Começar',

    // Help
    'help.title': 'Central de Ajuda',
    'help.search.placeholder': 'Pesquisar artigos de ajuda, guias e tutoriais...',
    'help.categories.gettingStarted': 'Primeiros Passos',
    'help.categories.chat': 'Chat Inteligente',
    'help.categories.agents': 'Agentes',
    'help.categories.collaborations': 'Colaborações',
    'help.categories.mcps': 'Ferramentas MCP',
    'help.categories.troubleshooting': 'Solução de Problemas',

    // Errors
    'errors.networkError': 'Erro de conexão de rede. Tente novamente.',
    'errors.unauthorized': 'Você não tem autorização para executar esta ação.',
    'errors.notFound': 'O recurso solicitado não foi encontrado.',
    'errors.serverError': 'Erro interno do servidor. Tente novamente mais tarde.',
    'errors.validationError': 'Verifique sua entrada e tente novamente.',
  },

  ru: {
    // Common
    'common.loading': 'Загрузка...',
    'common.error': 'Ошибка',
    'common.success': 'Успех',
    'common.cancel': 'Отмена',
    'common.save': 'Сохранить',
    'common.delete': 'Удалить',
    'common.edit': 'Редактировать',
    'common.create': 'Создать',
    'common.close': 'Закрыть',
    'common.back': 'Назад',
    'common.next': 'Далее',
    'common.previous': 'Предыдущий',
    'common.search': 'Поиск',
    'common.settings': 'Настройки',

    // Navigation
    'nav.dashboard': 'Панель управления',
    'nav.chat': 'Умный чат',
    'nav.agents': 'Агенты',
    'nav.models': 'ИИ модели',
    'nav.demos': 'Демо',
    'nav.help': 'Помощь',
    'nav.onboarding': 'Начать',

    // Dashboard
    'dashboard.title': 'Современный фреймворк агентов',
    'dashboard.subtitle': 'Создавайте, управляйте и организуйте автономных агентов с расширенными возможностями ИИ и совместными рабочими процессами.',
    'dashboard.quickActions': 'Быстрые действия',
    'dashboard.recentActivity': 'Недавняя активность',
    'dashboard.stats.agents': 'Активные агенты',
    'dashboard.stats.tasks': 'Выполненные задачи',
    'dashboard.stats.collaborations': 'Сотрудничества',

    // Chat
    'chat.placeholder': 'Опишите, что вы хотели бы создать или автоматизировать...',
    'chat.sendMessage': 'Отправить сообщение',
    'chat.voiceInput': 'Голосовой ввод',
    'chat.suggestions': 'Предложения',
    'chat.intelligentOrchestrator': 'Умный чат-оркестратор',
    'chat.smartSuggestions': 'Умные предложения',

    // Agents
    'agents.create': 'Создать агента',
    'agents.list': 'Список агентов',
    'agents.edit': 'Редактировать агента',
    'agents.delete': 'Удалить агента',
    'agents.status.idle': 'Бездействует',
    'agents.status.busy': 'Занят',
    'agents.status.error': 'Ошибка',
    'agents.capabilities': 'Возможности',
    'agents.templates': 'Шаблоны',

    // Onboarding
    'onboarding.welcome.title': 'Добро пожаловать в умный чат',
    'onboarding.welcome.description': 'Ваш центр управления агентами с ИИ',
    'onboarding.features.title': 'Мощные возможности под рукой',
    'onboarding.demo.title': 'Попробуйте эти демо-сценарии',
    'onboarding.ready.title': 'Вы готовы!',
    'onboarding.skip': 'Пропустить урок',
    'onboarding.complete': 'Начать',

    // Help
    'help.title': 'Центр помощи',
    'help.search.placeholder': 'Поиск справочных статей, руководств и учебников...',
    'help.categories.gettingStarted': 'Начало работы',
    'help.categories.chat': 'Умный чат',
    'help.categories.agents': 'Агенты',
    'help.categories.collaborations': 'Сотрудничества',
    'help.categories.mcps': 'MCP инструменты',
    'help.categories.troubleshooting': 'Устранение неполадок',

    // Errors
    'errors.networkError': 'Ошибка сетевого соединения. Пожалуйста, попробуйте еще раз.',
    'errors.unauthorized': 'У вас нет разрешения на выполнение этого действия.',
    'errors.notFound': 'Запрашиваемый ресурс не найден.',
    'errors.serverError': 'Внутренняя ошибка сервера. Пожалуйста, попробуйте позже.',
    'errors.validationError': 'Пожалуйста, проверьте ввод и попробуйте еще раз.',
  },

  ar: {
    // Common
    'common.loading': 'جارٍ التحميل...',
    'common.error': 'خطأ',
    'common.success': 'نجح',
    'common.cancel': 'إلغاء',
    'common.save': 'حفظ',
    'common.delete': 'حذف',
    'common.edit': 'تعديل',
    'common.create': 'إنشاء',
    'common.close': 'إغلاق',
    'common.back': 'رجوع',
    'common.next': 'التالي',
    'common.previous': 'السابق',
    'common.search': 'بحث',
    'common.settings': 'الإعدادات',

    // Navigation
    'nav.dashboard': 'لوحة التحكم',
    'nav.chat': 'المحادثة الذكية',
    'nav.agents': 'الوكلاء',
    'nav.models': 'نماذج الذكاء الاصطناعي',
    'nav.demos': 'العروض التوضيحية',
    'nav.help': 'المساعدة',
    'nav.onboarding': 'البدء',

    // Dashboard
    'dashboard.title': 'إطار عمل الوكلاء الحديث',
    'dashboard.subtitle': 'قم بإنشاء وإدارة وتنسيق الوكلاء المستقلين بقدرات الذكاء الاصطناعي المتقدمة وسير العمل التعاوني.',
    'dashboard.quickActions': 'الإجراءات السريعة',
    'dashboard.recentActivity': 'النشاط الأخير',
    'dashboard.stats.agents': 'الوكلاء النشطون',
    'dashboard.stats.tasks': 'المهام المكتملة',
    'dashboard.stats.collaborations': 'التعاونات',

    // Chat
    'chat.placeholder': 'صف ما تريد إنشاؤه أو أتمتته...',
    'chat.sendMessage': 'إرسال رسالة',
    'chat.voiceInput': 'إدخال صوتي',
    'chat.suggestions': 'اقتراحات',
    'chat.intelligentOrchestrator': 'منسق المحادثة الذكية',
    'chat.smartSuggestions': 'اقتراحات ذكية',

    // Agents
    'agents.create': 'إنشاء وكيل',
    'agents.list': 'قائمة الوكلاء',
    'agents.edit': 'تعديل الوكيل',
    'agents.delete': 'حذف الوكيل',
    'agents.status.idle': 'خامل',
    'agents.status.busy': 'مشغول',
    'agents.status.error': 'خطأ',
    'agents.capabilities': 'القدرات',
    'agents.templates': 'القوالب',

    // Onboarding
    'onboarding.welcome.title': 'مرحباً بك في المحادثة الذكية',
    'onboarding.welcome.description': 'مركز تنسيق الوكلاء المدعوم بالذكاء الاصطناعي',
    'onboarding.features.title': 'ميزات قوية في متناول يدك',
    'onboarding.demo.title': 'جرب هذه السيناريوهات التوضيحية',
    'onboarding.ready.title': 'أنت مستعد!',
    'onboarding.skip': 'تخطي البرنامج التعليمي',
    'onboarding.complete': 'البدء',

    // Help
    'help.title': 'مركز المساعدة',
    'help.search.placeholder': 'البحث عن مقالات المساعدة والأدلة والدروس...',
    'help.categories.gettingStarted': 'البدء',
    'help.categories.chat': 'المحادثة الذكية',
    'help.categories.agents': 'الوكلاء',
    'help.categories.collaborations': 'التعاونات',
    'help.categories.mcps': 'أدوات MCP',
    'help.categories.troubleshooting': 'استكشاف الأخطاء وإصلاحها',

    // Errors
    'errors.networkError': 'خطأ في الاتصال بالشبكة. يرجى المحاولة مرة أخرى.',
    'errors.unauthorized': 'ليس لديك إذن لتنفيذ هذا الإجراء.',
    'errors.notFound': 'لم يتم العثور على المورد المطلوب.',
    'errors.serverError': 'خطأ داخلي في الخادم. يرجى المحاولة مرة أخرى لاحقاً.',
    'errors.validationError': 'يرجى مراجعة المدخلات والمحاولة مرة أخرى.',
  },
}

export const SUPPORTED_LANGUAGES: Array<{
  code: SupportedLanguage
  name: string
  nativeName: string
  flag: string
}> = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', flag: '🇰🇷' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦' },
]
