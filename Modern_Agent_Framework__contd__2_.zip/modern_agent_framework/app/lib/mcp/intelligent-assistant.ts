
// Stub file to prevent import errors
const intelligentAssistant = {
  // Empty stub
}

const mcpAssistant = {
  // Empty stub
}

export { intelligentAssistant, mcpAssistant }
export default intelligentAssistant
