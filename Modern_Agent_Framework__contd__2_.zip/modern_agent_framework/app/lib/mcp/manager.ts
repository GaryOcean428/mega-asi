
// Stub file to prevent import errors
export const mcpManager = {
  // Empty stub
}

export default mcpManager
