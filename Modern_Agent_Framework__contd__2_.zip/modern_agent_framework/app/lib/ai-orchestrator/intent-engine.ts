
import { PLATFORM_MODELS } from '@/lib/llm-client'

export interface IntentAnalysis {
  intent: 'general_chat' | 'create_agent' | 'create_collaboration' | 'install_mcp' | 'workflow_automation' | 'help_request'
  confidence: number
  entities: {
    agentType?: string
    capabilities?: string[]
    mcpName?: string
    collaborationType?: string
    urgency?: 'low' | 'medium' | 'high'
    complexity?: 'simple' | 'moderate' | 'complex'
  }
  suggestedActions: SuggestedAction[]
  context: ConversationContext
}

export interface SuggestedAction {
  id: string
  type: 'create_agent' | 'install_mcp' | 'create_collaboration' | 'setup_workflow'
  title: string
  description: string
  confidence: number
  parameters: Record<string, any>
  quickSetup: boolean
}

export interface ConversationContext {
  userId: string
  workspaceId: string
  conversationId: string
  messageHistory: Array<{
    role: 'user' | 'assistant' | 'agent'
    content: string
    timestamp: Date
  }>
  activeAgents: string[]
  currentProject?: string
  userExpertise: 'beginner' | 'intermediate' | 'expert'
}

export class IntentRecognitionEngine {
  private llmClient: any

  constructor() {
    // Initialize with platform LLM client
  }

  async analyzeIntent(message: string, context: ConversationContext): Promise<IntentAnalysis> {
    const prompt = this.buildIntentPrompt(message, context)
    
    try {
      const response = await fetch('/api/llm/analyze-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          model: 'gpt-4.1-mini',
          context
        })
      })

      const analysis = await response.json()
      return this.processIntentResponse(analysis, context)
    } catch (error) {
      console.error('Intent analysis failed:', error)
      return this.fallbackIntent(message, context)
    }
  }

  private buildIntentPrompt(message: string, context: ConversationContext): string {
    return `
You are an AI intent recognition system for an autonomous agent management platform. Analyze the user's message and determine their intent.

User Message: "${message}"

Conversation Context:
- User Expertise: ${context.userExpertise}
- Active Agents: ${context.activeAgents.join(', ') || 'None'}
- Current Project: ${context.currentProject || 'None'}
- Recent Messages: ${context.messageHistory.slice(-3).map(m => `${m.role}: ${m.content}`).join('\n')}

Intent Categories:
1. general_chat - Casual conversation, questions, discussions
2. create_agent - User wants to create a new autonomous agent
3. create_collaboration - User wants to set up multi-agent collaboration  
4. install_mcp - User wants to install or manage MCP tools
5. workflow_automation - User wants to automate processes
6. help_request - User needs assistance or guidance

Extract:
- Intent category and confidence (0-1)
- Entity information (agent types, capabilities, MCP names, etc.)
- Suggested actions with parameters
- Complexity assessment

Respond in JSON format:
{
  "intent": "category",
  "confidence": 0.95,
  "entities": {
    "agentType": "data_analyst",
    "capabilities": ["data_analysis", "visualization"],
    "urgency": "medium",
    "complexity": "moderate"
  },
  "suggestedActions": [
    {
      "type": "create_agent",
      "title": "Create Data Analysis Agent",
      "description": "Set up an agent specialized in data analysis and visualization",
      "confidence": 0.9,
      "parameters": {
        "role": "data_analyst",
        "capabilities": ["pandas", "matplotlib", "statistical_analysis"],
        "mcps": ["data-processing-mcp", "visualization-mcp"]
      },
      "quickSetup": true
    }
  ]
}
`
  }

  private processIntentResponse(response: any, context: ConversationContext): IntentAnalysis {
    return {
      ...response,
      context,
      suggestedActions: response.suggestedActions.map((action: any, index: number) => ({
        ...action,
        id: `action_${Date.now()}_${index}`
      }))
    }
  }

  private fallbackIntent(message: string, context: ConversationContext): IntentAnalysis {
    // Simple keyword-based fallback
    const agentKeywords = ['agent', 'bot', 'assistant', 'create', 'build', 'make']
    const mcpKeywords = ['tool', 'integration', 'mcp', 'install', 'add', 'capability']
    
    let intent: IntentAnalysis['intent'] = 'general_chat'
    let confidence = 0.3

    if (agentKeywords.some(keyword => message.toLowerCase().includes(keyword))) {
      intent = 'create_agent'
      confidence = 0.6
    } else if (mcpKeywords.some(keyword => message.toLowerCase().includes(keyword))) {
      intent = 'install_mcp'
      confidence = 0.5
    }

    return {
      intent,
      confidence,
      entities: {},
      suggestedActions: [],
      context
    }
  }
}

export const intentEngine = new IntentRecognitionEngine()
