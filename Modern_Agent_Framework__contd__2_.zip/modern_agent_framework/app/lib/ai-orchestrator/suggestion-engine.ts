
import { IntentAnalysis } from './intent-engine'

export interface AgentTemplate {
  id: string
  name: string
  description: string
  role: string
  capabilities: string[]
  systemPrompt: string
  requiredMCPs: string[]
  complexity: 'beginner' | 'intermediate' | 'advanced'
  useCase: string
  icon: string
}

export interface MCPRecommendation {
  id: string
  name: string
  description: string
  capabilities: string[]
  compatibility: string[]
  installationComplexity: 'easy' | 'moderate' | 'complex'
  popularity: number
  rating: number
  tags: string[]
}

export interface CollaborationTemplate {
  id: string
  name: string
  description: string
  agents: Array<{
    role: string
    capabilities: string[]
    template: string
  }>
  workflow: Array<{
    step: string
    agent: string
    dependencies: string[]
  }>
  complexity: 'simple' | 'moderate' | 'complex'
  useCase: string
}

export class SuggestionEngine {
  private agentTemplates: AgentTemplate[] = [
    {
      id: 'data_analyst',
      name: 'Data Analyst Agent',
      description: 'Specialized in data analysis, visualization, and statistical insights',
      role: 'analyst',
      capabilities: ['data_analysis', 'visualization', 'statistics', 'reporting'],
      systemPrompt: 'You are a data analyst AI assistant specialized in analyzing data, creating visualizations, and providing statistical insights. You excel at finding patterns, trends, and actionable insights from datasets.',
      requiredMCPs: ['data-processing-mcp', 'visualization-mcp', 'statistics-mcp'],
      complexity: 'intermediate',
      useCase: 'Data analysis, reporting, business intelligence',
      icon: 'BarChart3'
    },
    {
      id: 'research_assistant',
      name: 'Research Assistant',
      description: 'Comprehensive research agent for information gathering and analysis',
      role: 'researcher',
      capabilities: ['web_research', 'document_analysis', 'summarization', 'fact_checking'],
      systemPrompt: 'You are a research assistant AI specialized in gathering, analyzing, and synthesizing information from various sources. You provide comprehensive, well-sourced research reports and insights.',
      requiredMCPs: ['web-search-mcp', 'document-parser-mcp', 'fact-checker-mcp'],
      complexity: 'beginner',
      useCase: 'Research, information gathering, market analysis',
      icon: 'Search'
    },
    {
      id: 'code_assistant',
      name: 'Code Assistant',
      description: 'Expert coding companion for development tasks',
      role: 'developer',
      capabilities: ['code_generation', 'debugging', 'code_review', 'testing'],
      systemPrompt: 'You are an expert software development assistant specialized in writing, reviewing, and debugging code across multiple programming languages and frameworks.',
      requiredMCPs: ['code-execution-mcp', 'git-integration-mcp', 'testing-framework-mcp'],
      complexity: 'advanced',
      useCase: 'Software development, code review, debugging',
      icon: 'Code'
    },
    {
      id: 'content_creator',
      name: 'Content Creator',
      description: 'Creative writing and content generation specialist',
      role: 'creator',
      capabilities: ['writing', 'editing', 'seo_optimization', 'social_media'],
      systemPrompt: 'You are a creative content specialist focused on producing engaging, high-quality written content for various platforms and audiences.',
      requiredMCPs: ['seo-optimizer-mcp', 'social-media-mcp', 'grammar-checker-mcp'],
      complexity: 'intermediate',
      useCase: 'Content marketing, blog writing, social media',
      icon: 'PenTool'
    },
    {
      id: 'project_manager',
      name: 'Project Manager',
      description: 'Organizational and project coordination specialist',
      role: 'coordinator',
      capabilities: ['task_management', 'scheduling', 'team_coordination', 'reporting'],
      systemPrompt: 'You are a project management specialist focused on organizing tasks, coordinating team activities, and ensuring project success through effective planning and communication.',
      requiredMCPs: ['calendar-integration-mcp', 'task-tracker-mcp', 'communication-mcp'],
      complexity: 'intermediate',
      useCase: 'Project management, team coordination, planning',
      icon: 'Calendar'
    }
  ]

  private mcpRecommendations: MCPRecommendation[] = [
    {
      id: 'web-search-mcp',
      name: 'Web Search MCP',
      description: 'Advanced web searching and information retrieval',
      capabilities: ['search', 'crawling', 'content_extraction'],
      compatibility: ['research_assistant', 'data_analyst'],
      installationComplexity: 'easy',
      popularity: 95,
      rating: 4.8,
      tags: ['search', 'web', 'research']
    },
    {
      id: 'data-processing-mcp',
      name: 'Data Processing MCP',
      description: 'Comprehensive data manipulation and analysis toolkit',
      capabilities: ['data_cleaning', 'transformation', 'analysis'],
      compatibility: ['data_analyst', 'research_assistant'],
      installationComplexity: 'moderate',
      popularity: 88,
      rating: 4.7,
      tags: ['data', 'analysis', 'pandas', 'numpy']
    },
    {
      id: 'visualization-mcp',
      name: 'Visualization MCP',
      description: 'Advanced data visualization and charting capabilities',
      capabilities: ['charts', 'graphs', 'interactive_viz'],
      compatibility: ['data_analyst', 'research_assistant'],
      installationComplexity: 'easy',
      popularity: 85,
      rating: 4.6,
      tags: ['visualization', 'charts', 'plotting']
    },
    {
      id: 'code-execution-mcp',
      name: 'Code Execution MCP',
      description: 'Safe code execution environment for multiple languages',
      capabilities: ['code_execution', 'testing', 'debugging'],
      compatibility: ['code_assistant', 'data_analyst'],
      installationComplexity: 'complex',
      popularity: 92,
      rating: 4.9,
      tags: ['code', 'execution', 'development']
    },
    {
      id: 'calendar-integration-mcp',
      name: 'Calendar Integration MCP',
      description: 'Calendar management and scheduling integration',
      capabilities: ['scheduling', 'calendar_sync', 'reminders'],
      compatibility: ['project_manager', 'research_assistant'],
      installationComplexity: 'moderate',
      popularity: 75,
      rating: 4.3,
      tags: ['calendar', 'scheduling', 'productivity']
    }
  ]

  private collaborationTemplates: CollaborationTemplate[] = [
    {
      id: 'research_and_analysis',
      name: 'Research & Analysis Pipeline',
      description: 'Comprehensive research followed by data analysis and reporting',
      agents: [
        { role: 'researcher', capabilities: ['web_research'], template: 'research_assistant' },
        { role: 'analyst', capabilities: ['data_analysis'], template: 'data_analyst' },
        { role: 'writer', capabilities: ['reporting'], template: 'content_creator' }
      ],
      workflow: [
        { step: 'Information Gathering', agent: 'researcher', dependencies: [] },
        { step: 'Data Analysis', agent: 'analyst', dependencies: ['Information Gathering'] },
        { step: 'Report Generation', agent: 'writer', dependencies: ['Data Analysis'] }
      ],
      complexity: 'moderate',
      useCase: 'Market research, competitive analysis, business intelligence'
    },
    {
      id: 'content_pipeline',
      name: 'Content Production Pipeline',
      description: 'End-to-end content creation from research to publication',
      agents: [
        { role: 'researcher', capabilities: ['research'], template: 'research_assistant' },
        { role: 'writer', capabilities: ['writing'], template: 'content_creator' },
        { role: 'reviewer', capabilities: ['editing'], template: 'content_creator' }
      ],
      workflow: [
        { step: 'Topic Research', agent: 'researcher', dependencies: [] },
        { step: 'Content Writing', agent: 'writer', dependencies: ['Topic Research'] },
        { step: 'Content Review', agent: 'reviewer', dependencies: ['Content Writing'] }
      ],
      complexity: 'simple',
      useCase: 'Blog writing, content marketing, documentation'
    }
  ]

  async generateSuggestions(analysis: IntentAnalysis): Promise<{
    agents: AgentTemplate[]
    mcps: MCPRecommendation[]
    collaborations: CollaborationTemplate[]
    quickActions: Array<{
      id: string
      title: string
      description: string
      action: () => void
    }>
  }> {
    const suggestions = {
      agents: this.suggestAgents(analysis),
      mcps: this.suggestMCPs(analysis),
      collaborations: this.suggestCollaborations(analysis),
      quickActions: this.generateQuickActions(analysis)
    }

    return suggestions
  }

  private suggestAgents(analysis: IntentAnalysis): AgentTemplate[] {
    const { entities, intent } = analysis
    
    if (intent !== 'create_agent' && intent !== 'create_collaboration') {
      return []
    }

    // Filter based on extracted entities
    let suggestions = [...this.agentTemplates]

    if (entities.agentType) {
      suggestions = suggestions.filter(template => 
        template.role.includes(entities.agentType!) || 
        template.name.toLowerCase().includes(entities.agentType!.toLowerCase())
      )
    }

    if (entities.capabilities) {
      suggestions = suggestions.filter(template =>
        entities.capabilities!.some(cap => 
          template.capabilities.includes(cap)
        )
      )
    }

    // Sort by relevance
    return suggestions.slice(0, 3)
  }

  private suggestMCPs(analysis: IntentAnalysis): MCPRecommendation[] {
    const { entities, intent } = analysis

    if (intent !== 'install_mcp' && intent !== 'create_agent') {
      return []
    }

    let suggestions = [...this.mcpRecommendations]

    if (entities.mcpName) {
      suggestions = suggestions.filter(mcp =>
        mcp.name.toLowerCase().includes(entities.mcpName!.toLowerCase()) ||
        mcp.tags.some(tag => tag.includes(entities.mcpName!.toLowerCase()))
      )
    }

    if (entities.capabilities) {
      suggestions = suggestions.filter(mcp =>
        entities.capabilities!.some(cap =>
          mcp.capabilities.includes(cap)
        )
      )
    }

    // Sort by popularity and rating
    return suggestions
      .sort((a, b) => (b.popularity * b.rating) - (a.popularity * a.rating))
      .slice(0, 5)
  }

  private suggestCollaborations(analysis: IntentAnalysis): CollaborationTemplate[] {
    const { intent, entities } = analysis

    if (intent !== 'create_collaboration') {
      return []
    }

    let suggestions = [...this.collaborationTemplates]

    if (entities.collaborationType) {
      suggestions = suggestions.filter(template =>
        template.name.toLowerCase().includes(entities.collaborationType!.toLowerCase()) ||
        template.useCase.toLowerCase().includes(entities.collaborationType!.toLowerCase())
      )
    }

    return suggestions.slice(0, 2)
  }

  private generateQuickActions(analysis: IntentAnalysis): Array<{
    id: string
    title: string
    description: string
    action: () => void
  }> {
    const actions = []

    if (analysis.intent === 'create_agent') {
      actions.push({
        id: 'quick_agent_setup',
        title: '⚡ Quick Agent Setup',
        description: 'Create an agent with smart defaults',
        action: () => console.log('Quick agent setup')
      })
    }

    if (analysis.intent === 'install_mcp') {
      actions.push({
        id: 'browse_mcps',
        title: '🔧 Browse MCP Store',
        description: 'Explore available tools and integrations',
        action: () => console.log('Browse MCPs')
      })
    }

    return actions
  }

  getAgentTemplate(id: string): AgentTemplate | undefined {
    return this.agentTemplates.find(template => template.id === id)
  }

  getMCPRecommendation(id: string): MCPRecommendation | undefined {
    return this.mcpRecommendations.find(mcp => mcp.id === id)
  }

  getCollaborationTemplate(id: string): CollaborationTemplate | undefined {
    return this.collaborationTemplates.find(template => template.id === id)
  }
}

export const suggestionEngine = new SuggestionEngine()
