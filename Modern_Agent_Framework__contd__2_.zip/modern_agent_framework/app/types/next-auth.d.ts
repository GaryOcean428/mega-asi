
import NextAuth from 'next-auth'

declare module 'next-auth' {
  interface User {
    id: string
    role?: string
    organization?: any
    workspaces?: any[]
  }

  interface Session {
    user: {
      id: string
      name?: string | null
      email?: string | null
      image?: string | null
      role?: string
      organization?: any
      workspaces?: any[]
    }
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string
    role?: string
    organization?: any
    workspaces?: any[]
  }
}
