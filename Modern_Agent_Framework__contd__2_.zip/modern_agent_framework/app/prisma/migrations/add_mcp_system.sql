
-- MCP (Model Context Protocol) Management System
-- This migration adds comprehensive MCP support with secure credential management

-- MCP Registry - Available MCP servers in the marketplace
CREATE TABLE IF NOT EXISTS mcp_registry (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    category TEXT NOT NULL, -- 'productivity', 'development', 'data', 'ai', etc.
    provider TEXT, -- GitHub username, company, etc.
    repository_url TEXT,
    documentation_url TEXT,
    icon_url TEXT,
    
    -- Capabilities and metadata
    capabilities TEXT[], -- ['file_system', 'web_search', 'database', etc.]
    supported_protocols TEXT[] DEFAULT ARRAY['mcp'],
    version TEXT NOT NULL DEFAULT '1.0.0',
    minimum_agent_version TEXT,
    
    -- Installation metadata
    install_command TEXT, -- npm install, pip install, etc.
    config_schema JSONB, -- Schema for required configuration
    required_credentials TEXT[], -- ['api_key', 'oauth_token', etc.]
    
    -- Metrics and status
    install_count INTEGER DEFAULT 0,
    rating DECIMAL(2,1) DEFAULT 0.0,
    is_verified BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    
    -- Security and trust
    security_level TEXT DEFAULT 'community', -- 'official', 'verified', 'community'
    permissions_required TEXT[], -- Permissions this MCP needs
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Search optimization
    search_vector tsvector GENERATED ALWAYS AS (
        to_tsvector('english', name || ' ' || description || ' ' || array_to_string(capabilities, ' '))
    ) STORED
);

-- MCP Installations - User/workspace specific MCP installations
CREATE TABLE IF NOT EXISTS mcp_installations (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    mcp_registry_id TEXT NOT NULL REFERENCES mcp_registry(id) ON DELETE CASCADE,
    
    -- Installation context
    user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
    workspace_id TEXT REFERENCES workspaces(id) ON DELETE CASCADE,
    organization_id TEXT REFERENCES organizations(id) ON DELETE CASCADE,
    
    -- Installation details
    version TEXT NOT NULL,
    config JSONB NOT NULL DEFAULT '{}',
    custom_name TEXT, -- User can rename their installation
    
    -- Status and health
    status TEXT DEFAULT 'installing', -- 'installing', 'active', 'error', 'disabled'
    last_health_check TIMESTAMP WITH TIME ZONE,
    health_status TEXT DEFAULT 'unknown', -- 'healthy', 'warning', 'error', 'unknown'
    error_message TEXT,
    
    -- Usage tracking
    last_used_at TIMESTAMP WITH TIME ZONE,
    usage_count INTEGER DEFAULT 0,
    
    -- Timestamps
    installed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(mcp_registry_id, workspace_id)
);

-- MCP Credentials - Secure storage for MCP-specific credentials
CREATE TABLE IF NOT EXISTS mcp_credentials (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    installation_id TEXT NOT NULL REFERENCES mcp_installations(id) ON DELETE CASCADE,
    
    -- Credential identification
    credential_key TEXT NOT NULL, -- 'api_key', 'oauth_token', 'database_url', etc.
    credential_type TEXT NOT NULL, -- 'api_key', 'oauth', 'basic_auth', 'certificate', etc.
    
    -- Encrypted storage
    encrypted_value TEXT NOT NULL, -- Encrypted credential value
    encryption_key_id TEXT NOT NULL, -- Reference to encryption key used
    
    -- Metadata
    description TEXT,
    expires_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    
    -- Security tracking
    created_by TEXT REFERENCES users(id),
    last_used_at TIMESTAMP WITH TIME ZONE,
    access_count INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(installation_id, credential_key)
);

-- MCP Knowledge Base - RAG system for MCP documentation and assistance
CREATE TABLE IF NOT EXISTS mcp_knowledge_base (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    mcp_registry_id TEXT REFERENCES mcp_registry(id) ON DELETE CASCADE,
    
    -- Content details
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    content_type TEXT DEFAULT 'documentation', -- 'documentation', 'tutorial', 'troubleshooting', 'example'
    section TEXT, -- 'installation', 'configuration', 'usage', 'api', etc.
    
    -- Metadata
    source_url TEXT,
    author TEXT,
    version TEXT, -- MCP version this knowledge applies to
    tags TEXT[],
    
    -- Vector embeddings for RAG
    embedding vector(1536), -- OpenAI embedding dimension
    
    -- Quality and verification
    is_official BOOLEAN DEFAULT false,
    quality_score DECIMAL(3,2) DEFAULT 0.0,
    upvotes INTEGER DEFAULT 0,
    downvotes INTEGER DEFAULT 0,
    
    -- Search optimization
    search_vector tsvector GENERATED ALWAYS AS (
        to_tsvector('english', title || ' ' || content || ' ' || array_to_string(tags, ' '))
    ) STORED,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- MCP Usage Analytics - Track how MCPs are being used
CREATE TABLE IF NOT EXISTS mcp_usage_analytics (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    installation_id TEXT NOT NULL REFERENCES mcp_installations(id) ON DELETE CASCADE,
    agent_id TEXT REFERENCES agents(id) ON DELETE SET NULL,
    
    -- Usage details
    method_called TEXT NOT NULL, -- MCP method that was called
    parameters JSONB,
    response_status TEXT, -- 'success', 'error', 'timeout'
    response_time_ms INTEGER,
    error_message TEXT,
    
    -- Context
    chat_room_id TEXT REFERENCES chat_rooms(id) ON DELETE SET NULL,
    task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL,
    
    -- Timestamps
    used_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Indexes for analytics queries
    INDEX idx_mcp_usage_installation_date (installation_id, used_at),
    INDEX idx_mcp_usage_agent_date (agent_id, used_at),
    INDEX idx_mcp_usage_method (method_called)
);

-- MCP Recommendations - Smart recommendations based on user behavior
CREATE TABLE IF NOT EXISTS mcp_recommendations (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Recommendation target
    user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
    workspace_id TEXT REFERENCES workspaces(id) ON DELETE CASCADE,
    
    -- Recommendation details
    mcp_registry_id TEXT NOT NULL REFERENCES mcp_registry(id) ON DELETE CASCADE,
    recommendation_type TEXT NOT NULL, -- 'workflow_based', 'colleague_suggested', 'trending', 'ai_suggested'
    confidence_score DECIMAL(3,2) NOT NULL, -- 0.00 to 1.00
    reasoning TEXT, -- Why this MCP was recommended
    
    -- Context that generated the recommendation
    trigger_context JSONB, -- What user action/query triggered this
    related_agents TEXT[], -- Agent IDs that might benefit
    
    -- Recommendation lifecycle
    status TEXT DEFAULT 'pending', -- 'pending', 'viewed', 'accepted', 'dismissed'
    viewed_at TIMESTAMP WITH TIME ZONE,
    responded_at TIMESTAMP WITH TIME ZONE,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() + INTERVAL '30 days'
);

-- Encryption Keys - For secure credential storage
CREATE TABLE IF NOT EXISTS encryption_keys (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    key_purpose TEXT NOT NULL, -- 'mcp_credentials', 'user_secrets', etc.
    encrypted_key TEXT NOT NULL, -- The actual encryption key, encrypted with master key
    algorithm TEXT NOT NULL DEFAULT 'AES-256-GCM',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    rotated_at TIMESTAMP WITH TIME ZONE
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_mcp_registry_category ON mcp_registry(category);
CREATE INDEX IF NOT EXISTS idx_mcp_registry_search ON mcp_registry USING gin(search_vector);
CREATE INDEX IF NOT EXISTS idx_mcp_installations_workspace ON mcp_installations(workspace_id);
CREATE INDEX IF NOT EXISTS idx_mcp_installations_status ON mcp_installations(status);
CREATE INDEX IF NOT EXISTS idx_mcp_knowledge_embedding ON mcp_knowledge_base USING ivfflat (embedding vector_cosine_ops);
CREATE INDEX IF NOT EXISTS idx_mcp_knowledge_search ON mcp_knowledge_base USING gin(search_vector);
CREATE INDEX IF NOT EXISTS idx_mcp_recommendations_user ON mcp_recommendations(user_id, status);

-- Create triggers for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_mcp_registry_updated_at BEFORE UPDATE ON mcp_registry FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_mcp_installations_updated_at BEFORE UPDATE ON mcp_installations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_mcp_credentials_updated_at BEFORE UPDATE ON mcp_credentials FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_mcp_knowledge_base_updated_at BEFORE UPDATE ON mcp_knowledge_base FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
