
'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { 
  MessageSquare, 
  Send, 
  Mic, 
  Plus, 
  Settings, 
  Menu,
  X,
  Bot,
  Zap,
  Users,
  Lightbulb,
  ChevronUp,
  ChevronDown
} from 'lucide-react'

interface MobileChatInterfaceProps {
  workspaceId: string
  onSendMessage: (content: any) => void
  messages: any[]
  suggestions?: any[]
  currentIntent?: any
}

export function MobileChatInterface({ 
  workspaceId, 
  onSendMessage, 
  messages, 
  suggestions,
  currentIntent 
}: MobileChatInterfaceProps) {
  const { data: session } = useSession() || {}
  const [input, setInput] = useState('')
  const [isRecording, setIsRecording] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [keyboardHeight, setKeyboardHeight] = useState(0)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Handle keyboard appearing on mobile
  useEffect(() => {
    const handleResize = () => {
      const windowHeight = window.innerHeight
      const documentHeight = document.documentElement.clientHeight
      const heightDiff = documentHeight - windowHeight
      
      if (heightDiff > 150) { // Keyboard likely visible
        setKeyboardHeight(heightDiff)
      } else {
        setKeyboardHeight(0)
      }
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = () => {
    if (input.trim()) {
      onSendMessage({ text: input.trim() })
      setInput('')
      setShowSuggestions(false)
    }
  }

  const handleVoiceRecord = () => {
    setIsRecording(!isRecording)
    // Voice recording logic would go here
  }

  const handleQuickAction = (action: string, params?: any) => {
    const actionMessages = {
      create_agent: "I need to create a new agent",
      install_mcp: "Help me install some new tools",
      create_collaboration: "Set up a team collaboration",
      get_help: "I need help getting started"
    }
    
    const message = actionMessages[action as keyof typeof actionMessages] || action
    onSendMessage({ text: message })
  }

  const quickActions = [
    { id: 'create_agent', label: 'Create Agent', icon: <Bot className="h-4 w-4" />, color: 'bg-blue-500' },
    { id: 'install_mcp', label: 'Add Tools', icon: <Zap className="h-4 w-4" />, color: 'bg-green-500' },
    { id: 'create_collaboration', label: 'Team Up', icon: <Users className="h-4 w-4" />, color: 'bg-purple-500' },
    { id: 'get_help', label: 'Get Help', icon: <Lightbulb className="h-4 w-4" />, color: 'bg-yellow-500' }
  ]

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950">
      {/* Mobile Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-black/40 backdrop-blur-sm sticky top-0 z-10">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
            <MessageSquare className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="font-semibold text-white">AI Chat</h1>
            <p className="text-xs text-gray-400">Intelligent orchestration</p>
          </div>
        </div>
        
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="sm">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="bg-gray-900 border-gray-700">
            <SheetHeader>
              <SheetTitle className="text-white">Menu</SheetTitle>
            </SheetHeader>
            <div className="mt-6 space-y-4">
              <Button variant="ghost" className="w-full justify-start">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Bot className="h-4 w-4 mr-2" />
                My Agents
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Users className="h-4 w-4 mr-2" />
                Collaborations
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Messages Area */}
      <ScrollArea 
        className="flex-1 p-4"
        style={{ height: `calc(100vh - 160px - ${keyboardHeight}px)` }}
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-6">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
              <MessageSquare className="h-10 w-10 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white mb-2">Ready to help!</h3>
              <p className="text-gray-400 text-sm max-w-xs">
                Describe what you'd like to create or automate
              </p>
            </div>
            
            {/* Quick Actions for Empty State */}
            <div className="grid grid-cols-2 gap-3 w-full max-w-xs">
              {quickActions.map((action) => (
                <Button
                  key={action.id}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickAction(action.id)}
                  className="flex flex-col items-center p-4 h-auto space-y-2"
                >
                  <div className={`p-2 rounded-lg ${action.color}`}>
                    {action.icon}
                  </div>
                  <span className="text-xs">{action.label}</span>
                </Button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message, index) => (
              <MobileMessage key={index} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </ScrollArea>

      {/* Suggestions Panel */}
      {suggestions && (suggestions as any)?.agents?.length > 0 && (
        <div className="px-4 py-2 border-t border-gray-800 bg-black/20">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSuggestions(!showSuggestions)}
            className="w-full flex items-center justify-center space-x-2"
          >
            <Lightbulb className="h-4 w-4 text-yellow-400" />
            <span className="text-sm">Smart Suggestions</span>
            {showSuggestions ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
          </Button>
          
          {showSuggestions && (
            <div className="mt-2 space-y-2">
              {((suggestions as any)?.agents || []).slice(0, 2).map((agent: any) => (
                <Button
                  key={agent.id}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickAction('create_agent', { template: agent })}
                  className="w-full text-left justify-start"
                >
                  <Bot className="h-4 w-4 mr-2 text-blue-400" />
                  <span className="truncate">{agent.name}</span>
                </Button>
              ))}
              
              {((suggestions as any)?.mcps || []).slice(0, 1).map((mcp: any) => (
                <Button
                  key={mcp.id}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickAction('install_mcp', { mcp })}
                  className="w-full text-left justify-start"
                >
                  <Zap className="h-4 w-4 mr-2 text-green-400" />
                  <span className="truncate">{mcp.name}</span>
                </Button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Input Area */}
      <div className="p-4 border-t border-gray-800 bg-black/40 backdrop-blur-sm">
        <div className="flex items-center space-x-2">
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Describe what you'd like to create..."
              className="pr-12 bg-gray-800/50 border-gray-600 text-white placeholder:text-gray-400"
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={handleVoiceRecord}
              className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-1 ${
                isRecording ? 'text-red-400' : 'text-gray-400'
              }`}
            >
              <Mic className="h-4 w-4" />
            </Button>
          </div>
          <Button
            onClick={handleSend}
            disabled={!input.trim()}
            size="sm"
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Quick Actions Bar */}
        <div className="flex space-x-2 mt-2 overflow-x-auto pb-1">
          {quickActions.map((action) => (
            <Button
              key={action.id}
              variant="outline"
              size="sm"
              onClick={() => handleQuickAction(action.id)}
              className="flex items-center space-x-1 whitespace-nowrap"
            >
              {action.icon}
              <span className="text-xs">{action.label}</span>
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}

function MobileMessage({ message }: { message: any }) {
  const isUser = message.role === 'user'
  const isSystem = message.role === 'system'
  
  return (
    <div className={`flex items-start space-x-3 ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}>
      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
        isUser ? 'bg-blue-500' : isSystem ? 'bg-green-500' : 'bg-purple-500'
      }`}>
        {isUser ? (
          <span className="text-white text-xs font-semibold">You</span>
        ) : isSystem ? (
          <span className="text-white text-xs">✓</span>
        ) : (
          <MessageSquare className="h-4 w-4 text-white" />
        )}
      </div>
      
      <div className={`max-w-[75%] ${isUser ? 'text-right' : 'text-left'}`}>
        <div className={`rounded-2xl px-4 py-2 ${
          isUser 
            ? 'bg-blue-600 text-white' 
            : isSystem
            ? 'bg-green-600/20 border border-green-500/30 text-green-200'
            : 'bg-gray-700 text-white'
        }`}>
          <p className="text-sm">
            {typeof message.content === 'string' ? message.content : message.content.text}
          </p>
        </div>
        
        {message.intentAnalysis && (
          <div className="mt-2">
            <Badge variant="secondary" className="text-xs">
              {message.intentAnalysis.intent} ({Math.round(message.intentAnalysis.confidence * 100)}%)
            </Badge>
          </div>
        )}
        
        <p className="text-xs text-gray-400 mt-1">
          {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  )
}
