
/**
 * Enhanced Navigation with MCP Marketplace Integration
 */

'use client'

import React from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { 
  Home, 
  MessageCircle, 
  Users, 
  BarChart3, 
  Settings, 
  HelpCircle, 
  Brain,
  Zap,
  Store
} from 'lucide-react'

interface NavigationProps {
  isMobile?: boolean
}

export function Navigation({ isMobile = false }: NavigationProps) {
  const pathname = usePathname()
  const { data: session } = useSession()

  const navigationItems = [
    {
      name: 'Home',
      href: '/',
      icon: Home,
      description: 'Dashboard overview'
    },
    {
      name: 'Chat',
      href: '/chat',
      icon: MessageCircle,
      description: 'Intelligent conversations'
    },
    {
      name: 'Agents',
      href: '/agents',
      icon: Users,
      description: 'Manage AI agents'
    },
    {
      name: 'MCP Store',
      href: '/mcp-marketplace',
      icon: Store,
      description: 'Discover & install MCPs',
      badge: 'New'
    },
    {
      name: 'Models',
      href: '/models',
      icon: Brain,
      description: 'Available AI models'
    },
    {
      name: 'Analytics',
      href: '/analytics',
      icon: BarChart3,
      description: 'Usage insights'
    },
    {
      name: 'Help',
      href: '/help',
      icon: HelpCircle,
      description: 'Documentation & support'
    }
  ]

  const isActive = (href: string) => {
    if (href === '/') {
      return pathname === '/'
    }
    return pathname?.startsWith(href)
  }

  const NavItem = ({ item, index }: { item: typeof navigationItems[0], index: number }) => {
    const active = isActive(item.href)
    
    return (
      <Link
        key={item.href}
        href={item.href}
        className={`group relative flex items-center space-x-3 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 ${
          active
            ? 'bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300'
            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
        } ${isMobile ? 'w-full' : ''}`}
      >
        <item.icon className={`h-5 w-5 flex-shrink-0 ${
          active ? 'text-blue-500' : 'text-gray-400 group-hover:text-gray-500 dark:group-hover:text-gray-400'
        }`} />
        
        <span className="truncate">{item.name}</span>
        
        {/* New Badge for MCP Store */}
        {item.badge && (
          <span className="inline-flex items-center rounded-full bg-blue-100 dark:bg-blue-900 px-2 py-0.5 text-xs font-medium text-blue-800 dark:text-blue-200">
            {item.badge}
          </span>
        )}
        
        {/* Tooltip for desktop */}
        {!isMobile && (
          <div className="absolute left-full ml-3 hidden group-hover:block z-50">
            <div className="rounded-lg bg-gray-900 px-2 py-1 text-xs text-white shadow-lg">
              {item.description}
              <div className="absolute left-0 top-1/2 -ml-1 h-2 w-2 -translate-y-1/2 rotate-45 bg-gray-900"></div>
            </div>
          </div>
        )}
      </Link>
    )
  }

  if (isMobile) {
    return (
      <nav className="space-y-1 px-2 pb-3">
        {navigationItems.map((item, index) => (
          <NavItem key={item.href} item={item} index={index} />
        ))}
      </nav>
    )
  }

  return (
    <nav className="flex-1 space-y-1 px-2 py-4">
      {/* Main Navigation */}
      <div className="space-y-1">
        {navigationItems.map((item, index) => (
          <NavItem key={item.href} item={item} index={index} />
        ))}
      </div>

      {/* MCP Quick Actions (if user is signed in) */}
      {session && (
        <div className="pt-6">
          <div className="px-3 py-2">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
              Quick Actions
            </h3>
          </div>
          <div className="space-y-1">
            <Link
              href="/mcp-marketplace?action=chat"
              className="group flex items-center space-x-3 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-200"
            >
              <Zap className="h-4 w-4 text-yellow-500" />
              <span>Ask MCP Assistant</span>
            </Link>
            
            <Link
              href="/mcp-marketplace?view=installed"
              className="group flex items-center space-x-3 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-200"
            >
              <Settings className="h-4 w-4 text-gray-400" />
              <span>Manage MCPs</span>
            </Link>
          </div>
        </div>
      )}
      
      {/* User Status Indicator */}
      {session && (
        <div className="pt-6">
          <div className="px-3 py-2">
            <div className="flex items-center space-x-2">
              <div className="h-2 w-2 rounded-full bg-green-400"></div>
              <span className="text-xs text-gray-500 dark:text-gray-400">
                MCP System Active
              </span>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}

export default Navigation
