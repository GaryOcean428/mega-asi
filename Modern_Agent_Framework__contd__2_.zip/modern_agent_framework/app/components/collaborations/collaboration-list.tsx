
'use client'

import { useState, useEffect } from 'react'
import { CollaborationCard } from './collaboration-card'
import { LoadingSpinner } from '@/components/ui/loading-spinner'
import { motion } from 'framer-motion'

interface CollaborationListProps {
  refreshKey: number
  onRefresh: () => void
}

interface CollaborationWithAgents {
  id: string
  name: string
  description?: string
  type: string
  status: string
  currentStep: number
  totalSteps?: number
  result?: string
  createdAt: Date
  updatedAt: Date
  agents: Array<{
    id: string
    name: string
    role: string
    status: string
  }>
}

export function CollaborationList({ refreshKey, onRefresh }: CollaborationListProps) {
  const [collaborations, setCollaborations] = useState<CollaborationWithAgents[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchCollaborations = async () => {
    try {
      setError(null)
      const response = await fetch('/api/collaborations')
      
      if (!response.ok) {
        throw new Error('Failed to fetch collaborations')
      }
      
      const data = await response.json()
      setCollaborations(data.collaborations || [])
    } catch (error) {
      console.error('Error fetching collaborations:', error)
      setError(error instanceof Error ? error.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchCollaborations()
  }, [refreshKey])

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <div className="text-red-500 mb-4">Error loading collaborations: {error}</div>
        <button 
          onClick={fetchCollaborations}
          className="text-blue-500 hover:text-blue-400 underline"
        >
          Try again
        </button>
      </div>
    )
  }

  if (collaborations.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 text-lg mb-2">No collaborations created yet</div>
        <div className="text-gray-500 text-sm">
          Create collaborations to coordinate multiple agents working together.
        </div>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {collaborations.map((collaboration, index) => (
        <motion.div
          key={collaboration.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <CollaborationCard 
            collaboration={collaboration} 
            onUpdate={onRefresh}
          />
        </motion.div>
      ))}
    </div>
  )
}
