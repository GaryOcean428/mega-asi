
'use client'

import { useState, useEffect } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { X, Users, ArrowRight, Network } from 'lucide-react'
import { AgentWithRelations, CollaborationType } from '@/lib/types'

interface CreateCollaborationDialogProps {
  open: boolean
  onClose: () => void
  onSuccess: () => void
}

interface FormData {
  name: string
  description: string
  type: CollaborationType
  agentIds: string[]
  totalSteps?: number
}

export function CreateCollaborationDialog({ open, onClose, onSuccess }: CreateCollaborationDialogProps) {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    description: '',
    type: CollaborationType.SEQUENTIAL,
    agentIds: []
  })
  const [agents, setAgents] = useState<AgentWithRelations[]>([])
  const [loading, setLoading] = useState(false)

  const fetchAgents = async () => {
    try {
      const response = await fetch('/api/agents')
      const data = await response.json()
      setAgents(data.agents || [])
    } catch (error) {
      console.error('Error fetching agents:', error)
    }
  }

  useEffect(() => {
    if (open) {
      fetchAgents()
    }
  }, [open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name || formData.agentIds.length < 2) {
      return
    }

    setLoading(true)
    try {
      const response = await fetch('/api/collaborations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        onSuccess()
        handleClose()
      } else {
        console.error('Failed to create collaboration')
      }
    } catch (error) {
      console.error('Error creating collaboration:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setFormData({
      name: '',
      description: '',
      type: CollaborationType.SEQUENTIAL,
      agentIds: []
    })
    onClose()
  }

  const handleAgentToggle = (agentId: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      agentIds: checked 
        ? [...prev.agentIds, agentId]
        : prev.agentIds.filter(id => id !== agentId)
    }))
  }

  const removeAgent = (agentId: string) => {
    setFormData(prev => ({
      ...prev,
      agentIds: prev.agentIds.filter(id => id !== agentId)
    }))
  }

  const getTypeIcon = (type: CollaborationType) => {
    switch (type) {
      case CollaborationType.SEQUENTIAL: return ArrowRight
      case CollaborationType.PARALLEL: return Network
      case CollaborationType.HIERARCHICAL: return Users
    }
  }

  const getTypeDescription = (type: CollaborationType) => {
    switch (type) {
      case CollaborationType.SEQUENTIAL:
        return 'Agents work one after another, each building on the previous output'
      case CollaborationType.PARALLEL:
        return 'All agents work simultaneously on the same task'
      case CollaborationType.HIERARCHICAL:
        return 'Agents are organized in a hierarchy with coordinators and executors'
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl bg-gray-900 border-gray-700 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl text-white">Create New Collaboration</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-gray-300">Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter collaboration name"
              className="bg-gray-800 border-gray-600 text-white"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-300">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Describe the collaborative task..."
              className="bg-gray-800 border-gray-600 text-white resize-none"
              rows={3}
            />
          </div>

          <div className="space-y-3">
            <Label className="text-gray-300">Collaboration Type</Label>
            <div className="grid grid-cols-1 gap-3">
              {Object.values(CollaborationType).map((type) => {
                const Icon = getTypeIcon(type)
                return (
                  <div
                    key={type}
                    className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                      formData.type === type
                        ? 'border-purple-500 bg-purple-500/10'
                        : 'border-gray-600 bg-gray-800/30 hover:bg-gray-800/50'
                    }`}
                    onClick={() => setFormData(prev => ({ ...prev, type }))}
                  >
                    <div className="flex items-start space-x-3">
                      <Icon className={`h-5 w-5 mt-1 ${
                        formData.type === type ? 'text-purple-400' : 'text-gray-400'
                      }`} />
                      <div className="flex-1">
                        <div className={`font-medium ${
                          formData.type === type ? 'text-purple-400' : 'text-white'
                        }`}>
                          {type.charAt(0).toUpperCase() + type.slice(1).toLowerCase()}
                        </div>
                        <p className="text-sm text-gray-400 mt-1">
                          {getTypeDescription(type)}
                        </p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {formData.type === CollaborationType.SEQUENTIAL && (
            <div className="space-y-2">
              <Label htmlFor="totalSteps" className="text-gray-300">Expected Steps (Optional)</Label>
              <Input
                id="totalSteps"
                type="number"
                value={formData.totalSteps || ''}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  totalSteps: e.target.value ? parseInt(e.target.value) : undefined 
                }))}
                placeholder="Number of expected steps"
                className="bg-gray-800 border-gray-600 text-white"
                min="1"
              />
            </div>
          )}

          <div className="space-y-3">
            <Label className="text-gray-300">Select Agents * (minimum 2)</Label>
            
            {/* Selected agents */}
            {formData.agentIds.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {formData.agentIds.map(agentId => {
                  const agent = agents.find(a => a.id === agentId)
                  return agent ? (
                    <Badge
                      key={agentId}
                      variant="outline"
                      className="bg-purple-500/10 text-purple-400 border-purple-500/20"
                    >
                      {agent.name} ({agent.role})
                      <button
                        type="button"
                        onClick={() => removeAgent(agentId)}
                        className="ml-1 hover:text-red-400"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ) : null
                })}
              </div>
            )}

            {/* Agent selection list */}
            <div className="max-h-48 overflow-y-auto bg-gray-800/30 rounded-lg border border-gray-700">
              {agents.map(agent => (
                <div key={agent.id} className="flex items-center space-x-3 p-3 border-b border-gray-700 last:border-b-0">
                  <Checkbox
                    checked={formData.agentIds.includes(agent.id)}
                    onCheckedChange={(checked) => handleAgentToggle(agent.id, !!checked)}
                    className="border-gray-600"
                  />
                  <div className="flex-1">
                    <div className="text-white font-medium">{agent.name}</div>
                    <div className="text-sm text-gray-400 capitalize">{agent.role}</div>
                  </div>
                  <Badge variant="outline" className="bg-gray-700/50 text-gray-300 border-gray-600 text-xs">
                    {agent.status}
                  </Badge>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
              className="bg-gray-800 border-gray-600 text-gray-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading || !formData.name || formData.agentIds.length < 2}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {loading ? 'Creating...' : 'Create Collaboration'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
