
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import { 
  Users, 
  Play, 
  Pause, 
  CheckCircle, 
  Clock,
  AlertCircle,
  Settings,
  ArrowRight,
  Network
} from 'lucide-react'
import { CollaborationExecutionDialog } from './collaboration-execution-dialog'

interface CollaborationCardProps {
  collaboration: {
    id: string
    name: string
    description?: string
    type: string
    status: string
    currentStep: number
    totalSteps?: number
    result?: string
    createdAt: Date
    updatedAt: Date
    agents: Array<{
      id: string
      name: string
      role: string
      status: string
    }>
  }
  onUpdate: () => void
}

export function CollaborationCard({ collaboration, onUpdate }: CollaborationCardProps) {
  const [showExecution, setShowExecution] = useState(false)

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active': return 'bg-blue-500/10 text-blue-400 border-blue-500/20'
      case 'completed': return 'bg-green-500/10 text-green-400 border-green-500/20'
      case 'paused': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'failed': return 'bg-red-500/10 text-red-400 border-red-500/20'
      default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active': return Play
      case 'completed': return CheckCircle
      case 'paused': return Pause
      case 'failed': return AlertCircle
      default: return Clock
    }
  }

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'sequential': return 'text-blue-400'
      case 'parallel': return 'text-green-400'
      case 'hierarchical': return 'text-purple-400'
      default: return 'text-gray-400'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'sequential': return ArrowRight
      case 'parallel': return Network
      case 'hierarchical': return Users
      default: return Users
    }
  }

  const StatusIcon = getStatusIcon(collaboration.status)
  const TypeIcon = getTypeIcon(collaboration.type)
  
  const progress = collaboration.totalSteps ? 
    (collaboration.currentStep / collaboration.totalSteps) * 100 : 0

  return (
    <>
      <Card className="bg-gray-900/30 border-gray-800 hover:bg-gray-800/30 transition-all duration-200 hover:shadow-lg">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <TypeIcon className={`h-5 w-5 ${getTypeColor(collaboration.type)}`} />
              </div>
              <div>
                <CardTitle className="text-lg text-white">
                  {collaboration.name}
                </CardTitle>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge 
                    variant="outline" 
                    className={`${getTypeColor(collaboration.type)} border-current/20 text-xs`}
                  >
                    {collaboration.type}
                  </Badge>
                  <Badge variant="outline" className={getStatusColor(collaboration.status)}>
                    <StatusIcon className="h-3 w-3 mr-1" />
                    {collaboration.status}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
          
          {collaboration.description && (
            <p className="text-sm text-gray-400 mt-2 line-clamp-2">
              {collaboration.description}
            </p>
          )}
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Progress */}
          {collaboration.totalSteps && collaboration.totalSteps > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400">Progress</span>
                <span className="text-white">
                  {collaboration.currentStep}/{collaboration.totalSteps}
                </span>
              </div>
              <Progress value={progress} className="h-2 bg-gray-700">
                <div 
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                />
              </Progress>
            </div>
          )}

          {/* Participating Agents */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Participating Agents</span>
              <span className="text-sm text-white">{collaboration.agents.length}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              {collaboration.agents.slice(0, 4).map((agent) => (
                <div 
                  key={agent.id} 
                  className="flex items-center space-x-1 cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => console.log(`Agent ${agent.name} clicked`)}
                  title={`View ${agent.name} details`}
                >
                  <Avatar className="h-8 w-8 bg-gray-700 border border-gray-600">
                    <AvatarFallback className="text-xs text-gray-300 bg-transparent">
                      {agent.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-gray-400 hidden md:block">
                    {agent.name}
                  </span>
                </div>
              ))}
              
              {collaboration.agents.length > 4 && (
                <div className="text-xs text-gray-500">
                  +{collaboration.agents.length - 4} more
                </div>
              )}
            </div>
          </div>

          {/* Result Preview */}
          {collaboration.result && (
            <div className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-sm text-gray-400 mb-1">Result:</div>
              <p className="text-sm text-gray-300 line-clamp-2">
                {collaboration.result}
              </p>
            </div>
          )}

          {/* Timestamps */}
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>Created: {new Date(collaboration.createdAt).toLocaleDateString()}</span>
            <span>Updated: {new Date(collaboration.updatedAt).toLocaleDateString()}</span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 pt-2 border-t border-gray-700">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowExecution(true)}
              disabled={collaboration.status === 'ACTIVE'}
              className="flex-1 bg-purple-500/10 border-purple-500/20 text-purple-400 hover:bg-purple-500/20"
            >
              <Play className="h-3 w-3 mr-1" />
              Execute
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-400 hover:text-white"
            >
              <Settings className="h-3 w-3" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <CollaborationExecutionDialog
        open={showExecution}
        onClose={() => setShowExecution(false)}
        collaboration={collaboration}
        onSuccess={onUpdate}
      />
    </>
  )
}
