
'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'
import { 
  Play, 
  Loader2,
  CheckCircle,
  Users
} from 'lucide-react'

interface CollaborationExecutionDialogProps {
  open: boolean
  onClose: () => void
  collaboration: {
    id: string
    name: string
    type: string
    agents: Array<{
      id: string
      name: string
      role: string
    }>
  }
  onSuccess: () => void
}

interface StreamResponse {
  status: 'processing' | 'completed' | 'error'
  message?: string
  chunk?: string
  currentAgent?: string
  step?: number
  totalSteps?: number
  result?: any
}

export function CollaborationExecutionDialog({ 
  open, 
  onClose, 
  collaboration, 
  onSuccess 
}: CollaborationExecutionDialogProps) {
  const [taskInput, setTaskInput] = useState('')
  const [executing, setExecuting] = useState(false)
  const [output, setOutput] = useState('')
  const [progress, setProgress] = useState(0)
  const [currentAgent, setCurrentAgent] = useState('')
  const [executionResult, setExecutionResult] = useState<any>(null)

  const handleExecute = async () => {
    if (!taskInput.trim()) {
      return
    }

    setExecuting(true)
    setOutput('')
    setProgress(0)
    setCurrentAgent('')
    setExecutionResult(null)

    try {
      const response = await fetch(`/api/collaborations/${collaboration.id}/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          task: {
            title: `Collaboration Task: ${collaboration.name}`,
            description: taskInput
          },
          stream: true
        })
      })

      if (!response.ok) {
        throw new Error('Failed to execute collaboration')
      }

      const reader = response.body?.getReader()
      if (!reader) {
        throw new Error('No response stream')
      }

      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6)
            if (data === '[DONE]') {
              setExecuting(false)
              return
            }

            try {
              const parsed: StreamResponse = JSON.parse(data)
              
              if (parsed.status === 'processing') {
                if (parsed.currentAgent) {
                  setCurrentAgent(parsed.currentAgent)
                }
                
                if (parsed.step && parsed.totalSteps) {
                  setProgress((parsed.step / parsed.totalSteps) * 100)
                }
                
                if (parsed.chunk) {
                  setOutput(prev => prev + parsed.chunk)
                } else if (parsed.message) {
                  setOutput(prev => prev + parsed.message + '\n')
                }
              } else if (parsed.status === 'completed' && parsed.result) {
                setExecutionResult(parsed.result)
                setProgress(100)
                setExecuting(false)
                onSuccess()
                return
              } else if (parsed.status === 'error') {
                console.error('Collaboration execution error:', parsed.message)
                setExecuting(false)
                return
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Collaboration execution error:', error)
      setExecuting(false)
    }
  }

  const handleClose = () => {
    if (executing) {
      return
    }
    
    setTaskInput('')
    setOutput('')
    setProgress(0)
    setCurrentAgent('')
    setExecutionResult(null)
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl bg-gray-900 border-gray-700 max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="text-xl text-white flex items-center space-x-2">
            <Users className="h-5 w-5 text-purple-400" />
            <span>Execute Collaboration: {collaboration.name}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Collaboration Info */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-semibold text-white">Collaboration Details</h3>
              <span className="text-sm text-gray-400 capitalize">
                {collaboration.type} Mode
              </span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-400">Agents:</span>
                <span className="text-white ml-2">{collaboration.agents.length}</span>
              </div>
              <div>
                <span className="text-gray-400">Type:</span>
                <span className="text-white ml-2 capitalize">{collaboration.type}</span>
              </div>
            </div>
            <div className="mt-3">
              <span className="text-gray-400 text-sm">Participating Agents:</span>
              <div className="flex flex-wrap gap-2 mt-1">
                {collaboration.agents.map(agent => (
                  <span 
                    key={agent.id} 
                    className="text-xs bg-purple-500/10 text-purple-400 px-2 py-1 rounded border border-purple-500/20"
                  >
                    {agent.name} ({agent.role})
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Task Input */}
          <div className="space-y-3">
            <Label className="text-gray-300">Task Description *</Label>
            <Textarea
              value={taskInput}
              onChange={(e) => setTaskInput(e.target.value)}
              placeholder="Describe the task for the agents to collaborate on..."
              className="bg-gray-800 border-gray-600 text-white resize-none"
              rows={4}
            />
          </div>

          {/* Progress */}
          {executing && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-gray-300">Collaboration Progress</Label>
                <span className="text-sm text-gray-400">
                  {currentAgent && `Current: ${currentAgent}`}
                </span>
              </div>
              <Progress value={progress} className="h-2 bg-gray-700">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                />
              </Progress>
            </div>
          )}

          {/* Execution Output */}
          {(output || executionResult) && (
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Label className="text-gray-300">Collaboration Output</Label>
                {executing && <Loader2 className="h-4 w-4 animate-spin text-purple-400" />}
                {executionResult && <CheckCircle className="h-4 w-4 text-green-400" />}
              </div>
              <ScrollArea className="h-64 bg-gray-800 border border-gray-600 rounded-lg">
                <div className="p-4">
                  <pre className="text-gray-300 text-sm whitespace-pre-wrap font-mono">
                    {output}
                  </pre>
                  {executionResult && (
                    <div className="mt-4 pt-4 border-t border-gray-600">
                      <div className="text-green-400 text-sm font-semibold mb-2">
                        ✓ Collaboration Completed
                      </div>
                      {executionResult.collaborationResult && (
                        <div className="text-gray-300 text-sm whitespace-pre-wrap">
                          {executionResult.collaborationResult}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={executing}
              className="bg-gray-800 border-gray-600 text-gray-300"
            >
              {executing ? 'Executing...' : 'Close'}
            </Button>
            
            <Button
              onClick={handleExecute}
              disabled={executing || !taskInput.trim()}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {executing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Executing
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Start Collaboration
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
