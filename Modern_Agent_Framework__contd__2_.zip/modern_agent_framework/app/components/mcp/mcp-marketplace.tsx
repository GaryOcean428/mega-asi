
// Stub file to prevent import errors
function MCPMarketplace() {
  return <div>MCP Marketplace - Under Development</div>
}

export { MCPMarketplace }
export default MCPMarketplace
