
// Stub file to prevent import errors
function MCPManagementDashboard() {
  return <div>MCP Management Dashboard - Under Development</div>
}

export { MCPManagementDashboard }
export default MCPManagementDashboard
