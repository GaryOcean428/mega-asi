
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Bot, 
  Lightbulb, 
  Users, 
  Zap, 
  BarChart3,
  FileText,
  Code,
  Search,
  Play,
  Clock,
  CheckCircle,
  ArrowRight,
  Sparkles
} from 'lucide-react'

interface DemoScenario {
  id: string
  title: string
  category: 'data' | 'research' | 'content' | 'development' | 'automation'
  description: string
  userPrompt: string
  expectedFlow: Array<{
    step: string
    description: string
    type: 'intent' | 'suggestion' | 'creation' | 'result'
    icon?: React.ReactNode
  }>
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  timeEstimate: string
  tags: string[]
}

export function DemoScenarios() {
  const [selectedScenario, setSelectedScenario] = useState<DemoScenario | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentFlowStep, setCurrentFlowStep] = useState(0)

  const scenarios: DemoScenario[] = [
    {
      id: 'data-analysis',
      title: 'Data Analysis Powerhouse',
      category: 'data',
      description: 'Create a complete data analysis workflow with visualization and reporting capabilities',
      userPrompt: 'I need to analyze our quarterly sales data and create insights with charts and graphs',
      expectedFlow: [
        {
          step: 'Intent Recognition',
          description: 'AI detects data analysis intent with high confidence (95%)',
          type: 'intent',
          icon: <Bot className="h-4 w-4 text-blue-400" />
        },
        {
          step: 'Smart Suggestions',
          description: 'Recommends Data Analyst agent template and visualization MCPs',
          type: 'suggestion',
          icon: <Lightbulb className="h-4 w-4 text-yellow-400" />
        },
        {
          step: 'Agent Creation',
          description: 'Creates "Sales Analyst" with pandas, matplotlib, and statistical capabilities',
          type: 'creation',
          icon: <Bot className="h-4 w-4 text-green-400" />
        },
        {
          step: 'Tool Installation',
          description: 'Auto-installs Data Processing MCP and Visualization MCP',
          type: 'creation',
          icon: <Zap className="h-4 w-4 text-purple-400" />
        },
        {
          step: 'Ready to Use',
          description: 'Agent ready with full data analysis and visualization stack',
          type: 'result',
          icon: <CheckCircle className="h-4 w-4 text-green-400" />
        }
      ],
      difficulty: 'beginner',
      timeEstimate: '2 minutes',
      tags: ['data', 'analytics', 'visualization', 'reporting']
    },
    {
      id: 'research-team',
      title: 'Research Collaboration Hub',
      category: 'research',
      description: 'Set up a multi-agent research team for comprehensive market analysis',
      userPrompt: 'Set up a research team to analyze the AI market landscape and competitor strategies',
      expectedFlow: [
        {
          step: 'Multi-Agent Intent',
          description: 'Recognizes collaboration setup with research focus',
          type: 'intent',
          icon: <Users className="h-4 w-4 text-purple-400" />
        },
        {
          step: 'Team Template',
          description: 'Suggests Research Pipeline collaboration template',
          type: 'suggestion',
          icon: <Lightbulb className="h-4 w-4 text-yellow-400" />
        },
        {
          step: 'Agent Assembly',
          description: 'Creates Research Agent, Analysis Agent, and Report Agent',
          type: 'creation',
          icon: <Users className="h-4 w-4 text-blue-400" />
        },
        {
          step: 'Workflow Setup',
          description: 'Configures sequential workflow: Research → Analysis → Report',
          type: 'creation',
          icon: <ArrowRight className="h-4 w-4 text-green-400" />
        },
        {
          step: 'Collaboration Active',
          description: 'Team ready with web search, data analysis, and writing capabilities',
          type: 'result',
          icon: <CheckCircle className="h-4 w-4 text-green-400" />
        }
      ],
      difficulty: 'intermediate',
      timeEstimate: '3 minutes',
      tags: ['research', 'collaboration', 'market-analysis', 'teams']
    },
    {
      id: 'content-pipeline',
      title: 'Content Creation Pipeline',
      category: 'content',
      description: 'Build an automated content creation and review workflow',
      userPrompt: 'Create a content creation workflow for our tech blog with research, writing, and review stages',
      expectedFlow: [
        {
          step: 'Workflow Intent',
          description: 'Identifies content pipeline automation need',
          type: 'intent',
          icon: <FileText className="h-4 w-4 text-green-400" />
        },
        {
          step: 'Pipeline Design',
          description: 'Recommends Content Pipeline with 3-stage workflow',
          type: 'suggestion',
          icon: <Sparkles className="h-4 w-4 text-yellow-400" />
        },
        {
          step: 'Content Agents',
          description: 'Sets up Researcher, Writer, and Editor agents',
          type: 'creation',
          icon: <Users className="h-4 w-4 text-purple-400" />
        },
        {
          step: 'Tool Integration',
          description: 'Installs SEO optimization and grammar checking tools',
          type: 'creation',
          icon: <Zap className="h-4 w-4 text-blue-400" />
        },
        {
          step: 'Pipeline Ready',
          description: 'Automated content workflow from idea to publication',
          type: 'result',
          icon: <CheckCircle className="h-4 w-4 text-green-400" />
        }
      ],
      difficulty: 'intermediate',
      timeEstimate: '4 minutes',
      tags: ['content', 'writing', 'automation', 'seo']
    },
    {
      id: 'dev-assistant',
      title: 'Development Assistant Suite',
      category: 'development',
      description: 'Create a comprehensive development helper with code review and testing',
      userPrompt: 'I need help with code reviews, automated testing, and debugging assistance',
      expectedFlow: [
        {
          step: 'Dev Intent Analysis',
          description: 'Recognizes multi-faceted development assistance need',
          type: 'intent',
          icon: <Code className="h-4 w-4 text-blue-400" />
        },
        {
          step: 'Development Suite',
          description: 'Suggests Code Assistant with enhanced capabilities',
          type: 'suggestion',
          icon: <Lightbulb className="h-4 w-4 text-yellow-400" />
        },
        {
          step: 'Code Agent Setup',
          description: 'Creates specialized Code Review and Testing agents',
          type: 'creation',
          icon: <Bot className="h-4 w-4 text-purple-400" />
        },
        {
          step: 'DevTools Integration',
          description: 'Installs code execution, git integration, and testing MCPs',
          type: 'creation',
          icon: <Zap className="h-4 w-4 text-green-400" />
        },
        {
          step: 'Dev Environment Ready',
          description: 'Complete development assistant with review, test, and debug capabilities',
          type: 'result',
          icon: <CheckCircle className="h-4 w-4 text-green-400" />
        }
      ],
      difficulty: 'advanced',
      timeEstimate: '5 minutes',
      tags: ['development', 'testing', 'code-review', 'debugging']
    },
    {
      id: 'automation-workflow',
      title: 'Smart Automation Hub',
      category: 'automation',
      description: 'Set up intelligent automation for recurring business processes',
      userPrompt: 'Automate our daily reporting process with data collection, analysis, and distribution',
      expectedFlow: [
        {
          step: 'Automation Mapping',
          description: 'Maps complex automation workflow requirements',
          type: 'intent',
          icon: <BarChart3 className="h-4 w-4 text-green-400" />
        },
        {
          step: 'Process Architecture',
          description: 'Designs end-to-end automation with scheduling',
          type: 'suggestion',
          icon: <Sparkles className="h-4 w-4 text-yellow-400" />
        },
        {
          step: 'Automation Agents',
          description: 'Creates Data Collector, Analyst, and Distribution agents',
          type: 'creation',
          icon: <Users className="h-4 w-4 text-purple-400" />
        },
        {
          step: 'Schedule Integration',
          description: 'Sets up daily triggers and automated handoffs',
          type: 'creation',
          icon: <Clock className="h-4 w-4 text-blue-400" />
        },
        {
          step: 'Automation Live',
          description: 'Fully automated daily reporting with minimal human intervention',
          type: 'result',
          icon: <CheckCircle className="h-4 w-4 text-green-400" />
        }
      ],
      difficulty: 'advanced',
      timeEstimate: '6 minutes',
      tags: ['automation', 'scheduling', 'reporting', 'workflows']
    }
  ]

  const playScenario = async (scenario: DemoScenario) => {
    setSelectedScenario(scenario)
    setIsPlaying(true)
    setCurrentFlowStep(0)

    // Simulate the flow progression
    for (let i = 0; i < scenario.expectedFlow.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1500))
      setCurrentFlowStep(i)
    }

    setTimeout(() => {
      setIsPlaying(false)
    }, 2000)
  }

  const getCategoryIcon = (category: string) => {
    const icons = {
      data: <BarChart3 className="h-5 w-5" />,
      research: <Search className="h-5 w-5" />,
      content: <FileText className="h-5 w-5" />,
      development: <Code className="h-5 w-5" />,
      automation: <Zap className="h-5 w-5" />
    }
    return icons[category as keyof typeof icons]
  }

  const getCategoryColor = (category: string) => {
    const colors = {
      data: 'text-blue-400 bg-blue-500/20 border-blue-500/30',
      research: 'text-green-400 bg-green-500/20 border-green-500/30',
      content: 'text-purple-400 bg-purple-500/20 border-purple-500/30',
      development: 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30',
      automation: 'text-red-400 bg-red-500/20 border-red-500/30'
    }
    return colors[category as keyof typeof colors]
  }

  const getDifficultyColor = (difficulty: string) => {
    const colors = {
      beginner: 'text-green-300 bg-green-500/20',
      intermediate: 'text-yellow-300 bg-yellow-500/20',
      advanced: 'text-red-300 bg-red-500/20'
    }
    return colors[difficulty as keyof typeof colors]
  }

  const categorizedScenarios = scenarios.reduce((acc, scenario) => {
    if (!acc[scenario.category]) acc[scenario.category] = []
    acc[scenario.category].push(scenario)
    return acc
  }, {} as Record<string, DemoScenario[]>)

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-3">Interactive Demo Scenarios</h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          See how natural conversation creates powerful AI workflows. Click any scenario to watch the magic happen.
        </p>
      </div>

      <Tabs value="all" onValueChange={() => {}} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6 bg-gray-800/50">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="data">Data</TabsTrigger>
          <TabsTrigger value="research">Research</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="development">Dev</TabsTrigger>
          <TabsTrigger value="automation">Auto</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {scenarios.map((scenario) => (
              <ScenarioCard
                key={scenario.id}
                scenario={scenario}
                onPlay={() => playScenario(scenario)}
                isPlaying={isPlaying && selectedScenario?.id === scenario.id}
                getCategoryIcon={getCategoryIcon}
                getCategoryColor={getCategoryColor}
                getDifficultyColor={getDifficultyColor}
              />
            ))}
          </div>
        </TabsContent>

        {Object.entries(categorizedScenarios).map(([category, categoryScenarios]) => (
          <TabsContent key={category} value={category} className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {categoryScenarios.map((scenario) => (
                <ScenarioCard
                  key={scenario.id}
                  scenario={scenario}
                  onPlay={() => playScenario(scenario)}
                  isPlaying={isPlaying && selectedScenario?.id === scenario.id}
                  getCategoryIcon={getCategoryIcon}
                  getCategoryColor={getCategoryColor}
                  getDifficultyColor={getDifficultyColor}
                />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Flow Visualization */}
      {selectedScenario && isPlaying && (
        <Card className="bg-gray-900/80 border-purple-500/30 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Play className="h-5 w-5 text-purple-400" />
              <span>Live Demo: {selectedScenario.title}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-black/40 rounded-lg p-4 border border-gray-700">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-semibold">You</span>
                  </div>
                  <div className="bg-blue-600/20 rounded-lg px-4 py-2 flex-1">
                    <p className="text-blue-200 text-sm">"{selectedScenario.userPrompt}"</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                {selectedScenario.expectedFlow.map((flow, index) => (
                  <div
                    key={index}
                    className={`flex items-center space-x-3 transition-all duration-500 ${
                      index <= currentFlowStep
                        ? 'opacity-100 scale-100'
                        : 'opacity-30 scale-95'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      index <= currentFlowStep ? 'bg-purple-500' : 'bg-gray-600'
                    }`}>
                      {index <= currentFlowStep ? (
                        flow.icon || <CheckCircle className="h-4 w-4 text-white" />
                      ) : (
                        <span className="text-xs text-gray-400">{index + 1}</span>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-white text-sm">{flow.step}</div>
                      <div className="text-gray-300 text-xs">{flow.description}</div>
                    </div>
                    {index <= currentFlowStep && (
                      <CheckCircle className="h-5 w-5 text-green-400 animate-pulse" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function ScenarioCard({ 
  scenario, 
  onPlay, 
  isPlaying, 
  getCategoryIcon, 
  getCategoryColor, 
  getDifficultyColor 
}: {
  scenario: DemoScenario
  onPlay: () => void
  isPlaying: boolean
  getCategoryIcon: (category: string) => React.ReactNode
  getCategoryColor: (category: string) => string
  getDifficultyColor: (difficulty: string) => string
}) {
  return (
    <Card className={`transition-all duration-300 hover:scale-105 cursor-pointer ${
      isPlaying ? 'border-purple-500/50 bg-purple-500/10' : 'hover:border-gray-600'
    }`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className={`p-2 rounded-lg border ${getCategoryColor(scenario.category)}`}>
            {getCategoryIcon(scenario.category)}
          </div>
          <div className="flex space-x-2">
            <Badge className={getDifficultyColor(scenario.difficulty)}>
              {scenario.difficulty}
            </Badge>
            <Badge variant="outline" className="text-xs">
              <Clock className="h-3 w-3 mr-1" />
              {scenario.timeEstimate}
            </Badge>
          </div>
        </div>
        <CardTitle className="text-lg text-white">{scenario.title}</CardTitle>
        <p className="text-sm text-gray-300">{scenario.description}</p>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="bg-gray-800/50 rounded-lg p-3">
            <p className="text-xs text-gray-400 mb-1">You would say:</p>
            <p className="text-sm text-gray-200 italic">"{scenario.userPrompt}"</p>
          </div>
          
          <div className="flex flex-wrap gap-1">
            {scenario.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
          
          <Button 
            onClick={onPlay} 
            disabled={isPlaying}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {isPlaying ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Playing Demo...
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Play Demo
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
