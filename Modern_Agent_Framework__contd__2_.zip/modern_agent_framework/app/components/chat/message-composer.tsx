
'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useTypingIndicator } from '@/lib/websocket/client'
import { 
  Send, 
  Paperclip, 
  Smile, 
  AtSign, 
  Code,
  Mic,
  Square
} from 'lucide-react'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface MessageComposerProps {
  onSendMessage: (content: any, options?: { threadId?: string, replyToId?: string }) => void
  disabled?: boolean
  placeholder?: string
  roomId: string
  threadId?: string
  replyToId?: string
  className?: string
}

export function MessageComposer({
  onSendMessage,
  disabled = false,
  placeholder = "Type a message...",
  roomId,
  threadId,
  replyToId,
  className
}: MessageComposerProps) {
  const [message, setMessage] = useState('')
  const [isCodeMode, setIsCodeMode] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [mentionQuery, setMentionQuery] = useState('')
  const [showMentions, setShowMentions] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  
  const { startTyping, stopTyping } = useTypingIndicator(roomId, 1000)

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`
    }
  }, [message])

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value
    setMessage(value)
    
    if (value.trim()) {
      startTyping()
    } else {
      stopTyping()
    }

    // Handle @ mentions
    const lastAtIndex = value.lastIndexOf('@')
    const cursorPosition = e.target.selectionStart
    
    if (lastAtIndex !== -1 && lastAtIndex < cursorPosition) {
      const query = value.slice(lastAtIndex + 1, cursorPosition)
      if (query.length >= 0 && !query.includes(' ')) {
        setMentionQuery(query)
        setShowMentions(true)
      } else {
        setShowMentions(false)
      }
    } else {
      setShowMentions(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleSendMessage = () => {
    const trimmedMessage = message.trim()
    if (!trimmedMessage || disabled) return

    const content = isCodeMode 
      ? { type: 'code', code: trimmedMessage, language: 'auto' }
      : { type: 'text', text: trimmedMessage }

    onSendMessage(content, { threadId, replyToId })
    setMessage('')
    stopTyping()
    textareaRef.current?.focus()
  }

  const handleToggleCodeMode = () => {
    setIsCodeMode(!isCodeMode)
    textareaRef.current?.focus()
  }

  const handleVoiceRecording = () => {
    if (isRecording) {
      // Stop recording
      setIsRecording(false)
      // TODO: Process voice recording
    } else {
      // Start recording
      setIsRecording(true)
      // TODO: Start voice recording
    }
  }

  return (
    <TooltipProvider>
      <Card className={`p-3 ${className}`}>
        {/* Mode indicator */}
        {isCodeMode && (
          <div className="mb-2">
            <Badge variant="outline" className="text-xs">
              <Code className="h-3 w-3 mr-1" />
              Code Mode
            </Badge>
          </div>
        )}

        <div className="flex gap-2">
          {/* Message input */}
          <div className="flex-1">
            <Textarea
              ref={textareaRef}
              value={message}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder={placeholder}
              disabled={disabled}
              className={`min-h-[40px] resize-none ${isCodeMode ? 'font-mono text-sm' : ''}`}
              rows={1}
            />
            
            {/* Mentions dropdown */}
            {showMentions && (
              <Card className="absolute mt-1 p-2 border shadow-md z-10 max-w-xs">
                <p className="text-xs text-muted-foreground">
                  Type to search agents and users...
                </p>
                {/* TODO: Implement actual mention suggestions */}
              </Card>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex flex-col gap-1">
            <div className="flex gap-1">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="sm"
                    variant={isCodeMode ? "default" : "ghost"}
                    onClick={handleToggleCodeMode}
                    className="h-8 w-8 p-0"
                  >
                    <Code className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Code Mode</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 w-8 p-0"
                  >
                    <Paperclip className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Attach File</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 w-8 p-0"
                  >
                    <AtSign className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Mention Agent</p>
                </TooltipContent>
              </Tooltip>
            </div>

            <div className="flex gap-1">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="sm"
                    variant={isRecording ? "destructive" : "ghost"}
                    onClick={handleVoiceRecording}
                    className="h-8 w-8 p-0"
                  >
                    {isRecording ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isRecording ? 'Stop Recording' : 'Voice Message'}</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="sm"
                    onClick={handleSendMessage}
                    disabled={disabled || !message.trim()}
                    className="h-8 w-8 p-0"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Send Message</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>
        </div>
      </Card>
    </TooltipProvider>
  )
}
