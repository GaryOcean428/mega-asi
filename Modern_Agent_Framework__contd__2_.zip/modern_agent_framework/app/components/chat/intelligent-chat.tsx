
'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { MessageComposer } from './message-composer'
import { MessageThread } from './message-thread'
import { IntentSuggestionPanel } from './intent-suggestion-panel'
import { AgentCreationWizard } from './agent-creation-wizard'
// import { MCPIntegrationPanel } from './mcp-integration-panel' // Temporarily disabled
import { CollaborationBuilder } from './collaboration-builder'
import { useWebSocket } from '@/lib/websocket/client'
import { intentEngine, IntentAnalysis } from '@/lib/ai-orchestrator/intent-engine'
import { 
  Brain, 
  Sparkles, 
  Zap, 
  MessageSquare, 
  Settings,
  Bot,
  Users,
  Workflow,
  Lightbulb
} from 'lucide-react'

interface IntelligentChatMessage {
  id: string
  content: any
  role: 'user' | 'assistant' | 'agent' | 'system'
  timestamp: Date
  sender?: {
    id: string
    name: string
    type: 'user' | 'agent'
    avatar?: string
  }
  intentAnalysis?: IntentAnalysis
  attachments?: any[]
  agentActions?: any[]
}

interface IntelligentChatProps {
  workspaceId: string
  className?: string
}

export function IntelligentChat({ workspaceId, className }: IntelligentChatProps) {
  const { data: session } = useSession() || {}
  const [messages, setMessages] = useState<IntelligentChatMessage[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [currentIntent, setCurrentIntent] = useState<IntentAnalysis | null>(null)
  const [activeMode, setActiveMode] = useState<'chat' | 'agent_creation' | 'mcp_integration' | 'collaboration'>('chat')
  const [suggestions, setSuggestions] = useState<any>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { socket, state, sendMessage } = useWebSocket({
    autoConnect: true,
    workspaceId
  })

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSendMessage = async (content: any) => {
    const userMessage: IntelligentChatMessage = {
      id: `msg_${Date.now()}`,
      content,
      role: 'user',
      timestamp: new Date(),
      sender: {
        id: (session?.user as any)?.id || 'unknown',
        name: session?.user?.name || 'You',
        type: 'user',
        avatar: session?.user?.image || undefined
      }
    }

    setMessages(prev => [...prev, userMessage])
    
    // Analyze intent
    await analyzeMessageIntent(content.text || content, userMessage.id)
  }

  const analyzeMessageIntent = async (messageText: string, messageId: string) => {
    if (!messageText || typeof messageText !== 'string') return

    setIsAnalyzing(true)

    try {
      const context = {
        userId: (session?.user as any)?.id || '',
        workspaceId,
        conversationId: 'current',
        messageHistory: messages.slice(-5)
          .filter(m => m.role !== 'system')
          .map(m => ({
            role: m.role as 'user' | 'agent' | 'assistant',
            content: typeof m.content === 'string' ? m.content : m.content.text || '',
            timestamp: m.timestamp
          })),
        activeAgents: [],
        userExpertise: 'intermediate' as const
      }

      const analysis = await intentEngine.analyzeIntent(messageText, context)
      
      setCurrentIntent(analysis)
      
      // Update the message with intent analysis
      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, intentAnalysis: analysis } : msg
      ))

      // Generate suggestions if relevant intent detected
      if (analysis.intent !== 'general_chat' && analysis.confidence > 0.6) {
        await generateSuggestions(analysis)
        
        // Show contextual UI based on intent
        switch (analysis.intent) {
          case 'create_agent':
            setActiveMode('agent_creation')
            break
          case 'install_mcp':
            setActiveMode('mcp_integration')
            break
          case 'create_collaboration':
            setActiveMode('collaboration')
            break
          default:
            setActiveMode('chat')
        }
      }

      // Send AI assistant response
      if (analysis.confidence > 0.7) {
        const assistantResponse = generateAssistantResponse(analysis)
        const assistantMessage: IntelligentChatMessage = {
          id: `assistant_${Date.now()}`,
          content: { text: assistantResponse },
          role: 'assistant',
          timestamp: new Date(),
          sender: {
            id: 'ai_orchestrator',
            name: 'AI Orchestrator',
            type: 'agent'
          }
        }
        
        setTimeout(() => {
          setMessages(prev => [...prev, assistantMessage])
        }, 1000)
      }

    } catch (error) {
      console.error('Intent analysis failed:', error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const generateSuggestions = async (analysis: IntentAnalysis) => {
    try {
      const response = await fetch('/api/orchestrator/suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ analysis })
      })

      if (response.ok) {
        const suggestions = await response.json()
        setSuggestions(suggestions)
      }
    } catch (error) {
      console.error('Failed to generate suggestions:', error)
    }
  }

  const generateAssistantResponse = (analysis: IntentAnalysis): string => {
    const responses = {
      create_agent: `I can help you create an agent! Based on our conversation, I suggest ${analysis.entities.agentType ? `a ${analysis.entities.agentType} agent` : 'an agent'} with${analysis.entities.capabilities ? ` ${analysis.entities.capabilities.join(', ')} capabilities` : ' smart capabilities'}. Would you like me to set this up for you?`,
      install_mcp: `I notice you're interested in adding new capabilities. I can help you find and install the right MCP tools${analysis.entities.mcpName ? ` like ${analysis.entities.mcpName}` : ''}. Let me show you some recommendations.`,
      create_collaboration: `Setting up a multi-agent collaboration sounds great! I can help you design a workflow with multiple agents working together. What's the main goal you're trying to achieve?`,
      workflow_automation: `I can help you automate this process! Let me suggest some workflow patterns and agents that could handle this for you.`,
      help_request: `I'm here to help! Let me provide some guidance and suggest the best approach for your needs.`,
      general_chat: `I understand you're looking for assistance. How can I help you today?`
    }

    return responses[analysis.intent as keyof typeof responses] || `I understand you're looking for assistance. How can I help you today?`
  }

  const handleQuickAction = async (actionId: string, parameters?: any) => {
    switch (actionId) {
      case 'create_agent':
        setActiveMode('agent_creation')
        break
      case 'install_mcp':
        setActiveMode('mcp_integration')
        break
      case 'create_collaboration':
        setActiveMode('collaboration')
        break
      default:
        console.log('Quick action:', actionId, parameters)
    }
  }

  const renderActiveMode = () => {
    switch (activeMode) {
      case 'agent_creation':
        return (
          <AgentCreationWizard
            suggestions={suggestions?.agents || []}
            onComplete={(agent) => {
              setActiveMode('chat')
              const message: IntelligentChatMessage = {
                id: `system_${Date.now()}`,
                content: { text: `✅ Successfully created agent: ${agent.name}` },
                role: 'system',
                timestamp: new Date()
              }
              setMessages(prev => [...prev, message])
            }}
            onCancel={() => setActiveMode('chat')}
          />
        )
      
      case 'mcp_integration':
        return (
          <div className="p-8 text-center">
            <div className="text-gray-600 mb-4">
              MCP Integration temporarily disabled for authentication update
            </div>
            <Button onClick={() => setActiveMode('chat')} variant="outline">
              Back to Chat
            </Button>
          </div>
        )
      
      case 'collaboration':
        return (
          <CollaborationBuilder
            suggestions={suggestions?.collaborations || []}
            onComplete={(collaboration) => {
              setActiveMode('chat')
              const message: IntelligentChatMessage = {
                id: `system_${Date.now()}`,
                content: { text: `✅ Successfully created collaboration: ${collaboration.name}` },
                role: 'system',
                timestamp: new Date()
              }
              setMessages(prev => [...prev, message])
            }}
            onCancel={() => setActiveMode('chat')}
          />
        )
      
      default:
        return null
    }
  }

  return (
    <div className={`flex flex-col h-full bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-black/40 backdrop-blur">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Brain className="h-8 w-8 text-blue-400" />
            {isAnalyzing && (
              <div className="absolute -top-1 -right-1">
                <Sparkles className="h-4 w-4 text-yellow-400 animate-pulse" />
              </div>
            )}
          </div>
          <div>
            <h1 className="text-lg font-semibold text-white">Intelligent Chat Orchestrator</h1>
            <p className="text-sm text-gray-400">
              {currentIntent ? `Intent: ${currentIntent.intent} (${Math.round(currentIntent.confidence * 100)}% confidence)` : 'Chat naturally to create agents and automations'}
            </p>
          </div>
        </div>

        {/* Mode Indicators */}
        <div className="flex items-center space-x-2">
          {activeMode === 'agent_creation' && (
            <Badge variant="secondary" className="bg-blue-500/20 text-blue-300">
              <Bot className="h-3 w-3 mr-1" />
              Creating Agent
            </Badge>
          )}
          {activeMode === 'mcp_integration' && (
            <Badge variant="secondary" className="bg-green-500/20 text-green-300">
              <Zap className="h-3 w-3 mr-1" />
              Installing MCP
            </Badge>
          )}
          {activeMode === 'collaboration' && (
            <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">
              <Users className="h-3 w-3 mr-1" />
              Building Collaboration
            </Badge>
          )}
          {activeMode === 'chat' && (
            <Badge variant="secondary" className="bg-gray-500/20 text-gray-300">
              <MessageSquare className="h-3 w-3 mr-1" />
              Chat Mode
            </Badge>
          )}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col">
          {activeMode === 'chat' ? (
            <>
              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-center">
                    <div className="max-w-md">
                      <Brain className="h-16 w-16 text-blue-400 mx-auto mb-4 opacity-60" />
                      <h3 className="text-xl font-semibold text-white mb-2">Welcome to Intelligent Chat</h3>
                      <p className="text-gray-400 mb-6">
                        Start a conversation to create agents, install tools, or set up collaborations. 
                        I'll understand your intent and help you build what you need.
                      </p>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
                          <Bot className="h-5 w-5 text-blue-400 mb-2" />
                          <p className="text-blue-300 font-medium">Create Agents</p>
                          <p className="text-gray-400">"I need a data analyst agent"</p>
                        </div>
                        <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
                          <Zap className="h-5 w-5 text-green-400 mb-2" />
                          <p className="text-green-300 font-medium">Install Tools</p>
                          <p className="text-gray-400">"Add web search capability"</p>
                        </div>
                        <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-3">
                          <Users className="h-5 w-5 text-purple-400 mb-2" />
                          <p className="text-purple-300 font-medium">Collaborations</p>
                          <p className="text-gray-400">"Set up a research team"</p>
                        </div>
                        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
                          <Workflow className="h-5 w-5 text-yellow-400 mb-2" />
                          <p className="text-yellow-300 font-medium">Automate</p>
                          <p className="text-gray-400">"Automate my reports"</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <>
                    <MessageThread
                      messages={messages.map(msg => ({
                        id: msg.id,
                        content: msg.content,
                        senderUserId: msg.sender?.type === 'user' ? msg.sender.id : undefined,
                        senderAgentId: msg.sender?.type === 'agent' ? msg.sender.id : undefined,
                        senderType: msg.role === 'user' ? 'USER' : msg.role === 'agent' ? 'AGENT' : 'SYSTEM',
                        userSender: msg.sender?.type === 'user' ? {
                          id: msg.sender.id,
                          name: msg.sender.name,
                          email: msg.sender.name, // Using name as email fallback
                          image: msg.sender.avatar
                        } : undefined,
                        agentSender: msg.sender?.type === 'agent' ? {
                          id: msg.sender.id,
                          name: msg.sender.name,
                          description: null
                        } : undefined,
                        createdAt: msg.timestamp.toISOString()
                      }))}
                      onReply={() => {}}
                      onStartThread={() => {}}
                      currentUserId={(session?.user as any)?.id}
                    />
                    <div ref={messagesEndRef} />
                  </>
                )}
              </ScrollArea>

              <Separator />

              {/* Message Composer */}
              <div className="p-4">
                <MessageComposer
                  onSendMessage={handleSendMessage}
                  disabled={isAnalyzing}
                  placeholder={isAnalyzing ? "Analyzing your message..." : "Describe what you'd like to create or automate..."}
                  roomId="intelligent-chat"
                />
              </div>
            </>
          ) : (
            <div className="flex-1 p-4">
              {renderActiveMode()}
            </div>
          )}
        </div>

        {/* Intent Suggestions Panel */}
        {currentIntent && suggestions && activeMode === 'chat' && (
          <div className="w-80 border-l border-gray-800 bg-black/20 backdrop-blur">
            <IntentSuggestionPanel
              intent={currentIntent}
              suggestions={suggestions}
              onQuickAction={handleQuickAction}
              onDismiss={() => {
                setCurrentIntent(null)
                setSuggestions(null)
              }}
            />
          </div>
        )}
      </div>
    </div>
  )
}
