
'use client'

import { useEffect, useState, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { useWebSocket } from '@/lib/websocket/client'
import { MessageThread } from './message-thread'
import { MessageComposer } from './message-composer'
import { ChatSidebar } from './chat-sidebar'
import { AgentPresenceIndicator } from './agent-presence-indicator'
import { TypingIndicator } from './typing-indicator'
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable'

interface ChatRoomProps {
  roomId: string
  workspaceId: string
  className?: string
}

interface ChatMessage {
  id: string
  content: any
  senderUserId?: string
  senderAgentId?: string
  senderType: 'USER' | 'AGENT' | 'SYSTEM'
  userSender?: {
    id: string
    name?: string | null
    email: string
    image?: string | null
  }
  agentSender?: {
    id: string
    name: string
    description?: string | null
  }
  threadId?: string
  replyToId?: string
  createdAt: string
  editedAt?: string
}

export function ChatRoom({ roomId, workspaceId, className }: ChatRoomProps) {
  const { data: session } = useSession() || {}
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedThread, setSelectedThread] = useState<string | null>(null)
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set())
  const messagesEndRef = useRef<HTMLDivElement>(null)
  
  const { socket, state, joinChat, sendMessage, on, off } = useWebSocket({
    autoConnect: true,
    workspaceId
  })

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    if (state.connected && roomId) {
      joinChat(roomId)
      loadMessages()
    }
  }, [state.connected, roomId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // WebSocket event handlers
  useEffect(() => {
    if (!socket) return

    const handleNewMessage = (message: ChatMessage) => {
      setMessages(prev => {
        // Avoid duplicates
        const exists = prev.some(m => m.id === message.id)
        if (exists) return prev
        return [...prev, message]
      })
    }

    const handleUserTyping = (data: { userId: string, isTyping: boolean }) => {
      setTypingUsers(prev => {
        const newSet = new Set(prev)
        if (data.isTyping && data.userId !== (session?.user as any)?.id) {
          newSet.add(data.userId)
        } else {
          newSet.delete(data.userId)
        }
        return newSet
      })
    }

    const handleJoinedChat = (data: { roomId: string }) => {
      console.log('Joined chat room:', data.roomId)
    }

    const handleChatError = (error: { message: string }) => {
      setError(error.message)
    }

    // Subscribe to events
    const unsubscribeNewMessage = on('new_message', handleNewMessage)
    const unsubscribeTyping = on('user_typing', handleUserTyping)
    const unsubscribeJoined = on('joined_chat', handleJoinedChat)
    const unsubscribeError = on('chat_error', handleChatError)

    return () => {
      unsubscribeNewMessage?.()
      unsubscribeTyping?.()
      unsubscribeJoined?.()
      unsubscribeError?.()
    }
  }, [socket, session?.user?.id, on])

  const loadMessages = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/chat/rooms/${roomId}/messages`)
      if (!response.ok) throw new Error('Failed to load messages')
      
      const data = await response.json()
      setMessages(data.messages || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load messages')
    } finally {
      setLoading(false)
    }
  }

  const handleSendMessage = (content: any, options: { threadId?: string, replyToId?: string } = {}) => {
    if (!state.connected) {
      setError('Not connected to chat server')
      return
    }

    sendMessage({
      roomId,
      content,
      ...options
    })
  }

  const handleStartThread = (messageId: string) => {
    setSelectedThread(messageId)
  }

  const getMessagesByThread = () => {
    if (selectedThread) {
      return messages.filter(msg => msg.threadId === selectedThread)
    }
    return messages.filter(msg => !msg.threadId)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className={`flex flex-col h-full bg-background ${className}`}>
      {error && (
        <div className="bg-destructive/10 text-destructive px-4 py-2 text-sm">
          {error}
        </div>
      )}

      <ResizablePanelGroup direction="horizontal" className="flex-1">
        {/* Main chat area */}
        <ResizablePanel defaultSize={75} minSize={50}>
          <div className="flex flex-col h-full">
            {/* Messages area */}
            <ScrollArea className="flex-1 p-4">
              <MessageThread
                messages={getMessagesByThread()}
                onReply={(messageId) => setSelectedThread(messageId)}
                onStartThread={handleStartThread}
                currentUserId={(session?.user as any)?.id}
              />
              
              {/* Typing indicator */}
              {typingUsers.size > 0 && (
                <TypingIndicator users={Array.from(typingUsers)} />
              )}
              
              <div ref={messagesEndRef} />
            </ScrollArea>

            <Separator />

            {/* Message composer */}
            <div className="p-4">
              <MessageComposer
                onSendMessage={handleSendMessage}
                disabled={!state.connected}
                placeholder={
                  selectedThread 
                    ? "Reply to thread..." 
                    : "Type a message..."
                }
                roomId={roomId}
              />
            </div>
          </div>
        </ResizablePanel>

        <ResizableHandle />

        {/* Sidebar */}
        <ResizablePanel defaultSize={25} minSize={20} maxSize={40}>
          <ChatSidebar
            roomId={roomId}
            workspaceId={workspaceId}
            onThreadSelect={setSelectedThread}
            selectedThread={selectedThread}
          />
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  )
}
