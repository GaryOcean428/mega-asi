
'use client'

import { useState, useEffect } from 'react'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Card, CardContent } from '@/components/ui/card'
import { Bot, Brain, Zap, Clock } from 'lucide-react'

interface Agent {
  id: string
  name: string
  status: 'IDLE' | 'BUSY' | 'ERROR' | 'OFFLINE'
  currentTask?: string
  lastActivity?: string
}

interface AgentPresenceIndicatorProps {
  roomId: string
  className?: string
}

export function AgentPresenceIndicator({ roomId, className }: AgentPresenceIndicatorProps) {
  const [agents, setAgents] = useState<Agent[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadAgentPresence()
    
    // Set up periodic updates
    const interval = setInterval(loadAgentPresence, 30000) // Update every 30 seconds
    
    return () => clearInterval(interval)
  }, [roomId])

  const loadAgentPresence = async () => {
    try {
      const response = await fetch(`/api/chat/rooms/${roomId}/agents`)
      if (response.ok) {
        const data = await response.json()
        setAgents(data.agents || [])
      }
    } catch (error) {
      console.error('Failed to load agent presence:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'BUSY':
        return <Brain className="h-3 w-3" />
      case 'ERROR':
        return <Zap className="h-3 w-3" />
      case 'OFFLINE':
        return <Clock className="h-3 w-3" />
      default:
        return <Bot className="h-3 w-3" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'BUSY':
        return 'bg-yellow-500'
      case 'ERROR':
        return 'bg-red-500'
      case 'OFFLINE':
        return 'bg-gray-500'
      default:
        return 'bg-green-500'
    }
  }

  if (loading) {
    return (
      <div className={`animate-pulse ${className}`}>
        <div className="h-16 bg-muted rounded-md"></div>
      </div>
    )
  }

  if (agents.length === 0) {
    return null
  }

  return (
    <Card className={`${className}`}>
      <CardContent className="p-3">
        <div className="flex items-center gap-2 mb-2">
          <Bot className="h-4 w-4 text-muted-foreground" />
          <h4 className="text-sm font-medium">Active Agents</h4>
          <Badge variant="secondary" className="h-5 text-xs">
            {agents.filter(a => a.status !== 'OFFLINE').length}
          </Badge>
        </div>
        
        <div className="space-y-2">
          {agents.map((agent) => (
            <div 
              key={agent.id} 
              className="flex items-center gap-2 p-2 rounded-md hover:bg-muted cursor-pointer transition-colors"
              onClick={() => console.log(`Agent ${agent.name} clicked`)} // Add click handler
              title={`Click to view ${agent.name} details`}
            >
              <div className="relative">
                <Avatar className="h-6 w-6 bg-purple-500">
                  <AvatarFallback className="text-xs text-white">
                    {agent.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background ${getStatusColor(agent.status)}`}></div>
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{agent.name}</p>
                <div className="flex items-center gap-1">
                  {getStatusIcon(agent.status)}
                  <p className="text-xs text-muted-foreground">
                    {agent.currentTask || agent.status.toLowerCase()}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
