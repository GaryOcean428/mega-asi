
'use client'

import { useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatDistanceToNow } from 'date-fns'
import { MessageCircle, MoreHorizontal, Edit, Trash2, Copy } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface Message {
  id: string
  content: any
  senderUserId?: string
  senderAgentId?: string
  senderType: 'USER' | 'AGENT' | 'SYSTEM'
  userSender?: {
    id: string
    name?: string | null
    email: string
    image?: string | null
  }
  agentSender?: {
    id: string
    name: string
    description?: string | null
  }
  threadId?: string
  replyToId?: string
  createdAt: string
  editedAt?: string
}

interface MessageThreadProps {
  messages: Message[]
  onReply: (messageId: string) => void
  onStartThread: (messageId: string) => void
  currentUserId?: string
  className?: string
}

export function MessageThread({ 
  messages, 
  onReply, 
  onStartThread, 
  currentUserId,
  className 
}: MessageThreadProps) {
  const [hoveredMessage, setHoveredMessage] = useState<string | null>(null)

  const renderMessageContent = (content: any) => {
    if (typeof content === 'string') {
      return <p className="text-sm whitespace-pre-wrap">{content}</p>
    }
    
    if (content?.type === 'text') {
      return <p className="text-sm whitespace-pre-wrap">{content.text}</p>
    }
    
    if (content?.type === 'code') {
      return (
        <pre className="bg-muted p-3 rounded-md text-sm overflow-x-auto">
          <code>{content.code}</code>
        </pre>
      )
    }
    
    if (content?.type === 'tool_result') {
      return (
        <div className="border border-muted rounded-md p-3">
          <div className="text-xs text-muted-foreground mb-2">
            Tool: {content.tool_name}
          </div>
          <pre className="text-sm">{JSON.stringify(content.result, null, 2)}</pre>
        </div>
      )
    }
    
    // Default: try to render as text
    return <p className="text-sm">{JSON.stringify(content)}</p>
  }

  const getSenderInfo = (message: Message) => {
    if (message.senderType === 'USER' && message.userSender) {
      return {
        name: message.userSender.name || message.userSender.email,
        avatar: message.userSender.image,
        initials: (message.userSender.name || message.userSender.email).charAt(0).toUpperCase(),
        isAgent: false
      }
    }
    
    if (message.senderType === 'AGENT' && message.agentSender) {
      return {
        name: message.agentSender.name,
        avatar: null, // Agents typically don't have avatars
        initials: message.agentSender.name.charAt(0).toUpperCase(),
        isAgent: true
      }
    }
    
    return {
      name: 'System',
      avatar: null,
      initials: 'S',
      isAgent: false
    }
  }

  const isOwnMessage = (message: Message) => {
    return message.senderUserId === currentUserId
  }

  if (messages.length === 0) {
    return (
      <div className="flex items-center justify-center h-32 text-muted-foreground">
        <p>No messages yet. Start the conversation!</p>
      </div>
    )
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {messages.map((message) => {
        const senderInfo = getSenderInfo(message)
        const isOwn = isOwnMessage(message)
        
        return (
          <div
            key={message.id}
            className={`group relative flex gap-3 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}
            onMouseEnter={() => setHoveredMessage(message.id)}
            onMouseLeave={() => setHoveredMessage(null)}
          >
            {/* Avatar */}
            <Avatar className="h-8 w-8 flex-shrink-0">
              <AvatarImage src={senderInfo.avatar || undefined} />
              <AvatarFallback className={senderInfo.isAgent ? 'bg-purple-500' : 'bg-primary'}>
                {senderInfo.initials}
              </AvatarFallback>
            </Avatar>

            {/* Message content */}
            <div className={`flex-1 min-w-0 ${isOwn ? 'text-right' : ''}`}>
              {/* Header */}
              <div className={`flex items-center gap-2 mb-1 ${isOwn ? 'flex-row-reverse' : ''}`}>
                <span className="text-sm font-medium">{senderInfo.name}</span>
                {senderInfo.isAgent && (
                  <Badge variant="secondary" className="text-xs">
                    Agent
                  </Badge>
                )}
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
                </span>
                {message.editedAt && (
                  <span className="text-xs text-muted-foreground">(edited)</span>
                )}
              </div>

              {/* Message content */}
              <div className={`bg-muted rounded-lg p-3 ${isOwn ? 'bg-primary text-primary-foreground' : ''}`}>
                {renderMessageContent(message.content)}
              </div>

              {/* Action buttons (show on hover) */}
              {hoveredMessage === message.id && (
                <div className={`flex items-center gap-1 mt-2 ${isOwn ? 'justify-end' : 'justify-start'}`}>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onReply(message.id)}
                    className="h-6 px-2"
                  >
                    <MessageCircle className="h-3 w-3" />
                  </Button>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="sm" variant="ghost" className="h-6 px-2">
                        <MoreHorizontal className="h-3 w-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onStartThread(message.id)}>
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Start Thread
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigator.clipboard.writeText(JSON.stringify(message.content))}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </DropdownMenuItem>
                      {isOwn && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
