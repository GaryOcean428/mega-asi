
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { IntentAnalysis } from '@/lib/ai-orchestrator/intent-engine'
import { 
  Brain, 
  Bot, 
  Zap, 
  Users, 
  Workflow,
  Sparkles,
  ArrowRight,
  X,
  Lightbulb
} from 'lucide-react'

interface IntentSuggestionPanelProps {
  intent: IntentAnalysis
  suggestions: {
    agents: any[]
    mcps: any[]
    collaborations: any[]
    quickActions: any[]
  }
  onQuickAction: (actionId: string, parameters?: any) => void
  onDismiss: () => void
}

export function IntentSuggestionPanel({ 
  intent, 
  suggestions, 
  onQuickAction, 
  onDismiss 
}: IntentSuggestionPanelProps) {
  const [activeTab, setActiveTab] = useState<'suggestions' | 'templates' | 'actions'>('suggestions')
  
  // Safe access to suggestions with default values
  const safeSuggestions = {
    agents: Array.isArray(suggestions?.agents) ? suggestions.agents : [],
    mcps: Array.isArray(suggestions?.mcps) ? suggestions.mcps : [],
    collaborations: Array.isArray(suggestions?.collaborations) ? suggestions.collaborations : [],
    quickActions: Array.isArray(suggestions?.quickActions) ? suggestions.quickActions : []
  }

  const getIntentIcon = (intentType: string) => {
    const icons = {
      create_agent: Bot,
      install_mcp: Zap,
      create_collaboration: Users,
      workflow_automation: Workflow,
      general_chat: Brain
    }
    return icons[intentType as keyof typeof icons] || Brain
  }

  const getIntentColor = (intentType: string) => {
    const colors = {
      create_agent: 'text-blue-400',
      install_mcp: 'text-green-400',
      create_collaboration: 'text-purple-400',
      workflow_automation: 'text-yellow-400',
      general_chat: 'text-gray-400'
    }
    return colors[intentType as keyof typeof colors] || 'text-gray-400'
  }

  const renderSuggestions = () => {
    return (
      <div className="space-y-4">
        {/* Intent Summary */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              {(() => {
                const IconComponent = getIntentIcon(intent.intent)
                return <IconComponent className={`h-5 w-5 ${getIntentColor(intent.intent)}`} />
              })()}
              <div>
                <h4 className="font-semibold text-white capitalize">
                  {intent.intent.replace('_', ' ')}
                </h4>
                <p className="text-sm text-gray-400">
                  {Math.round(intent.confidence * 100)}% confidence
                </p>
              </div>
            </div>
            
            {Object.keys(intent.entities).length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-300">Detected entities:</p>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(intent.entities).map(([key, value]) => (
                    <Badge key={key} variant="secondary" className="text-xs">
                      {key}: {Array.isArray(value) ? value.join(', ') : String(value)}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        {safeSuggestions.quickActions.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center">
              <Sparkles className="h-4 w-4 mr-2 text-yellow-400" />
              Quick Actions
            </h4>
            {safeSuggestions.quickActions.map((action) => (
              <Button
                key={action.id}
                variant="outline"
                className="w-full justify-start text-left h-auto p-3"
                onClick={() => onQuickAction(action.id)}
              >
                <div className="flex-1">
                  <p className="font-medium">{action.title}</p>
                  <p className="text-xs text-muted-foreground mt-1">{action.description}</p>
                </div>
                <ArrowRight className="h-4 w-4 ml-2 text-muted-foreground" />
              </Button>
            ))}
          </div>
        )}

        {/* Agent Suggestions */}
        {safeSuggestions.agents.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center">
              <Bot className="h-4 w-4 mr-2 text-blue-400" />
              Recommended Agents
            </h4>
            {safeSuggestions.agents.map((agent) => (
              <Card key={agent.id} className="bg-blue-500/10 border-blue-500/20">
                <CardContent className="p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h5 className="font-medium text-blue-300">{agent.name}</h5>
                      <p className="text-xs text-gray-400 mt-1">{agent.description}</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {agent.capabilities.slice(0, 3).map((cap: string) => (
                          <Badge key={cap} variant="secondary" className="text-xs">
                            {cap}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => onQuickAction('create_agent', { template: agent })}
                      className="ml-2"
                    >
                      Create
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* MCP Suggestions */}
        {safeSuggestions.mcps.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center">
              <Zap className="h-4 w-4 mr-2 text-green-400" />
              Recommended Tools
            </h4>
            {safeSuggestions.mcps.map((mcp) => (
              <Card key={mcp.id} className="bg-green-500/10 border-green-500/20">
                <CardContent className="p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h5 className="font-medium text-green-300">{mcp.name}</h5>
                      <p className="text-xs text-gray-400 mt-1">{mcp.description}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="secondary" className="text-xs">
                          ⭐ {mcp.rating}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {mcp.installationComplexity}
                        </Badge>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => onQuickAction('install_mcp', { mcp })}
                      className="ml-2"
                    >
                      Install
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Collaboration Suggestions */}
        {safeSuggestions.collaborations.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-white flex items-center">
              <Users className="h-4 w-4 mr-2 text-purple-400" />
              Collaboration Templates
            </h4>
            {safeSuggestions.collaborations.map((collab) => (
              <Card key={collab.id} className="bg-purple-500/10 border-purple-500/20">
                <CardContent className="p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h5 className="font-medium text-purple-300">{collab.name}</h5>
                      <p className="text-xs text-gray-400 mt-1">{collab.description}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="secondary" className="text-xs">
                          {collab.agents.length} agents
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {collab.complexity}
                        </Badge>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => onQuickAction('create_collaboration', { template: collab })}
                      className="ml-2"
                    >
                      Setup
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800">
        <h3 className="text-lg font-semibold text-white flex items-center">
          <Lightbulb className="h-5 w-5 mr-2 text-yellow-400" />
          Smart Suggestions
        </h3>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onDismiss}
          className="p-1"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1 p-4">
        {renderSuggestions()}
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-gray-800">
        <p className="text-xs text-gray-400 text-center">
          AI-powered suggestions based on your conversation
        </p>
      </div>
    </div>
  )
}
