
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'
import { 
  Bot, 
  Brain, 
  Settings, 
  Sparkles, 
  Check,
  ArrowLeft,
  ArrowRight,
  Zap
} from 'lucide-react'

interface AgentTemplate {
  id: string
  name: string
  description: string
  role: string
  capabilities: string[]
  systemPrompt: string
  requiredMCPs: string[]
  complexity: string
  icon: string
}

interface AgentCreationWizardProps {
  suggestions: AgentTemplate[]
  onComplete: (agent: any) => void
  onCancel: () => void
}

export function AgentCreationWizard({ suggestions, onComplete, onCancel }: AgentCreationWizardProps) {
  const [step, setStep] = useState<'template' | 'customize' | 'capabilities' | 'review'>('template')
  const [selectedTemplate, setSelectedTemplate] = useState<AgentTemplate | null>(null)
  const [agentConfig, setAgentConfig] = useState({
    name: '',
    description: '',
    role: '',
    systemPrompt: '',
    capabilities: [] as string[],
    model: 'gpt-4.1-mini'
  })
  const [isCreating, setIsCreating] = useState(false)

  const steps = ['template', 'customize', 'capabilities', 'review']
  const currentStepIndex = steps.indexOf(step)
  const progress = ((currentStepIndex + 1) / steps.length) * 100

  const handleTemplateSelect = (template: AgentTemplate) => {
    setSelectedTemplate(template)
    setAgentConfig({
      name: template.name,
      description: template.description,
      role: template.role,
      systemPrompt: template.systemPrompt,
      capabilities: [...template.capabilities],
      model: 'gpt-4.1-mini'
    })
    setStep('customize')
  }

  const handleNext = () => {
    const currentIndex = steps.indexOf(step)
    if (currentIndex < steps.length - 1) {
      setStep(steps[currentIndex + 1] as any)
    }
  }

  const handlePrevious = () => {
    const currentIndex = steps.indexOf(step)
    if (currentIndex > 0) {
      setStep(steps[currentIndex - 1] as any)
    }
  }

  const handleCreateAgent = async () => {
    setIsCreating(true)

    try {
      const response = await fetch('/api/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...agentConfig,
          capabilities: agentConfig.capabilities,
          requiredMCPs: selectedTemplate?.requiredMCPs || []
        })
      })

      if (response.ok) {
        const agent = await response.json()
        onComplete(agent)
      }
    } catch (error) {
      console.error('Failed to create agent:', error)
    } finally {
      setIsCreating(false)
    }
  }

  const toggleCapability = (capability: string) => {
    setAgentConfig(prev => ({
      ...prev,
      capabilities: prev.capabilities.includes(capability)
        ? prev.capabilities.filter(c => c !== capability)
        : [...prev.capabilities, capability]
    }))
  }

  const renderTemplateStep = () => (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <Bot className="h-12 w-12 text-blue-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Choose Agent Template</h2>
        <p className="text-gray-400">Start with a pre-configured template or create from scratch</p>
      </div>

      <div className="grid gap-4">
        {/* Quick Start Option */}
        <Card className="bg-blue-500/10 border-blue-500/20 cursor-pointer hover:bg-blue-500/20 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Sparkles className="h-8 w-8 text-yellow-400" />
              <div className="flex-1">
                <h3 className="font-semibold text-white">Smart Setup</h3>
                <p className="text-sm text-gray-400">AI will configure the agent based on our conversation</p>
              </div>
              <Button onClick={() => handleTemplateSelect(suggestions[0] || {} as AgentTemplate)}>
                Quick Start
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Template Options */}
        {suggestions.map((template) => (
          <Card key={template.id} className="cursor-pointer hover:bg-gray-800/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-gray-700 rounded-lg">
                  <Bot className="h-6 w-6 text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-white">{template.name}</h3>
                  <p className="text-sm text-gray-400 mt-1">{template.description}</p>
                  <div className="flex items-center space-x-2 mt-3">
                    <Badge variant="secondary" className="text-xs">
                      {template.role}
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {template.complexity}
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {template.capabilities.length} capabilities
                    </Badge>
                  </div>
                </div>
                <Button onClick={() => handleTemplateSelect(template)}>
                  Select
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  const renderCustomizeStep = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Settings className="h-12 w-12 text-blue-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Customize Agent</h2>
        <p className="text-gray-400">Configure your agent's basic properties</p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="name">Agent Name</Label>
          <Input
            id="name"
            value={agentConfig.name}
            onChange={(e) => setAgentConfig(prev => ({ ...prev, name: e.target.value }))}
            placeholder="Enter agent name"
          />
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={agentConfig.description}
            onChange={(e) => setAgentConfig(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Describe what this agent does"
            rows={3}
          />
        </div>

        <div>
          <Label htmlFor="role">Role</Label>
          <Input
            id="role"
            value={agentConfig.role}
            onChange={(e) => setAgentConfig(prev => ({ ...prev, role: e.target.value }))}
            placeholder="e.g., analyst, researcher, assistant"
          />
        </div>

        <div>
          <Label htmlFor="systemPrompt">System Prompt</Label>
          <Textarea
            id="systemPrompt"
            value={agentConfig.systemPrompt}
            onChange={(e) => setAgentConfig(prev => ({ ...prev, systemPrompt: e.target.value }))}
            placeholder="Define the agent's personality and instructions"
            rows={4}
          />
        </div>
      </div>
    </div>
  )

  const renderCapabilitiesStep = () => {
    const availableCapabilities = [
      'data_analysis', 'web_research', 'code_generation', 'writing', 'visualization',
      'debugging', 'testing', 'documentation', 'translation', 'summarization',
      'fact_checking', 'scheduling', 'email_management', 'file_processing'
    ]

    return (
      <div className="space-y-6">
        <div className="text-center mb-6">
          <Zap className="h-12 w-12 text-green-400 mx-auto mb-4" />
          <h2 className="text-2xl font-semibold text-white mb-2">Select Capabilities</h2>
          <p className="text-gray-400">Choose what your agent can do</p>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold text-white mb-3">Current Capabilities</h3>
            <div className="flex flex-wrap gap-2 mb-4">
              {agentConfig.capabilities.map((cap) => (
                <Badge key={cap} className="bg-blue-500/20 text-blue-300">
                  {cap}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="ml-2 h-4 w-4 p-0"
                    onClick={() => toggleCapability(cap)}
                  >
                    ×
                  </Button>
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-3">Available Capabilities</h3>
            <div className="grid grid-cols-2 gap-2">
              {availableCapabilities.filter(cap => !agentConfig.capabilities.includes(cap)).map((cap) => (
                <Button
                  key={cap}
                  variant="outline"
                  onClick={() => toggleCapability(cap)}
                  className="justify-start"
                >
                  + {cap}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  const renderReviewStep = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Check className="h-12 w-12 text-green-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Review & Create</h2>
        <p className="text-gray-400">Confirm your agent configuration</p>
      </div>

      <Card className="bg-gray-800/50">
        <CardHeader>
          <CardTitle className="text-white">{agentConfig.name}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold text-white mb-2">Description</h4>
            <p className="text-gray-300">{agentConfig.description}</p>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-2">Role</h4>
            <Badge variant="secondary">{agentConfig.role}</Badge>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-2">Capabilities ({agentConfig.capabilities.length})</h4>
            <div className="flex flex-wrap gap-2">
              {agentConfig.capabilities.map((cap) => (
                <Badge key={cap} variant="secondary">{cap}</Badge>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-2">LLM Model</h4>
            <Badge variant="secondary">{agentConfig.model}</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="h-full flex flex-col">
      {/* Header with Progress */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold text-white">Create Agent</h1>
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
        </div>
        <Progress value={progress} className="w-full" />
        <p className="text-sm text-gray-400 mt-2">
          Step {currentStepIndex + 1} of {steps.length}
        </p>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1 p-6">
        {step === 'template' && renderTemplateStep()}
        {step === 'customize' && renderCustomizeStep()}
        {step === 'capabilities' && renderCapabilitiesStep()}
        {step === 'review' && renderReviewStep()}
      </ScrollArea>

      {/* Footer */}
      <div className="p-6 border-t border-gray-800">
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={handlePrevious}
            disabled={step === 'template'}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>

          {step === 'review' ? (
            <Button 
              onClick={handleCreateAgent}
              disabled={isCreating}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isCreating ? 'Creating...' : 'Create Agent'}
            </Button>
          ) : (
            <Button 
              onClick={handleNext}
              disabled={!selectedTemplate && step !== 'template'}
            >
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
