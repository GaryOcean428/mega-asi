
'use client'

import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'

interface TypingIndicatorProps {
  users: string[]
  className?: string
}

export function TypingIndicator({ users, className }: TypingIndicatorProps) {
  if (users.length === 0) return null

  const displayUsers = users.slice(0, 3)
  const remainingCount = users.length - 3

  return (
    <div className={`flex items-center gap-2 py-2 px-3 ${className}`}>
      {/* Avatars */}
      <div className="flex -space-x-1">
        {displayUsers.map((userId, index) => (
          <Avatar key={userId} className="h-6 w-6 border-2 border-background">
            <AvatarFallback className="text-xs bg-muted">
              {userId.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        ))}
        {remainingCount > 0 && (
          <Badge variant="secondary" className="h-6 w-6 p-0 text-xs rounded-full">
            +{remainingCount}
          </Badge>
        )}
      </div>

      {/* Typing animation and text */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <div className="flex space-x-1">
          <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
          <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
          <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
        </div>
        <span className="text-xs">
          {users.length === 1 ? 'is typing...' : 'are typing...'}
        </span>
      </div>
    </div>
  )
}
