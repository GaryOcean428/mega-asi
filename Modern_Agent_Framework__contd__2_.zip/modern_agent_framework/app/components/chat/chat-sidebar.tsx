
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Users, 
  Bot, 
  MessageSquare, 
  Settings,
  UserPlus,
  Search
} from 'lucide-react'
import { Input } from '@/components/ui/input'

interface ChatSidebarProps {
  roomId: string
  workspaceId: string
  onThreadSelect: (threadId: string | null) => void
  selectedThread?: string | null
  className?: string
}

interface Participant {
  id: string
  userId?: string
  agentId?: string
  role: string
  user?: {
    id: string
    name?: string | null
    email: string
    image?: string | null
  }
  agent?: {
    id: string
    name: string
    status: string
  }
  lastReadAt?: string
}

interface Thread {
  id: string
  title?: string
  messageCount: number
  lastActivity: string
  parentMessage?: {
    content: any
    userSender?: { name?: string | null }
    agentSender?: { name: string }
  }
}

export function ChatSidebar({ 
  roomId, 
  workspaceId, 
  onThreadSelect, 
  selectedThread,
  className 
}: ChatSidebarProps) {
  const { data: session } = useSession() || {}
  const [participants, setParticipants] = useState<Participant[]>([])
  const [threads, setThreads] = useState<Thread[]>([])
  const [activeTab, setActiveTab] = useState<'participants' | 'threads' | 'settings'>('participants')
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (roomId) {
      loadSidebarData()
    }
  }, [roomId])

  const loadSidebarData = async () => {
    try {
      setLoading(true)
      const [participantsResponse, threadsResponse] = await Promise.all([
        fetch(`/api/chat/rooms/${roomId}/participants`),
        fetch(`/api/chat/rooms/${roomId}/threads`)
      ])

      if (participantsResponse.ok) {
        const participantsData = await participantsResponse.json()
        setParticipants(participantsData.participants || [])
      }

      if (threadsResponse.ok) {
        const threadsData = await threadsResponse.json()
        setThreads(threadsData.threads || [])
      }
    } catch (error) {
      console.error('Failed to load sidebar data:', error)
    } finally {
      setLoading(false)
    }
  }

  const renderParticipants = () => {
    const filteredParticipants = participants.filter(p => {
      const name = p.user?.name || p.user?.email || p.agent?.name || ''
      return name.toLowerCase().includes(searchQuery.toLowerCase())
    })

    const users = filteredParticipants.filter(p => p.userId)
    const agents = filteredParticipants.filter(p => p.agentId)

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-semibold">Users ({users.length})</h4>
          <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
            <UserPlus className="h-3 w-3" />
          </Button>
        </div>
        
        <div className="space-y-2">
          {users.map(participant => (
            <div key={participant.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted cursor-pointer">
              <Avatar className="h-6 w-6">
                <AvatarImage src={participant.user?.image || undefined} />
                <AvatarFallback className="text-xs">
                  {(participant.user?.name || participant.user?.email)?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">
                  {participant.user?.name || participant.user?.email}
                </p>
                <p className="text-xs text-muted-foreground">
                  {participant.role}
                </p>
              </div>
              <div className="h-2 w-2 bg-green-500 rounded-full"></div>
            </div>
          ))}
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <h4 className="text-sm font-semibold flex items-center gap-1">
            <Bot className="h-3 w-3" />
            Agents ({agents.length})
          </h4>
        </div>
        
        <div className="space-y-2">
          {agents.map(participant => (
            <div 
              key={participant.id} 
              className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted cursor-pointer transition-colors"
              onClick={() => console.log(`Agent ${participant.agent?.name} clicked`)}
              title={`View ${participant.agent?.name} details`}
            >
              <Avatar className="h-6 w-6 bg-purple-500">
                <AvatarFallback className="text-xs text-white">
                  {participant.agent?.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">
                  {participant.agent?.name}
                </p>
                <Badge 
                  variant={participant.agent?.status === 'BUSY' ? 'default' : 'secondary'} 
                  className="text-xs h-4"
                >
                  {participant.agent?.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  const renderThreads = () => {
    const filteredThreads = threads.filter(thread => {
      const title = thread.title || 'Thread'
      return title.toLowerCase().includes(searchQuery.toLowerCase())
    })

    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-semibold">Threads ({filteredThreads.length})</h4>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onThreadSelect(null)}
            className="text-xs h-6"
          >
            Main
          </Button>
        </div>

        {filteredThreads.map(thread => (
          <Card 
            key={thread.id}
            className={`p-2 cursor-pointer hover:bg-muted transition-colors ${
              selectedThread === thread.id ? 'bg-muted border-primary' : ''
            }`}
            onClick={() => onThreadSelect(thread.id)}
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium truncate">
                  {thread.title || `Thread (${thread.messageCount} messages)`}
                </p>
                <MessageSquare className="h-3 w-3 text-muted-foreground flex-shrink-0" />
              </div>
              
              {thread.parentMessage && (
                <p className="text-xs text-muted-foreground truncate">
                  Started by {
                    thread.parentMessage.userSender?.name || 
                    thread.parentMessage.agentSender?.name ||
                    'Unknown'
                  }
                </p>
              )}
              
              <p className="text-xs text-muted-foreground">
                {new Date(thread.lastActivity).toLocaleString()}
              </p>
            </div>
          </Card>
        ))}

        {filteredThreads.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-xs">No threads yet</p>
          </div>
        )}
      </div>
    )
  }

  const renderSettings = () => {
    return (
      <div className="space-y-4">
        <h4 className="text-sm font-semibold">Room Settings</h4>
        
        <div className="space-y-2">
          <Button variant="ghost" size="sm" className="justify-start w-full text-xs">
            <Settings className="h-3 w-3 mr-2" />
            Room Settings
          </Button>
          
          <Button variant="ghost" size="sm" className="justify-start w-full text-xs">
            <Users className="h-3 w-3 mr-2" />
            Manage Participants
          </Button>
          
          <Button variant="ghost" size="sm" className="justify-start w-full text-xs text-destructive">
            Leave Room
          </Button>
        </div>
      </div>
    )
  }

  return (
    <Card className={`h-full ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex space-x-1">
          <Button
            size="sm"
            variant={activeTab === 'participants' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('participants')}
            className="flex-1 text-xs h-7"
          >
            <Users className="h-3 w-3 mr-1" />
            People
          </Button>
          <Button
            size="sm"
            variant={activeTab === 'threads' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('threads')}
            className="flex-1 text-xs h-7"
          >
            <MessageSquare className="h-3 w-3 mr-1" />
            Threads
          </Button>
          <Button
            size="sm"
            variant={activeTab === 'settings' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('settings')}
            className="h-7 w-7 p-0"
          >
            <Settings className="h-3 w-3" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="pt-2">
        {/* Search */}
        {activeTab !== 'settings' && (
          <div className="relative mb-4">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-muted-foreground" />
            <Input
              placeholder={`Search ${activeTab}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-7 h-7 text-xs"
            />
          </div>
        )}

        <ScrollArea className="h-[calc(100%-5rem)]">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              {activeTab === 'participants' && renderParticipants()}
              {activeTab === 'threads' && renderThreads()}
              {activeTab === 'settings' && renderSettings()}
            </>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
