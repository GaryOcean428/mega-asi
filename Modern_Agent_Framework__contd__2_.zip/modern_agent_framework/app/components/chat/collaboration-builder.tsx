
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Users, 
  Bot, 
  Workflow, 
  Plus, 
  ArrowRight, 
  ArrowLeft,
  Settings,
  Play,
  Check,
  X
} from 'lucide-react'

interface CollaborationTemplate {
  id: string
  name: string
  description: string
  agents: Array<{
    role: string
    capabilities: string[]
    template: string
  }>
  workflow: Array<{
    step: string
    agent: string
    dependencies: string[]
  }>
  complexity: 'simple' | 'moderate' | 'complex'
  useCase: string
}

interface AgentConfig {
  id: string
  name: string
  role: string
  template: string
  capabilities: string[]
  position: { x: number; y: number }
}

interface WorkflowStep {
  id: string
  name: string
  description: string
  assignedAgent: string
  dependencies: string[]
  estimatedTime?: string
}

interface CollaborationBuilderProps {
  suggestions: CollaborationTemplate[]
  onComplete: (collaboration: any) => void
  onCancel: () => void
}

export function CollaborationBuilder({ suggestions, onComplete, onCancel }: CollaborationBuilderProps) {
  const [step, setStep] = useState<'template' | 'agents' | 'workflow' | 'review'>('template')
  const [selectedTemplate, setSelectedTemplate] = useState<CollaborationTemplate | null>(null)
  const [collaborationConfig, setCollaborationConfig] = useState({
    name: '',
    description: '',
    type: 'SEQUENTIAL' as 'SEQUENTIAL' | 'PARALLEL' | 'HIERARCHICAL'
  })
  const [agents, setAgents] = useState<AgentConfig[]>([])
  const [workflowSteps, setWorkflowSteps] = useState<WorkflowStep[]>([])
  const [isCreating, setIsCreating] = useState(false)

  const steps = ['template', 'agents', 'workflow', 'review']
  const currentStepIndex = steps.indexOf(step)
  const progress = ((currentStepIndex + 1) / steps.length) * 100

  const handleTemplateSelect = (template: CollaborationTemplate) => {
    setSelectedTemplate(template)
    setCollaborationConfig({
      name: template.name,
      description: template.description,
      type: 'SEQUENTIAL'
    })

    // Configure agents from template
    const templateAgents = template.agents.map((agent, index) => ({
      id: `agent_${index}`,
      name: agent.role.charAt(0).toUpperCase() + agent.role.slice(1),
      role: agent.role,
      template: agent.template,
      capabilities: agent.capabilities,
      position: { x: 100 + index * 200, y: 100 }
    }))
    setAgents(templateAgents)

    // Configure workflow from template
    const templateSteps = template.workflow.map((step, index) => ({
      id: `step_${index}`,
      name: step.step,
      description: `Execute ${step.step}`,
      assignedAgent: templateAgents.find(a => a.role === step.agent)?.id || '',
      dependencies: step.dependencies
    }))
    setWorkflowSteps(templateSteps)

    setStep('agents')
  }

  const addAgent = () => {
    const newAgent: AgentConfig = {
      id: `agent_${Date.now()}`,
      name: 'New Agent',
      role: 'assistant',
      template: 'general_assistant',
      capabilities: [],
      position: { x: 100 + agents.length * 200, y: 100 }
    }
    setAgents(prev => [...prev, newAgent])
  }

  const updateAgent = (id: string, updates: Partial<AgentConfig>) => {
    setAgents(prev => prev.map(agent => 
      agent.id === id ? { ...agent, ...updates } : agent
    ))
  }

  const removeAgent = (id: string) => {
    setAgents(prev => prev.filter(agent => agent.id !== id))
    setWorkflowSteps(prev => prev.filter(step => step.assignedAgent !== id))
  }

  const addWorkflowStep = () => {
    const newStep: WorkflowStep = {
      id: `step_${Date.now()}`,
      name: 'New Step',
      description: '',
      assignedAgent: '',
      dependencies: []
    }
    setWorkflowSteps(prev => [...prev, newStep])
  }

  const updateWorkflowStep = (id: string, updates: Partial<WorkflowStep>) => {
    setWorkflowSteps(prev => prev.map(step => 
      step.id === id ? { ...step, ...updates } : step
    ))
  }

  const removeWorkflowStep = (id: string) => {
    setWorkflowSteps(prev => prev.filter(step => step.id !== id))
  }

  const handleNext = () => {
    const currentIndex = steps.indexOf(step)
    if (currentIndex < steps.length - 1) {
      setStep(steps[currentIndex + 1] as any)
    }
  }

  const handlePrevious = () => {
    const currentIndex = steps.indexOf(step)
    if (currentIndex > 0) {
      setStep(steps[currentIndex - 1] as any)
    }
  }

  const handleCreateCollaboration = async () => {
    setIsCreating(true)

    try {
      const collaboration = {
        name: collaborationConfig.name,
        description: collaborationConfig.description,
        type: collaborationConfig.type,
        agents: agents.map(agent => ({
          name: agent.name,
          role: agent.role,
          template: agent.template,
          capabilities: agent.capabilities
        })),
        workflow: workflowSteps.map(step => ({
          name: step.name,
          description: step.description,
          assignedAgent: agents.find(a => a.id === step.assignedAgent)?.name || '',
          dependencies: step.dependencies
        }))
      }

      // Create agents first
      for (const agent of agents) {
        await fetch('/api/agents', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: agent.name,
            role: agent.role,
            capabilities: agent.capabilities,
            systemPrompt: `You are a ${agent.role} agent working as part of a collaboration called "${collaborationConfig.name}".`
          })
        })
      }

      // Create collaboration
      const response = await fetch('/api/collaborations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(collaboration)
      })

      if (response.ok) {
        const result = await response.json()
        onComplete(result)
      }
    } catch (error) {
      console.error('Failed to create collaboration:', error)
    } finally {
      setIsCreating(false)
    }
  }

  const renderTemplateStep = () => (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <Users className="h-12 w-12 text-purple-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Choose Collaboration Template</h2>
        <p className="text-gray-400">Start with a proven multi-agent workflow pattern</p>
      </div>

      <div className="grid gap-4">
        {suggestions.map((template) => (
          <Card key={template.id} className="cursor-pointer hover:bg-gray-800/50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-purple-500/20 rounded-lg">
                  <Workflow className="h-6 w-6 text-purple-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-white">{template.name}</h3>
                  <p className="text-sm text-gray-400 mt-1">{template.description}</p>
                  <div className="flex items-center space-x-2 mt-3">
                    <Badge variant="secondary" className="text-xs">
                      {template.agents.length} agents
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {template.workflow.length} steps
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {template.complexity}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {template.agents.map((agent, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {agent.role}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Button onClick={() => handleTemplateSelect(template)}>
                  Select
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Custom Template */}
        <Card className="border-dashed border-gray-600 cursor-pointer hover:bg-gray-800/50 transition-colors">
          <CardContent className="p-4">
            <div className="text-center">
              <Plus className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white">Create Custom Collaboration</h3>
              <p className="text-sm text-gray-400">Build a collaboration from scratch</p>
              <Button 
                variant="outline" 
                className="mt-3"
                onClick={() => {
                  setSelectedTemplate(null)
                  setStep('agents')
                }}
              >
                Start Custom
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const renderAgentsStep = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Bot className="h-12 w-12 text-blue-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Configure Agents</h2>
        <p className="text-gray-400">Set up the agents that will work together</p>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Team Members</h3>
          <Button onClick={addAgent} size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Agent
          </Button>
        </div>

        {agents.map((agent) => (
          <Card key={agent.id} className="p-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Bot className="h-5 w-5 text-blue-400" />
                  <Input
                    value={agent.name}
                    onChange={(e) => updateAgent(agent.id, { name: e.target.value })}
                    placeholder="Agent name"
                    className="font-semibold"
                  />
                </div>
                <Button variant="ghost" size="sm" onClick={() => removeAgent(agent.id)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Role</Label>
                  <Input
                    value={agent.role}
                    onChange={(e) => updateAgent(agent.id, { role: e.target.value })}
                    placeholder="e.g., researcher, analyst"
                  />
                </div>
                <div>
                  <Label>Template</Label>
                  <Select 
                    value={agent.template} 
                    onValueChange={(value) => updateAgent(agent.id, { template: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="research_assistant">Research Assistant</SelectItem>
                      <SelectItem value="data_analyst">Data Analyst</SelectItem>
                      <SelectItem value="code_assistant">Code Assistant</SelectItem>
                      <SelectItem value="content_creator">Content Creator</SelectItem>
                      <SelectItem value="project_manager">Project Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Capabilities</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {agent.capabilities.map((cap) => (
                    <Badge key={cap} variant="secondary" className="text-xs">
                      {cap}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="ml-1 h-3 w-3 p-0"
                        onClick={() => updateAgent(agent.id, {
                          capabilities: agent.capabilities.filter(c => c !== cap)
                        })}
                      >
                        ×
                      </Button>
                    </Badge>
                  ))}
                  <Input
                    placeholder="Add capability..."
                    className="w-32 h-6 text-xs"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        const capability = e.currentTarget.value.trim()
                        if (capability && !agent.capabilities.includes(capability)) {
                          updateAgent(agent.id, {
                            capabilities: [...agent.capabilities, capability]
                          })
                          e.currentTarget.value = ''
                        }
                      }
                    }}
                  />
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )

  const renderWorkflowStep = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Workflow className="h-12 w-12 text-green-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Design Workflow</h2>
        <p className="text-gray-400">Define the steps and dependencies</p>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Workflow Steps</h3>
          <Button onClick={addWorkflowStep} size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Step
          </Button>
        </div>

        <div>
          <Label>Collaboration Type</Label>
          <Select 
            value={collaborationConfig.type} 
            onValueChange={(value) => setCollaborationConfig(prev => ({ ...prev, type: value as any }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="SEQUENTIAL">Sequential - Steps run one after another</SelectItem>
              <SelectItem value="PARALLEL">Parallel - Steps run simultaneously</SelectItem>
              <SelectItem value="HIERARCHICAL">Hierarchical - Manager coordinates workers</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {workflowSteps.map((step, index) => (
          <Card key={step.id} className="p-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center justify-center w-8 h-8 bg-green-500/20 text-green-400 rounded-full text-sm font-semibold">
                    {index + 1}
                  </div>
                  <Input
                    value={step.name}
                    onChange={(e) => updateWorkflowStep(step.id, { name: e.target.value })}
                    placeholder="Step name"
                    className="font-semibold"
                  />
                </div>
                <Button variant="ghost" size="sm" onClick={() => removeWorkflowStep(step.id)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div>
                <Label>Description</Label>
                <Textarea
                  value={step.description}
                  onChange={(e) => updateWorkflowStep(step.id, { description: e.target.value })}
                  placeholder="What should happen in this step?"
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Assigned Agent</Label>
                  <Select 
                    value={step.assignedAgent} 
                    onValueChange={(value) => updateWorkflowStep(step.id, { assignedAgent: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select agent" />
                    </SelectTrigger>
                    <SelectContent>
                      {agents.map((agent) => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.name} ({agent.role})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Estimated Time</Label>
                  <Input
                    value={step.estimatedTime || ''}
                    onChange={(e) => updateWorkflowStep(step.id, { estimatedTime: e.target.value })}
                    placeholder="e.g., 5 minutes"
                  />
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )

  const renderReviewStep = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Check className="h-12 w-12 text-green-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Review & Create</h2>
        <p className="text-gray-400">Confirm your collaboration setup</p>
      </div>

      <Card className="bg-gray-800/50">
        <CardHeader>
          <CardTitle className="text-white">{collaborationConfig.name}</CardTitle>
          <p className="text-gray-300">{collaborationConfig.description}</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold text-white mb-2">Team ({agents.length} agents)</h4>
            <div className="grid grid-cols-2 gap-2">
              {agents.map((agent) => (
                <div key={agent.id} className="flex items-center space-x-2">
                  <Bot className="h-4 w-4 text-blue-400" />
                  <span className="text-sm text-gray-300">{agent.name} - {agent.role}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-2">Workflow ({workflowSteps.length} steps)</h4>
            <div className="space-y-2">
              {workflowSteps.map((step, index) => (
                <div key={step.id} className="flex items-center space-x-3">
                  <div className="flex items-center justify-center w-6 h-6 bg-green-500/20 text-green-400 rounded-full text-xs font-semibold">
                    {index + 1}
                  </div>
                  <span className="text-sm text-gray-300">{step.name}</span>
                  <ArrowRight className="h-3 w-3 text-gray-500" />
                  <span className="text-xs text-gray-500">
                    {agents.find(a => a.id === step.assignedAgent)?.name || 'Unassigned'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-2">Type</h4>
            <Badge variant="secondary">{collaborationConfig.type}</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="h-full flex flex-col">
      {/* Header with Progress */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold text-white">Create Collaboration</h1>
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
        </div>
        <Progress value={progress} className="w-full" />
        <p className="text-sm text-gray-400 mt-2">
          Step {currentStepIndex + 1} of {steps.length}
        </p>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1 p-6">
        {step === 'template' && renderTemplateStep()}
        {step === 'agents' && renderAgentsStep()}
        {step === 'workflow' && renderWorkflowStep()}
        {step === 'review' && renderReviewStep()}
      </ScrollArea>

      {/* Footer */}
      <div className="p-6 border-t border-gray-800">
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={handlePrevious}
            disabled={step === 'template'}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>

          {step === 'review' ? (
            <Button 
              onClick={handleCreateCollaboration}
              disabled={isCreating}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isCreating ? 'Creating...' : 'Create Collaboration'}
            </Button>
          ) : (
            <Button 
              onClick={handleNext}
              disabled={agents.length === 0 && step === 'agents'}
            >
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
