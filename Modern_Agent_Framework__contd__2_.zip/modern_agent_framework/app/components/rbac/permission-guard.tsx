
'use client'

import React from 'react'
import { rbac, type Permission } from '@/lib/auth/rbac'

// Permission guard component
export function PermissionGuard({ 
  permission, 
  userId, 
  resource,
  fallback = null,
  children 
}: {
  permission: Permission | Permission[]
  userId: string
  resource?: { type: string; id: string }
  fallback?: React.ReactNode
  children: React.ReactNode
}) {
  const [hasAccess, setHasAccess] = React.useState(false)
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    const checkPermission = async () => {
      try {
        let result: boolean
        if (Array.isArray(permission)) {
          result = await rbac.hasAnyPermission(userId, permission, resource)
        } else {
          result = await rbac.hasPermission(userId, permission, resource)
        }
        setHasAccess(result)
      } catch (error) {
        console.error('Permission check failed:', error)
        setHasAccess(false)
      } finally {
        setLoading(false)
      }
    }

    checkPermission()
  }, [permission, userId, resource])

  if (loading) {
    return <div className="animate-pulse bg-gray-200 h-4 w-full rounded" />
  }

  return hasAccess ? <>{children}</> : <>{fallback}</>
}
