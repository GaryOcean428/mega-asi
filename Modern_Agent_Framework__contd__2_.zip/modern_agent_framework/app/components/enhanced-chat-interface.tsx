
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { IntelligentChat } from '@/components/chat/intelligent-chat'
import { MobileChatInterface } from '@/components/mobile/mobile-chat-interface'
import { OnboardingFlow } from '@/components/onboarding/onboarding-flow'
import { DemoScenarios } from '@/components/demo/demo-scenarios'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { useUserPreferences } from '@/lib/user-preferences'
import { 
  HelpCircle, 
  Play, 
  Settings,
  Smartphone,
  Monitor,
  X
} from 'lucide-react'

interface EnhancedChatInterfaceProps {
  workspaceId: string
  className?: string
}

export function EnhancedChatInterface({ workspaceId, className }: EnhancedChatInterfaceProps) {
  const { data: session } = useSession() || {}
  const { preferences, markOnboardingComplete, skipTutorial } = useUserPreferences()
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [showDemos, setShowDemos] = useState(false)
  const [showHelp, setShowHelp] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [forceDesktop, setForceDesktop] = useState(false)

  // Check if onboarding should be shown
  useEffect(() => {
    if (session && !preferences.onboarding.completed && !preferences.onboarding.skippedTutorial) {
      setShowOnboarding(true)
    }
  }, [session, preferences.onboarding])

  // Detect mobile device
  useEffect(() => {
    const checkMobile = () => {
      const isMobileDevice = window.innerWidth < 768
      setIsMobile(isMobileDevice && !forceDesktop)
    }

    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [forceDesktop])

  const handleOnboardingComplete = () => {
    setShowOnboarding(false)
    markOnboardingComplete()
    
    // Show demo scenarios after onboarding
    setTimeout(() => {
      setShowDemos(true)
    }, 1000)
  }

  const handleSkipOnboarding = () => {
    setShowOnboarding(false)
    skipTutorial()
  }

  const handleDemosClose = () => {
    setShowDemos(false)
  }

  // If onboarding should be shown, render it
  if (showOnboarding) {
    return (
      <OnboardingFlow 
        onComplete={handleOnboardingComplete}
        onSkip={handleSkipOnboarding}
      />
    )
  }

  return (
    <div className={`relative ${className}`}>
      {/* Main Chat Interface */}
      {isMobile && !forceDesktop ? (
        <MobileChatInterface 
          workspaceId={workspaceId}
          onSendMessage={(content) => {
            // Handle message sending
            console.log('Mobile message sent:', content)
          }}
          messages={[]}
        />
      ) : (
        <IntelligentChat workspaceId={workspaceId} />
      )}

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col space-y-3 z-50">
        {/* Mobile/Desktop Toggle */}
        {window.innerWidth < 1024 && (
          <Button
            onClick={() => setForceDesktop(!forceDesktop)}
            className="rounded-full w-12 h-12 bg-gray-700 hover:bg-gray-600 shadow-lg"
            title={forceDesktop ? "Switch to Mobile View" : "Switch to Desktop View"}
          >
            {forceDesktop ? (
              <Smartphone className="h-5 w-5" />
            ) : (
              <Monitor className="h-5 w-5" />
            )}
          </Button>
        )}

        {/* Demo Scenarios */}
        <Button
          onClick={() => setShowDemos(true)}
          className="rounded-full w-12 h-12 bg-purple-600 hover:bg-purple-700 shadow-lg"
          title="View Demo Scenarios"
        >
          <Play className="h-5 w-5" />
        </Button>

        {/* Help */}
        <Button
          onClick={() => setShowHelp(true)}
          className="rounded-full w-12 h-12 bg-blue-600 hover:bg-blue-700 shadow-lg"
          title="Get Help"
        >
          <HelpCircle className="h-5 w-5" />
        </Button>

        {/* Settings */}
        <Button
          onClick={() => console.log('Open settings')}
          className="rounded-full w-12 h-12 bg-gray-600 hover:bg-gray-500 shadow-lg"
          title="Settings"
        >
          <Settings className="h-5 w-5" />
        </Button>
      </div>

      {/* Demo Scenarios Modal */}
      <Dialog open={showDemos} onOpenChange={setShowDemos}>
        <DialogContent className="max-w-6xl max-h-[90vh] bg-gray-900 border-gray-700 overflow-hidden">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-white">Demo Scenarios</DialogTitle>
            <DialogDescription className="text-gray-400">
              Explore different use cases and scenarios to get started with the Modern Agent Framework
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-between mb-4">
            <div /> {/* Spacer */}
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDemosClose}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <div className="overflow-auto max-h-[75vh]">
            <DemoScenarios />
          </div>
        </DialogContent>
      </Dialog>

      {/* Help Modal */}
      <Dialog open={showHelp} onOpenChange={setShowHelp}>
        <DialogContent className="max-w-4xl max-h-[90vh] bg-gray-900 border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white">Quick Help</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowHelp(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <div className="space-y-4 max-h-[70vh] overflow-auto">
            <QuickHelpContent onViewFullHelp={() => {
              setShowHelp(false)
              window.open('/help', '_blank')
            }} />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function QuickHelpContent({ onViewFullHelp }: { onViewFullHelp: () => void }) {
  const helpCards = [
    {
      title: 'Creating Your First Agent',
      content: 'Simply describe what you need: "I need a data analyst agent" or "Help me with research"',
      example: '"I need help analyzing customer feedback data"'
    },
    {
      title: 'Installing Tools (MCPs)',
      content: 'Ask for capabilities: "Add web search" or "Install data processing tools"',
      example: '"Add web scraping capabilities to my agent"'
    },
    {
      title: 'Setting Up Collaborations',
      content: 'Describe your workflow: "Set up a research team" or "Create a content pipeline"',
      example: '"Set up a team for market analysis and reporting"'
    },
    {
      title: 'Getting Better Results',
      content: 'Be specific about your goals, mention data types, and describe desired outcomes',
      example: '"Analyze Q3 sales data and create charts showing regional performance"'
    }
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-white mb-2">Getting Started</h3>
        <p className="text-gray-400">
          Our intelligent chat understands natural language. Just describe what you want to achieve!
        </p>
      </div>

      <div className="grid gap-4">
        {helpCards.map((card, index) => (
          <div key={index} className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
            <h4 className="font-semibold text-white mb-2">{card.title}</h4>
            <p className="text-gray-300 text-sm mb-3">{card.content}</p>
            <div className="bg-black/40 rounded p-3 border border-gray-600">
              <p className="text-blue-300 text-sm italic">Example: {card.example}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center space-y-3">
        <Button onClick={onViewFullHelp} className="bg-blue-600 hover:bg-blue-700">
          View Complete Help Center
        </Button>
        <p className="text-gray-400 text-sm">
          Access detailed guides, tutorials, and troubleshooting information
        </p>
      </div>
    </div>
  )
}
