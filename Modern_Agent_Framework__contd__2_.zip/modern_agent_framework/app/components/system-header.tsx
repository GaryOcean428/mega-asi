
'use client'

import { useState, useEffect } from 'react'
import { useSession, signOut } from 'next-auth/react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Activity, 
  Brain, 
  Settings, 
  RefreshCw,
  Users,
  CheckCircle,
  AlertCircle,
  Clock,
  Cpu,
  Home,
  MessageSquare,
  Play,
  HelpCircle,
  LogOut,
  User,
  LogIn,
  UserPlus
} from 'lucide-react'
import { SystemHealth, AgentMetrics } from '@/lib/types'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export function SystemHeader() {
  const { data: session, status } = useSession() || {}
  const [metrics, setMetrics] = useState<AgentMetrics | null>(null)
  const [health, setHealth] = useState<SystemHealth | null>(null)
  const [loading, setLoading] = useState(true)
  const pathname = usePathname()

  const fetchMetrics = async () => {
    try {
      const response = await fetch('/api/system/metrics')
      const data = await response.json()
      
      if (data.metrics) {
        setMetrics(data.metrics)
      }
      if (data.health) {
        setHealth(data.health)
      }
    } catch (error) {
      console.error('Failed to fetch system metrics:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMetrics()
    const interval = setInterval(fetchMetrics, 30000) // Update every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const getHealthColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-500'
      case 'warning': case 'idle': return 'text-yellow-500'
      case 'error': return 'text-red-500'
      default: return 'text-gray-500'
    }
  }

  const getHealthIcon = (status: string) => {
    switch (status) {
      case 'healthy': return CheckCircle
      case 'warning': case 'idle': return AlertCircle
      case 'error': return AlertCircle
      default: return Clock
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-800 bg-black/95 backdrop-blur supports-[backdrop-filter]:bg-black/60">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
              <Brain className="h-6 w-6 text-blue-500" />
              <span className="text-lg font-bold text-white">Agent Framework</span>
            </Link>

            {/* Navigation Links */}
            <nav className="flex items-center space-x-6">
              <Link 
                href="/" 
                className={`flex items-center space-x-1 text-sm transition-colors ${
                  pathname === '/' 
                    ? 'text-white font-medium' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Home className="h-4 w-4" />
                <span>Dashboard</span>
              </Link>
              
              <Link 
                href="/chat/intelligent" 
                className={`flex items-center space-x-1 text-sm transition-colors ${
                  pathname === '/chat/intelligent' 
                    ? 'text-white font-medium' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <MessageSquare className="h-4 w-4" />
                <span>Intelligent Chat</span>
              </Link>
              
              <Link 
                href="/models" 
                className={`flex items-center space-x-1 text-sm transition-colors ${
                  pathname === '/models' 
                    ? 'text-white font-medium' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Cpu className="h-4 w-4" />
                <span>AI Models</span>
              </Link>
              
              <Link 
                href="/demos" 
                className={`flex items-center space-x-1 text-sm transition-colors ${
                  pathname === '/demos' 
                    ? 'text-white font-medium' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Play className="h-4 w-4" />
                <span>Demos</span>
              </Link>
              
              <Link 
                href="/help" 
                className={`flex items-center space-x-1 text-sm transition-colors ${
                  pathname === '/help' 
                    ? 'text-white font-medium' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <HelpCircle className="h-4 w-4" />
                <span>Help</span>
              </Link>
            </nav>
          </div>

          <div className="flex items-center space-x-6">
            {/* System Health & Metrics - only for authenticated users */}
            {!loading && metrics && health && session && (
              <>
                <div className="flex items-center space-x-2">
                  {Object.entries(health).map(([key, status]) => {
                    if (key === 'lastUpdated') return null
                    
                    const Icon = getHealthIcon(status as string)
                    return (
                      <div key={key} className="flex items-center space-x-1">
                        <Icon className={`h-4 w-4 ${getHealthColor(status as string)}`} />
                        <span className="text-xs text-gray-400 capitalize">{key}</span>
                      </div>
                    )
                  })}
                </div>

                <div className="flex items-center space-x-4">
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                    <Users className="h-3 w-3 mr-1" />
                    {metrics.activeAgents}/{metrics.totalAgents} Active
                  </Badge>
                  
                  <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    {metrics.completedTasks} Completed
                  </Badge>
                  
                  <Badge variant="outline" className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">
                    <Clock className="h-3 w-3 mr-1" />
                    {metrics.pendingTasks} Pending
                  </Badge>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={fetchMetrics}
                  className="text-gray-400 hover:text-white"
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </>
            )}

            {/* Authentication */}
            {status === 'loading' ? (
              <div className="w-8 h-8 bg-gray-700 rounded-full animate-pulse" />
            ) : session ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={session.user?.image || ""} alt={session.user?.name || ""} />
                      <AvatarFallback className="bg-blue-500 text-white">
                        {session.user?.name?.[0]?.toUpperCase() || session.user?.email?.[0]?.toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{session.user?.name}</p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {session.user?.email}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard" className="flex items-center">
                      <User className="mr-2 h-4 w-4" />
                      <span>Dashboard</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="flex items-center">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => signOut({ callbackUrl: '/' })}
                    className="text-red-600"
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sign out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-3">
                <Link href="/auth/signin">
                  <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                    <LogIn className="h-4 w-4 mr-2" />
                    Sign In
                  </Button>
                </Link>
                <Link href="/auth/signup">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
