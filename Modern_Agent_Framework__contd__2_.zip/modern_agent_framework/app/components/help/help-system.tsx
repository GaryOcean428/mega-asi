
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  HelpCircle, 
  Search, 
  Book, 
  Video, 
  MessageSquare,
  Lightbulb,
  ExternalLink,
  ChevronRight,
  Star,
  Clock,
  User,
  Bot,
  Zap,
  Users,
  Settings,
  Keyboard,
  BarChart3
} from 'lucide-react'

interface HelpArticle {
  id: string
  title: string
  category: 'getting-started' | 'agents' | 'chat' | 'collaborations' | 'mcps' | 'troubleshooting'
  type: 'article' | 'video' | 'interactive'
  description: string
  content: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  readTime: string
  rating: number
  tags: string[]
  lastUpdated: Date
  popular: boolean
}

interface FAQ {
  id: string
  question: string
  answer: string
  category: string
  helpful: number
}

export function HelpSystem() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedArticle, setSelectedArticle] = useState<HelpArticle | null>(null)
  const [activeCategory, setActiveCategory] = useState<string>('all')

  const articles: HelpArticle[] = [
    {
      id: 'getting-started-guide',
      title: 'Getting Started with Intelligent Chat',
      category: 'getting-started',
      type: 'article',
      description: 'Learn how to create your first agent using natural conversation',
      content: `
# Getting Started with Intelligent Chat

Welcome to the most intuitive way to create AI agents and workflows! This guide will help you get started with our intelligent chat system.

## What is Intelligent Chat?

Intelligent Chat is an AI-powered interface that understands your goals and automatically creates agents, installs tools, and sets up collaborations for you. No technical knowledge required!

## Your First Agent

Simply type what you want to achieve:

**Example**: "I need help analyzing customer data"

The system will:
1. **Recognize your intent** - Understanding you want data analysis
2. **Suggest solutions** - Recommend a Data Analyst agent template
3. **Create the agent** - Set up the agent with relevant tools
4. **Install tools** - Add data processing and visualization capabilities
5. **You're ready!** - Start using your new agent immediately

## Best Practices

- **Be specific** about your goals
- **Mention the type of data** you're working with
- **Describe the outcome** you want to achieve
- **Ask follow-up questions** to refine your setup

## Next Steps

Once you have your first agent:
- Try creating a collaboration with multiple agents
- Install additional MCP tools for more capabilities
- Explore workflow automation options
      `,
      difficulty: 'beginner',
      readTime: '5 min read',
      rating: 4.9,
      tags: ['getting-started', 'chat', 'agents', 'beginner'],
      lastUpdated: new Date('2024-01-15'),
      popular: true
    },
    {
      id: 'agent-types-guide',
      title: 'Understanding Agent Types and Capabilities',
      category: 'agents',
      type: 'article',
      description: 'Complete guide to different agent types and their specialized capabilities',
      content: `
# Agent Types and Capabilities

Our platform supports various specialized agent types, each optimized for specific tasks.

## Agent Categories

### 🔍 Research Agents
- **Web Research**: Gather information from multiple sources
- **Data Collection**: Structured data gathering and organization
- **Fact Checking**: Verify information accuracy
- **Market Analysis**: Competitive intelligence and trends

**Best for**: Market research, academic research, competitive analysis

### 📊 Data Analysis Agents
- **Statistical Analysis**: Advanced statistical computations
- **Data Visualization**: Charts, graphs, and interactive dashboards
- **Pattern Recognition**: Identify trends and anomalies
- **Reporting**: Automated report generation

**Best for**: Business intelligence, data science, reporting

### 💻 Development Agents
- **Code Generation**: Write code in multiple languages
- **Code Review**: Automated code quality assessment
- **Testing**: Unit tests, integration tests, debugging
- **Documentation**: API docs, code comments

**Best for**: Software development, DevOps, code maintenance

### ✍️ Content Creation Agents
- **Writing**: Blog posts, articles, copy
- **Editing**: Grammar, style, SEO optimization
- **Social Media**: Post creation, scheduling
- **Translation**: Multi-language content adaptation

**Best for**: Content marketing, blogging, social media management

### 🎯 Project Management Agents
- **Task Coordination**: Workflow management
- **Scheduling**: Calendar integration, reminders
- **Team Communication**: Status updates, reporting
- **Resource Planning**: Allocation and tracking

**Best for**: Project coordination, team management, planning
      `,
      difficulty: 'intermediate',
      readTime: '8 min read',
      rating: 4.7,
      tags: ['agents', 'capabilities', 'types', 'intermediate'],
      lastUpdated: new Date('2024-01-12'),
      popular: true
    },
    {
      id: 'collaboration-setup',
      title: 'Setting Up Multi-Agent Collaborations',
      category: 'collaborations',
      type: 'interactive',
      description: 'Step-by-step guide to creating powerful multi-agent teams',
      content: `
# Multi-Agent Collaborations

Learn how to create powerful teams of AI agents that work together seamlessly.

## Collaboration Types

### Sequential Workflows
Agents work one after another in a defined order.

**Example**: Research → Analysis → Report
1. Research Agent gathers data
2. Analysis Agent processes findings
3. Content Agent creates final report

### Parallel Processing
Multiple agents work simultaneously on different aspects.

**Example**: Content creation team
- Researcher gathers topic information
- Writer creates initial draft
- SEO Specialist optimizes for search
- Editor reviews and polishes

### Hierarchical Management
Manager agent coordinates worker agents.

**Example**: Project management
- Project Manager Agent oversees
- Specialist agents handle specific tasks
- Manager aggregates results and reports

## Creating Your First Collaboration

Simply describe your goal:
"Set up a research team to analyze market trends"

The system will automatically:
1. Identify the collaboration pattern needed
2. Suggest relevant agent templates
3. Set up the workflow connections
4. Configure communication protocols
5. Initialize the collaboration

## Best Practices

- **Clear role definition** - Each agent should have distinct responsibilities
- **Proper sequencing** - Order tasks logically
- **Communication protocols** - Define how agents share information
- **Quality checkpoints** - Include review stages
- **Scalability planning** - Design for growth and changes
      `,
      difficulty: 'intermediate',
      readTime: '12 min read',
      rating: 4.8,
      tags: ['collaborations', 'workflows', 'teams', 'advanced'],
      lastUpdated: new Date('2024-01-10'),
      popular: false
    }
  ]

  const faqs: FAQ[] = [
    {
      id: 'what-is-intelligent-chat',
      question: 'What makes the chat "intelligent"?',
      answer: 'Our chat system uses advanced AI to understand your intent, automatically suggest solutions, and create agents or workflows based on natural conversation. You don\'t need to navigate complex menus or fill out forms.',
      category: 'general',
      helpful: 156
    },
    {
      id: 'agent-creation-time',
      question: 'How long does it take to create an agent?',
      answer: 'Most agents are created instantly (within 2-5 seconds) after you describe what you need. Complex multi-agent collaborations might take 30-60 seconds to fully configure.',
      category: 'agents',
      helpful: 89
    },
    {
      id: 'mcp-compatibility',
      question: 'Are all MCPs compatible with every agent?',
      answer: 'MCPs are automatically matched to compatible agents. Our system ensures that only relevant and compatible tools are suggested and installed for each agent type.',
      category: 'mcps',
      helpful: 67
    },
    {
      id: 'collaboration-limits',
      question: 'How many agents can work in a collaboration?',
      answer: 'You can have up to 10 agents in a single collaboration. For larger teams, we recommend creating multiple smaller collaborations that can communicate with each other.',
      category: 'collaborations',
      helpful: 34
    }
  ]

  const filteredArticles = articles.filter(article => {
    const matchesSearch = searchQuery === '' || 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    
    const matchesCategory = activeCategory === 'all' || article.category === activeCategory
    
    return matchesSearch && matchesCategory
  })

  const categories = [
    { id: 'all', label: 'All', icon: <Book className="h-4 w-4" /> },
    { id: 'getting-started', label: 'Getting Started', icon: <Lightbulb className="h-4 w-4" /> },
    { id: 'chat', label: 'Intelligent Chat', icon: <MessageSquare className="h-4 w-4" /> },
    { id: 'agents', label: 'Agents', icon: <Bot className="h-4 w-4" /> },
    { id: 'collaborations', label: 'Collaborations', icon: <Users className="h-4 w-4" /> },
    { id: 'mcps', label: 'MCP Tools', icon: <Zap className="h-4 w-4" /> },
    { id: 'troubleshooting', label: 'Troubleshooting', icon: <Settings className="h-4 w-4" /> }
  ]

  const quickHelp = [
    {
      title: 'Keyboard Shortcuts',
      description: 'Speed up your workflow with keyboard shortcuts',
      icon: <Keyboard className="h-5 w-5" />,
      action: () => console.log('Show shortcuts')
    },
    {
      title: 'Video Tutorials',
      description: 'Watch step-by-step video guides',
      icon: <Video className="h-5 w-5" />,
      action: () => console.log('Open videos')
    },
    {
      title: 'Community Forum',
      description: 'Get help from other users and experts',
      icon: <User className="h-5 w-5" />,
      action: () => console.log('Open forum')
    },
    {
      title: 'Feature Requests',
      description: 'Suggest new features and improvements',
      icon: <Lightbulb className="h-5 w-5" />,
      action: () => console.log('Submit feature request')
    }
  ]

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-3 flex items-center justify-center space-x-3">
          <HelpCircle className="h-8 w-8 text-blue-400" />
          <span>Help Center</span>
        </h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Everything you need to know about creating agents, managing collaborations, and maximizing your workflow efficiency.
        </p>
      </div>

      {/* Search */}
      <div className="relative max-w-2xl mx-auto">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
        <Input
          placeholder="Search for help articles, guides, and tutorials..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 py-3 text-lg bg-gray-800/50 border-gray-600"
        />
      </div>

      {/* Quick Help Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {quickHelp.map((item, index) => (
          <Card key={index} className="cursor-pointer hover:bg-gray-800/50 transition-colors">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                {item.icon}
              </div>
              <h3 className="font-semibold text-white mb-1">{item.title}</h3>
              <p className="text-sm text-gray-400">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Categories Sidebar */}
        <div className="space-y-2">
          <h3 className="font-semibold text-white mb-3">Categories</h3>
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? "default" : "ghost"}
              onClick={() => setActiveCategory(category.id)}
              className="w-full justify-start"
            >
              {category.icon}
              <span className="ml-2">{category.label}</span>
            </Button>
          ))}
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <Tabs value="articles" onValueChange={() => {}} className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="articles">Articles & Guides</TabsTrigger>
              <TabsTrigger value="faq">FAQ</TabsTrigger>
            </TabsList>

            <TabsContent value="articles" className="space-y-4">
              {filteredArticles.length > 0 ? (
                <div className="space-y-4">
                  {filteredArticles.map((article) => (
                    <Card key={article.id} className="hover:bg-gray-800/30 transition-colors">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="text-lg font-semibold text-white">{article.title}</h3>
                              {article.popular && (
                                <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300">
                                  <Star className="h-3 w-3 mr-1" />
                                  Popular
                                </Badge>
                              )}
                            </div>
                            <p className="text-gray-300 text-sm mb-3">{article.description}</p>
                            
                            <div className="flex items-center space-x-4 text-sm text-gray-400">
                              <div className="flex items-center space-x-1">
                                <Clock className="h-3 w-3" />
                                <span>{article.readTime}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                <span>{article.rating}</span>
                              </div>
                              <Badge variant="outline" className="text-xs">
                                {article.difficulty}
                              </Badge>
                            </div>
                          </div>
                          
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => setSelectedArticle(article)}
                              >
                                Read More
                                <ChevronRight className="h-4 w-4 ml-1" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[80vh] bg-gray-900 border-gray-700">
                              <DialogHeader>
                                <DialogTitle className="text-white">{article.title}</DialogTitle>
                              </DialogHeader>
                              <ScrollArea className="max-h-[60vh] mt-4">
                                <div className="prose prose-invert max-w-none">
                                  <div className="whitespace-pre-line text-gray-300">
                                    {article.content}
                                  </div>
                                </div>
                              </ScrollArea>
                            </DialogContent>
                          </Dialog>
                        </div>
                        
                        <div className="flex flex-wrap gap-1">
                          {article.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Book className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">No articles found</h3>
                    <p className="text-gray-400">Try adjusting your search or browse different categories</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="faq" className="space-y-4">
              {faqs.map((faq) => (
                <Card key={faq.id}>
                  <CardContent className="p-6">
                    <h4 className="font-semibold text-white mb-3">{faq.question}</h4>
                    <p className="text-gray-300 mb-4">{faq.answer}</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{faq.category}</Badge>
                      <div className="flex items-center space-x-2 text-sm text-gray-400">
                        <span>{faq.helpful} found helpful</span>
                        <Button variant="ghost" size="sm">
                          👍
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
