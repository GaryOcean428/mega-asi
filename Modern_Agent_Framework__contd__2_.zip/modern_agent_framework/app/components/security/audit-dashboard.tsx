
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts'
import {
  Shield,
  AlertTriangle,
  Activity,
  Search,
  Download,
  Filter,
  Calendar,
  Clock,
  User,
  FileText,
  Eye,
  RefreshCw,
  TrendingUp,
  AlertCircle
} from 'lucide-react'
import { AuditEvent, AuditFilter, AuditReport, useAuditLogger } from '@/lib/audit/audit-logger'
import { useAnalytics } from '@/lib/analytics/collector'

const SEVERITY_COLORS = {
  low: '#10B981',
  medium: '#F59E0B', 
  high: '#EF4444',
  critical: '#7C2D12'
}

const OUTCOME_COLORS = {
  success: '#10B981',
  failure: '#EF4444',
  partial: '#F59E0B'
}

export function AuditDashboard() {
  const [events, setEvents] = useState<AuditEvent[]>([])
  const [filteredEvents, setFilteredEvents] = useState<AuditEvent[]>([])
  const [filter, setFilter] = useState<AuditFilter>({
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    endDate: new Date()
  })
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [selectedEvent, setSelectedEvent] = useState<AuditEvent | null>(null)
  
  const { queryEvents, generateReport, exportEvents, subscribe } = useAuditLogger()
  const { trackFeatureUsage, trackInteraction } = useAnalytics()

  useEffect(() => {
    trackFeatureUsage('audit-dashboard', 'view')
    loadAuditEvents()
    
    // Subscribe to real-time events
    const unsubscribe = subscribe((event) => {
      setEvents(prev => [event, ...prev.slice(0, 999)]) // Keep latest 1000 events
    })
    
    return unsubscribe
  }, [])

  useEffect(() => {
    applyFilters()
  }, [events, filter, searchQuery])

  const loadAuditEvents = async () => {
    try {
      setLoading(true)
      const auditEvents = await queryEvents(filter)
      setEvents(auditEvents)
    } catch (error) {
      console.error('Failed to load audit events:', error)
      // Use mock data for demonstration
      setEvents(getMockAuditEvents())
    } finally {
      setLoading(false)
    }
  }

  const applyFilters = () => {
    let filtered = events

    // Apply search
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(event =>
        event.action.toLowerCase().includes(query) ||
        event.userId?.toLowerCase().includes(query) ||
        event.userEmail?.toLowerCase().includes(query) ||
        event.resource?.name?.toLowerCase().includes(query) ||
        JSON.stringify(event.details).toLowerCase().includes(query)
      )
    }

    setFilteredEvents(filtered)
  }

  const handleFilterChange = (key: keyof AuditFilter, value: any) => {
    const newFilter = { ...filter, [key]: value }
    setFilter(newFilter)
    loadAuditEvents()
  }

  const handleExportEvents = async (format: 'json' | 'csv' | 'pdf') => {
    try {
      const data = await exportEvents(filter, format)
      
      // Create download
      const blob = new Blob([data], { 
        type: format === 'json' ? 'application/json' : 'text/csv' 
      })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `audit-events-${new Date().toISOString().split('T')[0]}.${format}`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      
      trackInteraction('audit-dashboard', 'export_events', { format })
    } catch (error) {
      console.error('Failed to export events:', error)
    }
  }

  const handleGenerateReport = async () => {
    try {
      const report = await generateReport(
        'Security Audit Report',
        `Comprehensive audit report for ${filter.startDate?.toDateString()} to ${filter.endDate?.toDateString()}`,
        filter,
        'current-user-id'
      )
      
      // In production, this would save the report or redirect to report page
      console.log('Generated report:', report)
      trackInteraction('audit-dashboard', 'generate_report')
    } catch (error) {
      console.error('Failed to generate report:', error)
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'bg-green-500/20 text-green-300'
      case 'medium': return 'bg-yellow-500/20 text-yellow-300'
      case 'high': return 'bg-red-500/20 text-red-300'
      case 'critical': return 'bg-red-800/20 text-red-200'
      default: return 'bg-gray-500/20 text-gray-300'
    }
  }

  const getOutcomeColor = (outcome: string) => {
    switch (outcome) {
      case 'success': return 'bg-green-500/20 text-green-300'
      case 'failure': return 'bg-red-500/20 text-red-300'
      case 'partial': return 'bg-yellow-500/20 text-yellow-300'
      default: return 'bg-gray-500/20 text-gray-300'
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'auth': return <Shield className="h-4 w-4" />
      case 'security': return <AlertTriangle className="h-4 w-4" />
      case 'system': return <Activity className="h-4 w-4" />
      case 'data': return <FileText className="h-4 w-4" />
      default: return <Eye className="h-4 w-4" />
    }
  }

  const getEventStats = () => {
    const total = filteredEvents.length
    const bySeverity = filteredEvents.reduce((acc, event) => {
      acc[event.severity] = (acc[event.severity] || 0) + 1
      return acc
    }, {} as Record<string, number>)
    
    const byCategory = filteredEvents.reduce((acc, event) => {
      acc[event.category] = (acc[event.category] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    const byOutcome = filteredEvents.reduce((acc, event) => {
      acc[event.outcome] = (acc[event.outcome] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    return { total, bySeverity, byCategory, byOutcome }
  }

  const stats = getEventStats()

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Security Audit Dashboard</h1>
          <p className="text-gray-400 mt-2">
            Monitor system activities, security events, and compliance
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={() => loadAuditEvents()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button variant="outline" onClick={handleGenerateReport}>
            <FileText className="h-4 w-4 mr-2" />
            Generate Report
          </Button>
          
          <Select onValueChange={(format) => handleExportEvents(format as any)}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Export" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="json">Export JSON</SelectItem>
              <SelectItem value="csv">Export CSV</SelectItem>
              <SelectItem value="pdf">Export PDF</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Activity className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{stats.total}</div>
                <div className="text-sm text-gray-400">Total Events</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-500/20 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-red-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">
                  {(stats.bySeverity.high || 0) + (stats.bySeverity.critical || 0)}
                </div>
                <div className="text-sm text-gray-400">High/Critical</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-600/20 rounded-lg">
                <AlertCircle className="h-6 w-6 text-red-500" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">
                  {stats.byOutcome.failure || 0}
                </div>
                <div className="text-sm text-gray-400">Failed Events</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <Shield className="h-6 w-6 text-green-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">
                  {Math.round(((stats.byOutcome.success || 0) / stats.total) * 100) || 0}%
                </div>
                <div className="text-sm text-gray-400">Success Rate</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search events..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">Category</label>
              <Select 
                value={filter.category || 'all'} 
                onValueChange={(value) => handleFilterChange('category', value === 'all' ? undefined : value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="auth">Authentication</SelectItem>
                  <SelectItem value="security">Security</SelectItem>
                  <SelectItem value="agents">Agents</SelectItem>
                  <SelectItem value="system">System</SelectItem>
                  <SelectItem value="data">Data Access</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">Severity</label>
              <Select 
                value={filter.severity || 'all'} 
                onValueChange={(value) => handleFilterChange('severity', value === 'all' ? undefined : value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">Outcome</label>
              <Select 
                value={filter.outcome || 'all'} 
                onValueChange={(value) => handleFilterChange('outcome', value === 'all' ? undefined : value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Outcomes</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="failure">Failure</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">Time Range</label>
              <Select 
                value="7d"
                onValueChange={(value) => {
                  const now = new Date()
                  let startDate: Date
                  
                  switch (value) {
                    case '24h':
                      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000)
                      break
                    case '7d':
                      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
                      break
                    case '30d':
                      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
                      break
                    case '90d':
                      startDate = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000)
                      break
                    default:
                      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
                  }
                  
                  handleFilterChange('startDate', startDate)
                  handleFilterChange('endDate', now)
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="24h">Last 24 hours</SelectItem>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value="events" onValueChange={() => {}} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="events">Event Log</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="alerts">Security Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="events">
          <AuditEventsList
            events={filteredEvents}
            loading={loading}
            onEventSelect={setSelectedEvent}
            getSeverityColor={getSeverityColor}
            getOutcomeColor={getOutcomeColor}
            getCategoryIcon={getCategoryIcon}
          />
        </TabsContent>

        <TabsContent value="analytics">
          <AuditAnalytics events={filteredEvents} />
        </TabsContent>

        <TabsContent value="alerts">
          <SecurityAlerts events={filteredEvents.filter(e => e.category === 'security' || e.severity === 'critical')} />
        </TabsContent>
      </Tabs>

      {/* Event Detail Modal */}
      {selectedEvent && (
        <EventDetailDialog
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          getSeverityColor={getSeverityColor}
          getOutcomeColor={getOutcomeColor}
          getCategoryIcon={getCategoryIcon}
        />
      )}
    </div>
  )
}

function AuditEventsList({
  events,
  loading,
  onEventSelect,
  getSeverityColor,
  getOutcomeColor,
  getCategoryIcon
}: {
  events: AuditEvent[]
  loading: boolean
  onEventSelect: (event: AuditEvent) => void
  getSeverityColor: (severity: string) => string
  getOutcomeColor: (outcome: string) => string
  getCategoryIcon: (category: string) => React.ReactNode
}) {
  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (events.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <Shield className="h-16 w-16 text-gray-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No audit events found</h3>
          <p className="text-gray-400">Try adjusting your filters or time range</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-white">Audit Events</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96">
          <div className="space-y-2">
            {events.map((event) => (
              <div
                key={event.id}
                className="p-4 border border-gray-700 rounded-lg hover:bg-gray-800/50 cursor-pointer transition-colors"
                onClick={() => onEventSelect(event)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className="p-2 bg-gray-800 rounded-lg">
                      {getCategoryIcon(event.category)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-medium text-white">{event.action}</h4>
                        <Badge className={getSeverityColor(event.severity)}>
                          {event.severity}
                        </Badge>
                        <Badge className={getOutcomeColor(event.outcome)}>
                          {event.outcome}
                        </Badge>
                      </div>
                      
                      <div className="text-sm text-gray-400 mb-2">
                        {event.userEmail || event.userId || 'System'} • {event.category}
                        {event.resource && ` • ${event.resource.type}:${event.resource.name || event.resource.id}`}
                      </div>
                      
                      <div className="text-xs text-gray-500 flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>{event.timestamp.toLocaleString()}</span>
                        </div>
                        {event.metadata.ip && (
                          <div>IP: {event.metadata.ip}</div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

function AuditAnalytics({ events }: { events: AuditEvent[] }) {
  const getTimeSeriesData = () => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date()
      date.setDate(date.getDate() - (6 - i))
      return {
        date: date.toISOString().split('T')[0],
        events: events.filter(e => 
          e.timestamp.toDateString() === date.toDateString()
        ).length,
        failures: events.filter(e => 
          e.timestamp.toDateString() === date.toDateString() && 
          e.outcome === 'failure'
        ).length
      }
    })
    return last7Days
  }

  const getSeverityData = () => {
    return Object.entries(
      events.reduce((acc, event) => {
        acc[event.severity] = (acc[event.severity] || 0) + 1
        return acc
      }, {} as Record<string, number>)
    ).map(([severity, count]) => ({ severity, count }))
  }

  const getCategoryData = () => {
    return Object.entries(
      events.reduce((acc, event) => {
        acc[event.category] = (acc[event.category] || 0) + 1
        return acc
      }, {} as Record<string, number>)
    ).map(([category, count]) => ({ category, count }))
  }

  const timeSeriesData = getTimeSeriesData()
  const severityData = getSeverityData()
  const categoryData = getCategoryData()

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Event Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-white">Event Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={timeSeriesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: '1px solid #374151',
                  borderRadius: '8px'
                }}
              />
              <Area
                type="monotone"
                dataKey="events"
                stackId="1"
                stroke="#3B82F6"
                fill="#3B82F6"
                fillOpacity={0.6}
              />
              <Area
                type="monotone"
                dataKey="failures"
                stackId="2"
                stroke="#EF4444"
                fill="#EF4444"
                fillOpacity={0.8}
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Severity Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="text-white">Severity Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={severityData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="count"
                label={({ severity, percent }) => 
                  `${severity} (${(percent * 100).toFixed(0)}%)`
                }
              >
                {severityData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={Object.values(SEVERITY_COLORS)[index % Object.values(SEVERITY_COLORS).length]} 
                  />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Category Breakdown */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-white">Events by Category</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={categoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="category" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: '1px solid #374151',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="count" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

function SecurityAlerts({ events }: { events: AuditEvent[] }) {
  const criticalEvents = events.filter(e => e.severity === 'critical')
  const securityEvents = events.filter(e => e.category === 'security')
  const recentAlerts = [...criticalEvents, ...securityEvents]
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
    .slice(0, 10)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-red-400" />
            <span>Recent Security Alerts</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentAlerts.length === 0 ? (
            <div className="text-center py-8">
              <Shield className="h-12 w-12 text-green-500 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-white mb-2">All Clear</h3>
              <p className="text-gray-400">No security alerts in the selected time period</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentAlerts.map((event) => (
                <div
                  key={event.id}
                  className="p-4 border-l-4 border-red-500 bg-red-500/10 rounded-lg"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-white mb-1">{event.action}</h4>
                      <p className="text-sm text-gray-300 mb-2">
                        {JSON.stringify(event.details)}
                      </p>
                      <div className="text-xs text-gray-400">
                        {event.timestamp.toLocaleString()} • 
                        {event.userEmail || event.userId || 'System'}
                      </div>
                    </div>
                    <Badge className={event.severity === 'critical' ? 'bg-red-800/20 text-red-200' : 'bg-red-500/20 text-red-300'}>
                      {event.severity}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function EventDetailDialog({
  event,
  onClose,
  getSeverityColor,
  getOutcomeColor,
  getCategoryIcon
}: {
  event: AuditEvent
  onClose: () => void
  getSeverityColor: (severity: string) => string
  getOutcomeColor: (outcome: string) => string
  getCategoryIcon: (category: string) => React.ReactNode
}) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center space-x-2">
              {getCategoryIcon(event.category)}
              <span>Audit Event Details</span>
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ×
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-300">Action</label>
              <div className="text-white">{event.action}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300">Category</label>
              <div className="text-white capitalize">{event.category}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300">Severity</label>
              <Badge className={getSeverityColor(event.severity)}>
                {event.severity}
              </Badge>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300">Outcome</label>
              <Badge className={getOutcomeColor(event.outcome)}>
                {event.outcome}
              </Badge>
            </div>
          </div>

          {/* User Info */}
          {event.userId && (
            <div>
              <label className="text-sm font-medium text-gray-300">User</label>
              <div className="text-white">
                {event.userName} ({event.userEmail || event.userId})
              </div>
            </div>
          )}

          {/* Resource Info */}
          {event.resource && (
            <div>
              <label className="text-sm font-medium text-gray-300">Resource</label>
              <div className="text-white">
                {event.resource.type}: {event.resource.name || event.resource.id}
              </div>
            </div>
          )}

          {/* Timestamp */}
          <div>
            <label className="text-sm font-medium text-gray-300">Timestamp</label>
            <div className="text-white">{event.timestamp.toLocaleString()}</div>
          </div>

          {/* Metadata */}
          <div>
            <label className="text-sm font-medium text-gray-300">Metadata</label>
            <div className="bg-gray-800 rounded-lg p-3 mt-2">
              <pre className="text-sm text-gray-300 overflow-x-auto">
                {JSON.stringify(event.metadata, null, 2)}
              </pre>
            </div>
          </div>

          {/* Details */}
          <div>
            <label className="text-sm font-medium text-gray-300">Details</label>
            <div className="bg-gray-800 rounded-lg p-3 mt-2">
              <pre className="text-sm text-gray-300 overflow-x-auto">
                {JSON.stringify(event.details, null, 2)}
              </pre>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Mock data for demonstration
function getMockAuditEvents(): AuditEvent[] {
  const now = new Date()
  const events: AuditEvent[] = []
  
  const actions = [
    'user_login', 'user_logout', 'agent_created', 'agent_deleted', 'role_granted',
    'permission_denied', 'data_accessed', 'system_config_changed', 'security_alert'
  ]
  
  const categories = ['auth', 'agents', 'security', 'system', 'data']
  const severities = ['low', 'medium', 'high', 'critical']
  const outcomes = ['success', 'failure', 'partial']
  
  for (let i = 0; i < 50; i++) {
    const timestamp = new Date(now.getTime() - Math.random() * 7 * 24 * 60 * 60 * 1000)
    const action = actions[Math.floor(Math.random() * actions.length)]
    const category = categories[Math.floor(Math.random() * categories.length)]
    const severity = severities[Math.floor(Math.random() * severities.length)]
    const outcome = outcomes[Math.floor(Math.random() * outcomes.length)]
    
    events.push({
      id: `audit_${i}`,
      timestamp,
      userId: `user_${Math.floor(Math.random() * 5) + 1}`,
      userEmail: `user${Math.floor(Math.random() * 5) + 1}@company.com`,
      userName: `User ${Math.floor(Math.random() * 5) + 1}`,
      action,
      category: category as any,
      resource: Math.random() > 0.5 ? {
        type: 'agent',
        id: `agent_${Math.floor(Math.random() * 10)}`,
        name: `Agent ${Math.floor(Math.random() * 10)}`
      } : undefined,
      details: {
        ip: `192.168.1.${Math.floor(Math.random() * 255)}`,
        userAgent: 'Mozilla/5.0...',
        success: outcome === 'success'
      },
      metadata: {
        ip: `192.168.1.${Math.floor(Math.random() * 255)}`,
        sessionId: `session_${i}`,
        organizationId: 'org_1'
      },
      severity: severity as any,
      outcome: outcome as any
    })
  }
  
  return events.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
}
