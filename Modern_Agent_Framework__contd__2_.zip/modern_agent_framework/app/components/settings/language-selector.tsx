
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Globe, Check } from 'lucide-react'
import { useTranslation, SUPPORTED_LANGUAGES } from '@/lib/i18n'

export function LanguageSelector() {
  const { language, setLanguage, availableLanguages, isRTL } = useTranslation()
  const [isChanging, setIsChanging] = useState(false)

  const handleLanguageChange = async (newLanguage: string) => {
    if (newLanguage === language) return
    
    setIsChanging(true)
    try {
      setLanguage(newLanguage as any)
      
      // Add a small delay for smooth transition
      await new Promise(resolve => setTimeout(resolve, 300))
    } catch (error) {
      console.error('Failed to change language:', error)
    } finally {
      setIsChanging(false)
    }
  }

  const currentLangData = availableLanguages.find(lang => lang.code === language)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-white flex items-center space-x-2">
          <Globe className="h-5 w-5" />
          <span>Language & Region</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Language Display */}
        <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg border border-gray-700">
          <div className="flex items-center space-x-3">
            <span className="text-2xl">{currentLangData?.flag}</span>
            <div>
              <div className="text-white font-medium">{currentLangData?.nativeName}</div>
              <div className="text-gray-400 text-sm">{currentLangData?.name}</div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {isRTL && <Badge variant="secondary" className="text-xs">RTL</Badge>}
            <Check className="h-4 w-4 text-green-400" />
          </div>
        </div>

        {/* Language Selector */}
        <div>
          <label className="text-sm font-medium text-gray-300 mb-3 block">
            Choose Language
          </label>
          <Select
            value={language}
            onValueChange={handleLanguageChange}
            disabled={isChanging}
          >
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {availableLanguages.map((lang) => (
                <SelectItem key={lang.code} value={lang.code}>
                  <div className="flex items-center space-x-3">
                    <span className="text-lg">{lang.flag}</span>
                    <div className="flex-1">
                      <div className="font-medium">{lang.nativeName}</div>
                      <div className="text-xs text-gray-500">{lang.name}</div>
                    </div>
                    {lang.code === language && (
                      <Check className="h-4 w-4 text-green-400" />
                    )}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Language Features Info */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-gray-300">Language Features</h4>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Interface</span>
              <Badge variant="secondary" className="text-xs">Translated</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Help Content</span>
              <Badge variant="secondary" className="text-xs">Translated</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Number Format</span>
              <Badge variant="secondary" className="text-xs">Localized</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Date Format</span>
              <Badge variant="secondary" className="text-xs">Localized</Badge>
            </div>
          </div>
        </div>

        {/* Language Stats */}
        <div className="pt-4 border-t border-gray-700">
          <div className="text-sm text-gray-400 text-center">
            {availableLanguages.length} languages supported
          </div>
        </div>

        {isChanging && (
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-400">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
            <span>Applying language changes...</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
