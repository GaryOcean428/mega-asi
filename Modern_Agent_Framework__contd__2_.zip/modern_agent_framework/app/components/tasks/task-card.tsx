
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Activity, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  XCircle,
  User,
  Trash2,
  PlayCircle,
  Calendar
} from 'lucide-react'
import { TaskWithRelations, TaskStatus, Priority } from '@/lib/types'

interface TaskCardProps {
  task: TaskWithRelations
  onUpdate: () => void
  onDelete: () => void
}

export function TaskCard({ task, onUpdate, onDelete }: TaskCardProps) {
  const [deleting, setDeleting] = useState(false)

  const getStatusColor = (status: TaskStatus) => {
    switch (status) {
      case TaskStatus.PENDING: return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case TaskStatus.IN_PROGRESS: return 'bg-blue-500/10 text-blue-400 border-blue-500/20'
      case TaskStatus.COMPLETED: return 'bg-green-500/10 text-green-400 border-green-500/20'
      case TaskStatus.FAILED: return 'bg-red-500/10 text-red-400 border-red-500/20'
      case TaskStatus.CANCELLED: return 'bg-gray-500/10 text-gray-400 border-gray-500/20'
      default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20'
    }
  }

  const getStatusIcon = (status: TaskStatus) => {
    switch (status) {
      case TaskStatus.PENDING: return Clock
      case TaskStatus.IN_PROGRESS: return Activity
      case TaskStatus.COMPLETED: return CheckCircle
      case TaskStatus.FAILED: return AlertCircle
      case TaskStatus.CANCELLED: return XCircle
      default: return Clock
    }
  }

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case Priority.LOW: return 'text-gray-400'
      case Priority.MEDIUM: return 'text-yellow-400'
      case Priority.HIGH: return 'text-orange-400'
      case Priority.URGENT: return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  const handleDelete = async () => {
    if (!confirm(`Are you sure you want to delete task "${task.title}"?`)) {
      return
    }

    setDeleting(true)
    try {
      const response = await fetch(`/api/tasks/${task.id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        onDelete()
      } else {
        console.error('Failed to delete task')
      }
    } catch (error) {
      console.error('Error deleting task:', error)
    } finally {
      setDeleting(false)
    }
  }

  const StatusIcon = getStatusIcon(task.status)

  return (
    <Card className="bg-gray-900/30 border-gray-800 hover:bg-gray-800/30 transition-all duration-200 hover:shadow-lg">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <CardTitle className="text-lg text-white line-clamp-1">
                {task.title}
              </CardTitle>
              <Badge 
                variant="outline" 
                className={`${getPriorityColor(task.priority)} border-current/20`}
              >
                {task.priority}
              </Badge>
            </div>
            <p className="text-sm text-gray-400 line-clamp-2">
              {task.description}
            </p>
          </div>
          <Badge variant="outline" className={getStatusColor(task.status)}>
            <StatusIcon className="h-3 w-3 mr-1" />
            {task.status.replace('_', ' ')}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Agent Assignment */}
        <div className="flex items-center space-x-2 text-sm">
          <User className="h-4 w-4 text-gray-500" />
          <span className="text-gray-400">Agent:</span>
          <span className="text-white">
            {task.agent?.name || 'Unassigned'}
          </span>
        </div>

        {/* Timestamps */}
        <div className="grid grid-cols-2 gap-4 text-xs text-gray-500">
          <div className="flex items-center space-x-1">
            <Calendar className="h-3 w-3" />
            <span>Created: {new Date(task.createdAt).toLocaleDateString()}</span>
          </div>
          {task.completedAt && (
            <div className="flex items-center space-x-1">
              <CheckCircle className="h-3 w-3" />
              <span>Completed: {new Date(task.completedAt).toLocaleDateString()}</span>
            </div>
          )}
        </div>

        {/* Task Result */}
        {task.result && (
          <div className="bg-gray-800/50 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Result:</div>
            <p className="text-sm text-gray-300 line-clamp-3">
              {task.result}
            </p>
          </div>
        )}

        {/* Task Stats */}
        <div className="grid grid-cols-3 gap-4 pt-2 border-t border-gray-700">
          <div className="text-center">
            <div className="text-lg font-semibold text-purple-400">
              {task.executions?.length || 0}
            </div>
            <div className="text-xs text-gray-500">Executions</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-blue-400">
              {task.messages?.length || 0}
            </div>
            <div className="text-xs text-gray-500">Messages</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-green-400">
              {task.subTasks?.length || 0}
            </div>
            <div className="text-xs text-gray-500">Subtasks</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2 pt-2">
          {task.status === TaskStatus.PENDING && task.agent && (
            <Button
              variant="outline"
              size="sm"
              className="flex-1 bg-blue-500/10 border-blue-500/20 text-blue-400 hover:bg-blue-500/20"
            >
              <PlayCircle className="h-3 w-3 mr-1" />
              Execute
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDelete}
            disabled={deleting}
            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
