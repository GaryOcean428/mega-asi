
'use client'

import { useState, useEffect } from 'react'
import { TaskCard } from './task-card'
import { LoadingSpinner } from '@/components/ui/loading-spinner'
import { TaskWithRelations } from '@/lib/types'
import { motion } from 'framer-motion'

interface TaskListProps {
  refreshKey: number
  onRefresh: () => void
}

export function TaskList({ refreshKey, onRefresh }: TaskListProps) {
  const [tasks, setTasks] = useState<TaskWithRelations[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchTasks = async () => {
    try {
      setError(null)
      const response = await fetch('/api/tasks?limit=20')
      
      if (!response.ok) {
        throw new Error('Failed to fetch tasks')
      }
      
      const data = await response.json()
      setTasks(data.tasks || [])
    } catch (error) {
      console.error('Error fetching tasks:', error)
      setError(error instanceof Error ? error.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTasks()
  }, [refreshKey])

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <div className="text-red-500 mb-4">Error loading tasks: {error}</div>
        <button 
          onClick={fetchTasks}
          className="text-blue-500 hover:text-blue-400 underline"
        >
          Try again
        </button>
      </div>
    )
  }

  if (tasks.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 text-lg mb-2">No tasks created yet</div>
        <div className="text-gray-500 text-sm">
          Create tasks to assign to your agents for execution.
        </div>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {tasks.map((task, index) => (
        <motion.div
          key={task.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <TaskCard 
            task={task} 
            onUpdate={onRefresh}
            onDelete={onRefresh}
          />
        </motion.div>
      ))}
    </div>
  )
}
