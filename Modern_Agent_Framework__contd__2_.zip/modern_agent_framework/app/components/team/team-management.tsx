
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Users, 
  Plus, 
  Search, 
  Settings, 
  Mail, 
  Shield, 
  Clock, 
  MoreVertical,
  UserPlus,
  UserMinus,
  Crown,
  Key,
  Calendar,
  Activity
} from 'lucide-react'
import { Role, Permission, UserRole, rbac } from '@/lib/auth/rbac'
import { auditLogger } from '@/lib/audit/audit-logger'
import { useAnalytics } from '@/lib/analytics/collector'

interface TeamMember {
  id: string
  email: string
  name: string
  avatar?: string
  roles: UserRole[]
  status: 'active' | 'pending' | 'disabled'
  joinedAt: Date
  lastActiveAt?: Date
  invitedBy?: string
}

interface TeamInvitation {
  id: string
  email: string
  role: Role
  invitedBy: string
  invitedAt: Date
  expiresAt: Date
  status: 'pending' | 'accepted' | 'expired' | 'cancelled'
}

export function TeamManagement({ organizationId }: { organizationId: string }) {
  const [members, setMembers] = useState<TeamMember[]>([])
  const [invitations, setInvitations] = useState<TeamInvitation[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedRole, setSelectedRole] = useState<Role | 'all'>('all')
  const [showInviteDialog, setShowInviteDialog] = useState(false)
  const [loading, setLoading] = useState(true)
  const { trackFeatureUsage, trackInteraction } = useAnalytics()

  useEffect(() => {
    trackFeatureUsage('team-management', 'view')
    loadTeamData()
  }, [])

  const loadTeamData = async () => {
    try {
      setLoading(true)
      // In production, these would be API calls
      setMembers(getMockMembers())
      setInvitations(getMockInvitations())
    } catch (error) {
      console.error('Failed to load team data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleInviteMember = async (email: string, role: Role, expiresIn: number) => {
    try {
      const invitation: TeamInvitation = {
        id: `inv_${Date.now()}`,
        email,
        role,
        invitedBy: 'current-user-id', // Would come from session
        invitedAt: new Date(),
        expiresAt: new Date(Date.now() + expiresIn * 24 * 60 * 60 * 1000),
        status: 'pending'
      }

      setInvitations(prev => [invitation, ...prev])
      
      // Send invitation email (would be done on server)
      await sendInvitationEmail(invitation)
      
      // Audit log
      await auditLogger.logSystemEvent('team_member_invited', 'current-user-id', {
        inviteeEmail: email,
        role,
        organizationId
      })

      trackInteraction('team-management', 'invite_member', { role })
      setShowInviteDialog(false)
    } catch (error) {
      console.error('Failed to invite member:', error)
    }
  }

  const handleRoleChange = async (memberId: string, newRole: Role) => {
    try {
      await rbac.grantRole(memberId, newRole, 'organization', organizationId, 'current-user-id')
      
      setMembers(prev => 
        prev.map(member => 
          member.id === memberId 
            ? { ...member, roles: [{ ...member.roles[0], role: newRole }] }
            : member
        )
      )

      await auditLogger.logSystemEvent('role_changed', 'current-user-id', {
        targetUserId: memberId,
        newRole,
        organizationId
      })

      trackInteraction('team-management', 'change_role', { role: newRole })
    } catch (error) {
      console.error('Failed to change role:', error)
    }
  }

  const handleRemoveMember = async (memberId: string) => {
    try {
      await rbac.revokeRole(memberId, 'organization', organizationId, 'current-user-id')
      
      setMembers(prev => prev.filter(member => member.id !== memberId))

      await auditLogger.logSystemEvent('team_member_removed', 'current-user-id', {
        removedUserId: memberId,
        organizationId
      })

      trackInteraction('team-management', 'remove_member')
    } catch (error) {
      console.error('Failed to remove member:', error)
    }
  }

  const handleCancelInvitation = async (invitationId: string) => {
    try {
      setInvitations(prev => 
        prev.map(inv => 
          inv.id === invitationId 
            ? { ...inv, status: 'cancelled' as const }
            : inv
        )
      )

      await auditLogger.logSystemEvent('invitation_cancelled', 'current-user-id', {
        invitationId,
        organizationId
      })

      trackInteraction('team-management', 'cancel_invitation')
    } catch (error) {
      console.error('Failed to cancel invitation:', error)
    }
  }

  const filteredMembers = members.filter(member => {
    const matchesSearch = searchQuery === '' || 
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.email.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesRole = selectedRole === 'all' || 
      member.roles.some(role => role.role === selectedRole)
    
    return matchesSearch && matchesRole
  })

  const getRoleColor = (role: Role) => {
    switch (role) {
      case 'owner': return 'bg-purple-500/20 text-purple-300'
      case 'admin': return 'bg-red-500/20 text-red-300'
      case 'manager': return 'bg-blue-500/20 text-blue-300'
      case 'member': return 'bg-green-500/20 text-green-300'
      case 'viewer': return 'bg-gray-500/20 text-gray-300'
      case 'guest': return 'bg-yellow-500/20 text-yellow-300'
      default: return 'bg-gray-500/20 text-gray-300'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <div className="w-2 h-2 bg-green-400 rounded-full" />
      case 'pending': return <div className="w-2 h-2 bg-yellow-400 rounded-full" />
      case 'disabled': return <div className="w-2 h-2 bg-red-400 rounded-full" />
      default: return <div className="w-2 h-2 bg-gray-400 rounded-full" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Team Management</h2>
          <p className="text-gray-400">Manage team members, roles, and permissions</p>
        </div>
        
        <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <UserPlus className="h-4 w-4 mr-2" />
              Invite Member
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite Team Member</DialogTitle>
              <DialogDescription>
                Send an invitation to join your workspace. You can set their role and expiration time.
              </DialogDescription>
            </DialogHeader>
            <InviteMemberForm onSubmit={handleInviteMember} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Users className="h-8 w-8 text-blue-400" />
              <div>
                <div className="text-2xl font-bold text-white">{members.length}</div>
                <div className="text-sm text-gray-400">Total Members</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Crown className="h-8 w-8 text-purple-400" />
              <div>
                <div className="text-2xl font-bold text-white">
                  {members.filter(m => m.roles.some(r => ['owner', 'admin'].includes(r.role))).length}
                </div>
                <div className="text-sm text-gray-400">Admins</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Mail className="h-8 w-8 text-green-400" />
              <div>
                <div className="text-2xl font-bold text-white">
                  {invitations.filter(i => i.status === 'pending').length}
                </div>
                <div className="text-sm text-gray-400">Pending Invitations</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Activity className="h-8 w-8 text-yellow-400" />
              <div>
                <div className="text-2xl font-bold text-white">
                  {members.filter(m => 
                    m.lastActiveAt && 
                    m.lastActiveAt > new Date(Date.now() - 24 * 60 * 60 * 1000)
                  ).length}
                </div>
                <div className="text-sm text-gray-400">Active Today</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value="members" onValueChange={() => {}} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="members">Team Members</TabsTrigger>
          <TabsTrigger value="invitations">
            Invitations
            {invitations.filter(i => i.status === 'pending').length > 0 && (
              <Badge className="ml-2 bg-blue-500/20 text-blue-300">
                {invitations.filter(i => i.status === 'pending').length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="members" className="space-y-6">
          {/* Filters */}
          <div className="flex items-center space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search team members..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={selectedRole} onValueChange={(value) => setSelectedRole(value as Role | 'all')}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="owner">Owner</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="member">Member</SelectItem>
                <SelectItem value="viewer">Viewer</SelectItem>
                <SelectItem value="guest">Guest</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Members List */}
          <div className="grid gap-4">
            {filteredMembers.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Users className="h-16 w-16 text-gray-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No team members found</h3>
                  <p className="text-gray-400">Try adjusting your search or invite new members</p>
                </CardContent>
              </Card>
            ) : (
              filteredMembers.map((member) => (
                <MemberCard
                  key={member.id}
                  member={member}
                  onRoleChange={handleRoleChange}
                  onRemove={handleRemoveMember}
                  getRoleColor={getRoleColor}
                  getStatusIcon={getStatusIcon}
                />
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="invitations" className="space-y-6">
          <InvitationsList
            invitations={invitations}
            onCancel={handleCancelInvitation}
            getRoleColor={getRoleColor}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function MemberCard({
  member,
  onRoleChange,
  onRemove,
  getRoleColor,
  getStatusIcon
}: {
  member: TeamMember
  onRoleChange: (id: string, role: Role) => void
  onRemove: (id: string) => void
  getRoleColor: (role: Role) => string
  getStatusIcon: (status: string) => React.ReactNode
}) {
  const primaryRole = member.roles[0]?.role || 'member'

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Avatar className="h-12 w-12">
              <AvatarImage src={member.avatar} />
              <AvatarFallback className="bg-blue-500 text-white">
                {member.name.split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h3 className="font-semibold text-white">{member.name}</h3>
                {getStatusIcon(member.status)}
                {primaryRole === 'owner' && (
                  <Crown className="h-4 w-4 text-purple-400" />
                )}
              </div>
              <p className="text-gray-400 text-sm">{member.email}</p>
              <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                <div className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span>Joined {member.joinedAt.toLocaleDateString()}</span>
                </div>
                {member.lastActiveAt && (
                  <div className="flex items-center space-x-1">
                    <Clock className="h-3 w-3" />
                    <span>Last active {member.lastActiveAt.toLocaleDateString()}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="text-right">
              <Badge className={getRoleColor(primaryRole)}>
                {primaryRole}
              </Badge>
              <div className="mt-2 text-xs text-gray-500 capitalize">
                {member.status}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {primaryRole !== 'owner' && (
              <>
                <Select 
                  value={primaryRole} 
                  onValueChange={(role) => onRoleChange(member.id, role as Role)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="member">Member</SelectItem>
                    <SelectItem value="viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onRemove(member.id)}
                  className="text-red-400 hover:text-red-300"
                >
                  <UserMinus className="h-4 w-4" />
                </Button>
              </>
            )}
            
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function InviteMemberForm({
  onSubmit
}: {
  onSubmit: (email: string, role: Role, expiresIn: number) => void
}) {
  const [email, setEmail] = useState('')
  const [role, setRole] = useState<Role>('member')
  const [expiresIn, setExpiresIn] = useState(7) // days

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(email, role, expiresIn)
    setEmail('')
    setRole('member')
    setExpiresIn(7)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <DialogHeader>
        <DialogTitle>Invite Team Member</DialogTitle>
      </DialogHeader>
      
      <div>
        <Label htmlFor="email">Email Address</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="colleague@company.com"
          required
        />
      </div>
      
      <div>
        <Label htmlFor="role">Role</Label>
        <Select value={role} onValueChange={(value) => setRole(value as Role)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="admin">Admin - Full access</SelectItem>
            <SelectItem value="manager">Manager - Manage team and projects</SelectItem>
            <SelectItem value="member">Member - Create and manage own work</SelectItem>
            <SelectItem value="viewer">Viewer - Read-only access</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="expires">Invitation Expires</Label>
        <Select value={expiresIn.toString()} onValueChange={(value) => setExpiresIn(parseInt(value))}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1 day</SelectItem>
            <SelectItem value="3">3 days</SelectItem>
            <SelectItem value="7">7 days</SelectItem>
            <SelectItem value="14">14 days</SelectItem>
            <SelectItem value="30">30 days</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline">
          Cancel
        </Button>
        <Button type="submit">
          Send Invitation
        </Button>
      </div>
    </form>
  )
}

function InvitationsList({
  invitations,
  onCancel,
  getRoleColor
}: {
  invitations: TeamInvitation[]
  onCancel: (id: string) => void
  getRoleColor: (role: Role) => string
}) {
  const getInvitationStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-300'
      case 'accepted': return 'bg-green-500/20 text-green-300'
      case 'expired': return 'bg-red-500/20 text-red-300'
      case 'cancelled': return 'bg-gray-500/20 text-gray-300'
      default: return 'bg-gray-500/20 text-gray-300'
    }
  }

  return (
    <div className="space-y-4">
      {invitations.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Mail className="h-16 w-16 text-gray-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">No invitations sent</h3>
            <p className="text-gray-400">Team member invitations will appear here</p>
          </CardContent>
        </Card>
      ) : (
        invitations.map((invitation) => (
          <Card key={invitation.id}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-semibold text-white">{invitation.email}</h3>
                    <Badge className={getRoleColor(invitation.role)}>
                      {invitation.role}
                    </Badge>
                    <Badge className={getInvitationStatusColor(invitation.status)}>
                      {invitation.status}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-400">
                    Invited {invitation.invitedAt.toLocaleDateString()} • 
                    Expires {invitation.expiresAt.toLocaleDateString()}
                  </div>
                </div>
                
                {invitation.status === 'pending' && (
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        // Resend invitation
                        console.log('Resend invitation:', invitation.id)
                      }}
                    >
                      Resend
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onCancel(invitation.id)}
                      className="text-red-400 hover:text-red-300"
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  )
}

// Mock data functions
function getMockMembers(): TeamMember[] {
  return [
    {
      id: 'user-1',
      email: 'john@company.com',
      name: 'John Smith',
      roles: [{ userId: 'user-1', role: 'owner', scope: 'organization', scopeId: 'org-1', grantedBy: 'system', grantedAt: new Date('2024-01-01') }],
      status: 'active',
      joinedAt: new Date('2024-01-01'),
      lastActiveAt: new Date()
    },
    {
      id: 'user-2',
      email: 'jane@company.com',
      name: 'Jane Doe',
      roles: [{ userId: 'user-2', role: 'admin', scope: 'organization', scopeId: 'org-1', grantedBy: 'user-1', grantedAt: new Date('2024-01-15') }],
      status: 'active',
      joinedAt: new Date('2024-01-15'),
      lastActiveAt: new Date(Date.now() - 2 * 60 * 60 * 1000)
    },
    {
      id: 'user-3',
      email: 'bob@company.com',
      name: 'Bob Wilson',
      roles: [{ userId: 'user-3', role: 'member', scope: 'organization', scopeId: 'org-1', grantedBy: 'user-1', grantedAt: new Date('2024-02-01') }],
      status: 'active',
      joinedAt: new Date('2024-02-01'),
      lastActiveAt: new Date(Date.now() - 24 * 60 * 60 * 1000)
    }
  ]
}

function getMockInvitations(): TeamInvitation[] {
  return [
    {
      id: 'inv-1',
      email: 'alice@company.com',
      role: 'manager',
      invitedBy: 'user-1',
      invitedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      expiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      status: 'pending'
    },
    {
      id: 'inv-2',
      email: 'mike@company.com',
      role: 'member',
      invitedBy: 'user-1',
      invitedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      expiresAt: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      status: 'pending'
    }
  ]
}

async function sendInvitationEmail(invitation: TeamInvitation): Promise<void> {
  // In production, this would send an actual email
  console.log('Sending invitation email to:', invitation.email)
}
