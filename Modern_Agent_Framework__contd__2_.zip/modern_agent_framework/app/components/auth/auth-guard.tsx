
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, ReactNode } from "react";
import { Loader2 } from "lucide-react";

interface AuthGuardProps {
  children: ReactNode;
  fallback?: ReactNode;
  requireAuth?: boolean;
  redirectTo?: string;
}

export default function AuthGuard({ 
  children, 
  fallback, 
  requireAuth = true,
  redirectTo = "/auth/signin"
}: AuthGuardProps) {
  const { data: session, status } = useSession() || {};
  const router = useRouter();

  useEffect(() => {
    if (status === "loading") return;

    if (requireAuth && status === "unauthenticated") {
      router.push(redirectTo);
      return;
    }

    if (!requireAuth && status === "authenticated") {
      router.push("/dashboard");
      return;
    }
  }, [status, requireAuth, redirectTo, router]);

  if (status === "loading") {
    return (
      fallback || (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center space-y-4">
            <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
            <p className="text-gray-600">Loading...</p>
          </div>
        </div>
      )
    );
  }

  if (requireAuth && status === "unauthenticated") {
    return null; // Redirect will happen in useEffect
  }

  if (!requireAuth && status === "authenticated") {
    return null; // Redirect will happen in useEffect
  }

  return <>{children}</>;
}
