
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { 
  Plus, 
  Settings, 
  Trash2, 
  TestTube, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Link,
  Key,
  Clock,
  BarChart3
} from 'lucide-react'
import { APIIntegration, useAPIIntegrations } from '@/lib/integrations/api-client'
import { useAnalytics } from '@/lib/analytics/collector'

export function APIIntegrationManager() {
  const [integrations, setIntegrations] = useState<APIIntegration[]>([])
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [testingIntegration, setTestingIntegration] = useState<string | null>(null)
  const { getAllIntegrations, addIntegration, removeIntegration, testIntegration } = useAPIIntegrations()
  const { trackFeatureUsage, trackInteraction } = useAnalytics()

  useEffect(() => {
    trackFeatureUsage('api-integrations', 'view')
    loadIntegrations()
  }, [])

  const loadIntegrations = async () => {
    const allIntegrations = getAllIntegrations()
    setIntegrations(allIntegrations)
  }

  const handleCreateIntegration = async (integrationData: Partial<APIIntegration>) => {
    const newIntegration: APIIntegration = {
      id: `api_${Date.now()}`,
      createdAt: new Date(),
      status: 'active',
      timeout: 30000,
      ...integrationData
    } as APIIntegration

    await addIntegration(newIntegration)
    await loadIntegrations()
    setShowCreateDialog(false)
    trackInteraction('api-integrations', 'create', { type: newIntegration.type })
  }

  const handleDeleteIntegration = async (integrationId: string) => {
    await removeIntegration(integrationId)
    await loadIntegrations()
    trackInteraction('api-integrations', 'delete')
  }

  const handleTestIntegration = async (integrationId: string) => {
    setTestingIntegration(integrationId)
    
    try {
      const success = await testIntegration(integrationId)
      trackInteraction('api-integrations', 'test', { success })
      
      // Update integration status based on test result
      const integration = integrations.find(i => i.id === integrationId)
      if (integration) {
        integration.status = success ? 'active' : 'error'
        setIntegrations([...integrations])
      }
    } catch (error) {
      console.error('Test failed:', error)
    } finally {
      setTestingIntegration(null)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="h-4 w-4 text-green-400" />
      case 'error':
        return <XCircle className="h-4 w-4 text-red-400" />
      case 'disabled':
        return <AlertCircle className="h-4 w-4 text-yellow-400" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/20 text-green-300'
      case 'error':
        return 'bg-red-500/20 text-red-300'
      case 'disabled':
        return 'bg-yellow-500/20 text-yellow-300'
      default:
        return 'bg-gray-500/20 text-gray-300'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">API Integrations</h2>
          <p className="text-gray-400">Manage external API connections and webhooks</p>
        </div>
        
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Add Integration
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add API Integration</DialogTitle>
              <DialogDescription>
                Connect external APIs and services to expand your agent capabilities.
              </DialogDescription>
            </DialogHeader>
            <CreateIntegrationForm onSubmit={handleCreateIntegration} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Link className="h-8 w-8 text-blue-400" />
              <div>
                <div className="text-2xl font-bold text-white">{integrations.length}</div>
                <div className="text-sm text-gray-400">Total Integrations</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-8 w-8 text-green-400" />
              <div>
                <div className="text-2xl font-bold text-white">
                  {integrations.filter(i => i.status === 'active').length}
                </div>
                <div className="text-sm text-gray-400">Active</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <XCircle className="h-8 w-8 text-red-400" />
              <div>
                <div className="text-2xl font-bold text-white">
                  {integrations.filter(i => i.status === 'error').length}
                </div>
                <div className="text-sm text-gray-400">Errors</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Clock className="h-8 w-8 text-purple-400" />
              <div>
                <div className="text-2xl font-bold text-white">
                  {integrations.filter(i => i.lastUsed).length}
                </div>
                <div className="text-sm text-gray-400">Recently Used</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Integrations List */}
      <div className="grid gap-6">
        {integrations.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Link className="h-16 w-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">No Integrations Yet</h3>
              <p className="text-gray-400 mb-6">
                Connect external APIs and services to extend your agent capabilities
              </p>
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Integration
              </Button>
            </CardContent>
          </Card>
        ) : (
          integrations.map((integration) => (
            <IntegrationCard
              key={integration.id}
              integration={integration}
              onTest={() => handleTestIntegration(integration.id)}
              onDelete={() => handleDeleteIntegration(integration.id)}
              testing={testingIntegration === integration.id}
              getStatusIcon={getStatusIcon}
              getStatusColor={getStatusColor}
            />
          ))
        )}
      </div>
    </div>
  )
}

function IntegrationCard({ 
  integration, 
  onTest, 
  onDelete, 
  testing, 
  getStatusIcon, 
  getStatusColor 
}: {
  integration: APIIntegration
  onTest: () => void
  onDelete: () => void
  testing: boolean
  getStatusIcon: (status: string) => React.ReactNode
  getStatusColor: (status: string) => string
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-gray-800 rounded-lg">
                <Link className="h-5 w-5 text-gray-400" />
              </div>
              <div>
                <h3 className="font-semibold text-white">{integration.name}</h3>
                <p className="text-sm text-gray-400">{integration.baseUrl}</p>
              </div>
              <Badge className={getStatusColor(integration.status)}>
                <div className="flex items-center space-x-1">
                  {getStatusIcon(integration.status)}
                  <span>{integration.status}</span>
                </div>
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <div className="text-gray-400">Type</div>
                <div className="text-white capitalize">{integration.type}</div>
              </div>
              <div>
                <div className="text-gray-400">Auth</div>
                <div className="text-white capitalize">
                  {integration.authentication?.type || 'None'}
                </div>
              </div>
              <div>
                <div className="text-gray-400">Timeout</div>
                <div className="text-white">{integration.timeout / 1000}s</div>
              </div>
              <div>
                <div className="text-gray-400">Last Used</div>
                <div className="text-white">
                  {integration.lastUsed
                    ? new Date(integration.lastUsed).toLocaleDateString()
                    : 'Never'
                  }
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onTest}
              disabled={testing}
            >
              {testing ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current" />
              ) : (
                <TestTube className="h-4 w-4" />
              )}
            </Button>
            
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onDelete}
              className="text-red-400 hover:text-red-300"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function CreateIntegrationForm({ 
  onSubmit 
}: { 
  onSubmit: (data: Partial<APIIntegration>) => void 
}) {
  const [formData, setFormData] = useState({
    name: '',
    type: 'rest' as const,
    baseUrl: '',
    authType: 'none',
    authCredentials: {} as Record<string, string>,
    timeout: 30000,
    rateLimit: {
      requests: 100,
      window: 60
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const integrationData: Partial<APIIntegration> = {
      name: formData.name,
      type: formData.type,
      baseUrl: formData.baseUrl,
      timeout: formData.timeout,
      rateLimit: formData.rateLimit,
      authentication: formData.authType !== 'none' ? {
        type: formData.authType as any,
        credentials: formData.authCredentials
      } : undefined
    }
    
    onSubmit(integrationData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <DialogHeader>
        <DialogTitle>Create API Integration</DialogTitle>
      </DialogHeader>
      
      <div className="grid gap-4">
        <div>
          <Label htmlFor="name">Integration Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="e.g., Slack API, Customer Database"
            required
          />
        </div>
        
        <div>
          <Label htmlFor="type">API Type</Label>
          <Select 
            value={formData.type} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, type: value as any }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="rest">REST API</SelectItem>
              <SelectItem value="graphql">GraphQL</SelectItem>
              <SelectItem value="webhook">Webhook</SelectItem>
              <SelectItem value="websocket">WebSocket</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="baseUrl">Base URL</Label>
          <Input
            id="baseUrl"
            value={formData.baseUrl}
            onChange={(e) => setFormData(prev => ({ ...prev, baseUrl: e.target.value }))}
            placeholder="https://api.example.com/v1"
            required
          />
        </div>
        
        <div>
          <Label htmlFor="authType">Authentication</Label>
          <Select 
            value={formData.authType} 
            onValueChange={(value) => setFormData(prev => ({ 
              ...prev, 
              authType: value,
              authCredentials: {} 
            }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None</SelectItem>
              <SelectItem value="bearer">Bearer Token</SelectItem>
              <SelectItem value="api-key">API Key</SelectItem>
              <SelectItem value="basic">Basic Auth</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {/* Authentication Credentials */}
        {formData.authType === 'bearer' && (
          <div>
            <Label htmlFor="token">Bearer Token</Label>
            <Input
              id="token"
              type="password"
              value={formData.authCredentials.token || ''}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                authCredentials: { ...prev.authCredentials, token: e.target.value }
              }))}
            />
          </div>
        )}
        
        {formData.authType === 'api-key' && (
          <>
            <div>
              <Label htmlFor="headerName">Header Name</Label>
              <Input
                id="headerName"
                value={formData.authCredentials.headerName || ''}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  authCredentials: { ...prev.authCredentials, headerName: e.target.value }
                }))}
                placeholder="X-API-Key"
              />
            </div>
            <div>
              <Label htmlFor="key">API Key</Label>
              <Input
                id="key"
                type="password"
                value={formData.authCredentials.key || ''}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  authCredentials: { ...prev.authCredentials, key: e.target.value }
                }))}
              />
            </div>
          </>
        )}
        
        {formData.authType === 'basic' && (
          <>
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={formData.authCredentials.username || ''}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  authCredentials: { ...prev.authCredentials, username: e.target.value }
                }))}
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.authCredentials.password || ''}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  authCredentials: { ...prev.authCredentials, password: e.target.value }
                }))}
              />
            </div>
          </>
        )}
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline">
          Cancel
        </Button>
        <Button type="submit">
          Create Integration
        </Button>
      </div>
    </form>
  )
}
