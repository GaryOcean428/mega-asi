
'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Search, Filter, Zap, DollarSign, Clock, Brain } from 'lucide-react'

interface Model {
  id: string
  name: string
  provider: string
  capabilities: string[]
  contextWindow: number
  costPer1MTokens: {
    input: number
    output: number
  }
  description: string
}

interface ModelSelectorProps {
  selectedModel?: string
  onModelSelect: (modelId: string) => void
  agentRole?: string
  taskType?: 'reasoning' | 'coding' | 'writing' | 'multimodal' | 'fast' | 'cost_effective'
  trigger?: React.ReactNode
}

export function ModelSelector({
  selectedModel,
  onModelSelect,
  agentRole,
  taskType,
  trigger
}: ModelSelectorProps) {
  const [models, setModels] = useState<Model[]>([])
  const [recommendations, setRecommendations] = useState<Model[]>([])
  const [providers, setProviders] = useState<string[]>([])
  const [capabilities, setCapabilities] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedProvider, setSelectedProvider] = useState<string>('all-providers')
  const [selectedCapability, setSelectedCapability] = useState<string>('all-capabilities')
  const [sortBy, setSortBy] = useState('name')
  const [open, setOpen] = useState(false)

  // Fetch models and recommendations
  useEffect(() => {
    if (open) {
      fetchModels()
      if (agentRole || taskType) {
        fetchRecommendations()
      }
    }
  }, [open, agentRole, taskType])

  const fetchModels = async () => {
    try {
      const params = new URLSearchParams()
      if (selectedProvider && selectedProvider !== 'all-providers') {
        params.set('provider', selectedProvider)
      }
      if (selectedCapability && selectedCapability !== 'all-capabilities') {
        params.set('capability', selectedCapability)
      }
      params.set('sortBy', sortBy)

      const response = await fetch(`/api/models?${params}`)
      const data = await response.json()
      
      setModels(data.models || [])
      setProviders(data.providers || [])
      setCapabilities(data.capabilities || [])
    } catch (error) {
      console.error('Error fetching models:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchRecommendations = async () => {
    try {
      const response = await fetch('/api/models', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskType,
          agentRole,
          budget: 5.0, // Default budget limit
          requirements: ['text', 'code'] // Basic requirements
        })
      })
      const data = await response.json()
      setRecommendations(data.recommendations || [])
    } catch (error) {
      console.error('Error fetching recommendations:', error)
    }
  }

  // Filter models by search term
  const filteredModels = models.filter(model =>
    model.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    model.provider.toLowerCase().includes(searchTerm.toLowerCase()) ||
    model.capabilities.some(cap => cap.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  const handleModelSelect = (modelId: string) => {
    onModelSelect(modelId)
    setOpen(false)
  }

  const renderModelCard = (model: Model, showRecommendationBadge = false) => (
    <Card key={model.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => handleModelSelect(model.id)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">{model.name}</CardTitle>
          <Badge variant="secondary" className="text-xs">{model.provider}</Badge>
        </div>
        {showRecommendationBadge && (
          <Badge variant="default" className="w-fit">
            <Zap className="w-3 h-3 mr-1" />
            Recommended
          </Badge>
        )}
      </CardHeader>
      <CardContent className="space-y-2">
        <CardDescription className="text-xs">{model.description}</CardDescription>
        
        <div className="flex flex-wrap gap-1">
          {model.capabilities.slice(0, 3).map(cap => (
            <Badge key={cap} variant="outline" className="text-xs">
              {cap}
            </Badge>
          ))}
          {model.capabilities.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{model.capabilities.length - 3}
            </Badge>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
          <div className="flex items-center">
            <Brain className="w-3 h-3 mr-1" />
            {(model.contextWindow / 1000).toFixed(0)}K
          </div>
          <div className="flex items-center">
            <DollarSign className="w-3 h-3 mr-1" />
            ${model.costPer1MTokens.input.toFixed(2)}
          </div>
          <div className="flex items-center">
            <Clock className="w-3 h-3 mr-1" />
            {model.capabilities.includes('fast_processing') ? 'Fast' : 'Standard'}
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const selectedModelInfo = models.find(m => m.id === selectedModel)

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="w-full justify-between">
            {selectedModelInfo ? (
              <div className="flex items-center space-x-2">
                <span>{selectedModelInfo.name}</span>
                <Badge variant="secondary" className="text-xs">
                  {selectedModelInfo.provider}
                </Badge>
              </div>
            ) : (
              'Select AI Model'
            )}
          </Button>
        )}
      </DialogTrigger>
      
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>Select AI Model</DialogTitle>
        </DialogHeader>

        <Tabs value="all" onValueChange={() => {}} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="recommendations">Recommended</TabsTrigger>
            <TabsTrigger value="all">All Models</TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations" className="flex-1 overflow-auto">
            {recommendations.length > 0 ? (
              <div className="grid gap-3">
                {recommendations.map(model => renderModelCard(model, true))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No specific recommendations available.</p>
                <p className="text-sm">Check the "All Models" tab to browse available options.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="all" className="flex-1 flex flex-col overflow-hidden">
            {/* Filters */}
            <div className="space-y-4 mb-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Search models..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full"
                  />
                </div>
                <Button variant="outline" size="sm" onClick={fetchModels}>
                  <Filter className="w-4 h-4 mr-2" />
                  Apply
                </Button>
              </div>
              
              <div className="grid grid-cols-3 gap-2">
                <Select value={selectedProvider} onValueChange={setSelectedProvider}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Providers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-providers">All Providers</SelectItem>
                    {providers.map(provider => (
                      <SelectItem key={provider} value={provider}>
                        {provider}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedCapability} onValueChange={setSelectedCapability}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Capabilities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-capabilities">All Capabilities</SelectItem>
                    {capabilities.map(cap => (
                      <SelectItem key={cap} value={cap}>
                        {cap.replace('_', ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Name</SelectItem>
                    <SelectItem value="provider">Provider</SelectItem>
                    <SelectItem value="cost">Cost</SelectItem>
                    <SelectItem value="context">Context Size</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Models Grid */}
            <div className="flex-1 overflow-auto">
              {loading ? (
                <div className="text-center py-8">Loading models...</div>
              ) : filteredModels.length > 0 ? (
                <div className="grid gap-3">
                  {filteredModels.map(model => renderModelCard(model))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No models found matching your criteria.</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
