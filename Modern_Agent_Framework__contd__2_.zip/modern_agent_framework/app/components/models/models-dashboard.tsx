
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Brain, 
  DollarSign, 
  Clock, 
  Zap, 
  Search, 
  Filter,
  TrendingUp,
  Layers,
  Cpu,
  Globe,
  Code,
  FileText,
  Camera,
  Calculator,
  Sparkles
} from 'lucide-react'

interface Model {
  id: string
  name: string
  provider: string
  capabilities: string[]
  contextWindow: number
  costPer1MTokens: {
    input: number
    output: number
  }
  description: string
}

interface ModelsData {
  models: Model[]
  providers: string[]
  capabilities: string[]
  totalCount: number
}

const capabilityIcons: Record<string, any> = {
  text: FileText,
  code: Code,
  reasoning: Brain,
  multimodal: Camera,
  math: Calculator,
  programming: Code,
  creative: Sparkles,
  analysis: TrendingUp,
  fast_processing: Zap,
  multilingual: Globe,
  logic: Cpu,
  debugging: Code,
  problem_solving: Calculator,
  web_search: Globe,
  real_time: Clock,
  writing: FileText,
  advanced_reasoning: Brain
}

export function ModelsDashboard() {
  const [data, setData] = useState<ModelsData>({ models: [], providers: [], capabilities: [], totalCount: 0 })
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedProvider, setSelectedProvider] = useState('all-providers')
  const [selectedCapability, setSelectedCapability] = useState('all-capabilities')
  const [sortBy, setSortBy] = useState('name')
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid')

  useEffect(() => {
    fetchModels()
  }, [selectedProvider, selectedCapability, sortBy])

  const fetchModels = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (selectedProvider && selectedProvider !== 'all-providers') {
        params.set('provider', selectedProvider)
      }
      if (selectedCapability && selectedCapability !== 'all-capabilities') {
        params.set('capability', selectedCapability)
      }
      params.set('sortBy', sortBy)

      const response = await fetch(`/api/models?${params}`)
      const result = await response.json()
      setData(result)
    } catch (error) {
      console.error('Error fetching models:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredModels = data.models.filter(model =>
    model.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    model.provider.toLowerCase().includes(searchTerm.toLowerCase()) ||
    model.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    model.capabilities.some(cap => cap.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  // Calculate statistics
  const providerStats = data.providers.map(provider => ({
    provider,
    count: data.models.filter(m => m.provider === provider).length,
    avgCost: data.models
      .filter(m => m.provider === provider)
      .reduce((sum, m) => sum + m.costPer1MTokens.input, 0) / 
      data.models.filter(m => m.provider === provider).length
  }))

  const capabilityStats = data.capabilities.map(capability => ({
    capability,
    count: data.models.filter(m => m.capabilities.includes(capability)).length
  })).sort((a, b) => b.count - a.count)

  const renderCapabilityBadge = (capability: string) => {
    const Icon = capabilityIcons[capability] || Layers
    return (
      <Badge key={capability} variant="outline" className="flex items-center space-x-1">
        <Icon className="w-3 h-3" />
        <span>{capability.replace('_', ' ')}</span>
      </Badge>
    )
  }

  const renderModelCard = (model: Model) => (
    <Card key={model.id} className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{model.name}</CardTitle>
            <Badge variant="secondary" className="mt-1">
              {model.provider}
            </Badge>
          </div>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Input Cost</div>
            <div className="font-semibold">${model.costPer1MTokens.input}/1M</div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <CardDescription>{model.description}</CardDescription>
        
        <div className="flex flex-wrap gap-1">
          {model.capabilities.map(renderCapabilityBadge)}
        </div>

        <div className="grid grid-cols-3 gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <Brain className="w-4 h-4 text-blue-500" />
            <div>
              <div className="font-medium">{(model.contextWindow / 1000).toFixed(0)}K</div>
              <div className="text-muted-foreground">Context</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <DollarSign className="w-4 h-4 text-green-500" />
            <div>
              <div className="font-medium">${model.costPer1MTokens.output}/1M</div>
              <div className="text-muted-foreground">Output</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-yellow-500" />
            <div>
              <div className="font-medium">
                {model.capabilities.includes('fast_processing') ? 'Fast' : 'Standard'}
              </div>
              <div className="text-muted-foreground">Speed</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const renderTableRow = (model: Model) => (
    <tr key={model.id} className="border-b hover:bg-muted/50">
      <td className="p-4">
        <div>
          <div className="font-medium">{model.name}</div>
          <Badge variant="secondary" className="text-xs mt-1">
            {model.provider}
          </Badge>
        </div>
      </td>
      <td className="p-4">
        <div className="flex flex-wrap gap-1">
          {model.capabilities.slice(0, 3).map(cap => (
            <Badge key={cap} variant="outline" className="text-xs">
              {cap.replace('_', ' ')}
            </Badge>
          ))}
          {model.capabilities.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{model.capabilities.length - 3}
            </Badge>
          )}
        </div>
      </td>
      <td className="p-4 text-center">{(model.contextWindow / 1000).toFixed(0)}K</td>
      <td className="p-4 text-center">${model.costPer1MTokens.input.toFixed(3)}</td>
      <td className="p-4 text-center">${model.costPer1MTokens.output.toFixed(3)}</td>
    </tr>
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">AI Models Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Explore all {data.totalCount} available AI models on the platform
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Models</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalCount}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Providers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.providers.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Avg Cost (Input)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${(data.models.reduce((sum, m) => sum + m.costPer1MTokens.input, 0) / data.models.length || 0).toFixed(2)}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Max Context</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.max(...data.models.map(m => m.contextWindow)) / 1000000}M
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value="models" onValueChange={() => {}} className="space-y-4">
        <TabsList>
          <TabsTrigger value="models">All Models</TabsTrigger>
          <TabsTrigger value="providers">By Provider</TabsTrigger>
          <TabsTrigger value="capabilities">By Capability</TabsTrigger>
        </TabsList>

        <TabsContent value="models" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search models..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            
            <div className="flex gap-2">
              <Select value={selectedProvider} onValueChange={setSelectedProvider}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Provider" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-providers">All Providers</SelectItem>
                  {data.providers.map(provider => (
                    <SelectItem key={provider} value={provider}>
                      {provider}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedCapability} onValueChange={setSelectedCapability}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Capability" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-capabilities">All Capabilities</SelectItem>
                  {data.capabilities.map(cap => (
                    <SelectItem key={cap} value={cap}>
                      {cap.replace('_', ' ')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="provider">Provider</SelectItem>
                  <SelectItem value="cost">Cost</SelectItem>
                  <SelectItem value="context">Context</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex border rounded-md">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Layers className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'table' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('table')}
                  className="rounded-l-none"
                >
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Models Display */}
          {loading ? (
            <div className="text-center py-12">Loading models...</div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredModels.map(renderModelCard)}
            </div>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="p-4 text-left">Model</th>
                    <th className="p-4 text-left">Capabilities</th>
                    <th className="p-4 text-center">Context</th>
                    <th className="p-4 text-center">Input Cost</th>
                    <th className="p-4 text-center">Output Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredModels.map(renderTableRow)}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>

        <TabsContent value="providers" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {providerStats.map(stat => (
              <Card key={stat.provider}>
                <CardHeader>
                  <CardTitle>{stat.provider}</CardTitle>
                  <CardDescription>{stat.count} models</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Avg Input Cost:</span>
                      <span>${stat.avgCost.toFixed(3)}/1M</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="capabilities" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {capabilityStats.map(stat => {
              const Icon = capabilityIcons[stat.capability] || Layers
              return (
                <Card key={stat.capability}>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center space-x-2">
                      <Icon className="w-5 h-5" />
                      <span>{stat.capability.replace('_', ' ')}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stat.count}</div>
                    <div className="text-sm text-muted-foreground">models support this</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
