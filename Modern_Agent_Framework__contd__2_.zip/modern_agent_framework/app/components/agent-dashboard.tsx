
'use client'

import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AgentList } from './agents/agent-list'
import { TaskList } from './tasks/task-list'
import { CollaborationList } from './collaborations/collaboration-list'
import { CreateAgentDialog } from './agents/create-agent-dialog'
import { CreateTaskDialog } from './tasks/create-task-dialog'
import { CreateCollaborationDialog } from './collaborations/create-collaboration-dialog'
import { SystemMetrics } from './system-metrics'
import { Button } from '@/components/ui/button'
import { Plus, Activity, Users, MessageSquare, BarChart3 } from 'lucide-react'

export function AgentDashboard() {
  const [activeTab, setActiveTab] = useState('agents')
  const [showCreateAgent, setShowCreateAgent] = useState(false)
  const [showCreateTask, setShowCreateTask] = useState(false)
  const [showCreateCollaboration, setShowCreateCollaboration] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1)
  }

  const getCreateButton = () => {
    switch (activeTab) {
      case 'agents':
        return (
          <Button onClick={() => setShowCreateAgent(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Create Agent
          </Button>
        )
      case 'tasks':
        return (
          <Button onClick={() => setShowCreateTask(true)} className="bg-green-600 hover:bg-green-700">
            <Plus className="h-4 w-4 mr-2" />
            Create Task
          </Button>
        )
      case 'collaborations':
        return (
          <Button onClick={() => setShowCreateCollaboration(true)} className="bg-purple-600 hover:bg-purple-700">
            <Plus className="h-4 w-4 mr-2" />
            Create Collaboration
          </Button>
        )
      default:
        return null
    }
  }

  return (
    <div className="space-y-8">
      <SystemMetrics refreshKey={refreshKey} />

      <div className="bg-gray-900/50 backdrop-blur rounded-lg border border-gray-800 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Agent Management</h2>
          {getCreateButton()}
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
            <TabsTrigger value="agents" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>Agents</span>
            </TabsTrigger>
            <TabsTrigger value="tasks" className="flex items-center space-x-2">
              <Activity className="h-4 w-4" />
              <span>Tasks</span>
            </TabsTrigger>
            <TabsTrigger value="collaborations" className="flex items-center space-x-2">
              <MessageSquare className="h-4 w-4" />
              <span>Collaborations</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>Analytics</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="agents">
            <AgentList refreshKey={refreshKey} onRefresh={handleRefresh} />
          </TabsContent>

          <TabsContent value="tasks">
            <TaskList refreshKey={refreshKey} onRefresh={handleRefresh} />
          </TabsContent>

          <TabsContent value="collaborations">
            <CollaborationList refreshKey={refreshKey} onRefresh={handleRefresh} />
          </TabsContent>

          <TabsContent value="analytics">
            <div className="p-8 text-center text-gray-400">
              <BarChart3 className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Analytics Dashboard</h3>
              <p>Advanced analytics and performance metrics coming soon.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Dialogs */}
      <CreateAgentDialog 
        open={showCreateAgent} 
        onClose={() => setShowCreateAgent(false)}
        onSuccess={handleRefresh}
      />
      
      <CreateTaskDialog 
        open={showCreateTask} 
        onClose={() => setShowCreateTask(false)}
        onSuccess={handleRefresh}
      />
      
      <CreateCollaborationDialog 
        open={showCreateCollaboration} 
        onClose={() => setShowCreateCollaboration(false)}
        onSuccess={handleRefresh}
      />
    </div>
  )
}
