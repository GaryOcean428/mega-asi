
/**
 * Intelligent Chat Integration for MCP Management
 * Allows users to discover, install, and configure MCPs through natural language
 */

'use client'

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Bot, Lightbulb, Settings, Download, CheckCircle, AlertTriangle, ExternalLink, Sparkles } from 'lucide-react'

interface MCPIntentAnalysis {
  intent: 'discover' | 'install' | 'configure' | 'troubleshoot' | 'recommend'
  confidence: number
  extractedInfo: {
    mcpName?: string
    capabilities?: string[]
    service?: string
    problem?: string
    requirements?: string[]
  }
  suggestedActions: Array<{
    type: 'search' | 'install' | 'configure' | 'documentation'
    description: string
    parameters?: Record<string, any>
  }>
}

interface MCPRecommendation {
  mcp: {
    id: string
    name: string
    description: string
    category: string
    capabilities: string[]
    rating: number
  }
  reason: string
  confidence: number
}

interface ChatMessage {
  id: string
  type: 'user' | 'assistant'
  content: string
  timestamp: Date
  analysis?: MCPIntentAnalysis
  recommendations?: MCPRecommendation[]
  actions?: Array<{
    type: 'install' | 'configure' | 'learn_more'
    label: string
    mcpId?: string
    parameters?: Record<string, any>
  }>
}

interface IntelligentChatIntegrationProps {
  workspaceId?: string
  onMCPInstall?: (mcpId: string) => void
  onMCPConfigure?: (installationId: string) => void
}

export function IntelligentChatIntegration({ 
  workspaceId, 
  onMCPInstall, 
  onMCPConfigure 
}: IntelligentChatIntegrationProps) {
  const { data: session } = useSession()
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'assistant',
      content: "👋 Hi! I'm your MCP assistant. I can help you discover, install, and configure Model Context Protocol servers for your agents. Try asking me something like:\n\n• \"I need to connect to GitHub\"\n• \"What MCPs can help with data analysis?\"\n• \"How do I set up Slack integration?\"",
      timestamp: new Date()
    }
  ])
  const [inputValue, setInputValue] = useState('')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(true)

  const suggestedQueries = [
    "I need to connect to GitHub for my coding agent",
    "What MCPs can help with data analysis?", 
    "How do I set up database connectivity?",
    "Show me MCPs for content creation",
    "I'm having issues with my Slack MCP"
  ]

  const analyzeMessage = async (message: string): Promise<MCPIntentAnalysis | null> => {
    try {
      const response = await fetch('/api/mcp/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'analyze_intent',
          message
        })
      })

      if (response.ok) {
        const data = await response.json()
        return data.analysis
      }
      return null
    } catch (error) {
      console.error('Error analyzing message:', error)
      return null
    }
  }

  const getRecommendations = async (query: string): Promise<{
    recommendations: MCPRecommendation[]
    explanation: string
  } | null> => {
    try {
      const response = await fetch('/api/mcp/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'get_recommendations',
          query,
          workspaceId
        })
      })

      if (response.ok) {
        const data = await response.json()
        return data
      }
      return null
    } catch (error) {
      console.error('Error getting recommendations:', error)
      return null
    }
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isAnalyzing) return

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsAnalyzing(true)
    setShowSuggestions(false)

    try {
      // Analyze the user's intent
      const analysis = await analyzeMessage(userMessage.content)
      
      if (analysis) {
        // Get recommendations based on the analysis
        const recommendationData = await getRecommendations(userMessage.content)
        
        // Generate response content
        let responseContent = ''
        const actions: ChatMessage['actions'] = []
        
        switch (analysis.intent) {
          case 'discover':
          case 'recommend':
            if (recommendationData) {
              responseContent = `${recommendationData.explanation}\n\nHere are my top recommendations:`
              
              recommendationData.recommendations.slice(0, 3).forEach(rec => {
                actions.push({
                  type: 'install',
                  label: `Install ${rec.mcp.name}`,
                  mcpId: rec.mcp.id
                })
                actions.push({
                  type: 'learn_more',
                  label: `Learn about ${rec.mcp.name}`,
                  mcpId: rec.mcp.id
                })
              })
            } else {
              responseContent = "I can help you find the right MCPs. What specific capabilities are you looking for?"
            }
            break
            
          case 'install':
            if (analysis.extractedInfo.mcpName || analysis.extractedInfo.service) {
              const searchTerm = analysis.extractedInfo.mcpName || analysis.extractedInfo.service
              responseContent = `I'll help you install the ${searchTerm} MCP. Let me find the best option for you.`
              
              actions.push({
                type: 'install',
                label: `Search for ${searchTerm} MCPs`,
                parameters: { query: searchTerm }
              })
            } else {
              responseContent = "I can help you install an MCP. Which service or tool would you like to connect to?"
            }
            break
            
          case 'configure':
            responseContent = "I can help you configure your MCPs. Which MCP would you like to set up, or are you having trouble with a specific configuration?"
            break
            
          case 'troubleshoot':
            responseContent = `I'll help you troubleshoot your MCP issue. Based on your description: "${analysis.extractedInfo.problem}", here are some things we can try:`
            
            actions.push({
              type: 'learn_more',
              label: 'Get troubleshooting help',
              parameters: { problem: analysis.extractedInfo.problem }
            })
            break
            
          default:
            responseContent = "I understand you're asking about MCPs. How can I help you with discovering, installing, or configuring Model Context Protocol servers?"
        }

        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: 'assistant',
          content: responseContent,
          timestamp: new Date(),
          analysis,
          recommendations: recommendationData?.recommendations,
          actions
        }

        setMessages(prev => [...prev, assistantMessage])
      } else {
        // Fallback response
        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: 'assistant',
          content: "I'm here to help you with MCPs. You can ask me to:\n\n• Find MCPs for specific tasks\n• Install MCPs for your agents\n• Configure existing MCPs\n• Troubleshoot MCP issues\n\nWhat would you like to do?",
          timestamp: new Date()
        }

        setMessages(prev => [...prev, assistantMessage])
      }
    } catch (error) {
      console.error('Error processing message:', error)
      
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: "I encountered an error processing your request. Please try again or rephrase your question.",
        timestamp: new Date()
      }

      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handleActionClick = async (action: NonNullable<ChatMessage['actions']>[0]) => {
    switch (action.type) {
      case 'install':
        if (action.mcpId) {
          onMCPInstall?.(action.mcpId)
        } else if (action.parameters?.query) {
          // Search for MCPs
          const searchMessage = `Show me ${action.parameters.query} MCPs`
          setInputValue(searchMessage)
          handleSendMessage()
        }
        break
        
      case 'configure':
        if (action.parameters?.installationId) {
          onMCPConfigure?.(action.parameters.installationId)
        }
        break
        
      case 'learn_more':
        // Open documentation or detailed view
        if (action.mcpId) {
          // This would open MCP details
          console.log('Show MCP details:', action.mcpId)
        }
        break
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion)
    setShowSuggestions(false)
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700">
      {/* Header */}
      <div className="flex items-center space-x-3 p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
          <Bot className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        </div>
        <div>
          <h3 className="font-semibold text-gray-900 dark:text-white">MCP Assistant</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">Ask me anything about MCPs</p>
        </div>
        <div className="ml-auto">
          <Sparkles className="h-5 w-5 text-yellow-500" />
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(message => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.type === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
              }`}
            >
              <div className="whitespace-pre-wrap text-sm">{message.content}</div>
              
              {/* Recommendations */}
              {message.recommendations && message.recommendations.length > 0 && (
                <div className="mt-3 space-y-2">
                  {message.recommendations.slice(0, 3).map(rec => (
                    <div
                      key={rec.mcp.id}
                      className="p-3 bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium text-sm">{rec.mcp.name}</h4>
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <span>{(rec.confidence * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                        {rec.mcp.description}
                      </p>
                      <p className="text-xs text-blue-600 dark:text-blue-400">
                        {rec.reason}
                      </p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {rec.mcp.capabilities.slice(0, 3).map(cap => (
                          <span
                            key={cap}
                            className="px-2 py-1 bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs rounded"
                          >
                            {cap}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Action Buttons */}
              {message.actions && message.actions.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {message.actions.map((action, index) => (
                    <button
                      key={index}
                      onClick={() => handleActionClick(action)}
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs 
                               rounded-full transition-colors duration-200 flex items-center space-x-1"
                    >
                      {action.type === 'install' && <Download className="h-3 w-3" />}
                      {action.type === 'configure' && <Settings className="h-3 w-3" />}
                      {action.type === 'learn_more' && <ExternalLink className="h-3 w-3" />}
                      <span>{action.label}</span>
                    </button>
                  ))}
                </div>
              )}
              
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        
        {isAnalyzing && (
          <div className="flex justify-start">
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
              <div className="flex items-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Analyzing...</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Suggestions */}
      {showSuggestions && (
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2 mb-3">
            <Lightbulb className="h-4 w-4 text-yellow-500" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Try asking:
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestedQueries.slice(0, 3).map((suggestion, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(suggestion)}
                className="px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 
                         text-sm rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 
                         transition-colors duration-200"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex space-x-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask me about MCPs..."
            disabled={!session || isAnalyzing}
            className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md 
                     bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                     focus:ring-2 focus:ring-blue-500 focus:border-transparent
                     disabled:bg-gray-100 dark:disabled:bg-gray-700 disabled:cursor-not-allowed"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || !session || isAnalyzing}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 
                     text-white rounded-md transition-colors duration-200 
                     disabled:cursor-not-allowed"
          >
            Send
          </button>
        </div>
        
        {!session && (
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            Sign in to get personalized MCP recommendations
          </p>
        )}
      </div>
    </div>
  )
}
