
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { 
  Search, 
  Zap, 
  Star, 
  Download, 
  Settings, 
  CheckCircle,
  AlertCircle,
  Clock,
  ExternalLink,
  Filter,
  Package
} from 'lucide-react'

interface MCPRecommendation {
  id: string
  name: string
  description: string
  capabilities: string[]
  compatibility: string[]
  installationComplexity: 'easy' | 'moderate' | 'complex'
  popularity: number
  rating: number
  tags: string[]
  version?: string
  author?: string
  documentation?: string
}

interface MCPIntegrationPanelProps {
  suggestions: MCPRecommendation[]
  onComplete: (mcp: any) => void
  onCancel: () => void
}

interface InstalledMCP {
  id: string
  name: string
  version: string
  status: 'active' | 'inactive' | 'error'
  lastUsed?: Date
}

export function MCPIntegrationPanel({ suggestions, onComplete, onCancel }: MCPIntegrationPanelProps) {
  const [activeTab, setActiveTab] = useState<'browse' | 'install' | 'manage'>('browse')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedMCP, setSelectedMCP] = useState<MCPRecommendation | null>(null)
  const [installedMCPs, setInstalledMCPs] = useState<InstalledMCP[]>([])
  const [isInstalling, setIsInstalling] = useState(false)
  const [installProgress, setInstallProgress] = useState(0)
  const [availableMCPs, setAvailableMCPs] = useState<MCPRecommendation[]>([])

  useEffect(() => {
    loadAvailableMCPs()
    loadInstalledMCPs()
  }, [])

  const loadAvailableMCPs = async () => {
    // In a real app, this would fetch from MCP registry
    const mockMCPs: MCPRecommendation[] = [
      {
        id: 'web-search-mcp',
        name: 'Web Search MCP',
        description: 'Advanced web searching and information retrieval capabilities',
        capabilities: ['search', 'crawling', 'content_extraction', 'real_time_data'],
        compatibility: ['research_assistant', 'data_analyst'],
        installationComplexity: 'easy',
        popularity: 95,
        rating: 4.8,
        tags: ['search', 'web', 'research', 'google'],
        version: '2.1.0',
        author: 'MCP Community',
        documentation: 'https://docs.example.com/web-search-mcp'
      },
      {
        id: 'data-processing-mcp',
        name: 'Data Processing MCP',
        description: 'Comprehensive data manipulation, cleaning, and analysis toolkit',
        capabilities: ['data_cleaning', 'transformation', 'analysis', 'pandas_integration'],
        compatibility: ['data_analyst', 'research_assistant'],
        installationComplexity: 'moderate',
        popularity: 88,
        rating: 4.7,
        tags: ['data', 'analysis', 'pandas', 'numpy', 'csv'],
        version: '3.0.2',
        author: 'DataTools Inc',
        documentation: 'https://docs.example.com/data-processing-mcp'
      },
      {
        id: 'code-execution-mcp',
        name: 'Code Execution MCP',
        description: 'Safe code execution environment supporting multiple programming languages',
        capabilities: ['code_execution', 'testing', 'debugging', 'sandbox'],
        compatibility: ['code_assistant', 'data_analyst'],
        installationComplexity: 'complex',
        popularity: 92,
        rating: 4.9,
        tags: ['code', 'execution', 'python', 'javascript', 'development'],
        version: '1.5.3',
        author: 'DevTools Co',
        documentation: 'https://docs.example.com/code-execution-mcp'
      },
      ...suggestions
    ]

    setAvailableMCPs(mockMCPs)
  }

  const loadInstalledMCPs = async () => {
    // Mock installed MCPs
    const mockInstalled: InstalledMCP[] = [
      {
        id: 'basic-search-mcp',
        name: 'Basic Search',
        version: '1.0.0',
        status: 'active',
        lastUsed: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'file-manager-mcp',
        name: 'File Manager',
        version: '2.1.1',
        status: 'inactive'
      }
    ]

    setInstalledMCPs(mockInstalled)
  }

  const handleInstallMCP = async (mcp: MCPRecommendation) => {
    setIsInstalling(true)
    setInstallProgress(0)

    try {
      // Simulate installation progress
      const progressSteps = [
        { step: 'Downloading package', progress: 20 },
        { step: 'Installing dependencies', progress: 50 },
        { step: 'Configuring MCP', progress: 80 },
        { step: 'Running tests', progress: 95 },
        { step: 'Installation complete', progress: 100 }
      ]

      for (const { step, progress } of progressSteps) {
        setInstallProgress(progress)
        await new Promise(resolve => setTimeout(resolve, 1000))
      }

      // Add to installed MCPs
      const newInstalledMCP: InstalledMCP = {
        id: mcp.id,
        name: mcp.name,
        version: mcp.version || '1.0.0',
        status: 'active'
      }

      setInstalledMCPs(prev => [...prev, newInstalledMCP])
      setActiveTab('manage')
      onComplete({ mcp, installation: 'success' })

    } catch (error) {
      console.error('MCP installation failed:', error)
    } finally {
      setIsInstalling(false)
      setInstallProgress(0)
    }
  }

  const filteredMCPs = availableMCPs.filter(mcp =>
    mcp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mcp.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mcp.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const renderBrowseTab = () => (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="flex space-x-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search MCP tools..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline">
          <Filter className="h-4 w-4 mr-2" />
          Filter
        </Button>
      </div>

      {/* Recommended MCPs */}
      {suggestions.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-lg font-semibold text-white flex items-center">
            <Zap className="h-5 w-5 mr-2 text-yellow-400" />
            Recommended for You
          </h3>
          <div className="grid gap-3">
            {suggestions.map((mcp) => (
              <Card key={mcp.id} className="bg-yellow-500/10 border-yellow-500/20">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <Package className="h-5 w-5 text-yellow-400" />
                        <h4 className="font-semibold text-yellow-300">{mcp.name}</h4>
                        <Badge variant="secondary" className="text-xs">Recommended</Badge>
                      </div>
                      <p className="text-sm text-gray-300 mb-3">{mcp.description}</p>
                      <div className="flex items-center space-x-4 text-sm">
                        <div className="flex items-center space-x-1">
                          <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                          <span className="text-gray-300">{mcp.rating}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Download className="h-3 w-3 text-gray-400" />
                          <span className="text-gray-300">{mcp.popularity}%</span>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className={`text-xs ${
                            mcp.installationComplexity === 'easy' ? 'text-green-300' :
                            mcp.installationComplexity === 'moderate' ? 'text-yellow-300' : 'text-red-300'
                          }`}
                        >
                          {mcp.installationComplexity}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <Button 
                        size="sm" 
                        onClick={() => handleInstallMCP(mcp)}
                        disabled={isInstalling}
                      >
                        Install
                      </Button>
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Separator />

      {/* All Available MCPs */}
      <div className="space-y-2">
        <h3 className="text-lg font-semibold text-white">All Available MCPs</h3>
        <div className="grid gap-3">
          {filteredMCPs.map((mcp) => (
            <Card key={mcp.id} className="hover:bg-gray-800/50 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Package className="h-5 w-5 text-blue-400" />
                      <h4 className="font-semibold text-white">{mcp.name}</h4>
                      {mcp.version && (
                        <Badge variant="outline" className="text-xs">
                          v{mcp.version}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-300 mb-3">{mcp.description}</p>
                    
                    {/* Capabilities */}
                    <div className="flex flex-wrap gap-1 mb-3">
                      {mcp.capabilities.slice(0, 4).map((cap) => (
                        <Badge key={cap} variant="secondary" className="text-xs">
                          {cap}
                        </Badge>
                      ))}
                      {mcp.capabilities.length > 4 && (
                        <Badge variant="secondary" className="text-xs">
                          +{mcp.capabilities.length - 4} more
                        </Badge>
                      )}
                    </div>

                    <div className="flex items-center space-x-4 text-sm">
                      <div className="flex items-center space-x-1">
                        <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-gray-300">{mcp.rating}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Download className="h-3 w-3 text-gray-400" />
                        <span className="text-gray-300">{mcp.popularity}%</span>
                      </div>
                      {mcp.author && (
                        <span className="text-gray-400">by {mcp.author}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col space-y-2">
                    <Button 
                      size="sm" 
                      onClick={() => handleInstallMCP(mcp)}
                      disabled={isInstalling || installedMCPs.some(installed => installed.id === mcp.id)}
                    >
                      {installedMCPs.some(installed => installed.id === mcp.id) ? 'Installed' : 'Install'}
                    </Button>
                    {mcp.documentation && (
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )

  const renderManageTab = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Installed MCPs</h3>
        <Badge variant="secondary">
          {installedMCPs.length} installed
        </Badge>
      </div>

      {installedMCPs.length === 0 ? (
        <div className="text-center py-8">
          <Package className="h-12 w-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-400">No MCPs installed yet</p>
          <Button 
            className="mt-4" 
            onClick={() => setActiveTab('browse')}
          >
            Browse MCP Store
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {installedMCPs.map((mcp) => (
            <Card key={mcp.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      mcp.status === 'active' ? 'bg-green-500/20' :
                      mcp.status === 'error' ? 'bg-red-500/20' : 'bg-gray-500/20'
                    }`}>
                      {mcp.status === 'active' && <CheckCircle className="h-5 w-5 text-green-400" />}
                      {mcp.status === 'error' && <AlertCircle className="h-5 w-5 text-red-400" />}
                      {mcp.status === 'inactive' && <Clock className="h-5 w-5 text-gray-400" />}
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">{mcp.name}</h4>
                      <div className="flex items-center space-x-2 text-sm text-gray-400">
                        <span>v{mcp.version}</span>
                        <span>•</span>
                        <span className="capitalize">{mcp.status}</span>
                        {mcp.lastUsed && (
                          <>
                            <span>•</span>
                            <span>Used {mcp.lastUsed.toLocaleDateString()}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm">
                      <Settings className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant={mcp.status === 'active' ? 'secondary' : 'default'}
                      size="sm"
                    >
                      {mcp.status === 'active' ? 'Disable' : 'Enable'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold text-white flex items-center">
            <Zap className="h-6 w-6 mr-3 text-green-400" />
            MCP Integration Hub
          </h1>
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
        </div>
        <p className="text-gray-400">
          Discover, install, and manage Model Context Protocol tools
        </p>

        {/* Installation Progress */}
        {isInstalling && (
          <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
            <div className="flex items-center space-x-3 mb-2">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-400"></div>
              <span className="text-blue-300 font-medium">Installing MCP...</span>
            </div>
            <Progress value={installProgress} className="w-full" />
          </div>
        )}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="flex-1 flex flex-col">
        <div className="px-6 pt-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="browse">Browse MCPs</TabsTrigger>
            <TabsTrigger value="manage">Manage Installed</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="browse" className="flex-1 m-0">
          <ScrollArea className="h-full p-6">
            {renderBrowseTab()}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="manage" className="flex-1 m-0">
          <ScrollArea className="h-full p-6">
            {renderManageTab()}
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}
