
/**
 * MCP Marketplace Component - Browse, search, and install MCPs
 */

'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { Search, Filter, Star, Download, CheckCircle, AlertCircle, ExternalLink, Zap, Shield } from 'lucide-react'

interface MCP {
  id: string
  name: string
  slug: string
  description: string
  category: string
  provider: string
  capabilities: string[]
  version: string
  rating: number
  installCount: number
  isVerified: boolean
  isInstalled?: boolean
  securityLevel: 'official' | 'verified' | 'community'
  iconUrl?: string
  repositoryUrl?: string
  documentationUrl?: string
}

interface MCPMarketplaceProps {
  onInstall?: (mcp: MCP) => void
  workspaceId?: string
}

export function MCPMarketplace({ onInstall, workspaceId }: MCPMarketplaceProps) {
  const { data: session } = useSession()
  const [mcps, setMcps] = useState<MCP[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [sortBy, setSortBy] = useState<'name' | 'rating' | 'installs' | 'updated'>('rating')
  const [showInstallDialog, setShowInstallDialog] = useState<MCP | null>(null)

  const categories = [
    { value: 'all', label: 'All Categories', icon: '🔧' },
    { value: 'productivity', label: 'Productivity', icon: '⚡' },
    { value: 'development', label: 'Development', icon: '💻' },
    { value: 'data', label: 'Data & Analytics', icon: '📊' },
    { value: 'ai', label: 'AI & ML', icon: '🤖' },
    { value: 'communication', label: 'Communication', icon: '💬' },
    { value: 'automation', label: 'Automation', icon: '🔄' }
  ]

  const loadMCPs = useCallback(async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        q: searchQuery,
        ...(selectedCategory !== 'all' && { category: selectedCategory })
      })

      const response = await fetch(`/api/mcp?${params}`)
      if (response.ok) {
        const data = await response.json()
        setMcps(data.mcps || [])
      }
    } catch (error) {
      console.error('Error loading MCPs:', error)
    } finally {
      setLoading(false)
    }
  }, [searchQuery, selectedCategory])

  useEffect(() => {
    loadMCPs()
  }, [loadMCPs])

  const handleInstall = async (mcp: MCP) => {
    try {
      const response = await fetch('/api/mcp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'install',
          mcpRegistryId: mcp.id,
          workspaceId
        })
      })

      const result = await response.json()
      
      if (result.success) {
        // Update MCP as installed
        setMcps(prev => prev.map(m => 
          m.id === mcp.id ? { ...m, isInstalled: true } : m
        ))
        
        onInstall?.(mcp)
        setShowInstallDialog(null)
        
        // Show success notification
        // You could use a toast notification here
      } else {
        console.error('Installation failed:', result.error)
      }
    } catch (error) {
      console.error('Error installing MCP:', error)
    }
  }

  const getSecurityBadge = (securityLevel: string) => {
    switch (securityLevel) {
      case 'official':
        return (
          <div className="flex items-center space-x-1 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
            <Shield className="h-3 w-3" />
            <span>Official</span>
          </div>
        )
      case 'verified':
        return (
          <div className="flex items-center space-x-1 px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
            <CheckCircle className="h-3 w-3" />
            <span>Verified</span>
          </div>
        )
      default:
        return (
          <div className="flex items-center space-x-1 px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded-full">
            <span>Community</span>
          </div>
        )
    }
  }

  const filteredAndSortedMCPs = mcps
    .filter(mcp => {
      const matchesSearch = mcp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          mcp.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          mcp.capabilities.some(cap => cap.toLowerCase().includes(searchQuery.toLowerCase()))
      
      const matchesCategory = selectedCategory === 'all' || mcp.category === selectedCategory
      
      return matchesSearch && matchesCategory
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name)
        case 'rating':
          return b.rating - a.rating
        case 'installs':
          return b.installCount - a.installCount
        default:
          return 0
      }
    })

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        <span className="ml-3 text-gray-600">Loading MCPs...</span>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">MCP Marketplace</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Discover and install Model Context Protocol servers to extend your agents' capabilities
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 bg-white dark:bg-gray-800 text-sm"
          >
            <option value="rating">Sort by Rating</option>
            <option value="name">Sort by Name</option>
            <option value="installs">Sort by Popularity</option>
          </select>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4">
        {/* Search */}
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search MCPs by name, description, or capabilities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg 
                       bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                       focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="lg:w-64">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg 
                     bg-white dark:bg-gray-800 text-gray-900 dark:text-white
                     focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {categories.map(category => (
              <option key={category.value} value={category.value}>
                {category.icon} {category.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          {filteredAndSortedMCPs.length} MCPs found
        </p>
      </div>

      {/* MCP Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAndSortedMCPs.map(mcp => (
          <div
            key={mcp.id}
            className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 
                     hover:shadow-lg transition-shadow duration-200"
          >
            {/* MCP Header */}
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  {mcp.iconUrl ? (
                    <img src={mcp.iconUrl} alt={mcp.name} className="h-10 w-10 rounded-lg" />
                  ) : (
                    <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 
                                  flex items-center justify-center">
                      <Zap className="h-5 w-5 text-white" />
                    </div>
                  )}
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">{mcp.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">by {mcp.provider}</p>
                  </div>
                </div>
                
                {getSecurityBadge(mcp.securityLevel)}
              </div>

              <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
                {mcp.description}
              </p>

              {/* Capabilities Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {mcp.capabilities.slice(0, 3).map(capability => (
                  <span
                    key={capability}
                    className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 
                             text-xs rounded-full"
                  >
                    {capability}
                  </span>
                ))}
                {mcp.capabilities.length > 3 && (
                  <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-500 text-xs rounded-full">
                    +{mcp.capabilities.length - 3} more
                  </span>
                )}
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400 mb-4">
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>{mcp.rating.toFixed(1)}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Download className="h-4 w-4" />
                  <span>{mcp.installCount.toLocaleString()}</span>
                </div>
                <span className="text-xs">v{mcp.version}</span>
              </div>

              {/* Actions */}
              <div className="flex space-x-2">
                {mcp.isInstalled ? (
                  <div className="flex-1 flex items-center justify-center px-4 py-2 
                                bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 
                                rounded-md text-sm font-medium">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Installed
                  </div>
                ) : (
                  <button
                    onClick={() => setShowInstallDialog(mcp)}
                    disabled={!session}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 
                             text-white px-4 py-2 rounded-md text-sm font-medium 
                             transition-colors duration-200 disabled:cursor-not-allowed"
                  >
                    Install
                  </button>
                )}
                
                {mcp.repositoryUrl && (
                  <a
                    href={mcp.repositoryUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-2 border border-gray-300 dark:border-gray-600 
                             text-gray-700 dark:text-gray-300 rounded-md text-sm 
                             hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Install Dialog */}
      {showInstallDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
              Install {showInstallDialog.name}?
            </h3>
            
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              This will install the {showInstallDialog.name} MCP and make it available to your agents.
            </p>

            <div className="flex space-x-3">
              <button
                onClick={() => handleInstall(showInstallDialog)}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 
                         rounded-md font-medium transition-colors duration-200"
              >
                Install
              </button>
              <button
                onClick={() => setShowInstallDialog(null)}
                className="flex-1 border border-gray-300 dark:border-gray-600 
                         text-gray-700 dark:text-gray-300 px-4 py-2 rounded-md 
                         hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* No Results */}
      {filteredAndSortedMCPs.length === 0 && !loading && (
        <div className="text-center py-12">
          <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No MCPs found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Try adjusting your search criteria or browse different categories.
          </p>
        </div>
      )}
    </div>
  )
}
