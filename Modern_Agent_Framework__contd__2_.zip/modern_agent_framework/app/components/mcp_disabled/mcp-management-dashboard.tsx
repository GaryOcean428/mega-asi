
/**
 * MCP Management Dashboard - Manage installed MCPs, monitor health, and configure settings
 */

'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { 
  Server, 
  Settings, 
  Activity, 
  AlertCircle, 
  CheckCircle, 
  Trash2, 
  RefreshCw, 
  TrendingUp,
  Clock,
  Zap,
  Shield,
  ExternalLink
} from 'lucide-react'

interface MCPInstallation {
  id: string
  name: string
  description: string
  version: string
  status: 'installing' | 'active' | 'error' | 'disabled'
  healthStatus: 'healthy' | 'warning' | 'error' | 'unknown'
  config: Record<string, any>
  capabilities: string[]
  lastUsed?: Date
  usageCount?: number
  errorMessage?: string
  mcpRegistry: {
    name: string
    provider: string
    category: string
    securityLevel: string
    repositoryUrl?: string
  }
}

interface MCPManagementDashboardProps {
  workspaceId?: string
}

export function MCPManagementDashboard({ workspaceId }: MCPManagementDashboardProps) {
  const { data: session } = useSession()
  const [installations, setInstallations] = useState<MCPInstallation[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedMCP, setSelectedMCP] = useState<MCPInstallation | null>(null)
  const [showConfigDialog, setShowConfigDialog] = useState(false)
  const [insights, setInsights] = useState<any>(null)

  const loadInstallations = useCallback(async () => {
    if (!session?.user?.id) return

    try {
      setLoading(true)
      const params = new URLSearchParams({
        action: 'installed',
        ...(workspaceId && { workspace: workspaceId })
      })

      const response = await fetch(`/api/mcp?${params}`)
      if (response.ok) {
        const data = await response.json()
        setInstallations(data.mcps || [])
      }
    } catch (error) {
      console.error('Error loading installations:', error)
    } finally {
      setLoading(false)
    }
  }, [session?.user?.id, workspaceId])

  const loadInsights = useCallback(async () => {
    if (!session?.user?.id) return

    try {
      const params = new URLSearchParams({
        type: 'insights',
        ...(workspaceId && { workspace: workspaceId })
      })

      const response = await fetch(`/api/mcp/assistant?${params}`)
      if (response.ok) {
        const data = await response.json()
        setInsights(data.insights)
      }
    } catch (error) {
      console.error('Error loading insights:', error)
    }
  }, [session?.user?.id, workspaceId])

  useEffect(() => {
    loadInstallations()
    loadInsights()
  }, [loadInstallations, loadInsights])

  const handleHealthCheck = async (installation: MCPInstallation) => {
    try {
      const response = await fetch(`/api/mcp/${installation.id}/health`)
      if (response.ok) {
        const result = await response.json()
        
        // Update installation health status
        setInstallations(prev => prev.map(inst =>
          inst.id === installation.id
            ? { ...inst, healthStatus: result.status }
            : inst
        ))
      }
    } catch (error) {
      console.error('Error checking health:', error)
    }
  }

  const handleUninstall = async (installation: MCPInstallation) => {
    if (!confirm(`Are you sure you want to uninstall ${installation.name}?`)) {
      return
    }

    try {
      const response = await fetch(`/api/mcp?installationId=${installation.id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setInstallations(prev => prev.filter(inst => inst.id !== installation.id))
      }
    } catch (error) {
      console.error('Error uninstalling MCP:', error)
    }
  }

  const handleRestart = async (installation: MCPInstallation) => {
    try {
      const response = await fetch(`/api/mcp/${installation.id}/health`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'restart' })
      })

      if (response.ok) {
        // Refresh the installation data
        loadInstallations()
      }
    } catch (error) {
      console.error('Error restarting MCP:', error)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case 'installing':
        return <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />
      default:
        return <AlertCircle className="h-5 w-5 text-gray-400" />
    }
  }

  const getHealthIcon = (health: string) => {
    switch (health) {
      case 'healthy':
        return <Activity className="h-4 w-4 text-green-500" />
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <Activity className="h-4 w-4 text-gray-400" />
    }
  }

  const getSecurityBadge = (level: string) => {
    const colors = {
      official: 'bg-blue-100 text-blue-800',
      verified: 'bg-green-100 text-green-800',
      community: 'bg-gray-100 text-gray-800'
    }
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[level as keyof typeof colors] || colors.community}`}>
        <Shield className="h-3 w-3 inline mr-1" />
        {level.charAt(0).toUpperCase() + level.slice(1)}
      </span>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        <span className="ml-3 text-gray-600">Loading your MCPs...</span>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">MCP Management</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Monitor and manage your installed Model Context Protocol servers
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={loadInstallations}
            className="flex items-center space-x-2 px-4 py-2 border border-gray-300 dark:border-gray-600 
                     rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      {insights && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total MCPs</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {installations.length}
                </p>
              </div>
              <Server className="h-8 w-8 text-blue-500" />
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Active</p>
                <p className="text-2xl font-bold text-green-600">
                  {installations.filter(i => i.status === 'active').length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Issues</p>
                <p className="text-2xl font-bold text-red-600">
                  {installations.filter(i => i.status === 'error' || i.healthStatus === 'error').length}
                </p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-500" />
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Usage</p>
                <p className="text-2xl font-bold text-blue-600">
                  {installations.reduce((sum, i) => sum + (i.usageCount || 0), 0)}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
          </div>
        </div>
      )}

      {/* MCP List */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Installed MCPs ({installations.length})
          </h3>
        </div>
        
        {installations.length === 0 ? (
          <div className="p-8 text-center">
            <Server className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              No MCPs installed
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Get started by browsing the MCP marketplace and installing your first protocol server.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {installations.map(installation => (
              <div key={installation.id} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(installation.status)}
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">
                          {installation.name}
                        </h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {installation.mcpRegistry.provider} • v{installation.version}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {getSecurityBadge(installation.mcpRegistry.securityLevel)}
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                        {installation.mcpRegistry.category}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {/* Health Status */}
                    <div className="flex items-center space-x-1">
                      {getHealthIcon(installation.healthStatus)}
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {installation.healthStatus}
                      </span>
                    </div>
                    
                    {/* Actions */}
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleHealthCheck(installation)}
                        className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-200"
                        title="Check Health"
                      >
                        <Activity className="h-4 w-4" />
                      </button>
                      
                      <button
                        onClick={() => setSelectedMCP(installation)}
                        className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-200"
                        title="Configure"
                      >
                        <Settings className="h-4 w-4" />
                      </button>
                      
                      <button
                        onClick={() => handleRestart(installation)}
                        className="p-2 text-gray-400 hover:text-green-600 transition-colors duration-200"
                        title="Restart"
                      >
                        <RefreshCw className="h-4 w-4" />
                      </button>
                      
                      {installation.mcpRegistry.repositoryUrl && (
                        <a
                          href={installation.mcpRegistry.repositoryUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-200"
                          title="View Repository"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      )}
                      
                      <button
                        onClick={() => handleUninstall(installation)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors duration-200"
                        title="Uninstall"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* Description */}
                <p className="text-gray-600 dark:text-gray-300 text-sm mt-2 ml-8">
                  {installation.description}
                </p>
                
                {/* Capabilities */}
                <div className="flex flex-wrap gap-2 mt-3 ml-8">
                  {installation.capabilities.slice(0, 5).map(capability => (
                    <span
                      key={capability}
                      className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 
                               text-xs rounded"
                    >
                      <Zap className="h-3 w-3 inline mr-1" />
                      {capability}
                    </span>
                  ))}
                  {installation.capabilities.length > 5 && (
                    <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-500 text-xs rounded">
                      +{installation.capabilities.length - 5} more
                    </span>
                  )}
                </div>
                
                {/* Usage & Error Info */}
                <div className="flex items-center justify-between mt-3 ml-8">
                  <div className="flex items-center space-x-4 text-xs text-gray-500">
                    {installation.lastUsed && (
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>Last used {installation.lastUsed.toLocaleDateString()}</span>
                      </div>
                    )}
                    {installation.usageCount !== undefined && (
                      <span>{installation.usageCount} calls</span>
                    )}
                  </div>
                  
                  {installation.errorMessage && (
                    <div className="text-xs text-red-600 flex items-center space-x-1">
                      <AlertCircle className="h-3 w-3" />
                      <span>{installation.errorMessage}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Usage Insights */}
      {insights && insights.insights && insights.insights.length > 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Usage Insights
          </h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white mb-2">Key Insights</h4>
              <ul className="space-y-2">
                {insights.insights.slice(0, 3).map((insight: string, index: number) => (
                  <li key={index} className="flex items-start space-x-2">
                    <TrendingUp className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-600 dark:text-gray-300">{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            {insights.recommendations && insights.recommendations.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">Recommendations</h4>
                <ul className="space-y-2">
                  {insights.recommendations.slice(0, 3).map((rec: string, index: number) => (
                    <li key={index} className="flex items-start space-x-2">
                      <Zap className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-600 dark:text-gray-300">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Configuration Dialog */}
      {selectedMCP && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                Configure {selectedMCP.name}
              </h3>
              <button
                onClick={() => setSelectedMCP(null)}
                className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Configuration
                </label>
                <pre className="bg-gray-100 dark:bg-gray-700 p-3 rounded-md text-sm overflow-x-auto">
                  {JSON.stringify(selectedMCP.config, null, 2)}
                </pre>
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setSelectedMCP(null)}
                  className="flex-1 border border-gray-300 dark:border-gray-600 
                           text-gray-700 dark:text-gray-300 px-4 py-2 rounded-md 
                           hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
