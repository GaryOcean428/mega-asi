
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Shield,
  CheckCircle,
  AlertCircle,
  FileText,
  Download,
  Calendar,
  Clock,
  Globe,
  Lock,
  Eye,
  TrendingUp,
  Award
} from 'lucide-react'

interface ComplianceFramework {
  id: string
  name: string
  description: string
  requirements: ComplianceRequirement[]
  completionRate: number
  status: 'compliant' | 'partial' | 'non-compliant'
  lastAssessment: Date
  nextAssessment: Date
}

interface ComplianceRequirement {
  id: string
  name: string
  description: string
  category: string
  status: 'met' | 'partial' | 'not-met' | 'not-applicable'
  evidence: string[]
  lastVerified: Date
  assignedTo?: string
}

interface ComplianceReport {
  id: string
  frameworkId: string
  name: string
  generatedAt: Date
  completionRate: number
  findings: ComplianceFinding[]
  recommendations: string[]
}

interface ComplianceFinding {
  id: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  title: string
  description: string
  requirement: string
  remediation: string
  status: 'open' | 'in-progress' | 'resolved'
}

export function ComplianceDashboard() {
  const [frameworks, setFrameworks] = useState<ComplianceFramework[]>([])
  const [reports, setReports] = useState<ComplianceReport[]>([])
  const [selectedFramework, setSelectedFramework] = useState<string>('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadComplianceData()
  }, [])

  const loadComplianceData = async () => {
    try {
      setLoading(true)
      // In production, these would be API calls
      setFrameworks(getMockFrameworks())
      setReports(getMockReports())
    } catch (error) {
      console.error('Failed to load compliance data:', error)
    } finally {
      setLoading(false)
    }
  }

  const generateComplianceReport = async (frameworkId: string) => {
    try {
      // In production, this would call an API to generate the report
      console.log('Generating compliance report for framework:', frameworkId)
    } catch (error) {
      console.error('Failed to generate report:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'compliant':
      case 'met':
      case 'resolved':
        return 'bg-green-500/20 text-green-300'
      case 'partial':
      case 'in-progress':
        return 'bg-yellow-500/20 text-yellow-300'
      case 'non-compliant':
      case 'not-met':
      case 'open':
        return 'bg-red-500/20 text-red-300'
      case 'not-applicable':
        return 'bg-gray-500/20 text-gray-300'
      default:
        return 'bg-gray-500/20 text-gray-300'
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'bg-blue-500/20 text-blue-300'
      case 'medium': return 'bg-yellow-500/20 text-yellow-300'
      case 'high': return 'bg-red-500/20 text-red-300'
      case 'critical': return 'bg-red-800/20 text-red-200'
      default: return 'bg-gray-500/20 text-gray-300'
    }
  }

  const overallCompliance = frameworks.length > 0 
    ? Math.round(frameworks.reduce((acc, f) => acc + f.completionRate, 0) / frameworks.length)
    : 0

  const criticalFindings = reports.reduce((acc, report) => 
    acc + report.findings.filter(f => f.severity === 'critical' && f.status === 'open').length, 0
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Compliance Dashboard</h1>
          <p className="text-gray-400 mt-2">
            Monitor regulatory compliance and security frameworks
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Generate Report
          </Button>
          
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <Award className="h-6 w-6 text-green-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{overallCompliance}%</div>
                <div className="text-sm text-gray-400">Overall Compliance</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Shield className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{frameworks.length}</div>
                <div className="text-sm text-gray-400">Active Frameworks</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-500/20 rounded-lg">
                <AlertCircle className="h-6 w-6 text-red-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">{criticalFindings}</div>
                <div className="text-sm text-gray-400">Critical Issues</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <TrendingUp className="h-6 w-6 text-purple-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">
                  {frameworks.filter(f => f.status === 'compliant').length}
                </div>
                <div className="text-sm text-gray-400">Fully Compliant</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value="frameworks" onValueChange={() => {}} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="frameworks">Frameworks</TabsTrigger>
          <TabsTrigger value="requirements">Requirements</TabsTrigger>
          <TabsTrigger value="findings">Findings</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="frameworks">
          <FrameworksList 
            frameworks={frameworks} 
            onGenerateReport={generateComplianceReport}
            getStatusColor={getStatusColor}
          />
        </TabsContent>

        <TabsContent value="requirements">
          <RequirementsList 
            frameworks={frameworks}
            selectedFramework={selectedFramework}
            onFrameworkChange={setSelectedFramework}
            getStatusColor={getStatusColor}
          />
        </TabsContent>

        <TabsContent value="findings">
          <FindingsList 
            reports={reports}
            getSeverityColor={getSeverityColor}
            getStatusColor={getStatusColor}
          />
        </TabsContent>

        <TabsContent value="reports">
          <ReportsList reports={reports} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function FrameworksList({ 
  frameworks, 
  onGenerateReport, 
  getStatusColor 
}: { 
  frameworks: ComplianceFramework[]
  onGenerateReport: (id: string) => void
  getStatusColor: (status: string) => string
}) {
  return (
    <div className="grid gap-6">
      {frameworks.map((framework) => (
        <Card key={framework.id}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="font-semibold text-white">{framework.name}</h3>
                  <Badge className={getStatusColor(framework.status)}>
                    {framework.status}
                  </Badge>
                </div>
                <p className="text-gray-400 text-sm mb-4">{framework.description}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-gray-400">Completion Rate</div>
                    <div className="flex items-center space-x-2 mt-1">
                      <Progress value={framework.completionRate} className="flex-1" />
                      <span className="text-white font-medium">{framework.completionRate}%</span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-400">Last Assessment</div>
                    <div className="text-white text-sm">
                      {framework.lastAssessment.toLocaleDateString()}
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-400">Next Assessment</div>
                    <div className="text-white text-sm">
                      {framework.nextAssessment.toLocaleDateString()}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-gray-400">
                  <div>{framework.requirements.length} requirements</div>
                  <div>•</div>
                  <div>{framework.requirements.filter(r => r.status === 'met').length} completed</div>
                  <div>•</div>
                  <div>{framework.requirements.filter(r => r.status === 'not-met').length} pending</div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onGenerateReport(framework.id)}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Report
                </Button>
                
                <Button variant="outline" size="sm">
                  <Eye className="h-4 w-4 mr-2" />
                  Details
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function RequirementsList({
  frameworks,
  selectedFramework,
  onFrameworkChange,
  getStatusColor
}: {
  frameworks: ComplianceFramework[]
  selectedFramework: string
  onFrameworkChange: (id: string) => void
  getStatusColor: (status: string) => string
}) {
  const framework = selectedFramework 
    ? frameworks.find(f => f.id === selectedFramework) || frameworks[0]
    : frameworks[0]

  const requirements = framework?.requirements || []
  const requirementsByCategory = requirements.reduce((acc, req) => {
    if (!acc[req.category]) acc[req.category] = []
    acc[req.category].push(req)
    return acc
  }, {} as Record<string, ComplianceRequirement[]>)

  return (
    <div className="space-y-6">
      {frameworks.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <label className="text-sm font-medium text-gray-300">Framework:</label>
              <select
                value={framework?.id || ''}
                onChange={(e) => onFrameworkChange(e.target.value)}
                className="px-3 py-1 bg-gray-800 border border-gray-700 rounded text-white"
              >
                {frameworks.map(f => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
            </div>
          </CardContent>
        </Card>
      )}

      {Object.entries(requirementsByCategory).map(([category, reqs]) => (
        <Card key={category}>
          <CardHeader>
            <CardTitle className="text-white">{category}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {reqs.map((requirement) => (
              <div
                key={requirement.id}
                className="p-4 border border-gray-700 rounded-lg"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h4 className="font-medium text-white">{requirement.name}</h4>
                      <Badge className={getStatusColor(requirement.status)}>
                        {requirement.status.replace('-', ' ')}
                      </Badge>
                    </div>
                    
                    <p className="text-gray-400 text-sm mb-3">
                      {requirement.description}
                    </p>
                    
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>Verified {requirement.lastVerified.toLocaleDateString()}</span>
                      </div>
                      {requirement.assignedTo && (
                        <div>
                          Assigned to {requirement.assignedTo}
                        </div>
                      )}
                      {requirement.evidence.length > 0 && (
                        <div>
                          {requirement.evidence.length} evidence item(s)
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <Button variant="outline" size="sm">
                    View Evidence
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function FindingsList({
  reports,
  getSeverityColor,
  getStatusColor
}: {
  reports: ComplianceReport[]
  getSeverityColor: (severity: string) => string
  getStatusColor: (status: string) => string
}) {
  const allFindings = reports.flatMap(report => 
    report.findings.map(finding => ({ ...finding, reportId: report.id }))
  )

  const openFindings = allFindings.filter(f => f.status === 'open')

  return (
    <div className="space-y-4">
      {openFindings.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">No Open Findings</h3>
            <p className="text-gray-400">All compliance issues have been resolved</p>
          </CardContent>
        </Card>
      ) : (
        openFindings.map((finding) => (
          <Card key={finding.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h4 className="font-semibold text-white">{finding.title}</h4>
                    <Badge className={getSeverityColor(finding.severity)}>
                      {finding.severity}
                    </Badge>
                    <Badge className={getStatusColor(finding.status)}>
                      {finding.status}
                    </Badge>
                  </div>
                  
                  <p className="text-gray-400 text-sm mb-3">{finding.description}</p>
                  
                  <div className="mb-3">
                    <h5 className="text-sm font-medium text-gray-300 mb-1">Requirement:</h5>
                    <p className="text-sm text-gray-400">{finding.requirement}</p>
                  </div>
                  
                  <div>
                    <h5 className="text-sm font-medium text-gray-300 mb-1">Remediation:</h5>
                    <p className="text-sm text-gray-400">{finding.remediation}</p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    Assign
                  </Button>
                  <Button variant="outline" size="sm">
                    Mark Resolved
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  )
}

function ReportsList({ reports }: { reports: ComplianceReport[] }) {
  return (
    <div className="grid gap-4">
      {reports.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <FileText className="h-16 w-16 text-gray-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">No Reports Generated</h3>
            <p className="text-gray-400">Compliance reports will appear here</p>
          </CardContent>
        </Card>
      ) : (
        reports.map((report) => (
          <Card key={report.id}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-white mb-1">{report.name}</h4>
                  <div className="text-sm text-gray-400 mb-2">
                    Generated {report.generatedAt.toLocaleDateString()}
                  </div>
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="text-green-400">
                      {report.completionRate}% Complete
                    </div>
                    <div className="text-red-400">
                      {report.findings.length} Findings
                    </div>
                    <div className="text-yellow-400">
                      {report.recommendations.length} Recommendations
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    View
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  )
}

// Mock data functions
function getMockFrameworks(): ComplianceFramework[] {
  return [
    {
      id: 'soc2',
      name: 'SOC 2 Type II',
      description: 'Service Organization Control 2 Type II compliance framework focusing on security, availability, and confidentiality.',
      requirements: getMockRequirements('soc2'),
      completionRate: 85,
      status: 'partial',
      lastAssessment: new Date('2024-01-15'),
      nextAssessment: new Date('2024-07-15')
    },
    {
      id: 'gdpr',
      name: 'GDPR',
      description: 'General Data Protection Regulation compliance for data privacy and protection.',
      requirements: getMockRequirements('gdpr'),
      completionRate: 92,
      status: 'compliant',
      lastAssessment: new Date('2024-02-01'),
      nextAssessment: new Date('2024-08-01')
    },
    {
      id: 'iso27001',
      name: 'ISO 27001',
      description: 'International standard for information security management systems.',
      requirements: getMockRequirements('iso27001'),
      completionRate: 78,
      status: 'partial',
      lastAssessment: new Date('2024-01-30'),
      nextAssessment: new Date('2024-07-30')
    }
  ]
}

function getMockRequirements(frameworkId: string): ComplianceRequirement[] {
  const baseRequirements = [
    {
      id: `${frameworkId}-1`,
      name: 'Access Control',
      description: 'Implement proper access controls and user authentication',
      category: 'Security',
      status: 'met' as const,
      evidence: ['access-policy.pdf', 'audit-log.csv'],
      lastVerified: new Date('2024-02-01'),
      assignedTo: 'security-team@company.com'
    },
    {
      id: `${frameworkId}-2`,
      name: 'Data Encryption',
      description: 'Encrypt sensitive data at rest and in transit',
      category: 'Security',
      status: 'met' as const,
      evidence: ['encryption-cert.pdf'],
      lastVerified: new Date('2024-02-01')
    },
    {
      id: `${frameworkId}-3`,
      name: 'Incident Response',
      description: 'Maintain incident response procedures and documentation',
      category: 'Operations',
      status: 'partial' as const,
      evidence: ['incident-plan.pdf'],
      lastVerified: new Date('2024-01-15'),
      assignedTo: 'ops-team@company.com'
    }
  ]

  return baseRequirements
}

function getMockReports(): ComplianceReport[] {
  return [
    {
      id: 'report-1',
      frameworkId: 'soc2',
      name: 'SOC 2 Quarterly Assessment',
      generatedAt: new Date('2024-02-15'),
      completionRate: 85,
      findings: getMockFindings(),
      recommendations: [
        'Implement multi-factor authentication for all admin accounts',
        'Review and update incident response procedures',
        'Conduct regular security awareness training'
      ]
    }
  ]
}

function getMockFindings(): ComplianceFinding[] {
  return [
    {
      id: 'finding-1',
      severity: 'medium',
      title: 'Incomplete MFA Implementation',
      description: 'Multi-factor authentication is not enabled for all administrative accounts',
      requirement: 'Access Control - Administrative Access',
      remediation: 'Enable MFA for all admin accounts and enforce through policy',
      status: 'open'
    },
    {
      id: 'finding-2',
      severity: 'low',
      title: 'Outdated Security Documentation',
      description: 'Security policies have not been reviewed in the past 12 months',
      requirement: 'Policy Management - Documentation Review',
      remediation: 'Schedule annual policy review and update procedures',
      status: 'in-progress'
    }
  ]
}
