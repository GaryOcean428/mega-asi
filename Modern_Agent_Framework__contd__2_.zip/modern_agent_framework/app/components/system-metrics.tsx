
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Users, 
  Activity, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  Zap
} from 'lucide-react'
import { AgentMetrics } from '@/lib/types'
import { motion } from 'framer-motion'

interface SystemMetricsProps {
  refreshKey: number
}

export function SystemMetrics({ refreshKey }: SystemMetricsProps) {
  const [metrics, setMetrics] = useState<AgentMetrics | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchMetrics = async () => {
    try {
      const response = await fetch('/api/system/metrics')
      const data = await response.json()
      
      if (data.metrics) {
        setMetrics(data.metrics)
      }
    } catch (error) {
      console.error('Failed to fetch metrics:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMetrics()
  }, [refreshKey])

  if (loading || !metrics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} className="bg-gray-900/50 border-gray-800 animate-pulse">
            <CardHeader className="pb-2">
              <div className="h-4 bg-gray-700 rounded w-20"></div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-gray-700 rounded w-16 mb-2"></div>
              <div className="h-3 bg-gray-700 rounded w-24"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  const metricCards = [
    {
      title: 'Total Agents',
      value: metrics.totalAgents,
      icon: Users,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10'
    },
    {
      title: 'Active Agents',
      value: metrics.activeAgents,
      icon: Activity,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10'
    },
    {
      title: 'Completed Tasks',
      value: metrics.completedTasks,
      icon: CheckCircle,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-500/10'
    },
    {
      title: 'Pending Tasks',
      value: metrics.pendingTasks,
      icon: Clock,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10'
    },
    {
      title: 'Failed Tasks',
      value: metrics.failedTasks,
      icon: AlertTriangle,
      color: 'text-red-500',
      bgColor: 'bg-red-500/10'
    },
    {
      title: 'Avg. Completion Time',
      value: `${metrics.avgTaskCompletionTime}s`,
      icon: Zap,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10'
    }
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
      {metricCards.map((metric, index) => (
        <motion.div
          key={metric.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="bg-gray-900/50 border-gray-800 hover:bg-gray-800/50 transition-colors">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">
                {metric.title}
              </CardTitle>
              <div className={`rounded-full p-2 ${metric.bgColor}`}>
                <metric.icon className={`h-4 w-4 ${metric.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${metric.color}`}>
                {typeof metric.value === 'number' && metric.title !== 'Avg. Completion Time' ? (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    key={metric.value}
                  >
                    {metric.value}
                  </motion.span>
                ) : (
                  metric.value
                )}
              </div>
              <p className="text-xs text-gray-500">
                {metric.title === 'Active Agents' && `of ${metrics.totalAgents} total`}
                {metric.title === 'Completed Tasks' && 'successfully finished'}
                {metric.title === 'Pending Tasks' && 'awaiting execution'}
                {metric.title === 'Failed Tasks' && 'with errors'}
                {metric.title === 'Total Agents' && 'in the system'}
                {metric.title === 'Avg. Completion Time' && 'per task'}
              </p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
