
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { 
  Brain, 
  MessageSquare, 
  Bot, 
  Zap, 
  Users, 
  ArrowRight, 
  ArrowLeft,
  Play,
  CheckCircle,
  Sparkles,
  Target,
  Lightbulb,
  Rocket
} from 'lucide-react'

interface OnboardingStep {
  id: string
  title: string
  description: string
  content: React.ReactNode
  action?: {
    label: string
    handler: () => void
  }
  demoContent?: {
    type: 'chat' | 'visual' | 'interactive'
    data: any
  }
}

interface OnboardingFlowProps {
  onComplete: () => void
  onSkip: () => void
}

export function OnboardingFlow({ onComplete, onSkip }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set())
  const [isAnimating, setIsAnimating] = useState(false)

  const steps: OnboardingStep[] = [
    {
      id: 'welcome',
      title: 'Welcome to Intelligent Chat',
      description: 'Your AI-powered agent orchestration hub',
      content: (
        <div className="text-center space-y-6">
          <div className="relative">
            <div className="mx-auto w-32 h-32 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
              <Brain className="h-16 w-16 text-white animate-pulse" />
            </div>
            <div className="absolute -top-2 -right-2">
              <Sparkles className="h-8 w-8 text-yellow-400 animate-bounce" />
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-white">
              Transform Ideas into Action
            </h3>
            <p className="text-gray-300 max-w-md mx-auto">
              Simply describe what you want to achieve, and our AI will automatically create agents, 
              install tools, and set up collaborations for you.
            </p>
            <div className="flex justify-center space-x-4">
              <Badge variant="secondary" className="bg-blue-500/20 text-blue-300">
                🤖 Auto Agent Creation
              </Badge>
              <Badge variant="secondary" className="bg-green-500/20 text-green-300">
                ⚡ One-Click Tools
              </Badge>
              <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">
                👥 Team Collaboration
              </Badge>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'chat-demo',
      title: 'Chat Like You Mean It',
      description: 'See how natural conversation creates powerful automations',
      content: (
        <div className="space-y-6">
          <div className="bg-black/40 rounded-lg border border-gray-700 p-6">
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-semibold">You</span>
                </div>
                <div className="bg-blue-600/20 rounded-lg px-4 py-2 max-w-xs">
                  <p className="text-blue-200 text-sm">"I need help analyzing customer data"</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 justify-end">
                <div className="bg-purple-600/20 rounded-lg px-4 py-3 max-w-sm">
                  <div className="text-purple-200 text-sm space-y-2">
                    <p>💡 I'll create a data analyst agent for you!</p>
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2 text-xs">
                        <CheckCircle className="h-3 w-3 text-green-400" />
                        <span>Installing data processing tools</span>
                      </div>
                      <div className="flex items-center space-x-2 text-xs">
                        <CheckCircle className="h-3 w-3 text-green-400" />
                        <span>Setting up visualization capabilities</span>
                      </div>
                      <div className="flex items-center space-x-2 text-xs">
                        <CheckCircle className="h-3 w-3 text-green-400" />
                        <span>Configuring statistical analysis</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                  <Brain className="h-4 w-4 text-white" />
                </div>
              </div>

              <div className="bg-green-500/20 border border-green-500/40 rounded-lg p-3">
                <div className="flex items-center space-x-2 text-green-300">
                  <Rocket className="h-4 w-4" />
                  <span className="text-sm font-semibold">Agent "Data Wizard" created successfully!</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-gray-300 text-sm">
              No forms, no configuration - just natural conversation!
            </p>
          </div>
        </div>
      )
    },
    {
      id: 'features',
      title: 'Powerful Features at Your Fingertips',
      description: 'Discover what you can create with intelligent chat',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Bot className="h-6 w-6 text-blue-400" />
                <h4 className="font-semibold text-blue-300">Smart Agents</h4>
              </div>
              <p className="text-sm text-gray-300 mb-3">
                Create specialized AI agents for any task - data analysis, research, coding, writing, and more.
              </p>
              <Badge variant="outline" className="text-xs">Try: "Create a research assistant"</Badge>
            </div>

            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Zap className="h-6 w-6 text-green-400" />
                <h4 className="font-semibold text-green-300">MCP Tools</h4>
              </div>
              <p className="text-sm text-gray-300 mb-3">
                Install powerful tools and capabilities with a single message.
              </p>
              <Badge variant="outline" className="text-xs">Try: "Add web scraping capability"</Badge>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Users className="h-6 w-6 text-purple-400" />
                <h4 className="font-semibold text-purple-300">Collaborations</h4>
              </div>
              <p className="text-sm text-gray-300 mb-3">
                Set up multi-agent teams that work together on complex tasks.
              </p>
              <Badge variant="outline" className="text-xs">Try: "Set up a content team"</Badge>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Target className="h-6 w-6 text-yellow-400" />
                <h4 className="font-semibold text-yellow-300">Workflows</h4>
              </div>
              <p className="text-sm text-gray-300 mb-3">
                Automate complex processes with intelligent workflow orchestration.
              </p>
              <Badge variant="outline" className="text-xs">Try: "Automate my reports"</Badge>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'demo-scenarios',
      title: 'Try These Demo Scenarios',
      description: 'Practice with these common use cases',
      content: (
        <div className="space-y-4">
          <p className="text-gray-300 text-center">
            Click any scenario to see it in action:
          </p>
          
          <div className="grid gap-3">
            <DemoScenario
              title="Data Analysis Team"
              description="Analyze sales data and create insights"
              prompt="I need to analyze our Q3 sales data and create a report with visualizations"
              icon={<Bot className="h-5 w-5" />}
              color="blue"
            />
            
            <DemoScenario
              title="Research Assistant"
              description="Research market trends and competitors"
              prompt="Help me research AI market trends and identify key competitors"
              icon={<Lightbulb className="h-5 w-5" />}
              color="green"
            />
            
            <DemoScenario
              title="Content Creation Pipeline"
              description="Generate and review blog content"
              prompt="Set up a content creation workflow for our tech blog"
              icon={<Users className="h-5 w-5" />}
              color="purple"
            />
            
            <DemoScenario
              title="Development Helper"
              description="Code review and testing assistance"
              prompt="I need help with code reviews and automated testing"
              icon={<Zap className="h-5 w-5" />}
              color="yellow"
            />
          </div>
        </div>
      )
    },
    {
      id: 'ready',
      title: 'You\'re All Set!',
      description: 'Ready to start creating with intelligent chat',
      content: (
        <div className="text-center space-y-6">
          <div className="relative">
            <div className="mx-auto w-24 h-24 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center">
              <CheckCircle className="h-12 w-12 text-white" />
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-white">
              Ready to Transform Your Workflow!
            </h3>
            <p className="text-gray-300 max-w-md mx-auto">
              You now know how to create agents, install tools, and set up collaborations 
              through natural conversation. Let's get started!
            </p>
          </div>
          
          <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30 rounded-lg p-4">
            <div className="flex items-center justify-center space-x-2 text-purple-300">
              <MessageSquare className="h-5 w-5" />
              <span className="font-semibold">Pro Tip:</span>
              <span className="text-sm">Be specific about your goals for better results</span>
            </div>
          </div>
        </div>
      )
    }
  ]

  const currentStepData = steps[currentStep]
  const progress = ((currentStep + 1) / steps.length) * 100

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setIsAnimating(true)
      setCompletedSteps(prev => new Set([...prev, currentStep]))
      setTimeout(() => {
        setCurrentStep(prev => prev + 1)
        setIsAnimating(false)
      }, 300)
    } else {
      onComplete()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentStep(prev => prev - 1)
        setIsAnimating(false)
      }, 300)
    }
  }

  const handleStepClick = (stepIndex: number) => {
    if (stepIndex <= currentStep) {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentStep(stepIndex)
        setIsAnimating(false)
      }, 300)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900/20 to-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Welcome to the Future of AI</h1>
          <p className="text-gray-400">Let's get you started in just a few minutes</p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-400">Progress</span>
            <span className="text-sm text-gray-400">{currentStep + 1} of {steps.length}</span>
          </div>
          <Progress value={progress} className="w-full" />
        </div>

        {/* Step Indicators */}
        <div className="flex justify-center space-x-2 mb-8">
          {steps.map((step, index) => (
            <button
              key={step.id}
              onClick={() => handleStepClick(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentStep
                  ? 'bg-purple-500 ring-2 ring-purple-400/50'
                  : index < currentStep
                  ? 'bg-green-500 cursor-pointer hover:ring-2 hover:ring-green-400/50'
                  : 'bg-gray-600 cursor-not-allowed'
              }`}
              disabled={index > currentStep}
            />
          ))}
        </div>

        {/* Main Content */}
        <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-white flex items-center justify-center space-x-3">
              <div className={`transition-transform duration-300 ${isAnimating ? 'scale-110' : 'scale-100'}`}>
                {currentStep === 0 && <Brain className="h-8 w-8 text-purple-400" />}
                {currentStep === 1 && <MessageSquare className="h-8 w-8 text-blue-400" />}
                {currentStep === 2 && <Sparkles className="h-8 w-8 text-yellow-400" />}
                {currentStep === 3 && <Play className="h-8 w-8 text-green-400" />}
                {currentStep === 4 && <Rocket className="h-8 w-8 text-green-400" />}
              </div>
              <span>{currentStepData.title}</span>
            </CardTitle>
            <p className="text-gray-300 mt-2">{currentStepData.description}</p>
          </CardHeader>
          
          <CardContent className={`transition-opacity duration-300 ${isAnimating ? 'opacity-0' : 'opacity-100'}`}>
            {currentStepData.content}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8">
          <div className="flex space-x-3">
            <Button 
              variant="ghost" 
              onClick={onSkip}
              className="text-gray-400 hover:text-white"
            >
              Skip Tutorial
            </Button>
            {currentStep > 0 && (
              <Button variant="outline" onClick={handlePrevious}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>
            )}
          </div>

          <Button 
            onClick={handleNext}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
            {currentStep !== steps.length - 1 && <ArrowRight className="h-4 w-4 ml-2" />}
          </Button>
        </div>
      </div>
    </div>
  )
}

function DemoScenario({ 
  title, 
  description, 
  prompt, 
  icon, 
  color 
}: { 
  title: string
  description: string
  prompt: string
  icon: React.ReactNode
  color: 'blue' | 'green' | 'purple' | 'yellow'
}) {
  const colorClasses = {
    blue: 'bg-blue-500/10 border-blue-500/20 hover:bg-blue-500/20 text-blue-300',
    green: 'bg-green-500/10 border-green-500/20 hover:bg-green-500/20 text-green-300',
    purple: 'bg-purple-500/10 border-purple-500/20 hover:bg-purple-500/20 text-purple-300',
    yellow: 'bg-yellow-500/10 border-yellow-500/20 hover:bg-yellow-500/20 text-yellow-300'
  }

  return (
    <button
      className={`${colorClasses[color]} border rounded-lg p-4 text-left transition-all hover:scale-105 w-full`}
      onClick={() => {
        // This would trigger the demo scenario
        console.log('Demo scenario:', prompt)
      }}
    >
      <div className="flex items-start space-x-3">
        <div className="mt-1">{icon}</div>
        <div className="flex-1">
          <h4 className="font-semibold mb-1">{title}</h4>
          <p className="text-sm text-gray-300 mb-2">{description}</p>
          <p className="text-xs opacity-75 italic">"{prompt}"</p>
        </div>
        <ArrowRight className="h-4 w-4 mt-1 opacity-60" />
      </div>
    </button>
  )
}
