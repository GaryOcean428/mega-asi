
'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Brain, 
  Play, 
  Settings, 
  Trash2, 
  Activity,
  MessageSquare,
  CheckCircle,
  Clock,
  AlertCircle
} from 'lucide-react'
import { AgentWithRelations, AgentStatus } from '@/lib/types'
import { AgentExecutionDialog } from './agent-execution-dialog'
import { motion } from 'framer-motion'

interface AgentCardProps {
  agent: AgentWithRelations
  onUpdate: () => void
  onDelete: () => void
}

export function AgentCard({ agent, onUpdate, onDelete }: AgentCardProps) {
  const [showExecution, setShowExecution] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const getStatusColor = (status: AgentStatus) => {
    switch (status) {
      case AgentStatus.IDLE: return 'bg-gray-500/10 text-gray-400 border-gray-500/20'
      case AgentStatus.BUSY: return 'bg-green-500/10 text-green-400 border-green-500/20'
      case AgentStatus.ERROR: return 'bg-red-500/10 text-red-400 border-red-500/20'
      case AgentStatus.OFFLINE: return 'bg-gray-500/10 text-gray-500 border-gray-500/20'
      default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20'
    }
  }

  const getStatusIcon = (status: AgentStatus) => {
    switch (status) {
      case AgentStatus.IDLE: return Clock
      case AgentStatus.BUSY: return Activity
      case AgentStatus.ERROR: return AlertCircle
      case AgentStatus.OFFLINE: return AlertCircle
      default: return Clock
    }
  }

  const handleDelete = async () => {
    if (!confirm(`Are you sure you want to delete agent "${agent.name}"?`)) {
      return
    }

    setDeleting(true)
    try {
      const response = await fetch(`/api/agents/${agent.id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        onDelete()
      } else {
        console.error('Failed to delete agent')
      }
    } catch (error) {
      console.error('Error deleting agent:', error)
    } finally {
      setDeleting(false)
    }
  }

  const StatusIcon = getStatusIcon(agent.status)

  return (
    <>
      <Card className="bg-gray-900/30 border-gray-800 hover:bg-gray-800/30 transition-all duration-200 hover:shadow-lg">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Brain className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <CardTitle className="text-lg text-white">{agent.name}</CardTitle>
                <p className="text-sm text-gray-400 capitalize">{agent.role}</p>
              </div>
            </div>
            <Badge variant="outline" className={getStatusColor(agent.status)}>
              <StatusIcon className="h-3 w-3 mr-1" />
              {agent.status}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {agent.description && (
            <p className="text-sm text-gray-300 line-clamp-2">
              {agent.description}
            </p>
          )}

          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>Model: {agent.model}</span>
            <span>Created: {new Date(agent.createdAt).toLocaleDateString()}</span>
          </div>

          {/* Agent Stats */}
          <div className="grid grid-cols-3 gap-4 pt-2 border-t border-gray-700">
            <div className="text-center">
              <div className="text-lg font-semibold text-blue-400">
                {agent._count?.tasks || 0}
              </div>
              <div className="text-xs text-gray-500">Tasks</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-green-400">
                {agent._count?.sentMessages || 0}
              </div>
              <div className="text-xs text-gray-500">Messages</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-purple-400">
                {Array.isArray(agent.capabilities) ? agent.capabilities.length : 0}
              </div>
              <div className="text-xs text-gray-500">Skills</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowExecution(true)}
              disabled={agent.status === AgentStatus.BUSY}
              className="flex-1 bg-blue-500/10 border-blue-500/20 text-blue-400 hover:bg-blue-500/20"
            >
              <Play className="h-3 w-3 mr-1" />
              Execute
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-400 hover:text-white"
            >
              <Settings className="h-3 w-3" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              disabled={deleting}
              className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <AgentExecutionDialog
        open={showExecution}
        onClose={() => setShowExecution(false)}
        agent={agent}
        onSuccess={onUpdate}
      />
    </>
  )
}
