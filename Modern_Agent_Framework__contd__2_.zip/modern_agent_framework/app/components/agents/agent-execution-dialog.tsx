
'use client'

import { useState, useEffect } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { 
  Play, 
  Square, 
  Bot, 
  Loader2,
  CheckCircle
} from 'lucide-react'
import { AgentWithRelations, TaskWithRelations } from '@/lib/types'

interface AgentExecutionDialogProps {
  open: boolean
  onClose: () => void
  agent: AgentWithRelations
  onSuccess: () => void
}

interface StreamResponse {
  status: 'processing' | 'completed' | 'error'
  message?: string
  chunk?: string
  result?: any
}

export function AgentExecutionDialog({ open, onClose, agent, onSuccess }: AgentExecutionDialogProps) {
  const [tasks, setTasks] = useState<TaskWithRelations[]>([])
  const [selectedTaskId, setSelectedTaskId] = useState('')
  const [customInput, setCustomInput] = useState('')
  const [executing, setExecuting] = useState(false)
  const [output, setOutput] = useState('')
  const [executionResult, setExecutionResult] = useState<any>(null)

  const fetchTasks = async () => {
    try {
      const response = await fetch('/api/tasks?status=PENDING')
      const data = await response.json()
      setTasks(data.tasks || [])
    } catch (error) {
      console.error('Error fetching tasks:', error)
    }
  }

  useEffect(() => {
    if (open) {
      fetchTasks()
      setOutput('')
      setExecutionResult(null)
    }
  }, [open])

  const handleExecute = async () => {
    if (!selectedTaskId && !customInput.trim()) {
      return
    }

    setExecuting(true)
    setOutput('')
    setExecutionResult(null)

    try {
      const response = await fetch(`/api/agents/${agent.id}/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          taskId: selectedTaskId || undefined,
          input: customInput.trim() || undefined,
          stream: true
        })
      })

      if (!response.ok) {
        throw new Error('Failed to execute agent')
      }

      const reader = response.body?.getReader()
      if (!reader) {
        throw new Error('No response stream')
      }

      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6)
            if (data === '[DONE]') {
              setExecuting(false)
              return
            }

            try {
              const parsed: StreamResponse = JSON.parse(data)
              
              if (parsed.status === 'processing' && parsed.chunk) {
                setOutput(prev => prev + parsed.chunk)
              } else if (parsed.status === 'completed' && parsed.result) {
                setExecutionResult(parsed.result)
                setExecuting(false)
                onSuccess()
                return
              } else if (parsed.status === 'error') {
                console.error('Execution error:', parsed.message)
                setExecuting(false)
                return
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Execution error:', error)
      setExecuting(false)
    }
  }

  const handleClose = () => {
    if (executing) {
      // Could implement abort here
      return
    }
    
    setSelectedTaskId('')
    setCustomInput('')
    setOutput('')
    setExecutionResult(null)
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl bg-gray-900 border-gray-700 max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="text-xl text-white flex items-center space-x-2">
            <Bot className="h-5 w-5 text-blue-400" />
            <span>Execute Agent: {agent.name}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Agent Info */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-semibold text-white">Agent Details</h3>
              <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                {agent.role}
              </Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-400">Model:</span>
                <span className="text-white ml-2">{agent.model}</span>
              </div>
              <div>
                <span className="text-gray-400">Status:</span>
                <span className="text-white ml-2">{agent.status}</span>
              </div>
            </div>
            {agent.systemPrompt && (
              <div className="mt-3">
                <span className="text-gray-400 text-sm">System Prompt:</span>
                <p className="text-gray-300 text-sm mt-1 line-clamp-2">
                  {agent.systemPrompt}
                </p>
              </div>
            )}
          </div>

          {/* Task Selection */}
          <div className="space-y-3">
            <Label className="text-gray-300">Select Task (Optional)</Label>
            <Select value={selectedTaskId} onValueChange={setSelectedTaskId}>
              <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                <SelectValue placeholder="Choose a pending task or provide custom input" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {tasks.map(task => (
                  <SelectItem key={task.id} value={task.id} className="text-white">
                    <div className="flex flex-col">
                      <span>{task.title}</span>
                      <span className="text-xs text-gray-400">{task.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Custom Input */}
          <div className="space-y-3">
            <Label className="text-gray-300">Custom Input</Label>
            <Textarea
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="Enter custom instructions for the agent..."
              className="bg-gray-800 border-gray-600 text-white resize-none"
              rows={4}
            />
          </div>

          {/* Execution Output */}
          {(output || executionResult) && (
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Label className="text-gray-300">Execution Output</Label>
                {executing && <Loader2 className="h-4 w-4 animate-spin text-blue-400" />}
                {executionResult && <CheckCircle className="h-4 w-4 text-green-400" />}
              </div>
              <ScrollArea className="h-64 bg-gray-800 border border-gray-600 rounded-lg">
                <div className="p-4">
                  <pre className="text-gray-300 text-sm whitespace-pre-wrap font-mono">
                    {output}
                  </pre>
                  {executionResult && (
                    <div className="mt-4 pt-4 border-t border-gray-600">
                      <div className="text-green-400 text-sm font-semibold mb-2">
                        ✓ Execution Completed
                      </div>
                      {executionResult.response && (
                        <div className="text-gray-300 text-sm">
                          {executionResult.response}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={executing}
              className="bg-gray-800 border-gray-600 text-gray-300"
            >
              {executing ? 'Executing...' : 'Close'}
            </Button>
            
            <Button
              onClick={handleExecute}
              disabled={executing || (!selectedTaskId && !customInput.trim())}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {executing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Executing
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Execute Agent
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
