
'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { X, Plus } from 'lucide-react'
import { CreateAgentRequest } from '@/lib/types'
import { ModelSelector } from '@/components/models/model-selector'

interface CreateAgentDialogProps {
  open: boolean
  onClose: () => void
  onSuccess: () => void
}

const AGENT_ROLES = [
  'analyst',
  'researcher', 
  'coordinator',
  'executor',
  'reviewer',
  'writer',
  'developer',
  'designer',
  'consultant'
]

// Model selection is now handled by the ModelSelector component

export function CreateAgentDialog({ open, onClose, onSuccess }: CreateAgentDialogProps) {
  const [formData, setFormData] = useState<CreateAgentRequest>({
    name: '',
    description: '',
    role: '',
    model: 'gpt-4.1-mini',
    systemPrompt: '',
    capabilities: []
  })
  const [newCapability, setNewCapability] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name || !formData.role) {
      return
    }

    setLoading(true)
    try {
      const response = await fetch('/api/agents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        onSuccess()
        handleClose()
      } else {
        console.error('Failed to create agent')
      }
    } catch (error) {
      console.error('Error creating agent:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setFormData({
      name: '',
      description: '',
      role: '',
      model: 'gpt-4.1-mini',
      systemPrompt: '',
      capabilities: []
    })
    setNewCapability('')
    onClose()
  }

  const addCapability = () => {
    if (newCapability.trim() && !formData.capabilities?.includes(newCapability.trim())) {
      setFormData(prev => ({
        ...prev,
        capabilities: [...(prev.capabilities || []), newCapability.trim()]
      }))
      setNewCapability('')
    }
  }

  const removeCapability = (capability: string) => {
    setFormData(prev => ({
      ...prev,
      capabilities: prev.capabilities?.filter(c => c !== capability) || []
    }))
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl bg-gray-900 border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-xl text-white">Create New Agent</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-gray-300">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter agent name"
                className="bg-gray-800 border-gray-600 text-white"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role" className="text-gray-300">Role *</Label>
              <Select 
                value={formData.role} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, role: value }))}
              >
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {AGENT_ROLES.map(role => (
                    <SelectItem key={role} value={role} className="text-white">
                      {role.charAt(0).toUpperCase() + role.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-300">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Describe what this agent does..."
              className="bg-gray-800 border-gray-600 text-white resize-none"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300">AI Model</Label>
            <ModelSelector
              selectedModel={formData.model}
              onModelSelect={(modelId) => setFormData(prev => ({ ...prev, model: modelId }))}
              agentRole={formData.role}
              trigger={
                <Button variant="outline" className="w-full justify-start bg-gray-800 border-gray-600 text-white hover:bg-gray-700">
                  {formData.model ? `Selected: ${formData.model}` : 'Select AI Model'}
                </Button>
              }
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="systemPrompt" className="text-gray-300">System Prompt</Label>
            <Textarea
              id="systemPrompt"
              value={formData.systemPrompt}
              onChange={(e) => setFormData(prev => ({ ...prev, systemPrompt: e.target.value }))}
              placeholder="Define the agent's personality and core instructions..."
              className="bg-gray-800 border-gray-600 text-white resize-none"
              rows={4}
            />
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300">Capabilities</Label>
            <div className="flex space-x-2">
              <Input
                value={newCapability}
                onChange={(e) => setNewCapability(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCapability())}
                placeholder="Add capability..."
                className="bg-gray-800 border-gray-600 text-white"
              />
              <Button
                type="button"
                onClick={addCapability}
                variant="outline"
                size="sm"
                className="bg-blue-500/10 border-blue-500/20 text-blue-400"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            {formData.capabilities && formData.capabilities.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {formData.capabilities.map((capability, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="bg-gray-700/50 text-gray-300 border-gray-600"
                  >
                    {capability}
                    <button
                      type="button"
                      onClick={() => removeCapability(capability)}
                      className="ml-1 hover:text-red-400"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
              className="bg-gray-800 border-gray-600 text-gray-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading || !formData.name || !formData.role}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? 'Creating...' : 'Create Agent'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
