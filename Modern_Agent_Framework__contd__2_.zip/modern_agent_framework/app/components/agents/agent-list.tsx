
'use client'

import { useState, useEffect } from 'react'
import { AgentCard } from './agent-card'
import { LoadingSpinner } from '@/components/ui/loading-spinner'
import { AgentWithRelations } from '@/lib/types'
import { motion } from 'framer-motion'

interface AgentListProps {
  refreshKey: number
  onRefresh: () => void
}

export function AgentList({ refreshKey, onRefresh }: AgentListProps) {
  const [agents, setAgents] = useState<AgentWithRelations[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchAgents = async () => {
    try {
      setError(null)
      const response = await fetch('/api/agents')
      
      if (response.status === 401) {
        // User not authenticated, set empty array
        setAgents([])
        return
      }
      
      if (!response.ok) {
        throw new Error('Failed to fetch agents')
      }
      
      const data = await response.json()
      setAgents(data.agents || [])
    } catch (error) {
      console.error('Error fetching agents:', error)
      // Set empty array instead of showing error
      setAgents([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAgents()
  }, [refreshKey])

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <div className="text-red-500 mb-4">Error loading agents: {error}</div>
        <button 
          onClick={fetchAgents}
          className="text-blue-500 hover:text-blue-400 underline"
        >
          Try again
        </button>
      </div>
    )
  }

  if (agents.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 text-lg mb-2">No agents created yet</div>
        <div className="text-gray-500 text-sm">
          Create your first agent to get started with the autonomous framework.
        </div>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {agents.map((agent, index) => (
        <motion.div
          key={agent.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <AgentCard 
            agent={agent} 
            onUpdate={onRefresh}
            onDelete={onRefresh}
          />
        </motion.div>
      ))}
    </div>
  )
}
