
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts'
import {
  TrendingUp,
  TrendingDown,
  Users,
  Bot,
  MessageSquare,
  Activity,
  Clock,
  AlertCircle,
  CheckCircle,
  Zap,
  BarChart3,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react'
import { UsageAnalytics, AnalyticsInsight, PerformanceBenchmark } from '@/lib/analytics/types'
import { useAnalytics } from '@/lib/analytics/collector'

interface AnalyticsDashboardProps {
  className?: string
}

export function AnalyticsDashboard({ className }: AnalyticsDashboardProps) {
  const [analytics, setAnalytics] = useState<UsageAnalytics | null>(null)
  const [insights, setInsights] = useState<AnalyticsInsight[]>([])
  const [benchmarks, setBenchmarks] = useState<PerformanceBenchmark[]>([])
  const [timeRange, setTimeRange] = useState('7d')
  const [loading, setLoading] = useState(true)
  const { trackPageView, trackInteraction } = useAnalytics()

  useEffect(() => {
    trackPageView('/analytics', 'Analytics Dashboard')
    fetchAnalyticsData()
  }, [timeRange])

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true)
      
      // Fetch main analytics data
      const analyticsRes = await fetch(`/api/analytics/overview?timeRange=${timeRange}`)
      const analyticsData = await analyticsRes.json()
      
      // Fetch insights
      const insightsRes = await fetch(`/api/analytics/insights?timeRange=${timeRange}`)
      const insightsData = await insightsRes.json()
      
      // Fetch benchmarks
      const benchmarksRes = await fetch(`/api/analytics/benchmarks`)
      const benchmarksData = await benchmarksRes.json()
      
      setAnalytics(analyticsData)
      setInsights(insightsData.insights || [])
      setBenchmarks(benchmarksData.benchmarks || [])
    } catch (error) {
      console.error('Failed to fetch analytics data:', error)
      // Set mock data for demonstration
      setAnalytics(getMockAnalytics())
      setInsights(getMockInsights())
      setBenchmarks(getMockBenchmarks())
    } finally {
      setLoading(false)
    }
  }

  const handleExportData = () => {
    trackInteraction('analytics-dashboard', 'export_data')
    // Implementation for exporting analytics data
    console.log('Exporting analytics data...')
  }

  const handleRefresh = () => {
    trackInteraction('analytics-dashboard', 'refresh')
    fetchAnalyticsData()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!analytics) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500">
        <AlertCircle className="h-8 w-8 mr-2" />
        <span>Failed to load analytics data</span>
      </div>
    )
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Analytics Dashboard</h1>
          <p className="text-gray-400 mt-2">
            Track usage, performance, and insights across your agent framework
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Button variant="outline" size="sm" onClick={handleExportData}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Users"
          value={analytics.totalUsers}
          change={12}
          icon={<Users className="h-5 w-5" />}
          color="blue"
        />
        <MetricCard
          title="Active Agents"
          value={analytics.totalAgents}
          change={8}
          icon={<Bot className="h-5 w-5" />}
          color="green"
        />
        <MetricCard
          title="Messages Sent"
          value={analytics.totalMessages}
          change={-3}
          icon={<MessageSquare className="h-5 w-5" />}
          color="purple"
        />
        <MetricCard
          title="Collaborations"
          value={analytics.totalCollaborations}
          change={25}
          icon={<Activity className="h-5 w-5" />}
          color="yellow"
        />
      </div>

      <Tabs value="overview" onValueChange={() => {}} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* User Growth Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-white">User Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={analytics.userGrowth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="users"
                      stroke="#3B82F6"
                      strokeWidth={2}
                      dot={{ fill: '#3B82F6', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Agent Types Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-white">Agent Types</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analytics.agentPopularity}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    >
                      {analytics.agentPopularity.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Top Features Usage */}
          <Card>
            <CardHeader>
              <CardTitle className="text-white">Most Used Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.topFeatures.map((feature, index) => (
                  <div key={feature.feature} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-blue-300 font-semibold text-sm">
                        {index + 1}
                      </div>
                      <span className="text-white font-medium">{feature.feature}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="text-gray-400 text-sm">{feature.usage} uses</div>
                      <div className="w-24 bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-blue-500 h-2 rounded-full"
                          style={{
                            width: `${(feature.usage / Math.max(...analytics.topFeatures.map(f => f.usage))) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          {/* Performance Benchmarks */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benchmarks.map((benchmark) => (
              <PerformanceBenchmarkCard key={benchmark.metric} benchmark={benchmark} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          {/* AI-Generated Insights */}
          <div className="grid gap-6">
            {insights.map((insight) => (
              <InsightCard key={insight.id} insight={insight} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <ReportsSection />
        </TabsContent>
      </Tabs>
    </div>
  )
}

// Helper Components
function MetricCard({ 
  title, 
  value, 
  change, 
  icon, 
  color 
}: { 
  title: string
  value: number
  change: number
  icon: React.ReactNode
  color: string 
}) {
  const colorClasses = {
    blue: 'bg-blue-500/20 text-blue-300',
    green: 'bg-green-500/20 text-green-300',
    purple: 'bg-purple-500/20 text-purple-300',
    yellow: 'bg-yellow-500/20 text-yellow-300'
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className={`p-2 rounded-lg ${colorClasses[color as keyof typeof colorClasses]}`}>
            {icon}
          </div>
          <div className="flex items-center space-x-1">
            {change > 0 ? (
              <>
                <TrendingUp className="h-4 w-4 text-green-400" />
                <span className="text-green-400 text-sm">+{change}%</span>
              </>
            ) : (
              <>
                <TrendingDown className="h-4 w-4 text-red-400" />
                <span className="text-red-400 text-sm">{change}%</span>
              </>
            )}
          </div>
        </div>
        <div className="mt-4">
          <div className="text-2xl font-bold text-white">{value.toLocaleString()}</div>
          <div className="text-gray-400 text-sm">{title}</div>
        </div>
      </CardContent>
    </Card>
  )
}

function PerformanceBenchmarkCard({ benchmark }: { benchmark: PerformanceBenchmark }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-green-400 bg-green-500/20'
      case 'good': return 'text-blue-400 bg-blue-500/20'
      case 'needs_improvement': return 'text-yellow-400 bg-yellow-500/20'
      case 'critical': return 'text-red-400 bg-red-500/20'
      default: return 'text-gray-400 bg-gray-500/20'
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving': return <TrendingUp className="h-4 w-4 text-green-400" />
      case 'declining': return <TrendingDown className="h-4 w-4 text-red-400" />
      default: return <Activity className="h-4 w-4 text-gray-400" />
    }
  }

  const progress = Math.min((benchmark.current / benchmark.target) * 100, 100)

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-white">{benchmark.metric}</h3>
          <div className="flex items-center space-x-2">
            {getTrendIcon(benchmark.trend)}
            <Badge className={getStatusColor(benchmark.status)}>
              {benchmark.status.replace('_', ' ')}
            </Badge>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Current</span>
            <span className="text-white font-medium">{benchmark.current}</span>
          </div>
          
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Target: {benchmark.target}</span>
            <span className="text-gray-400">Benchmark: {benchmark.benchmark}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function InsightCard({ insight }: { insight: AnalyticsInsight }) {
  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'border-red-500/50 bg-red-500/10'
      case 'medium': return 'border-yellow-500/50 bg-yellow-500/10'
      case 'low': return 'border-blue-500/50 bg-blue-500/10'
      default: return 'border-gray-500/50 bg-gray-500/10'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'trend': return <TrendingUp className="h-5 w-5" />
      case 'anomaly': return <AlertCircle className="h-5 w-5" />
      case 'recommendation': return <Lightbulb className="h-5 w-5" />
      case 'alert': return <AlertCircle className="h-5 w-5" />
      default: return <BarChart3 className="h-5 w-5" />
    }
  }

  return (
    <Card className={`border ${getImpactColor(insight.impact)}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            <div className="p-2 rounded-lg bg-gray-800">
              {getTypeIcon(insight.type)}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white mb-2">{insight.title}</h3>
              <p className="text-gray-300 text-sm mb-4">{insight.description}</p>
              
              {insight.actionable && insight.actions && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-gray-200">Recommended Actions:</h4>
                  <div className="space-y-1">
                    {insight.actions.map((action, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="mr-2 mb-2"
                        onClick={() => console.log('Action:', action)}
                      >
                        {action.label}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="text-right">
            <Badge variant="secondary" className="mb-2">
              {insight.impact} impact
            </Badge>
            <div className="text-xs text-gray-400">
              {insight.confidence}% confidence
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ReportsSection() {
  const reports = [
    { name: 'Weekly Summary', description: 'Comprehensive weekly performance report', lastGenerated: '2 hours ago' },
    { name: 'Agent Utilization', description: 'Detailed agent usage and performance metrics', lastGenerated: '1 day ago' },
    { name: 'User Engagement', description: 'User behavior and feature adoption analysis', lastGenerated: '3 days ago' },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-white">Automated Reports</h3>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Create Report
        </Button>
      </div>
      
      <div className="grid gap-4">
        {reports.map((report, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-white mb-2">{report.name}</h4>
                  <p className="text-gray-400 text-sm">{report.description}</p>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-400 mb-2">Last: {report.lastGenerated}</div>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

// Mock data for demonstration
function getMockAnalytics(): UsageAnalytics {
  return {
    totalUsers: 1247,
    activeUsers: 356,
    newUsers: 89,
    returningUsers: 267,
    totalAgents: 45,
    totalCollaborations: 23,
    totalMessages: 8942,
    averageSessionDuration: 24.5,
    topFeatures: [
      { feature: 'Agent Creation', usage: 450 },
      { feature: 'Intelligent Chat', usage: 389 },
      { feature: 'Collaboration Setup', usage: 267 },
      { feature: 'MCP Integration', usage: 178 },
      { feature: 'Workflow Automation', usage: 134 }
    ],
    userGrowth: [
      { date: '2024-01-01', users: 100 },
      { date: '2024-01-07', users: 150 },
      { date: '2024-01-14', users: 220 },
      { date: '2024-01-21', users: 320 },
      { date: '2024-01-28', users: 450 }
    ],
    agentPopularity: [
      { type: 'Data Analysis', count: 15 },
      { type: 'Research', count: 12 },
      { type: 'Content Creation', count: 8 },
      { type: 'Development', count: 6 },
      { type: 'Project Management', count: 4 }
    ]
  }
}

function getMockInsights(): AnalyticsInsight[] {
  return [
    {
      id: '1',
      type: 'trend',
      title: 'Agent Usage Trending Up',
      description: 'Agent creation has increased by 45% over the past week, indicating growing adoption of automation features.',
      confidence: 87,
      impact: 'high',
      category: 'adoption',
      data: {},
      generatedAt: new Date(),
      actionable: true,
      actions: [
        { label: 'Create More Templates', action: 'create_templates' },
        { label: 'Improve Onboarding', action: 'enhance_onboarding' }
      ]
    },
    {
      id: '2',
      type: 'recommendation',
      title: 'Optimize Response Times',
      description: 'Average response time has increased to 2.3s. Consider implementing caching to improve performance.',
      confidence: 92,
      impact: 'medium',
      category: 'performance',
      data: {},
      generatedAt: new Date(),
      actionable: true,
      actions: [
        { label: 'Enable Redis Caching', action: 'enable_caching' },
        { label: 'Optimize Database', action: 'optimize_db' }
      ]
    }
  ]
}

function getMockBenchmarks(): PerformanceBenchmark[] {
  return [
    {
      metric: 'Response Time',
      current: 1.2,
      target: 1.0,
      benchmark: 0.8,
      status: 'good',
      trend: 'improving'
    },
    {
      metric: 'Success Rate',
      current: 94,
      target: 95,
      benchmark: 98,
      status: 'good',
      trend: 'stable'
    },
    {
      metric: 'User Satisfaction',
      current: 4.6,
      target: 4.5,
      benchmark: 4.8,
      status: 'excellent',
      trend: 'improving'
    }
  ]
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4']

// Missing imports
import { Lightbulb, Plus } from 'lucide-react'
