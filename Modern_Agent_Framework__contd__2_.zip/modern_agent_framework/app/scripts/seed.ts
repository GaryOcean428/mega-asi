
import { PrismaClient } from '@prisma/client'
import { AgentStatus, TaskStatus, Priority, CollaborationType, CollaborationStatus } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting seed...')

  // Create test user account (required for testing)
  const testUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      name: 'John Doe',
      role: 'SUPER_ADMIN',
      isActive: true,
      emailVerified: new Date(),
    }
  })

  // Create main admin user
  const adminUser = await prisma.user.upsert({
    where: { email: 'braden.lang77@gmail.com' },
    update: {},
    create: {
      email: 'braden.lang77@gmail.com',
      name: 'Braden Lang',
      role: 'SUPER_ADMIN',
      isActive: true,
      emailVerified: new Date(),
    }
  })

  // Create organization for test user
  const testOrg = await prisma.organization.upsert({
    where: { slug: 'john-doe-org' },
    update: {},
    create: {
      name: 'John Doe Organization',
      slug: 'john-doe-org',
      plan: 'ENTERPRISE',
    }
  })

  // Create default workspace for test user
  const testWorkspace = await prisma.workspace.upsert({
    where: { 
      organizationId_slug: {
        organizationId: testOrg.id,
        slug: 'default'
      }
    },
    update: {},
    create: {
      name: 'Default Workspace',
      slug: 'default',
      organizationId: testOrg.id,
      isDefault: true,
    }
  })

  // Add test user to workspace as admin
  await prisma.workspaceMember.upsert({
    where: {
      userId_workspaceId: {
        userId: testUser.id,
        workspaceId: testWorkspace.id
      }
    },
    update: {},
    create: {
      userId: testUser.id,
      workspaceId: testWorkspace.id,
      role: 'ADMIN',
    }
  })

  // Update test user with organization
  await prisma.user.update({
    where: { id: testUser.id },
    data: { organizationId: testOrg.id }
  })

  // Create organization for admin user
  const adminOrg = await prisma.organization.upsert({
    where: { slug: 'braden-lang-org' },
    update: {},
    create: {
      name: 'Braden Lang Organization',
      slug: 'braden-lang-org',
      plan: 'ENTERPRISE',
    }
  })

  // Create default workspace for admin user
  const adminWorkspace = await prisma.workspace.upsert({
    where: { 
      organizationId_slug: {
        organizationId: adminOrg.id,
        slug: 'default'
      }
    },
    update: {},
    create: {
      name: 'Default Workspace',
      slug: 'default',
      organizationId: adminOrg.id,
      isDefault: true,
    }
  })

  // Add admin user to workspace as admin
  await prisma.workspaceMember.upsert({
    where: {
      userId_workspaceId: {
        userId: adminUser.id,
        workspaceId: adminWorkspace.id
      }
    },
    update: {},
    create: {
      userId: adminUser.id,
      workspaceId: adminWorkspace.id,
      role: 'ADMIN',
    }
  })

  // Update admin user with organization
  await prisma.user.update({
    where: { id: adminUser.id },
    data: { organizationId: adminOrg.id }
  })

  console.log('✅ Created admin user account and organization')
  console.log('✅ Created test user account and organization')

  // Create sample agents
  const agents = await Promise.all([
    prisma.agent.create({
      data: {
        name: 'Alex Analyst',
        description: 'Specializes in data analysis and research, providing insights from complex datasets.',
        role: 'analyst',
        model: 'gpt-4.1-mini',
        systemPrompt: 'You are Alex, an expert data analyst. You excel at finding patterns, interpreting data, and providing clear insights. Always be thorough and analytical in your responses.',
        capabilities: ['data-analysis', 'research', 'pattern-recognition', 'statistical-analysis'],
        status: AgentStatus.IDLE
      }
    }),
    
    prisma.agent.create({
      data: {
        name: 'Sam Researcher',
        description: 'Conducts comprehensive research on various topics and compiles detailed reports.',
        role: 'researcher',
        model: 'gpt-4.1-mini',
        systemPrompt: 'You are Sam, a meticulous researcher. Your strength lies in gathering comprehensive information, fact-checking, and presenting findings in a structured manner.',
        capabilities: ['web-research', 'fact-checking', 'report-writing', 'information-synthesis'],
        status: AgentStatus.IDLE
      }
    }),
    
    prisma.agent.create({
      data: {
        name: 'Emma Coordinator',
        description: 'Manages projects and coordinates team activities to ensure smooth collaboration.',
        role: 'coordinator',
        model: 'gpt-4.1-mini',
        systemPrompt: 'You are Emma, a skilled project coordinator. You excel at organizing tasks, facilitating communication, and ensuring team efficiency.',
        capabilities: ['project-management', 'team-coordination', 'planning', 'communication'],
        status: AgentStatus.IDLE
      }
    }),
    
    prisma.agent.create({
      data: {
        name: 'Jordan Executor',
        description: 'Takes action on assigned tasks and implements solutions efficiently.',
        role: 'executor',
        model: 'gpt-4.1-mini',
        systemPrompt: 'You are Jordan, a reliable executor. You focus on getting things done efficiently and effectively, following instructions precisely while adapting as needed.',
        capabilities: ['task-execution', 'problem-solving', 'implementation', 'troubleshooting'],
        status: AgentStatus.IDLE
      }
    }),
    
    prisma.agent.create({
      data: {
        name: 'Maya Writer',
        description: 'Creates compelling content, reports, and documentation with excellent writing skills.',
        role: 'writer',
        model: 'gpt-4.1-mini',
        systemPrompt: 'You are Maya, a talented writer. You craft engaging, clear, and well-structured content tailored to your audience. Your writing is both informative and engaging.',
        capabilities: ['content-creation', 'copywriting', 'technical-writing', 'editing'],
        status: AgentStatus.IDLE
      }
    })
  ])

  console.log('✅ Created agents:', agents.map(a => a.name).join(', '))

  // Create sample tasks
  const tasks = await Promise.all([
    prisma.task.create({
      data: {
        title: 'Market Research Analysis',
        description: 'Conduct a comprehensive analysis of the AI agent market trends and competitive landscape.',
        instructions: 'Analyze current market trends, identify key players, assess market size, and provide insights on opportunities and challenges.',
        priority: Priority.HIGH,
        status: TaskStatus.PENDING,
        agentId: agents[0].id // Alex Analyst
      }
    }),
    
    prisma.task.create({
      data: {
        title: 'Product Feature Research',
        description: 'Research user needs and preferences for autonomous agent collaboration features.',
        instructions: 'Survey existing solutions, identify user pain points, and recommend feature improvements for better collaboration.',
        priority: Priority.MEDIUM,
        status: TaskStatus.PENDING,
        agentId: agents[1].id // Sam Researcher
      }
    }),
    
    prisma.task.create({
      data: {
        title: 'Project Roadmap Creation',
        description: 'Create a detailed project roadmap for the next quarter including milestones and deliverables.',
        instructions: 'Define project phases, set realistic timelines, identify dependencies, and create actionable milestones.',
        priority: Priority.HIGH,
        status: TaskStatus.PENDING,
        agentId: agents[2].id // Emma Coordinator
      }
    }),
    
    prisma.task.create({
      data: {
        title: 'System Integration Testing',
        description: 'Execute comprehensive testing of the agent collaboration system.',
        instructions: 'Test all integration points, verify data flow, check error handling, and document any issues found.',
        priority: Priority.URGENT,
        status: TaskStatus.PENDING,
        agentId: agents[3].id // Jordan Executor
      }
    }),
    
    prisma.task.create({
      data: {
        title: 'User Documentation',
        description: 'Create comprehensive user documentation for the agent framework.',
        instructions: 'Write clear, user-friendly documentation covering setup, usage, best practices, and troubleshooting.',
        priority: Priority.MEDIUM,
        status: TaskStatus.PENDING,
        agentId: agents[4].id // Maya Writer
      }
    }),

    // Some completed tasks for metrics
    prisma.task.create({
      data: {
        title: 'Initial System Setup',
        description: 'Set up the basic agent framework infrastructure.',
        priority: Priority.HIGH,
        status: TaskStatus.COMPLETED,
        agentId: agents[3].id,
        result: 'Successfully set up the agent framework with database, API endpoints, and basic UI components.',
        startedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
        completedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) // 1 day ago
      }
    })
  ])

  console.log('✅ Created tasks:', tasks.map(t => t.title).join(', '))

  // Create a sample collaboration
  const collaboration = await prisma.collaboration.create({
    data: {
      name: 'Product Launch Planning',
      description: 'Collaborative effort to plan and execute the launch of the new agent framework.',
      type: CollaborationType.SEQUENTIAL,
      status: CollaborationStatus.ACTIVE,
      agentIds: [agents[1].id, agents[2].id, agents[4].id], // Sam, Emma, Maya
      totalSteps: 3,
      currentStep: 0,
      metadata: {
        launchDate: '2025-02-15',
        targetAudience: 'Developers and AI enthusiasts',
        channels: ['Product Hunt', 'GitHub', 'Tech blogs']
      }
    }
  })

  console.log('✅ Created collaboration:', collaboration.name)

  // Create some sample messages for agent communication
  const messages = await Promise.all([
    prisma.message.create({
      data: {
        content: 'I\'ve completed the market research analysis. The AI agent market is showing strong growth with increasing demand for collaborative solutions.',
        role: 'ASSISTANT',
        senderId: agents[0].id,
        receiverId: agents[2].id,
        isInternal: true,
        metadata: { messageType: 'task_update' }
      }
    }),
    
    prisma.message.create({
      data: {
        content: 'Thanks Alex! Could you share the key findings so I can incorporate them into our project roadmap?',
        role: 'ASSISTANT',
        senderId: agents[2].id,
        receiverId: agents[0].id,
        isInternal: true,
        metadata: { messageType: 'follow_up' }
      }
    })
  ])

  console.log('✅ Created sample messages for agent communication')

  console.log('🎉 Seed completed successfully!')
  console.log('\n📊 Summary:')
  console.log(`- 2 user accounts created (1 admin + 1 test)`)
  console.log(`- ${agents.length} agents created`)
  console.log(`- ${tasks.length} tasks created`) 
  console.log(`- 1 collaboration created`)
  console.log(`- ${messages.length} messages created`)
  console.log('\n🚀 The modern agent framework is ready to use!')
  console.log('🔑 Admin and test credentials available for authentication')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
