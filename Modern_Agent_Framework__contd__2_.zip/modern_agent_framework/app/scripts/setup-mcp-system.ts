
/**
 * Complete MCP System Setup Script
 * Handles database migration, seeding, and initial configuration
 */

import { PrismaClient } from '@prisma/client'
import { seedMCPData } from './seed-mcp-data'
import { encryptionService } from '../lib/security/encryption'
import { logger } from '../lib/utils/logger'
import { ragService } from '../lib/rag/service'

const prisma = new PrismaClient()

interface SetupOptions {
  seedData?: boolean
  createEncryptionKey?: boolean
  initializeRAG?: boolean
  verbose?: boolean
}

async function setupMCPSystem(options: SetupOptions = {}) {
  const {
    seedData = true,
    createEncryptionKey = true,
    initializeRAG = true,
    verbose = false
  } = options

  console.log('🚀 Starting MCP system setup...')
  console.log('═'.repeat(50))

  try {
    // Step 1: Check database connection
    console.log('📡 Checking database connection...')
    await prisma.$connect()
    console.log('✅ Database connection successful')

    // Step 2: Run database migration if needed
    console.log('🗄️  Checking database schema...')
    try {
      // Test if MCP tables exist
      await prisma.mcpRegistry.findFirst()
      console.log('✅ MCP database schema is ready')
    } catch (error) {
      console.log('📋 Running database migration...')
      // In a real setup, you'd run: npx prisma db push
      console.log('⚠️  Please run: npx prisma db push')
      console.log('   Then run this setup script again')
      return
    }

    // Step 3: Create encryption keys if needed
    if (createEncryptionKey) {
      console.log('🔐 Setting up encryption keys...')
      try {
        const keyId = await encryptionService.generateEncryptionKey('mcp_credentials')
        console.log(`✅ Created encryption key: ${keyId}`)
      } catch (error) {
        if (verbose) {
          console.log('ℹ️  Encryption key may already exist:', error)
        }
        console.log('✅ Encryption system ready')
      }
    }

    // Step 4: Seed MCP marketplace data
    if (seedData) {
      console.log('🌱 Seeding MCP marketplace data...')
      await seedMCPData()
      console.log('✅ MCP marketplace data seeded successfully')
    }

    // Step 5: Initialize RAG system
    if (initializeRAG) {
      console.log('🧠 Initializing RAG knowledge system...')
      try {
        // Sync knowledge for existing MCPs
        const mcps = await prisma.mcpRegistry.findMany({
          take: 5 // Limit for initial setup
        })

        for (const mcp of mcps) {
          await ragService.syncMCPKnowledge(mcp.id)
          if (verbose) {
            console.log(`  📚 Synced knowledge for ${mcp.name}`)
          }
        }
        console.log('✅ RAG system initialized')
      } catch (error) {
        console.log('⚠️  RAG initialization had issues:', error)
        console.log('   System will work without advanced RAG features')
      }
    }

    // Step 6: Verify system health
    console.log('🏥 Performing system health check...')
    const healthCheck = await performHealthCheck(verbose)
    
    if (healthCheck.healthy) {
      console.log('✅ System health check passed')
    } else {
      console.log('⚠️  System health check found issues:')
      healthCheck.issues.forEach(issue => {
        console.log(`   - ${issue}`)
      })
    }

    // Step 7: Display setup summary
    console.log('\n🎉 MCP System Setup Complete!')
    console.log('═'.repeat(50))
    console.log('📊 Setup Summary:')
    console.log(`   • Database: ${healthCheck.components.database ? '✅' : '❌'} Connected`)
    console.log(`   • Encryption: ${healthCheck.components.encryption ? '✅' : '❌'} Ready`)
    console.log(`   • MCP Registry: ${healthCheck.components.registry ? '✅' : '❌'} ${healthCheck.mcpCount} MCPs available`)
    console.log(`   • Knowledge Base: ${healthCheck.components.knowledge ? '✅' : '❌'} ${healthCheck.knowledgeCount} entries`)
    console.log(`   • RAG System: ${healthCheck.components.rag ? '✅' : '❌'} Ready`)

    console.log('\n🚀 Next Steps:')
    console.log('   1. Start your application: npm run dev')
    console.log('   2. Navigate to: http://localhost:3000/mcp-marketplace')
    console.log('   3. Sign in to access MCP management features')
    console.log('   4. Try the intelligent MCP assistant!')

    if (!healthCheck.healthy) {
      console.log('\n⚠️  Issues found:')
      healthCheck.issues.forEach(issue => {
        console.log(`   • ${issue}`)
      })
      console.log('\nSome features may be limited until issues are resolved.')
    }

  } catch (error) {
    console.error('❌ MCP system setup failed:')
    console.error(error)
    
    console.log('\n🔧 Troubleshooting steps:')
    console.log('   1. Check database connection and credentials')
    console.log('   2. Ensure all environment variables are set')
    console.log('   3. Run: npx prisma db push')
    console.log('   4. Check logs for detailed error information')
    
    process.exit(1)
  } finally {
    await prisma.$disconnect()
  }
}

async function performHealthCheck(verbose: boolean = false) {
  const health = {
    healthy: true,
    issues: [] as string[],
    components: {
      database: false,
      encryption: false,
      registry: false,
      knowledge: false,
      rag: false
    },
    mcpCount: 0,
    knowledgeCount: 0
  }

  // Check database
  try {
    await prisma.$queryRaw`SELECT 1`
    health.components.database = true
  } catch (error) {
    health.healthy = false
    health.issues.push('Database connection failed')
    if (verbose) console.log('Database error:', error)
  }

  // Check encryption system
  try {
    const testEncryption = await encryptionService.encrypt('test', 'health_check')
    await encryptionService.decrypt(testEncryption.encryptedData, testEncryption.keyId)
    health.components.encryption = true
  } catch (error) {
    health.healthy = false
    health.issues.push('Encryption system not working')
    if (verbose) console.log('Encryption error:', error)
  }

  // Check MCP registry
  try {
    const mcpCount = await prisma.mcpRegistry.count()
    health.mcpCount = mcpCount
    health.components.registry = mcpCount > 0
    
    if (mcpCount === 0) {
      health.issues.push('No MCPs in registry - run seed script')
    }
  } catch (error) {
    health.healthy = false
    health.issues.push('MCP registry not accessible')
    if (verbose) console.log('Registry error:', error)
  }

  // Check knowledge base
  try {
    const knowledgeCount = await prisma.mcpKnowledgeBase.count()
    health.knowledgeCount = knowledgeCount
    health.components.knowledge = knowledgeCount > 0
    
    if (knowledgeCount === 0) {
      health.issues.push('Knowledge base is empty')
    }
  } catch (error) {
    health.issues.push('Knowledge base not accessible')
    if (verbose) console.log('Knowledge base error:', error)
  }

  // Check RAG system (basic check)
  try {
    // Simple test of RAG service
    await ragService.searchMCPKnowledge('test', { limit: 1 })
    health.components.rag = true
  } catch (error) {
    // RAG not critical for basic operation
    health.issues.push('RAG system may have limited functionality')
    if (verbose) console.log('RAG error:', error)
  }

  return health
}

// Command line interface
if (require.main === module) {
  const args = process.argv.slice(2)
  const options: SetupOptions = {
    seedData: !args.includes('--no-seed'),
    createEncryptionKey: !args.includes('--no-encryption'),
    initializeRAG: !args.includes('--no-rag'),
    verbose: args.includes('--verbose') || args.includes('-v')
  }

  if (args.includes('--help') || args.includes('-h')) {
    console.log(`
🚀 MCP System Setup Script

Usage: npx tsx scripts/setup-mcp-system.ts [options]

Options:
  --help, -h          Show this help message
  --verbose, -v       Show detailed output
  --no-seed           Skip seeding MCP marketplace data
  --no-encryption     Skip encryption key creation
  --no-rag            Skip RAG system initialization

Examples:
  npx tsx scripts/setup-mcp-system.ts           # Full setup
  npx tsx scripts/setup-mcp-system.ts --verbose # Detailed output
  npx tsx scripts/setup-mcp-system.ts --no-seed # Skip seeding data

Environment Variables Required:
  DATABASE_URL              PostgreSQL connection string
  ABACUSAI_API_KEY          API key for LLM services
  MASTER_ENCRYPTION_KEY     Master key for credential encryption

Optional Environment Variables:
  REDIS_URL                 Redis connection for caching
  LOG_LEVEL                 Logging level (debug, info, warn, error)
    `)
    process.exit(0)
  }

  setupMCPSystem(options)
    .then(() => {
      console.log('\n✨ Setup completed successfully!')
      process.exit(0)
    })
    .catch((error) => {
      console.error('\n💥 Setup failed:', error)
      process.exit(1)
    })
}

export { setupMCPSystem, performHealthCheck }
