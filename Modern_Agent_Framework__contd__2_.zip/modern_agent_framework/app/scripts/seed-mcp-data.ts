
/**
 * Seed script for MCP marketplace data
 * Populates the database with realistic MCP registry entries
 */

import { PrismaClient } from '@prisma/client'
import { ragService } from '../lib/rag/service'

const prisma = new PrismaClient()

const sampleMCPs = [
  // Productivity MCPs
  {
    name: 'GitHub Integration',
    slug: 'github-integration',
    description: 'Connect your agents to GitHub repositories for code analysis, issue tracking, and automated workflows. Supports repository browsing, file operations, pull requests, and issue management.',
    category: 'development',
    provider: 'GitHub Inc.',
    repositoryUrl: 'https://github.com/modelcontextprotocol/github-mcp',
    documentationUrl: 'https://docs.github.com/en/mcp',
    capabilities: ['code_analysis', 'repository_access', 'issue_management', 'pull_requests', 'webhook_handling'],
    version: '2.1.0',
    rating: 4.8,
    installCount: 15420,
    isVerified: true,
    securityLevel: 'official',
    configSchema: {
      type: 'object',
      properties: {
        token: { type: 'string', description: 'GitHub Personal Access Token' },
        defaultOrg: { type: 'string', description: 'Default organization' },
        webhookUrl: { type: 'string', description: 'Webhook endpoint URL' }
      },
      required: ['token']
    },
    requiredCredentials: ['token']
  },
  
  {
    name: 'Slack Workspace',
    slug: 'slack-workspace',
    description: 'Enable your agents to interact with Slack channels, send messages, manage channels, and respond to mentions. Perfect for team collaboration and automated notifications.',
    category: 'communication',
    provider: 'Slack Technologies',
    repositoryUrl: 'https://github.com/slackhq/slack-mcp',
    documentationUrl: 'https://api.slack.com/mcp',
    capabilities: ['messaging', 'channel_management', 'user_management', 'file_sharing', 'bot_interactions'],
    version: '1.5.2',
    rating: 4.6,
    installCount: 12380,
    isVerified: true,
    securityLevel: 'official',
    configSchema: {
      type: 'object',
      properties: {
        botToken: { type: 'string', description: 'Slack Bot User OAuth Token' },
        signingSecret: { type: 'string', description: 'Slack Signing Secret' },
        defaultChannel: { type: 'string', description: 'Default channel for messages' }
      },
      required: ['botToken', 'signingSecret']
    },
    requiredCredentials: ['botToken', 'signingSecret']
  },

  {
    name: 'PostgreSQL Database',
    slug: 'postgresql-database',
    description: 'Connect agents to PostgreSQL databases for data querying, analysis, and automated reporting. Supports complex queries, schema introspection, and data visualization.',
    category: 'data',
    provider: 'PostgreSQL Community',
    repositoryUrl: 'https://github.com/postgres/postgres-mcp',
    documentationUrl: 'https://postgresql.org/docs/mcp',
    capabilities: ['sql_queries', 'schema_introspection', 'data_export', 'automated_reporting', 'connection_pooling'],
    version: '3.0.1',
    rating: 4.7,
    installCount: 8920,
    isVerified: true,
    securityLevel: 'verified',
    configSchema: {
      type: 'object',
      properties: {
        connectionString: { type: 'string', description: 'PostgreSQL connection string' },
        maxConnections: { type: 'number', default: 10 },
        queryTimeout: { type: 'number', default: 30000 }
      },
      required: ['connectionString']
    },
    requiredCredentials: ['connectionString']
  },

  {
    name: 'OpenAI GPT Integration',
    slug: 'openai-gpt-integration',
    description: 'Advanced integration with OpenAI APIs including GPT models, DALL-E, and Whisper. Enables agents to generate text, images, and process audio with state-of-the-art AI.',
    category: 'ai',
    provider: 'OpenAI',
    repositoryUrl: 'https://github.com/openai/openai-mcp',
    documentationUrl: 'https://platform.openai.com/docs/mcp',
    capabilities: ['text_generation', 'image_generation', 'audio_transcription', 'embeddings', 'fine_tuning'],
    version: '4.2.0',
    rating: 4.9,
    installCount: 24680,
    isVerified: true,
    securityLevel: 'official',
    configSchema: {
      type: 'object',
      properties: {
        apiKey: { type: 'string', description: 'OpenAI API Key' },
        organization: { type: 'string', description: 'OpenAI Organization ID' },
        defaultModel: { type: 'string', default: 'gpt-4' }
      },
      required: ['apiKey']
    },
    requiredCredentials: ['apiKey']
  },

  {
    name: 'Google Drive Files',
    slug: 'google-drive-files',
    description: 'Access and manage Google Drive files, folders, and permissions. Perfect for document analysis, automated file organization, and collaborative workflows.',
    category: 'productivity',
    provider: 'Google LLC',
    repositoryUrl: 'https://github.com/google/drive-mcp',
    documentationUrl: 'https://developers.google.com/drive/mcp',
    capabilities: ['file_access', 'folder_management', 'permission_control', 'document_analysis', 'sharing'],
    version: '2.3.1',
    rating: 4.4,
    installCount: 11250,
    isVerified: true,
    securityLevel: 'official',
    configSchema: {
      type: 'object',
      properties: {
        credentials: { type: 'string', description: 'Google Service Account JSON' },
        sharedDriveId: { type: 'string', description: 'Shared Drive ID (optional)' }
      },
      required: ['credentials']
    },
    requiredCredentials: ['credentials']
  },

  {
    name: 'Web Scraping Toolkit',
    slug: 'web-scraping-toolkit',
    description: 'Powerful web scraping capabilities with JavaScript rendering, proxy support, and anti-detection features. Extract data from any website efficiently and reliably.',
    category: 'data',
    provider: 'ScrapingBee',
    repositoryUrl: 'https://github.com/scrapingbee/web-scraping-mcp',
    documentationUrl: 'https://scrapingbee.com/docs/mcp',
    capabilities: ['web_scraping', 'js_rendering', 'proxy_rotation', 'captcha_solving', 'data_extraction'],
    version: '1.8.0',
    rating: 4.3,
    installCount: 7890,
    isVerified: true,
    securityLevel: 'verified',
    configSchema: {
      type: 'object',
      properties: {
        apiKey: { type: 'string', description: 'ScrapingBee API Key' },
        renderJs: { type: 'boolean', default: true },
        proxyCountry: { type: 'string', description: 'Proxy country code' }
      },
      required: ['apiKey']
    },
    requiredCredentials: ['apiKey']
  },

  {
    name: 'Email Automation',
    slug: 'email-automation',
    description: 'Send, receive, and manage emails through various providers. Supports templates, bulk sending, tracking, and intelligent email classification and routing.',
    category: 'communication',
    provider: 'Mailgun Inc.',
    repositoryUrl: 'https://github.com/mailgun/email-mcp',
    documentationUrl: 'https://documentation.mailgun.com/mcp',
    capabilities: ['email_sending', 'template_management', 'bulk_operations', 'tracking', 'webhook_handling'],
    version: '1.6.3',
    rating: 4.2,
    installCount: 5670,
    isVerified: true,
    securityLevel: 'verified',
    configSchema: {
      type: 'object',
      properties: {
        apiKey: { type: 'string', description: 'Mailgun API Key' },
        domain: { type: 'string', description: 'Mailgun Domain' },
        fromEmail: { type: 'string', description: 'Default sender email' }
      },
      required: ['apiKey', 'domain']
    },
    requiredCredentials: ['apiKey']
  },

  {
    name: 'Calendar Integration',
    slug: 'calendar-integration',
    description: 'Universal calendar integration supporting Google Calendar, Outlook, and CalDAV. Schedule meetings, manage events, and automate calendar-based workflows.',
    category: 'productivity',
    provider: 'CalendarAPI Co.',
    repositoryUrl: 'https://github.com/calendarapi/calendar-mcp',
    documentationUrl: 'https://calendarapi.com/docs/mcp',
    capabilities: ['event_management', 'meeting_scheduling', 'calendar_sync', 'availability_checking', 'reminders'],
    version: '2.0.4',
    rating: 4.5,
    installCount: 9340,
    isVerified: true,
    securityLevel: 'verified',
    configSchema: {
      type: 'object',
      properties: {
        provider: { type: 'string', enum: ['google', 'outlook', 'caldav'] },
        credentials: { type: 'string', description: 'Provider-specific credentials' },
        defaultCalendar: { type: 'string', description: 'Default calendar ID' }
      },
      required: ['provider', 'credentials']
    },
    requiredCredentials: ['credentials']
  },

  {
    name: 'Financial Data API',
    slug: 'financial-data-api',
    description: 'Access real-time and historical financial data including stock prices, forex rates, cryptocurrency data, and economic indicators from major financial exchanges.',
    category: 'data',
    provider: 'Alpha Vantage',
    repositoryUrl: 'https://github.com/alphavantage/financial-mcp',
    documentationUrl: 'https://alphavantage.co/documentation/mcp',
    capabilities: ['stock_data', 'forex_rates', 'crypto_data', 'economic_indicators', 'technical_analysis'],
    version: '1.9.2',
    rating: 4.1,
    installCount: 4520,
    isVerified: true,
    securityLevel: 'verified',
    configSchema: {
      type: 'object',
      properties: {
        apiKey: { type: 'string', description: 'Alpha Vantage API Key' },
        updateFrequency: { type: 'string', enum: ['realtime', 'daily'], default: 'daily' }
      },
      required: ['apiKey']
    },
    requiredCredentials: ['apiKey']
  },

  {
    name: 'Code Executor',
    slug: 'code-executor',
    description: 'Safely execute code in sandboxed environments. Supports Python, JavaScript, TypeScript, and shell scripts with configurable security policies and resource limits.',
    category: 'development',
    provider: 'CodeRunner Labs',
    repositoryUrl: 'https://github.com/coderunner/executor-mcp',
    documentationUrl: 'https://coderunner.dev/docs/mcp',
    capabilities: ['code_execution', 'sandbox_isolation', 'multi_language', 'resource_limits', 'security_policies'],
    version: '1.4.0',
    rating: 4.6,
    installCount: 6780,
    isVerified: true,
    securityLevel: 'verified',
    configSchema: {
      type: 'object',
      properties: {
        maxExecutionTime: { type: 'number', default: 30 },
        maxMemoryMB: { type: 'number', default: 512 },
        allowedLanguages: { type: 'array', items: { type: 'string' } }
      }
    },
    requiredCredentials: []
  }
]

const sampleKnowledge = [
  {
    title: 'Getting Started with GitHub MCP',
    content: `The GitHub MCP allows your agents to interact with GitHub repositories seamlessly. 

To get started:
1. Create a Personal Access Token in GitHub Settings > Developer settings > Personal access tokens
2. Grant the necessary scopes: repo, user, admin:org (depending on your needs)
3. Configure the MCP with your token

Common use cases:
- Automated code review and analysis
- Issue tracking and management
- Repository maintenance and cleanup
- Pull request automation
- Webhook-based integrations

Best practices:
- Use fine-grained tokens for specific repositories when possible
- Regularly rotate your access tokens
- Monitor API rate limits to avoid throttling
- Set up webhook endpoints for real-time updates`,
    section: 'installation',
    contentType: 'documentation' as const,
    tags: ['github', 'git', 'version-control', 'automation'],
    isOfficial: true
  },
  
  {
    title: 'PostgreSQL Connection Troubleshooting',
    content: `Common issues when connecting to PostgreSQL and their solutions:

Connection refused:
- Check that PostgreSQL is running on the specified host and port
- Verify firewall settings allow connections
- Ensure pg_hba.conf allows connections from your client IP

Authentication failed:
- Double-check username and password
- Verify the database exists
- Check pg_hba.conf authentication method

SSL connection issues:
- Add sslmode=require to connection string for encrypted connections
- For development, you can use sslmode=disable (not recommended for production)

Performance optimization:
- Set appropriate connection pool size based on your workload
- Use prepared statements for repeated queries
- Monitor connection usage and adjust timeout settings`,
    section: 'troubleshooting',
    contentType: 'troubleshooting' as const,
    tags: ['postgresql', 'database', 'connection', 'ssl', 'authentication'],
    isOfficial: true
  },
  
  {
    title: 'Web Scraping Best Practices',
    content: `Effective web scraping with the Web Scraping Toolkit MCP:

Rate limiting:
- Always respect robots.txt and website terms of service
- Implement delays between requests (1-2 seconds minimum)
- Use proxy rotation to distribute load

JavaScript rendering:
- Enable renderJs for single-page applications (SPAs)
- Wait for dynamic content to load before extracting
- Use CSS selectors that target stable elements

Anti-detection:
- Rotate user agents and headers
- Use residential proxies when possible
- Mimic human browsing patterns

Data quality:
- Implement data validation and cleaning
- Handle missing or malformed data gracefully
- Store raw HTML for debugging and re-processing`,
    section: 'usage',
    contentType: 'tutorial' as const,
    tags: ['web-scraping', 'javascript', 'proxy', 'data-extraction'],
    isOfficial: false
  }
]

async function seedMCPData() {
  console.log('🌱 Seeding MCP marketplace data...')

  try {
    // Clear existing data
    await prisma.mcpKnowledgeBase.deleteMany()
    await prisma.mcpInstallation.deleteMany()
    await prisma.mcpRegistry.deleteMany()
    
    console.log('🧹 Cleared existing MCP data')

    // Create MCP registry entries
    for (const mcpData of sampleMCPs) {
      const mcp = await prisma.mcpRegistry.create({
        data: {
          name: mcpData.name,
          slug: mcpData.slug,
          description: mcpData.description,
          category: mcpData.category,
          provider: mcpData.provider,
          repositoryUrl: mcpData.repositoryUrl,
          documentationUrl: mcpData.documentationUrl,
          capabilities: mcpData.capabilities,
          version: mcpData.version,
          rating: mcpData.rating,
          installCount: mcpData.installCount,
          isVerified: mcpData.isVerified,
          securityLevel: mcpData.securityLevel,
          configSchema: mcpData.configSchema,
          requiredCredentials: mcpData.requiredCredentials
        }
      })
      
      console.log(`📦 Created MCP: ${mcp.name}`)
      
      // Add knowledge base entries for this MCP
      const mcpKnowledge = sampleKnowledge.find(k => 
        k.tags.some(tag => mcpData.capabilities.includes(tag) || mcpData.name.toLowerCase().includes(tag))
      )
      
      if (mcpKnowledge) {
        try {
          await ragService.addKnowledge({
            mcpRegistryId: mcp.id,
            title: mcpKnowledge.title,
            content: mcpKnowledge.content,
            section: mcpKnowledge.section,
            contentType: mcpKnowledge.contentType,
            tags: mcpKnowledge.tags,
            isOfficial: mcpKnowledge.isOfficial
          })
          
          console.log(`  📚 Added knowledge: ${mcpKnowledge.title}`)
        } catch (error) {
          console.warn(`  ⚠️  Failed to add knowledge for ${mcp.name}:`, error)
        }
      }
    }

    // Create some additional general knowledge entries
    const generalKnowledge = [
      {
        title: 'MCP Security Best Practices',
        content: `Security considerations when using MCPs:

1. Credential Management:
   - Never store credentials in plain text
   - Use environment variables or secure key management
   - Rotate credentials regularly
   - Use least-privilege access principles

2. Network Security:
   - Use HTTPS/TLS for all communications
   - Validate SSL certificates
   - Consider VPN or private networks for sensitive data

3. Data Privacy:
   - Understand what data each MCP accesses
   - Implement data retention policies
   - Ensure compliance with regulations (GDPR, CCPA)
   - Use encryption for sensitive data at rest

4. Access Control:
   - Implement role-based access control (RBAC)
   - Audit MCP usage regularly
   - Monitor for unusual activity patterns
   - Set up alerting for security events`,
        section: 'security',
        contentType: 'documentation' as const,
        tags: ['security', 'credentials', 'privacy', 'compliance'],
        isOfficial: true
      },
      
      {
        title: 'Choosing the Right MCP for Your Use Case',
        content: `Guide to selecting appropriate MCPs:

For Data Analysis:
- PostgreSQL/MySQL MCPs for structured data
- Web Scraping Toolkit for unstructured web data
- Financial Data API for market analysis
- Consider data volume and processing requirements

For Communication:
- Slack for internal team communication
- Email Automation for external communications
- Calendar Integration for scheduling
- Match communication patterns to MCP capabilities

For Development:
- GitHub Integration for code management
- Code Executor for dynamic code execution
- CI/CD MCPs for deployment automation
- Consider security implications of code access

For AI Enhancement:
- OpenAI GPT for text generation
- Image processing MCPs for visual analysis
- Speech-to-text for audio processing
- Balance cost with capability requirements`,
        section: 'overview',
        contentType: 'tutorial' as const,
        tags: ['selection', 'use-cases', 'best-practices', 'comparison'],
        isOfficial: true
      }
    ]

    // Add general knowledge entries (not tied to specific MCPs)
    for (const knowledge of generalKnowledge) {
      try {
        // Create a general knowledge entry without linking to specific MCP
        await prisma.mcpKnowledgeBase.create({
          data: {
            title: knowledge.title,
            content: knowledge.content,
            section: knowledge.section,
            contentType: knowledge.contentType,
            tags: knowledge.tags,
            isOfficial: knowledge.isOfficial
          }
        })
        
        console.log(`📚 Added general knowledge: ${knowledge.title}`)
      } catch (error) {
        console.warn(`⚠️  Failed to add general knowledge:`, error)
      }
    }

    console.log('✅ MCP marketplace seeding completed successfully!')
    console.log(`📊 Created ${sampleMCPs.length} MCPs and knowledge entries`)

  } catch (error) {
    console.error('❌ Error seeding MCP data:', error)
    throw error
  }
}

// Run the seeding
if (require.main === module) {
  seedMCPData()
    .then(() => {
      console.log('🎉 Seeding completed!')
      process.exit(0)
    })
    .catch((error) => {
      console.error('💥 Seeding failed:', error)
      process.exit(1)
    })
    .finally(() => {
      prisma.$disconnect()
    })
}

export { seedMCPData }
