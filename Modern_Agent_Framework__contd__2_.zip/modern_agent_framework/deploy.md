
# 🚀 Modern Agent Framework - GitHub & Railway Deployment Guide

## 📋 Pre-Deployment Checklist

✅ **Build System**: Using railpack.json (no conflicting configs)  
✅ **Health Endpoint**: Added at `/api/health`  
✅ **Port Binding**: Next.js handles PORT environment variable automatically  
✅ **Build Validation**: Successfully builds with `yarn build`  
✅ **All Runtime Errors**: Fixed and resolved  

---

## 🐙 Step 1: Push to GitHub

### 1.1 Create GitHub Repository
1. Go to [GitHub.com](https://github.com) and click "New Repository"
2. Name: `modern-agent-framework`
3. Set to Public or Private (your choice)
4. **Do NOT** initialize with README (we have existing code)
5. Click "Create Repository"

### 1.2 Push Code
```bash
cd /home/ubuntu/modern_agent_framework

# Add GitHub remote (replace YOUR_USERNAME with your actual GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/modern-agent-framework.git

# Push code to GitHub
git branch -M main
git push -u origin main
```

---

## 🚂 Step 2: Deploy to Railway

### 2.1 Railway Setup
1. Go to [Railway.app](https://railway.app)
2. Sign up/Login with GitHub
3. Click "New Project"
4. Select "Deploy from GitHub repo"
5. Choose your `modern-agent-framework` repository

### 2.2 Configure Environment Variables
Railway will automatically detect the railpack.json. Now set these environment variables:

#### Required Variables:
```bash
NODE_ENV=production
NEXTAUTH_SECRET=your-secure-random-string-here
DATABASE_URL=your-database-connection-string
ABACUSAI_API_KEY=your-abacus-api-key
```

#### Automatic Railway Variables:
```bash
# These are automatically set by Railway - DO NOT SET MANUALLY
PORT=auto-assigned-by-railway
RAILWAY_PUBLIC_DOMAIN=auto-generated-by-railway
RAILWAY_PRIVATE_DOMAIN=auto-generated-by-railway
```

#### NextAuth Configuration:
```bash
# This will be automatically populated once deployed
NEXTAUTH_URL=https://${{RAILWAY_PUBLIC_DOMAIN}}
```

### 2.3 Optional Variables (if needed):
```bash
# OAuth Providers
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
GITHUB_ID=your-github-client-id
GITHUB_SECRET=your-github-client-secret

# AWS S3 (for file uploads)
AWS_BUCKET_NAME=your-s3-bucket-name
AWS_FOLDER_PREFIX=uploads/
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
AWS_REGION=us-east-1

# Email Configuration
EMAIL_FROM=noreply@yourdomain.com
EMAIL_SERVER_HOST=smtp.yourdomain.com
EMAIL_SERVER_PORT=587
EMAIL_SERVER_USER=your-email-user
EMAIL_SERVER_PASSWORD=your-email-password
```

---

## 🔧 Step 3: Deployment Process

### 3.1 Automatic Deployment
Railway will automatically:
1. ✅ Detect railpack.json configuration
2. ✅ Run `cd app && yarn install --frozen-lockfile`
3. ✅ Run `cd app && yarn build`  
4. ✅ Start with `cd app && yarn start`
5. ✅ Health check at `/api/health`

### 3.2 Monitor Deployment
1. Watch the deployment logs in Railway dashboard
2. Check for successful health checks
3. Test the deployed application

---

## 🚨 Common Issues & Solutions

### Issue: Build Fails
**Solution**: Ensure no competing build configs (Dockerfile, railway.toml, nixpacks.toml)
```bash
# If you have these files, remove them
rm Dockerfile railway.toml nixpacks.toml
git add . && git commit -m "Remove competing build configs" && git push
```

### Issue: Health Check Fails
**Solution**: Verify health endpoint responds correctly
```bash
# Test locally first
curl http://localhost:3000/api/health
# Should return: {"status":"healthy","timestamp":"...","uptime":123.45,"environment":"development"}
```

### Issue: Application Won't Start
**Solution**: Check PORT environment variable usage
- ✅ Next.js automatically uses `process.env.PORT`
- ✅ Our startCommand: `cd app && yarn start`
- ❌ Never hardcode ports or bind to localhost

### Issue: Environment Variables Not Working
**Solution**: Double-check variable names and Railway References
```bash
# ✅ Correct
NEXTAUTH_URL=https://${{RAILWAY_PUBLIC_DOMAIN}}

# ❌ Wrong
NEXTAUTH_URL=https://${{SERVICE_NAME.PORT}}  # Can't reference PORT
```

---

## ✅ Post-Deployment Verification

1. **Health Check**: Visit `https://your-app.railway.app/api/health`
2. **Homepage**: Visit `https://your-app.railway.app/`
3. **Authentication**: Test login at `https://your-app.railway.app/auth/signin`
4. **Chat Interface**: Test chat at `https://your-app.railway.app/chat/intelligent`

---

## 🔄 Future Deployments

Railway will automatically redeploy when you push to GitHub:
```bash
# Make changes
git add .
git commit -m "Your changes"
git push origin main
# Railway will automatically rebuild and deploy
```

---

## 📞 Need Help?

- **Railway Docs**: [docs.railway.app](https://docs.railway.app)
- **GitHub Issues**: Create issues in your repository
- **Check Logs**: Railway dashboard → Your Service → Logs tab

---

**🎉 Your Modern Agent Framework is ready for production deployment!**
