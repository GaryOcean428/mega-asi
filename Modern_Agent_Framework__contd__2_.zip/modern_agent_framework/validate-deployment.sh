
#!/bin/bash

echo "🔍 Modern Agent Framework - Pre-Deployment Validation"
echo "=================================================="

# Check for competing build configs
echo "1. Checking for competing build configurations..."
COMPETING_FILES=$(find . -maxdepth 1 -name "Dockerfile" -o -name "railway.toml" -o -name "nixpacks.toml" 2>/dev/null)
if [ -n "$COMPETING_FILES" ]; then
    echo "❌ Found competing build configs that may conflict with railpack.json:"
    echo "$COMPETING_FILES"
    echo "Consider removing these files to avoid build conflicts"
else
    echo "✅ No competing build configurations found"
fi

# Validate railpack.json
echo -e "\n2. Validating railpack.json syntax..."
if [ -f "railpack.json" ]; then
    if command -v jq >/dev/null 2>&1; then
        if jq '.' railpack.json >/dev/null 2>&1; then
            echo "✅ railpack.json syntax is valid"
        else
            echo "❌ railpack.json has invalid JSON syntax"
            exit 1
        fi
    else
        echo "⚠️  jq not found, skipping JSON validation"
    fi
else
    echo "❌ railpack.json not found"
    exit 1
fi

# Check health endpoint
echo -e "\n3. Checking health endpoint..."
if [ -f "app/app/api/health/route.ts" ]; then
    echo "✅ Health endpoint exists at /app/app/api/health/route.ts"
else
    echo "❌ Health endpoint not found"
fi

# Verify package.json scripts
echo -e "\n4. Checking package.json scripts..."
if [ -f "app/package.json" ]; then
    if grep -q '"start"' app/package.json; then
        echo "✅ Start script found in package.json"
    else
        echo "❌ Start script missing in package.json"
    fi
    if grep -q '"build"' app/package.json; then
        echo "✅ Build script found in package.json"
    else
        echo "❌ Build script missing in package.json"
    fi
else
    echo "❌ app/package.json not found"
fi

# Check environment variables template
echo -e "\n5. Checking environment configuration..."
if [ -f ".railway.env" ]; then
    echo "✅ Railway environment template exists (.railway.env)"
    echo "📝 Make sure to set these variables in Railway dashboard"
else
    echo "⚠️  No Railway environment template found"
fi

# Test build
echo -e "\n6. Testing build process..."
cd app
if yarn build >/dev/null 2>&1; then
    echo "✅ Build process successful"
else
    echo "❌ Build process failed"
    echo "Run 'cd app && yarn build' to see detailed errors"
    exit 1
fi
cd ..

# Check git status
echo -e "\n7. Checking git status..."
if [ -d ".git" ]; then
    if [ -z "$(git status --porcelain)" ]; then
        echo "✅ Working directory is clean"
    else
        echo "⚠️  Uncommitted changes detected:"
        git status --short
        echo "Consider committing changes before deployment"
    fi
else
    echo "❌ Not a git repository"
    exit 1
fi

echo -e "\n🎉 Pre-deployment validation complete!"
echo "Next steps:"
echo "1. Push to GitHub: git remote add origin <your-repo-url> && git push -u origin main"
echo "2. Deploy on Railway: Connect your GitHub repo at railway.app"
echo "3. Set environment variables as listed in .railway.env"
